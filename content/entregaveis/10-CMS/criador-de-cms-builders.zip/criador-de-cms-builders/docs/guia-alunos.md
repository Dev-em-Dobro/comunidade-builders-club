# Guia do aluno — Criador de CMS (Builders Club)

Tutorial passo a passo para quem nunca rodou um projeto assim. Leia com calma.
No final você tem um painel CMS rodando no PC e sabe como criar um para cada cliente.

## Resposta rápida: um repo ou pasta por cliente?

**Pasta por cliente, no mesmo fork.**

```
clients/
  padaria-da-rua/     ← CMS do cliente 1
  clinica-sorriso/    ← CMS do cliente 2
configs/
  padaria-da-rua.config.ts
  clinica-sorriso.config.ts
```

É o mesmo modelo da Dev em Dobro: vários CMS dentro do monorepo; na Vercel você
cria **um projeto por cliente** apontando o Root Directory para
`clients/<slug>/`. Depois, se quiser, copia aquele cliente para um repo só dele.

Não precisa (e não deve) colocar todos os clientes da turma no mesmo GitHub
público. Cada aluno usa o **próprio fork** (de preferência privado).

---

## O que é isto

Não é o site do cliente. É a **fábrica** que gera o **painel** onde o cliente
edita textos, posts, fotos etc. O site público continua separado e lê o CMS
pela API.

Fluxo:

1. Você descreve o cliente num arquivo (`configs/…config.ts`)
2. A fábrica gera a pasta `clients/<slug>/`
3. Você liga num banco (Supabase free) e sobe o admin

---

## Contas que você precisa (grátis no começo)

| Conta | Para quê | Obrigatório? |
|-------|----------|--------------|
| GitHub | Fork e código | Sim |
| Node.js 18+ e pnpm | Rodar no PC | Sim |
| Supabase | Banco + login do admin | Sim (plano free) |
| Vercel | Publicar o CMS | Depois, pra entregar |
| Resend / Bunny | E-mail e mídia | Opcional no 1º teste |

---

## Parte 1 — Preparar o PC

1. Instale o [Node.js LTS](https://nodejs.org/) (18 ou mais novo).
2. No terminal:

```bash
npm i -g pnpm
node -v
pnpm -v
```

Se os dois comandos mostrarem número de versão, está ok.

---

## Parte 2 — Pegar o repositório

1. Abra https://github.com/Dev-em-Dobro/criador-de-cms-builders
2. Clique em **Fork** (copie para a sua conta).
3. No seu fork, clique em **Code** → copie a URL HTTPS.
4. No terminal:

```bash
git clone https://github.com/SEU-USUARIO/criador-de-cms-builders.git
cd criador-de-cms-builders
pnpm install
```

A primeira instalação demora. Espere terminar sem erro vermelho.

---

## Parte 3 — Criar o config do seu primeiro cliente

```bash
cp templates/config-examples/demo-corp.config.ts configs/meu-cliente.config.ts
```

Abra `configs/meu-cliente.config.ts` e mude pelo menos:

- `slug` → só letras minúsculas, números e hífen (ex.: `padaria-da-rua`)
- `displayName` → nome bonito do cliente
- cores em `branding.colors` (opcional no primeiro teste)

Salve e valide:

```bash
pnpm cms-factory validate --config configs/meu-cliente.config.ts
```

Se aparecer erro, leia a mensagem: costuma ser typo no slug ou campo inválido.

---

## Parte 4 — Gerar o CMS (só no seu PC)

```bash
pnpm cms-factory create-client --config configs/meu-cliente.config.ts --skip-provision
```

`--skip-provision` = **não** cria nada na nuvem ainda. Só gera a pasta
`clients/meu-cliente/` (ou o slug que você escolheu).

Confira se a pasta existe:

```bash
ls clients
```

---

## Parte 5 — Criar o projeto no Supabase

1. Entre em https://supabase.com e crie um projeto novo (região perto de você).
2. Em **Project Settings → API**, copie:
   - Project URL
   - `anon` / publishable key
   - `service_role` key (secreta — nunca cole em site público)
3. Em **Project Settings → Database**, copie a connection string:
   - **URI** do pooler (porta 6543) → vira `DATABASE_URL`
   - **URI** direta (porta 5432) → vira `DIRECT_URL`

---

## Parte 6 — Preencher o `.env.local`

Dentro de `clients/<seu-slug>/`:

```bash
cp .env.example .env.local
```

(Se `.env.example` ainda não existir no seu clone, use o modelo em
`templates/client-app/.env.example`.)

Preencha as variáveis (veja comentários no arquivo). **Nunca** faça commit de
`.env.local`.

---

## Parte 7 — Banco, admin e primeiro login

Troque `meu-cliente` pelo seu slug:

```bash
pnpm --filter meu-cliente run db:migrate
pnpm --filter meu-cliente run seed:locales
pnpm --filter meu-cliente run seed:admin -- voce@email.com 'SenhaForte123!'
pnpm --filter meu-cliente run dev
```

Abra http://localhost:3010 — deve pedir login. Use o e-mail/senha do
`seed:admin`. Na primeira vez o fluxo pede MFA (autenticador no celular).

Crie um post de teste no admin. Se salvou, o CMS está vivo.

---

## Parte 8 — Segundo cliente

Repita Parte 3–7 com outro slug. Fica tudo no **mesmo** fork:

```
clients/padaria-da-rua/
clients/clinica-sorriso/
```

Cada um com banco Supabase **separado** (projeto novo no Supabase).

---

## Parte 9 — Publicar na Vercel (quando for entregar)

1. Importe o **seu fork** na Vercel.
2. Root Directory: `clients/<slug>`
3. Cole as mesmas variáveis do `.env.local` (valores de produção).
4. Deploy.

Um cliente = um projeto Vercel apontando para a pasta dele.

---

## Segurança (não pule)

- Não versione `.env.local` nem `.factory.env`
- Prefira fork **privado** se tiver dados reais do cliente
- Depois do `db:migrate`, o script `harden:db` fecha o banco — é obrigatório
- Tokens de “fábrica” (`.factory.env`) criam/apagam projetos: só use quando
  já souber o fluxo manual

---

## Se der erro

| Sintoma | O que checar |
|---------|----------------|
| `pnpm: command not found` | Instalar pnpm de novo |
| validate falhou | Ler a mensagem; slug/coleções |
| migrate falhou | `DATABASE_URL` / `DIRECT_URL` e IP liberado no Supabase |
| admin no idioma errado | Rodou `seed:locales`? |
| login não entra | E-mail/senha do `seed:admin`; MFA |
| porta ocupada | Outro `dev` aberto; mate o processo ou mude a porta |

---

## Onde aprofundar

- README principal do repo (visão geral e segurança)
- `docs/architecture/` (por quê de cada decisão) — opcional no início
- Material no Builders Club: **Materiais → Modelo de CMS**
