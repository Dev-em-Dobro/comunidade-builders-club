# Segurança das dependências — versões 1.0.1 e 1.0.3

Na versão 1.0.3, a auditoria de 26/10/2026 encontrou [GHSA-mrhx-c7xc-m3w5](https://github.com/advisories/GHSA-mrhx-c7xc-m3w5) no Zod 4.4.3. A versão corrigida indicada pelo aviso é 4.6.6; o template foi atualizado e fixado em **Zod 4.6.7**. O alerta afetava a disponibilidade do processo diante de coleções grandes inválidas. O empacotador bloqueou a versão antes da atualização; a instalação limpa, a suíte da aplicação, o build e a auditoria são repetidos nesta revisão.

Os oito alertas altos registrados na versão anterior correspondiam a duas vulnerabilidades, propagadas pelos seus consumidores na árvore de dependências. A correção substitui os componentes afetados; não ignora avisos, não reduz o nível da auditoria e não remove as regras de lint do Next.js.

## O que mudou

| Caminho anterior | Correção |
|---|---|
| `eslint-config-next → @next/eslint-plugin-next → fast-glob → micromatch → braces` | O único uso de `fast-glob` no plugin Next fixado em 16.4.2 passa pelo adaptador local `packages/next-glob-compat`, baseado em `tinyglobby` 0.2.17. `braces` e `micromatch` saíram da árvore. |
| `prisma → @prisma/config → deepmerge-ts` | Override restrito ao consumidor `@prisma/config`, usando `deepmerge-ts` 8.0.0, versão com correção para referências circulares. Prisma e cliente continuam em 6.19.3. |

Na data da revisão, o [aviso de braces](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) não oferecia versão corrigida. A substituição evita esse caminho sem fazer downgrade de Next ou desligar ESLint. O [tinyglobby](https://github.com/SuperchupuDev/tinyglobby) fornece a busca por padrões; o pequeno adaptador mantém as opções necessárias ao `globSync` usado pelo plugin: somente diretórios, sem expansão recursiva implícita e com caminhos absolutos para padrões absolutos.

O adaptador é específico para esse consumidor e sua versão fixada; não pretende implementar toda a API de fast-glob. O nome `fast-glob` em `devDependencies` aponta para o pacote **local**, e o override `$fast-glob` faz o plugin usar essa mesma implementação. `.npmrc` usa `install-links=true` para instalá-la como pacote comum. Mantenha `packages/`, `.npmrc`, package.json e lockfile juntos, inclusive no contexto de build Docker. Não substitua essa entrada por um `npm install fast-glob` sem revisar a correção.

O [aviso de deepmerge-ts](https://github.com/advisories/GHSA-ggr8-5vv4-36mx) indica 8.0.0 como versão corrigida. Essa versão também [altera a mesclagem de Maps e tipos](https://github.com/RebeccaStevens/deepmerge-ts/releases/tag/v8.0.0). O carregador Prisma utilizado aqui mescla objetos de configuração. Foram incluídos testes do carregador real, de configurações aninhadas e da referência circular que motivou a correção; geração do cliente, migrations e build também precisam passar a cada atualização.

## Reproduzir a verificação

Com Node 22.16+ da série 22 e Docker ativo, execute na raiz do template:

```sh
npm run deps
npm run audit
npm --prefix apps/web audit --omit=dev
npm run test:security
npm run test:template
npm run test:app
```

`deps` usa `npm ci --ignore-scripts`, respeita o lockfile e gera explicitamente o cliente Prisma. Os testes de segurança verificam a resolução instalada dos dois consumidores, a ausência das bibliotecas removidas, configurações Prisma comuns e circulares, padrões de diretórios do plugin Next e uma regra real de links do ESLint. O build Docker também faz uma instalação limpa pelo lockfile.

O comando `npm run package` exige auditoria completa e testes de segurança aprovados antes de empacotar. Não use `npm audit fix --force`, `--audit-level=critical` ou exclusão de desenvolvimento para transformar um relatório com vulnerabilidades em aprovação. A auditoria completa inclui as ferramentas de lint e testes, mesmo quando não participam de uma requisição HTTP.

## Próximas atualizações

Antes de distribuir outra versão, repita a auditoria e a validação. Ao atualizar o plugin Next ou Prisma, confira se os overrides ainda são necessários e se as APIs consumidas continuam compatíveis. Se os projetos upstream eliminarem os caminhos vulneráveis, prefira retirar os overrides e o adaptador após validar a nova árvore.

Auditoria sem alertas significa que o serviço consultado não identificou vulnerabilidades conhecidas naquela árvore naquele momento. Não cobre todas as possíveis falhas do código ou dos serviços externos. Os resultados executados e os limites da entrega estão em [VALIDACAO.md](VALIDACAO.md).
