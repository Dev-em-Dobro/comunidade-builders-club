# Teste de instalação do zero no Windows

Ensaio executado em 23/10/2026, seguindo a pauta até o início da etapa 8. O ZIP 1.0.1 foi baixado do Drive, conferido por SHA-256 e extraído em uma pasta nova na Área de Trabalho, com espaços no caminho. O aviso de formulário encontrado nesse ensaio foi corrigido na versão 1.0.2.

## Ambiente e resultados

- Windows, Node 22.23.2, npm 11.1.0, Docker Engine 27.3.1 e Compose 2.30.3; Docker Desktop iniciado antes dos comandos.
- `npm run setup` executado de forma interativa, com empresa e e-mail fictícios. Gerados configuração e segredos próprios, canais inicialmente desligados.
- `npm run deps` terminou com sucesso, zero vulnerabilidades reportadas e cliente Prisma gerado.
- `docker compose up -d --wait` criou volumes novos; PostgreSQL com pgvector e Redis ficaram saudáveis nas portas locais padrão.
- `npm run db:init` aplicou as 20 migrations ao banco vazio e criou um administrador, o agente genérico e duas regras de exemplo.
- `npm run doctor` aprovou configuração, PostgreSQL, pgvector, administrador e Redis.
- `npm run dev` iniciou o servidor e os 11 workers. Primeiro login no navegador abriu o dashboard sem leads e conversas.
- Formulário de troca de senha conferido no navegador. O endpoint autenticado foi exercitado por uma verificação HTTP local: nova senha funcionou e a anterior foi recusada. Valores de bootstrap removidos do `.env`.
- Marca, razão social, e-mails, acesso ao produto, mensagem de transferência e tempo de agrupamento foram personalizados. Valores conferidos após salvar e recarregar.
- `/privacy` e `/data-deletion` abriram com a identidade e o contato fictícios configurados.
- Cadastro de chave de IA exercitado com valor claramente fictício, sem chamada ao provedor. Conferido armazenamento cifrado; credencial fictícia removida ao terminar.
- Agente de exemplo editado pelo painel: nome, persona, prompt e provedor/modelo; agente padrão mantido.
- Curso fictício cadastrado em **Cursos → Novo curso**, com slug, descrição, políticas, checkout ilustrativo e preço de R$ 199,90. Banco confirmou 19.990 centavos.
- O banco do exercício permaneceu sem contatos, leads ou conversas. Canais continuaram desligados.

## O que o ensaio corrigiu

O formulário Geral passava novos `defaultValue` ao componente Base UI depois da atualização do layout. Isso gerava um aviso de componente não controlado no desenvolvimento. Os campos agora têm estado controlado. Dois salvamentos seguidos e recarregamento foram repetidos sem novos avisos; lint e TypeScript aprovados.

README e pauta receberam instruções explícitas sobre a raiz após extrair o ZIP, o terminal que precisa permanecer aberto, reinício após editar `.env`, avisos de atualização e o caminho **Cursos → Novo curso**. Também ficou explícito que salvar uma chave não comprova uma resposta real da IA.

## Limites

Não foram conectados ativos Meta, aberto túnel público, enviados atendimentos externos nem usados créditos de IA. A etapa 8 e a entrega real de mensagens ficam para uma instalação com as próprias contas e credenciais. As páginas legais continuam sendo modelos que exigem revisão do responsável pelo negócio.

A instalação foi feita em diretório e serviços próprios. Nenhum arquivo, banco, credencial ou container da instalação comercial foi alterado. Dados e credenciais do exercício não fazem parte do ZIP de distribuição.
