# Arquitetura e adaptação da infraestrutura

## Visão geral

```mermaid
flowchart LR
  M[WhatsApp e Instagram] -->|Webhook HTTPS com assinatura| A[Next.js: painel e API]
  U[Operador] --> A
  A --> P[(PostgreSQL + pgvector)]
  A --> R[(Redis)]
  R --> W[Workers BullMQ no processo do CRM]
  W --> P
  A --> L[API de IA escolhida pelo aluno]
  W --> L
  A -->|Graph API| M
```

Next.js executa interface, APIs e ações de servidor. Prisma representa o modelo de dados e aplica migrations no PostgreSQL. Redis atende o agrupamento de mensagens e as filas BullMQ. Os workers são inicializados pelo hook `src/instrumentation.ts` no processo Node do CRM quando `ENABLE_WORKER=true`.

## PostgreSQL: a memória permanente

O banco guarda usuários e hashes de senha, contatos e suas identidades por canal, conversas, mensagens, agentes e prompts, regras, catálogo, lançamentos, notificações, consumo e credenciais criptografadas.

**pgvector** é uma extensão do PostgreSQL que armazena vetores numéricos e permite buscar textos semanticamente próximos. O RAG divide documentos em trechos e usa embeddings Gemini com 768 dimensões. Mesmo com RAG desligado, o schema e as migrations atuais exigem pgvector. Não substitua a imagem por um PostgreSQL que não disponibilize a extensão.

O banco é a fonte permanente dos dados comerciais. Backups devem incluir o banco e a chave `SECRETS_KEY`, guardada separadamente: o dump contém as credenciais cifradas, mas a chave que as abre fica no ambiente.

## Redis: coordenação e trabalho em segundo plano

Redis mantém estruturas de dados rápidas em memória. Neste CRM ele tem duas funções diferentes.

### Agrupar mensagens: debounce

Uma pessoa escreve “oi”, “quero saber” e “sobre o produto” em três mensagens. Sem agrupamento, cada mensagem pode causar uma resposta e uma chamada separada ao modelo. O debounce espera uma pequena janela após a última mensagem e reúne os textos.

O padrão é **5 segundos** (`5000` ms). O código usa listas, expiração e um token de lock no Redis para coordenar o agrupamento. Há um limite de 20 mensagens por buffer.

Altere o tempo no painel Geral, entre 1 e 30 segundos. Ou edite:

```json
"cache": {
  "enabled": true,
  "provider": "redis",
  "debounce": {
    "enabled": true,
    "windowMs": 5000,
    "maxBufferedMessages": 20,
    "keyPrefix": "debounce"
  }
}
```

`keyPrefix` controla o namespace do debounce. Ele **não isola as filas BullMQ**, que têm nomes fixos. Dois negócios precisam de Redis separado (ou de um trabalho adicional de isolamento de todas as filas e chaves); não basta trocar esse prefixo.

### Filas BullMQ

As filas organizam notificações, qualificação, SLA, transferência de agentes, acompanhamento de janelas de mensagens, reengajamento, auditoria e transições de lançamentos. Elas permitem executar trabalho fora da resposta HTTP, agendar e tentar novamente certas operações.

Redis é parte da operação, não apenas um cache descartável. Apagar seus dados pode perder tarefas pendentes, agendamentos, estados temporários e mensagens ainda no debounce. O Compose habilita **AOF** e volume persistente, com política **noeviction**. Políticas que expulsam chaves para liberar memória podem quebrar a coordenação das filas.

O debounce atual usa um timer no processo Node e buffer temporário no Redis. Ele **não é uma fila durável completa de entrada**: reiniciar o processo durante a janela pode impedir o flush daquele buffer. A entrega externa também depende de regras, retries e indisponibilidades da Meta. Para operação mais exigente, evolua a entrada para um job durável com idempotência e outbox.

## Posso remover o Redis?

Para explorar o painel, é possível desligar os workers (`ENABLE_WORKER=false`) e o debounce (`cache.debounce.enabled=false`). Há fallback síncrono no caminho de debounce quando Redis não está configurado ou a operação inicial falha.

Isso **não transforma o restante da aplicação em uma versão sem Redis**. Há produtores de jobs em regras, SLA, handoff, auditoria e outras rotas. Para operar canais sem Redis seria necessário refatorar esses produtores e consumidores, definir comportamento para cada automação e rever o tempo de resposta dos webhooks. O template instala Redis para preservar a arquitetura funcional.

## Posso trocar o banco ou o provedor?

**Trocar onde hospeda:** use PostgreSQL com pgvector e Redis compatível, atualize `DATABASE_URL` e `REDIS_URL`, transfira os dados com backup/restauração e teste as funções. Não há dependência do Railway para rodar o código localmente.

**Trocar PostgreSQL por SQLite/MySQL:** não basta mudar a URL. Há extensões, vetores, arrays, índices, SQL e migrations específicos de PostgreSQL. Essa mudança exige uma migração de arquitetura e de dados.

**Trocar Redis por outro produto:** confira compatibilidade com a versão instalada do BullMQ, comandos, Lua, expirações, locks e persistência. Um serviço que anuncia “cache Redis” pode ter restrições que não servem para filas. Dê preferência a conexão TCP persistente; APIs HTTP não substituem a conexão ioredis automaticamente.

**Separar workers da web:** requer um entrypoint próprio que inicie os workers/agendadores. Não crie outro serviço idêntico ao Next.js esperando que ele vire worker. O template inicial roda ambos juntos, com uma réplica. Escalar horizontalmente exige revisar debounce, gravação da configuração em arquivo e concorrência das rotinas.

## Onde ficam as configurações

| Conteúdo | Local |
|---|---|
| Conexões, assinatura de sessão e chave de criptografia | `.env` local / variáveis do Railway |
| Marca, contato, canais, fuso e opções de comportamento | `setup.config.json` local / `/app/data/setup.config.json` no servidor |
| Prompts e regras de agentes | PostgreSQL |
| Tokens Meta cadastrados no painel | PostgreSQL, AES-256-GCM |
| Chaves de IA cadastradas no painel | PostgreSQL, AES-256-GCM |
| Filas, debounce e locks | Redis |

O painel não mostra a configuração JSON inteira, pois ela pode ter sido preenchida indevidamente com tokens. A configuração do arquivo é relida, permitindo aplicar marca e canais sem reiniciar. Mudanças em variáveis de ambiente exigem reinício; mudanças em jobs já agendados podem exigir revisar a fila.

Não guarde tokens no bloco `channels` do JSON. Use o painel Meta ou variáveis do servidor. Nunca use prefixo `NEXT_PUBLIC_` para um segredo.
