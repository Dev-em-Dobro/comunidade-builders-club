# Validação do template para alunos

Validação completa da versão 1.0.1 em 22/10/2026; ensaio de instalação local e correção de interface na versão 1.0.2 em 23/10/2026; revisão das instruções Meta e da subscription WhatsApp na versão 1.0.3 em 26/10/2026. A versão 1.0.4 acrescenta os prompts de instalação assistida. Este registro descreve o que foi testado e os limites da verificação.

## Revisão 1.0.4 — instalação assistida

O novo [guia de instalação assistida](INSTALACAO_ASSISTIDA.md) contém um prompt mestre, um prompt único para avançar pela pauta e um prompt específico para cada uma das 17 etapas. Os prompts distinguem execução de comandos locais das configurações Meta/Railway que dependem do titular e exigem evidência de mensagem real antes de marcar um canal como operacional. Nenhuma credencial preenchida foi adicionada ao pacote. Esta revisão altera documentação e versão de distribuição; os resultados de auditoria, testes de template e scanner são conferidos no empacotamento.

## Revisão 1.0.3 — configuração Meta

O guia Meta e a etapa 8 da pauta agora descrevem a sequência operacional: aplicativo/ativos, IDs e tokens, túnel HTTPS, callbacks, inscrição dos ativos e mensagem real. Há um caminho explícito para o aluno que configura a instalação de um cliente sem acesso inicial ao portfólio dele. O botão **Verificar subscription** do WhatsApp passou a usar a WABA ID, conforme a API da Meta; o Phone Number ID continua sendo usado para consultar o número e enviar mensagens. Dois testes de regressão cobrem a inscrição na WABA e a ausência desse ID. Nenhuma credencial Meta real foi usada.

Nesta revisão, a auditoria inicialmente detectou o novo aviso [GHSA-mrhx-c7xc-m3w5](https://github.com/advisories/GHSA-mrhx-c7xc-m3w5) no Zod 4.4.3 e bloqueou o ZIP. O Zod foi fixado em 4.6.7. Depois dessa atualização, a instalação limpa pelo lockfile encontrou **zero vulnerabilidades**; **837 testes da aplicação em 113 arquivos**, lint dos arquivos alterados, TypeScript e build de produção passaram. Os três testes do instalador/distribuição e o scanner também passaram. A auditoria e os testes de segurança são executados mais uma vez pelo empacotador.

## Revisão 1.0.2 — instalação como aluno

ZIP baixado do Drive e instalado em diretório novo na Área de Trabalho do Windows. Setup interativo, dependências, banco vazio, migrations, doctor, login, senha, configurações, páginas públicas, agente e catálogo foram exercitados até o início da etapa 8. Um aviso de estado de formulário foi corrigido e retestado no navegador, com lint e TypeScript aprovados. Veja [o relatório do ensaio](TESTE_INSTALACAO_LOCAL.md).

As dependências da aplicação não mudaram nesta revisão. A suíte completa de 835 testes abaixo pertence à validação 1.0.1; não foi repetida por essa alteração de formulário. Auditoria e testes de segurança/distribuição são exigidos novamente no empacotamento.

## Resultado

- Instalação de dependências pelo lockfile com scripts automáticos bloqueados; cliente Prisma gerado explicitamente.
- PostgreSQL com pgvector e Redis criados em serviços separados para a instalação local e para os testes.
- Vinte migrations aplicadas a banco vazio. Seed genérico executado e repetido sem sobrescrever o usuário nem duplicar o agente padrão.
- `doctor`: conexão com PostgreSQL, extensão vector, administrador e Redis confirmados.
- Suíte da aplicação: **835 testes aprovados, em 112 arquivos**.
- Instalador e distribuição: **3 testes aprovados**, incluindo segredos únicos, recusa de sobrescrita e exclusão de arquivos privados.
- Correções das dependências: **4 testes de regressão aprovados**, incluindo resolução após instalação limpa, carregador real Prisma, referências circulares, busca de diretórios e regra real do ESLint Next.
- Auditoria npm completa: **zero vulnerabilidades**. Auditoria `--omit=dev`: **zero vulnerabilidades**.
- TypeScript e lint dos novos módulos de configuração aprovados.
- Build local e imagem Docker de produção compilados. A imagem iniciou a aplicação e os onze workers; `/api/health` respondeu corretamente.
- Acesso ao painel, estado vazio do CRM, salvamento das configurações gerais e formulário Meta conferidos no navegador.
- Empacotamento por lista de arquivos permitidos, sem `.env`, configuração preenchida, dados de banco, backups de prompts, scripts operacionais ou histórico Git.
- Comparação privada dos arquivos distribuídos com credenciais e identificadores da instalação de origem, sem publicar esses valores.

## Dependências corrigidas nesta versão

O Next.js foi atualizado para 16.4.2 e as atualizações compatíveis de segurança foram aplicadas. A ferramenta de testes foi atualizada para Vitest 5.0.5; a suíte acima foi rodada nessa versão. O CLI de geração de componentes, desnecessário para rodar o template, foi removido da aplicação.

Os **8 alertas altos** da versão anterior foram eliminados. Eles correspondiam a duas vulnerabilidades e às entradas dos consumidores afetados:

| Caminho anterior | Correção | Verificação |
|---|---|---|
| `eslint-config-next → fast-glob → micromatch → braces` (5 entradas) | Adaptador local para o uso de glob do plugin Next, baseado em tinyglobby 0.2.17. As bibliotecas vulneráveis foram removidas. | Padrões de diretórios e regra Next testados com o plugin real; todas as regras continuam habilitadas. |
| `prisma → @prisma/config → deepmerge-ts` (3 entradas) | Override do consumidor para deepmerge-ts 8.0.0. | Configuração comum e circular, carregador Prisma, geração do cliente e migrations. |

Veja [Segurança das dependências](SEGURANCA_DEPENDENCIAS.md) para o escopo dos overrides, fontes e comandos. Nenhum alerta foi suprimido e não foi usado `npm audit fix --force`. A instalação pelo lockfile foi repetida com scripts automáticos bloqueados. O empacotamento agora exige auditoria completa e testes dessas correções antes de gerar o ZIP.

Responsável pela revisão: mantenedor do template. Reavaliar antes de cada nova distribuição: os dados de vulnerabilidades podem mudar após esta verificação. Zero alertas conhecidos não equivale a garantia de inexistência de falhas.

## Verificações externas que cada aluno precisa fazer

Nenhuma credencial real de Meta ou de IA foi incluída ou utilizada para enviar mensagens nesta validação. Testes locais usam exemplos e mocks. Cada instalação deve confirmar permissões, inscrição de webhooks, modo do aplicativo, validade de tokens, disponibilidade do modelo, custos e entrega real com seus próprios ativos.

O deploy na conta Railway do aluno não foi executado. O Dockerfile, pre-deploy e volume foram preparados e a imagem foi validada localmente; conexão privada, domínio e políticas de serviço devem ser conferidos na conta de destino.

As páginas legais são modelos. Não há garantia automática de conformidade, expurgo de backups ou atendimento de solicitações de exclusão. O responsável pelo negócio precisa definir e executar esses procedimentos.

O domínio do CRM ainda contém telas e heurísticas voltadas a cursos. A aplicação é uma instância por negócio, e não um SaaS com múltiplas empresas isoladas no mesmo banco. O debounce usa temporizador no processo; para exigências maiores de durabilidade e escala, veja ARQUITETURA.md.
