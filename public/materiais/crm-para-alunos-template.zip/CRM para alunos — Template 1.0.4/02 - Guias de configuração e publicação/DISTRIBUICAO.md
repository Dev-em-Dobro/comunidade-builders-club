# Gerar e distribuir uma cópia limpa

Use este procedimento para entregar o código aos alunos sem compartilhar sua instalação.

```sh
npm run deps
npm run test:template
npm run check:distribution
npm run package
```

Na versão 1.0.4, o arquivo gerado é `release/crm-alunos-template-1.0.4.zip`. A cópia `release/crm-alunos-template.zip` contém exatamente a mesma versão. Há um SHA-256 ao lado de cada ZIP e um `MANIFEST.sha256` dentro do pacote. O empacotador usa uma lista de caminhos permitidos e não precisa copiar a pasta inteira.

`npm run package` executa a auditoria completa, inclusive dependências de desenvolvimento, e os testes de regressão das correções de segurança antes de gerar o ZIP. Precisa das dependências instaladas e de acesso ao serviço de auditoria do npm. Falhas nessas verificações interrompem a geração. Não remova esses passos para contornar um alerta: investigue a dependência e repita a validação. Veja [Segurança das dependências](SEGURANCA_DEPENDENCIAS.md).

Ficam fora: `.git`, `.env` preenchidos, `setup.config.json` da instância, node_modules, build, relatórios locais, bancos, volumes, backups de prompts, scripts operacionais da instalação de origem e arquivos fora dos caminhos aprovados. Cada aluno roda o setup para gerar as próprias chaves e criar o próprio banco.

O scanner bloqueia alguns formatos conhecidos de segredo e referências específicas da origem. Ele **não é prova universal de ausência de informação confidencial**. Ao adicionar arquivos, revise também conteúdo, exemplos, URLs, metadados de imagens e fixtures. Não distribua dumps, transcrições ou prompts reais como exemplo.

Para adicionar uma pasta ao pacote, revise e altere `scripts/distribution.mjs` conscientemente. Uma pasta não entra só porque existe no seu checkout. Isso permite continuar usando sua própria instalação local sem colocá-la no ZIP por acidente.

## Publicar como template no GitHub

1. Crie um repositório novo para o template, na conta que você escolher.
2. Envie os arquivos de código e exemplos. Não reutilize o histórico Git da aplicação que atende seu negócio.
3. Confira o conteúdo no GitHub, especialmente exemplos e testes.
4. Nas configurações do repositório, habilite “Template repository”.
5. Informe o endereço aos alunos; eles usam “Use this template” para criar um repositório próprio.

Não há publicação nem alteração de conta remota implícita na geração do ZIP. A licença MIT do código original permanece no pacote, incluindo seu aviso de autoria.

## Verificações de uma versão

Antes de liberar uma atualização, execute instalação pelo lockfile, `npm audit` em `apps/web`, build, testes relevantes e uma instalação com banco vazio. Registre vulnerabilidades adiadas e limitações conhecidas em `VALIDACAO.md`, sem colocar credenciais nesse registro.

Teste callbacks com ativos Meta próprios em uma instalação de teste. Sem credenciais e permissões do novo proprietário não é possível certificar entrega real de WhatsApp/Instagram para aquela conta.
