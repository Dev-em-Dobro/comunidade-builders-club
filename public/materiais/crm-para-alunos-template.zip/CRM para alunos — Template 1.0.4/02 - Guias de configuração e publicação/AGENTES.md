# Adaptar agentes ao seu negócio

## Primeiro agente

Entre em Agentes e edite o agente criado pelo seed. Defina um nome interno, persona (nome mostrado ao cliente), provedor, modelo, prompt, memória e limite de resposta. Mantenha um único agente padrão.

A chave deve corresponder ao provedor selecionado. O campo modelo aceita o identificador que sua conta de API oferece. Verifique esse identificador na documentação do provedor; o sistema não garante que qualquer texto informado corresponda a um modelo disponível.

Comece com memória `window_20`, temperatura moderada e um limite de saída compatível com mensagens curtas. O painel de consumo estima custos com uma tabela interna que pode ficar desatualizada; a cobrança real é a do provedor.

## Prompt de partida

Troque os campos entre colchetes. Não coloque credenciais nem dados pessoais de clientes no prompt.

```text
Você é o assistente virtual de atendimento da [MARCA].
Ajude pessoas interessadas em [PRODUTO OU SERVIÇO].

Objetivo: entender a necessidade e orientar o próximo passo aprovado.
Tom: [acolhedor, direto, profissional]. Português do Brasil.
Use mensagens curtas e faça uma pergunta por vez.

Pergunte, quando ainda não souber:
- Qual problema a pessoa quer resolver?
- Qual resultado ela procura?
- Existe algum prazo importante?

Use apenas os preços, políticas, prazos e links do catálogo e da base fornecidos.
Se uma informação não estiver disponível, explique isso e encaminhe para uma pessoa.
Não invente descontos, garantias, disponibilidade, promessas ou políticas.
Se perguntarem se você é uma IA, explique seu papel com transparência.

Peça transferência quando a pessoa solicitar atendimento humano,
quando estiver frustrada ou quando o assunto exigir decisão de uma pessoa.
Não prometa que uma ação ocorreu se nenhuma ferramenta confirmou essa ação.
```

O contexto de catálogo e as diretrizes de contato/handoff são inseridos pelo sistema. Mantenha as informações comerciais atualizadas nas telas correspondentes, evitando repetir preços contraditórios em muitos lugares.

## Regras e transferência

No agente, abra Regras. O exemplo inclui pedido explícito de humano e palavras para pausar a IA. Teste as palavras com o jeito que seus clientes escrevem.

As conversas permitem assumir atendimento e responder manualmente. Coloque seu operador em plantão para as rotinas que dependem de atribuição. Confirme que uma transferência interrompe a resposta automática no cenário que você pretende usar.

Há suporte no domínio a papéis `sdr`, `closer` e `support`. O editor atual não expõe todos os campos de roteamento. Para mudar o papel, use uma ferramenta administrativa própria ou Prisma Studio, **apenas no seu banco**:

```sh
cd apps/web
node --env-file=../../.env node_modules/prisma/build/index.js studio
```

Abra `AgentSession`, ajuste `role` e revise o fluxo automático de transferência. O sistema procura o primeiro agente do papel de destino. Um agente que você chamar de “Closer” pelo nome não recebe esse papel automaticamente. O SDR genérico criado pelo seed pode atender sozinho; múltiplos agentes são opcionais.

## Catálogo e políticas

Cadastre seus cursos/produtos antes de ativar atendimento. Revise nome, descrição, preço, parcelamento, link de checkout, acesso, suporte, garantia e políticas de cancelamento. Nunca reaproveite valores comerciais do professor ou de outro aluno.

O CRM tem telas e heurísticas de cursos, lançamentos, aluno, suporte e reembolso. Para clínicas, imóveis, e-commerce ou outros mercados, revise `src/lib/scoring.ts`, `qualification.ts`, `asked-fields.ts`, `student-signals.ts` e os contextos em `src/lib/llm/`. Mudar só o prompt não substitui todas as regras de domínio.

## Qualificação e automações avançadas

O template começa com `qualification.enabled=false`, `followup.enabled=false`, `outOfWindowFollowup.enabled=false` e `auditor.enabled=false`.

- Qualificação estruturada: usa um modelo Anthropic separado por padrão. Ter apenas OpenAI no agente não configura o classificador Anthropic. Para ativar, forneça uma chave Anthropic e revise o modelo/configuração, ou adapte o classificador em código.
- Jev: integração experimental opcional com chave própria; desligada por padrão.
- Follow-up: ative depois de revisar regras, horários, consentimento e limites. Fora da janela permitida, WhatsApp depende de templates aprovados pela Meta.
- Auditor: faz chamadas adicionais de IA e possui limites internos; revise o provedor/modelo e custos antes de ativar.

Esses blocos ficam no `setup.config.json`. No Railway, edite o arquivo persistente no volume; se preferir preparar uma configuração inicial, use `SETUP_CONFIG_JSON` conforme o guia de hospedagem.

## Base de conhecimento (RAG)

1. Configure `GEMINI_API_KEY` no servidor; o gerador de embeddings desta base usa Gemini, independentemente do provedor de conversa.
2. Ative `tools.rag=true` no JSON da sua instância.
3. Abra o agente → Base de conhecimento e adicione seus textos ou PDFs.
4. Teste perguntas cuja resposta está no material e perguntas que o material não responde.
5. Ao trocar conteúdo, reindexe e confirme que a versão antiga deixou de ser recuperada.

Não envie informações confidenciais sem considerar que o conteúdo será processado pelos provedores envolvidos. Importação por URL busca conteúdo no servidor; restrinja o uso a administradores e fontes confiáveis. Para começar, prefira texto colado ou PDF próprio.

## Roteiro de teste antes de liberar

- Cumprimento e pergunta vaga.
- Pergunta sobre um produto cadastrado e sobre um inexistente.
- Preço, parcelamento, acesso e política de cancelamento.
- Pedido de falar com humano e mensagem de frustração.
- Três mensagens curtas seguidas para conferir o agrupamento.
- Mensagem fora da janela, mídia e chave de API sem saldo.
- Recebimento e resposta nos dois canais que você ativou.

Use contas de teste sob seu controle. Confira o histórico do CRM, a entrega no aplicativo e o consumo no provedor de IA.
