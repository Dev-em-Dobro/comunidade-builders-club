# Instalação assistida por IA — prompts para o aluno

Este roteiro acompanha o [README](../README.md) e a [pauta completa](http://PAUTA_CONFIGURACAO_PUBLICACAO.md). Ele funciona melhor com um agente de código que tenha acesso **à pasta extraída do template e ao terminal**. Um chat sem essas ferramentas pode explicar e conferir suas respostas, mas não consegue instalar nem testar o projeto por você.

Abra a pasta `crm-alunos-template` no agente. Ela deve conter `README.md`, `package.json`, `apps` e `scripts`. Cole o **prompt mestre** uma vez e depois o prompt da etapa em que você está. Você pode usar os prompts 1 a 7 para instalar e configurar o painel, o 8 para conectar a Meta e os 9 a 17 para publicar. Se mudar de conversa, cole novamente o prompt mestre e informe o último checkpoint concluído.

O agente pode executar comandos e verificar arquivos locais. **Você precisa entrar com suas contas, conceder permissões e cadastrar segredos nas telas dos serviços externos.** Não cole no chat senhas, App Secret, tokens Meta, chave de IA, `AUTH_SECRET`, `SECRETS_KEY`, `.env` completo ou capturas que os mostrem. IDs públicos e mensagens de erro sem tokens podem ser informados. O agente deve conferir o resultado de cada etapa; uma mensagem “salvo” ou “connected” não substitui um teste de envio e recebimento.

## Prompt mestre — cole primeiro

```
Você é meu guia técnico para instalar e publicar este CRM a partir da pasta do template que abri como workspace. Leia README.md, docs/PAUTA_CONFIGURACAO_PUBLICACAO.md, docs/META.md, docs/RAILWAY.md e docs/PROBLEMAS.md antes de orientar mudanças. Siga a etapa que eu indicar e use os comandos reais do projeto. Antes de executar comandos, confirme que o terminal está na pasta que contém README.md, package.json, apps e scripts.

Execute por conta própria as ações locais reversíveis e as verificações que puder fazer com suas ferramentas. Não reinicie o setup se .env e setup.config.json já existirem, não apague bancos/volumes, não altere outra instalação e não invente resultados de serviços externos. Se encontrar uma falha, investigue, corrija o que estiver ao seu alcance e repita o checkpoint. Diga em linguagem simples: o que já foi feito, qual evidência você viu e qual é a próxima ação minha. Se não tiver terminal ou navegador, diga exatamente o que eu devo fazer e como reconhecer que deu certo.

Peça somente os dados não secretos necessários à etapa, como nome da empresa, e-mail do administrador, canal escolhido e domínio. Oriente-me a digitar senhas e tokens apenas no terminal local ou no painel do serviço correspondente; nunca peça que eu os cole no chat, em um print ou em um arquivo a ser enviado. Para a Meta, guie uma tela por vez, confirme qual ativo e qual ID aparecem, explique quando algo depender de acesso ou aprovação do titular e marque como pendente tudo que ainda não foi testado com uma mensagem real. Ao final de cada etapa, apresente: FEITO, TESTADO e PENDENTE.
```

### Prompt único — para avançar sem copiar cada etapa

Depois do prompt mestre, você pode colar este texto. O agente deve avançar sozinho sempre que tiver ferramentas e informações suficientes. Os prompts numerados abaixo servem para retomar uma etapa específica ou pedir mais detalhe.

```
Comece na etapa 3 da pauta e avance em ordem até a etapa 17. Execute e confira todos os comandos locais que estiverem ao seu alcance. Em cada etapa, apresente FEITO, TESTADO e PENDENTE em poucas linhas e inicie a seguinte quando não houver dependência minha. Nas etapas 1 e 2, dê apenas o resumo essencial enquanto prepara o ambiente.

Quando precisar de um dado meu, peça só esse dado. Quando depender de login, permissão, token, decisão de custo, tela Meta ou Railway, diga a ação exata que devo fazer na minha conta e aguarde meu resultado antes de continuar essa parte. Não solicite segredos no chat. Se a etapa 8 não estiver liberada, registre o bloqueio e continue apenas as partes independentes, sem declarar o canal conectado. Não publique serviço, ative canal ou altere callback de produção para um cliente que eu ainda não identifiquei como meu ou autorizado.
```

## Sessão 1 — instalar e conectar

### 1\. Entender o que será instalado

```
Vamos fazer a etapa 1 da pauta. Leia o README e me explique em até cinco frases o que o CRM faz, quais canais ele realmente implementa e qual é o resultado esperado da instalação. Mostre a ordem das etapas até o primeiro teste de mensagem. Ainda não altere arquivos nem ative canais.
```

### 2\. Entender PostgreSQL, Redis e workers

```
Vamos fazer a etapa 2. Leia docs/ARQUITETURA.md e explique com o exemplo de três mensagens seguidas o papel de PostgreSQL, Redis, BullMQ/workers e IA. Confirme no projeto quais serviços são obrigatórios para rodar localmente e aponte uma limitação relevante do agrupamento de mensagens. Não recomende remover Redis ou pgvector sem mostrar o trabalho necessário.
```

### 3\. Conferir computador e pasta

```
Vamos fazer a etapa 3. Verifique Node, npm, Docker Engine e Compose com os comandos do README. Confirme a versão exigida e que o terminal está na raiz da pasta extraída. Se Docker não estiver ativo, oriente-me a iniciá-lo e depois repita a verificação. No Windows, se npm.ps1 for bloqueado, use npm.cmd. Pare apenas se faltar uma ferramenta que não consiga instalar sem minha intervenção.
```

### 4\. Criar a instalação

```
Vamos fazer a etapa 4. Confira se .env e setup.config.json já existem. Se não existirem, peça meu nome de empresa e e-mail de administrador, execute npm run setup e acompanhe o resultado. Explique onde devo guardar a senha inicial sem reproduzi-la no chat. Verifique apenas a existência e os nomes dos campos gerados, sem imprimir segredos. Se a instalação já existir, preserve-a e passe ao checkpoint correspondente.
```

### 5\. Instalar dependências, PostgreSQL e Redis

```
Vamos fazer a etapa 5. Na raiz do template, execute npm run deps; espere terminar. Depois execute docker compose up -d --wait e docker compose ps. Confirme PostgreSQL e Redis healthy e as portas locais. Se houver conflito de porta, consulte docs/PROBLEMAS.md e ajuste Compose e URL correspondente no .env sem tocar em outra instalação. Não rode atualizações principais sugeridas pelo npm/Prisma durante a instalação.
```

### 6\. Banco, primeiro login e identidade

```
Vamos fazer a etapa 6. Execute npm run db:init e npm run doctor; resolva qualquer erro antes de seguir. Inicie npm run dev e mantenha esse terminal aberto. Abra ou me oriente a abrir http://localhost:3100, entrar com a credencial gerada localmente e trocar a senha. Guie-me em Configurações → Geral para ajustar marca, contato, fuso e textos, e confira /privacy e /data-deletion. Mantenha WhatsApp e Instagram desligados. Verifique que o painel abre e que doctor passou.
```

### 7\. IA, agente e catálogo

```
Vamos fazer a etapa 7. Leia docs/AGENTES.md. Guie-me a cadastrar minha chave própria em Chaves de API sem colá-la no chat, escolher um modelo disponível na minha conta, editar e salvar o agente padrão e cadastrar um curso/produto de exemplo em Cursos → Novo curso. Peça apenas informações comerciais não secretas que faltarem. Separe “chave armazenada” de “chamada real testada”; se eu não tiver chave ou crédito, deixe o teste de IA pendente e os canais desligados.
```

### 8\. Meta, WhatsApp, Instagram e HTTPS local

Esta etapa é **guiada** porque depende de login, permissões e ativos que pertencem ao aluno ou ao cliente. Faça WhatsApp, Instagram ou ambos, conforme o uso. A criação de conta, análise de aplicativo e autorização do titular não são executadas pelo CRM.

```
Vamos fazer a etapa 8. Leia docs/META.md inteiro e me guie UMA ação por vez. Primeiro pergunte se usarei ativos meus ou de um cliente, qual canal quero configurar e se tenho acesso autorizado ao aplicativo, à WABA e à Página/Instagram. Se forem ativos de cliente e eu não tiver acesso, mostre as opções “cliente configura junto”, “cliente delega acesso” e “teste com meus ativos”; não suponha permissão e não peça senha pessoal dele.

Depois confirme os pré-requisitos de cada canal, indique a tela da Meta e o campo equivalente do CRM para cada ID/token, sem pedir que eu cole segredos no chat. No Instagram, use o fluxo com Facebook Login e token da Página correta. No WhatsApp, diferencie WABA ID de Phone Number ID. Guie a instalação/autenticação do ngrok, mantenha npm run dev e ngrok http 3100 em terminais separados, valide a URL HTTPS em /api/health, atualize as duas URLs no .env e reinicie o app.

Só então oriente a configurar os dois callbacks aplicáveis, o Verify Token, os campos de webhook e a subscription na WABA ou Página. Mostre como conferir Status e Verificar subscription em Onboarding → Canais. Ative apenas o canal testado e peça uma mensagem real de outra conta autorizada. Marque separadamente: credencial salva, consulta de status, handshake, subscription, mensagem recebida e resposta entregue. Se a interface da Meta diferir do guia, peça os rótulos que vejo na tela e adapte a orientação sem inventar um botão.
```

## Sessão 2 — publicar e operar

As etapas abaixo pressupõem que você decidiu publicar na **sua conta Railway**. Antes de criar serviços pagos, confira custos e o projeto de destino. A instalação local pode continuar sendo usada sem publicar.

### 9\. Revisar o que será enviado

```
Vamos fazer a etapa 9. Leia docs/DISTRIBUICAO.md e docs/RAILWAY.md. Execute auditoria, testes de segurança/template e scanner de distribuição conforme a pauta. Confira que .env, setup.config.json, tokens, bancos e backups não entram no repositório. Se eu recebi um ZIP, oriente a criar um repositório novo meu. Mostre a lista de arquivos que serão enviados antes de concluir o commit e use somente o remoto que eu informar.
```

### 10\. Criar PostgreSQL com pgvector no Railway

```
Vamos fazer a etapa 10. Use docs/RAILWAY.md e minhas ferramentas disponíveis para me guiar na minha conta Railway. Crie ou me oriente a criar um projeto novo e um PostgreSQL que suporte pgvector, com volume persistente. Confira nome do serviço, URL privada e suporte à extensão. Não imprima credenciais e não use um banco de outra instalação.
```

### 11\. Adicionar Redis

```
Vamos fazer a etapa 11. Adicione ou me guie a adicionar Redis ao mesmo projeto Railway. Confira REDIS_URL privada, persistência AOF e política noeviction segundo docs/RAILWAY.md. Explique em uma frase o efeito sobre filas e trabalhos pendentes se Redis perder os dados. Não publique uma porta aberta de Redis.
```

### 12\. Publicar o serviço CRM e variáveis

```
Vamos fazer a etapa 12. Crie ou me guie a criar o serviço CRM a partir do meu repositório, usando Dockerfile e railway.toml fornecidos. Configure volume /app/data, SETUP_CONFIG_PATH, uma réplica e workers conforme docs/RAILWAY.md. Use referências privadas reais dos serviços PostgreSQL e Redis; não invente nomes. Gere segredos novos dentro do ambiente seguro, nunca copie os segredos locais para uma resposta de chat, e confira que nenhuma chave secreta ficou em NEXT_PUBLIC_*.
```

### 13\. Build, migrations e início

```
Vamos fazer a etapa 13. Acompanhe build, pre-deploy/migrations e logs de runtime do serviço CRM. Mostre a primeira falha concreta se houver, corrija e tente novamente. Confirme que as migrations passaram e que servidor e workers iniciaram. Não marque a etapa concluída apenas porque a construção da imagem terminou.
```

### 14\. HTTPS, login e persistência remota

```
Vamos fazer a etapa 14. Gere ou me guie a gerar um domínio HTTPS do CRM. Atualize NEXT_PUBLIC_APP_URL e PUBLIC_BASE_URL com esse domínio e faça redeploy. Teste /api/health e login, troque a senha inicial e remova as variáveis de primeiro acesso conforme o guia. Configure a identidade, agentes e chaves da instalação hospedada, confira /privacy e /data-deletion e valide que as configurações sobrevivem a um reinício. Não copie o .env local como um bloco inteiro para o Railway.
```

### 15\. Mover os callbacks Meta

```
Vamos fazer a etapa 15. Compare os callbacks atuais do túnel com os do novo domínio e me guie na substituição no aplicativo Meta. Confira Verify Token, App Secret, campos assinados e inscrição na WABA/Página. Faça o teste real com o servidor local fechado para provar que o atendimento usa o CRM hospedado. Se a Meta ainda exigir análise, acesso avançado ou modo público, registre a pendência específica sem chamar o canal de operacional.
```

### 16\. Teste de aceitação

```
Vamos fazer a etapa 16. Use a tabela de aceitação da pauta. Teste login, persistência, cada canal que ativei, agrupamento de três mensagens, pergunta fora do catálogo, transferência humana e comportamento de mídia/janela de mensagens. Para cada cenário, registre uma evidência sem expor dados de clientes ou tokens. Diferencie aprovado, falhou e não testado; deixe desligado qualquer canal que eu não configurei.
```

### 17\. Custos, backup e rotina

```
Vamos fazer a etapa 17. Mostre onde acompanhar custos de Railway, IA e Meta na minha conta; não presuma gratuidade. Revise o plano de backup do PostgreSQL, volume de configuração, Redis e segredos conforme docs/RAILWAY.md e docs/ARQUITETURA.md. Explique como restaurar sem perder SECRETS_KEY, como monitorar logs/filas e como testar atualizações em uma cópia separada. Termine com uma lista curta do que está pronto e do que ainda depende de mim ou da Meta.
```

## Como reconhecer um resultado confiável

| Evidência | O que comprova |
| :---- | :---- |
| `npm run doctor` sem falhas | Banco, extensão, administrador e Redis locais respondem |
| `http://localhost:3100/api/health` responde | Processo HTTP local está no ar |
| URL HTTPS do túnel `/api/health` responde | A Meta pode alcançar o endereço público do teste |
| Meta aceita **Verify and Save** | O desafio de verificação do callback passou |
| **Status** e **Verificar subscription** no CRM | Credencial lê o ativo e aplicativo está inscrito no ativo informado |
| Mensagem real aparece no CRM **e** resposta chega ao remetente | Fluxo de atendimento daquele canal funcionou no teste |
| Repetir mensagem com computador desligado após publicação | Serviço hospedado atende sem depender do ambiente local |

Essas evidências têm alcances diferentes. O assistente deve usar “pendente” quando ainda faltar um teste real ou uma autorização da Meta.