# Conectar seu Business, WhatsApp e Instagram

Este guia descreve o fluxo suportado pelo código: **WhatsApp Cloud API** e **Instagram Direct usando Facebook Login/Página vinculada**. Não existe login social automático nem cadastro de ativos Meta pelo CRM: você prepara os ativos no painel Meta e informa as credenciais no seu CRM. Siga primeiro o canal que pretende usar; o outro pode permanecer desligado.

A interface, permissões e requisitos de aprovação da Meta mudam. Confira as referências oficiais ao final e os requisitos exibidos no seu próprio aplicativo. O processo de análise e a elegibilidade do número/negócio dependem da Meta.

## 1. Separar as contas e os identificadores

Para praticar, use seu próprio perfil administrador, portfólio empresarial, aplicativo, Página e conta profissional. Em projetos de clientes, use os ativos autorizados pelo titular conforme o cenário da seção 2. Um aluno não precisa receber tokens nem acesso ao Business do professor.

| Campo do CRM | O que representa | Onde procurar |
|---|---|---|
| `META_APP_ID` | Identificador do aplicativo | Meta for Developers → seu aplicativo → configurações básicas |
| `META_APP_SECRET` | Segredo que verifica a assinatura dos webhooks | Mesmo aplicativo → configurações básicas → segredo do app |
| `META_WEBHOOK_VERIFY_TOKEN` | Segredo criado por você para o handshake | Já gerado no `.env` pelo setup; deve ser igual ao configurado na Meta |
| `META_PHONE_NUMBER_ID` | ID técnico do número Cloud API | Área WhatsApp / configuração de API do aplicativo |
| `META_BUSINESS_ACCOUNT_ID` | ID da **conta WhatsApp Business (WABA)** | WhatsApp Manager / área WhatsApp do aplicativo |
| `META_SYSTEM_USER_TOKEN` | Token com acesso ao WhatsApp do seu negócio | Configurações do Business → usuários de sistema |
| `META_IG_PAGE_ID` | ID da Página Facebook ligada ao Instagram | Configurações da Página / Graph API Explorer |
| `META_IG_BUSINESS_ACCOUNT_ID` | ID técnico do Instagram profissional | Campo `instagram_business_account` da Página na Graph API |
| `META_IG_PAGE_ACCESS_TOKEN` | Token de acesso da **Página** | Fluxo de Facebook Login / Graph API Explorer com acesso à Página |

O ID do portfólio empresarial, o WABA ID e o Phone Number ID são identificadores diferentes. O telefone com DDD e o `@usuario` do Instagram também não substituem os IDs técnicos.

**Antes de começar:** conclua as etapas 1–7 da [pauta](PAUTA_CONFIGURACAO_PUBLICACAO.md), entre como administrador, tenha Docker/PostgreSQL/Redis e `npm run dev` funcionando e confirme `http://localhost:3100/api/health`. Separe uma conta Meta própria com acesso administrativo aos ativos; uma conta de outra pessoa exige autorização dela. Para responder automaticamente, o CRM também precisa de chave de IA válida e agente padrão. Durante a configuração, mantenha os canais desligados em **Configurações → Geral**.

## 2. Preparar o aplicativo

1. Entre em [Meta for Developers — aplicativos](https://developers.facebook.com/apps/) com sua conta de desenvolvedor e escolha **Criar aplicativo**. Selecione os casos de uso empresariais/WhatsApp/mensagens que o painel oferecer. O nome e a organização dos menus variam conforme o aplicativo.
2. Para uma instalação do **seu próprio negócio**, associe o aplicativo ao seu portfólio empresarial quando a Meta solicitar. Para uma instalação de **cliente**, prefira que o cliente seja dono do aplicativo e dos ativos no portfólio dele. Confirme que a pessoa que vai concluir o processo tem acesso ao aplicativo, à WABA e à Página/Instagram necessários. Consulte o caso sem acesso logo abaixo.
3. No aplicativo, abra **Configurações → Básico** e anote o **App ID**. Revele e copie o **App Secret** apenas para cadastrar no CRM; nunca inclua esse segredo em aula gravada, README, Git ou captura de tela.
4. Prepare as páginas públicas `https://SEU-DOMINIO/privacy` e `https://SEU-DOMINIO/data-deletion`. Revise o texto e os contatos no CRM; são modelos. Informe essas URLs no aplicativo quando o painel pedir. Para teste local, use o domínio HTTPS do túnel da seção 5 e atualize-o se o endereço mudar.
5. Abra **Configurações → Meta / Business** no CRM. Cole **ID do aplicativo Meta** e **Segredo do aplicativo (App Secret)** nos campos com esses nomes e clique **Salvar credenciais Meta**. O formulário confirma armazenamento, não aprova permissões nem testa mensagens.

O template usa um único App ID/App Secret compartilhado entre os dois canais. Para usar aplicativos separados por canal seria necessário separar esses campos e a verificação de assinatura no código.

### Se o aluno não tem acesso ao portfólio do cliente

Não é possível conectar os canais de um cliente apenas sabendo o nome da empresa, telefone ou `@instagram`. O responsável pelo portfólio precisa autorizar o acesso aos ativos e ao aplicativo. Há três caminhos:

1. **Aula ou protótipo:** use seu próprio portfólio, número de teste e Página/Instagram de teste. Deixe a conexão do cliente como pendência; não conecte ativos dele por suposição.
2. **Cliente configura com você:** o administrador do cliente cria/seleciona o aplicativo no portfólio dele, vincula WABA e Página/Instagram, obtém os IDs/tokens e os cadastra na instalação **própria desse cliente**. O aluno orienta por chamada ou por este guia; o cliente não precisa entregar a senha pessoal da Meta. O cliente controla o acesso e pode revogá-lo.
3. **Cliente delega a configuração:** o administrador convida o aluno como pessoa ou parceiro e atribui as tarefas necessárias no **aplicativo, WABA, Página e Instagram**. A concessão de acesso à Página sozinha pode não dar acesso ao aplicativo ou à WABA. O aluno aceita os convites, confirma no painel os ativos visíveis e só então gera tokens do aplicativo autorizado. Se faltar permissão, o administrador ajusta o ativo/tarefa correspondente; o CRM não consegue concedê-la.

Antes de começar, combine **quem será dono do aplicativo**, **quem manterá os tokens** e **quem poderá revogar o acesso**. Para vários clientes, use **uma instalação do template por cliente**, cada uma com seu banco, Redis, segredos e credenciais; a versão atual não isola vários Businesses dentro de um único CRM. Não mova a Página ou o número do cliente para um portfólio do aluno como atalho. [A Meta distingue acesso a Página e tarefas de administração](https://www.facebook.com/help/289207354498410/r.php/); os menus e permissões concretos aparecem na conta do proprietário.

## 3. Preparar o WhatsApp

1. No aplicativo Meta, abra o caso de uso/produto **WhatsApp → Configuração da API** (ou o equivalente exibido). Use inicialmente o **número de teste**. Se o painel pedir, adicione um telefone pessoal como **destinatário de teste** e conclua a confirmação dele.
2. Copie o **Phone Number ID** e o **WhatsApp Business Account ID (WABA ID)** mostrados nessa área. No CRM, preencha respectivamente **ID do número WhatsApp (Phone Number ID)** e **ID da conta WhatsApp Business (WABA ID)**. Se o painel não mostrar o WABA ID ali, procure em **Configurações do Business → Contas → Contas do WhatsApp**. O WABA ID é o identificador da conta; o Phone Number ID é o identificador de um número dentro dela.
3. Para o primeiro teste, a Meta pode fornecer um **token temporário** no painel WhatsApp. Ele pode expirar rapidamente. Cole-o no campo **Token do usuário de sistema — WhatsApp** apenas durante esse teste, sabendo que terá de substituí-lo. O nome do campo no CRM descreve a configuração duradoura; ele também aceita o token temporário para o ensaio.
4. Para operação contínua, abra **Configurações do Business → Usuários → Usuários do sistema** na organização dona da WABA. Crie ou selecione um usuário de sistema, atribua a ele os ativos WhatsApp necessários e gere um token para **este mesmo aplicativo**. Solicite as permissões `whatsapp_business_messaging` e `whatsapp_business_management` conforme a Meta permitir para seus ativos. Copie o token para o mesmo campo do CRM e salve. Confira tipo, validade e permissões no [Access Token Debugger](https://developers.facebook.com/tools/debug/accesstoken/).
5. No CRM, abra **Onboarding → Canais**, clique **Status** no cartão WhatsApp e confirme que ele reconhece o número esperado. Depois do webhook configurado, clique **Verificar subscription**. Esse botão consulta/assina o aplicativo na **WABA ID**; preencher apenas Phone Number ID não basta. Confirme a inscrição também no painel Meta.
6. Para um número definitivo, siga o registro, verificação e elegibilidade apresentados pela Meta. Não exclua sua conta atual nem migre o número por tentativa: os fluxos de migração/coexistência variam. Você pode validar o CRM com o número de teste primeiro.

Se o status indicar ausência de credenciais, confira App Secret, Phone Number ID, token e Verify Token. A subscription e a sincronização de templates exigem o WABA ID. **Status `connected` significa que a consulta ao número respondeu; ainda não prova que o webhook ou o envio funcionam.**

## 4. Preparar Instagram com Facebook Login

1. Converta ou confirme a conta Instagram como **profissional** e vincule-a a uma **Página Facebook** que você administra. No Business Suite, confirme que a Página e o Instagram estão conectados e que seu usuário pode administrar mensagens de ambos.
2. No aplicativo Meta, configure o caso de uso de mensagens do Instagram **via Facebook Login**. Esse adaptador usa `graph.facebook.com` e **token de Página**; escolha esse fluxo, mesmo que o painel ofereça também **Instagram Login**.
3. No [Graph API Explorer](https://developers.facebook.com/tools/explorer/), selecione **seu aplicativo**, gere um **User Access Token** com as permissões de Página e Instagram solicitadas no painel e autorize a Página correta. Entre as permissões envolvidas estão `instagram_basic`, `instagram_manage_messages`, `pages_show_list`, `pages_read_engagement` e `pages_manage_metadata`; algumas configurações também exigem `pages_messaging`. Confira tarefas da Página, nível de acesso e permissões efetivamente concedidas. Use este token de usuário só para obter o token de Página; não o cadastre no CRM.
4. No Explorer, faça um **GET** a `/me/accounts?fields=id,name,access_token,tasks,instagram_business_account`. Na resposta, localize a **Página vinculada ao Instagram desejado**. Copie o `id` da Página, o `id` dentro de `instagram_business_account` e o `access_token` **da linha dessa Página**. A [coleção oficial da Meta para Instagram](https://www.postman.com/meta/instagram/request/0vuw3vk/get-access-tokens-of-pages-you-manage) documenta essa consulta. Se a resposta vier vazia ou sem `instagram_business_account`, revise o vínculo, as permissões e as tarefas antes de avançar.
5. No CRM, em **Configurações → Meta / Business**, preencha **ID da Página Facebook vinculada ao Instagram** com o `id` da Página, **ID da conta profissional Instagram** com o `instagram_business_account.id` e **Token de acesso da Página — Instagram** com o `access_token` dessa mesma Página. Salve. Não misture IDs ou token de outra Página.
6. Abra **Onboarding → Canais** e clique **Status** no cartão Instagram. O resultado deve identificar a Página e a conta profissional vinculada. Depois do webhook configurado, use **Verificar subscription** e confira no painel Meta se o aplicativo está inscrito na Página com `messages,messaging_postbacks`.
7. Configure os papéis de administrador/desenvolvedor/testador e aceite os convites necessários para ensaios em modo de desenvolvimento. Confira validade, permissões e ativos do token no [Access Token Debugger](https://developers.facebook.com/tools/debug/accesstoken/); mudanças de acesso ou segurança podem revogá-lo.

Não misture com **Instagram Login**, que usa outro fluxo, permissões e normalmente `graph.instagram.com`. Esse outro fluxo exige um adaptador próprio. Conta pessoal e Instagram Basic Display não substituem o canal de mensagens profissionais.

## 5. Disponibilizar HTTPS

### Caminho local: túnel de desenvolvimento

Use **três terminais**: um para `npm run dev`, outro para o túnel, e um terceiro para comandos de verificação. Com o app ativo em `3100`, instale o [ngrok para seu sistema](https://ngrok.com/download/windows), crie uma conta própria e configure o authtoken conforme o painel do ngrok. No Windows, a página oficial mostra instalação pela Microsoft Store/WinGet. Não coloque o authtoken do ngrok no projeto ou na gravação. Confirme `ngrok version`; então encaminhe o túnel para `http://127.0.0.1:3100`:

```sh
ngrok http 3100
```

Copie o endereço **HTTPS** exibido na linha de encaminhamento, sem a barra final. Abra `https://SEU-ENDERECO-PUBLICO/api/health` no navegador: deve retornar `"ok":true`. Se aparecer erro do túnel, confira se `npm run dev` continua aberto e se a porta é realmente `3100`.

No `.env` da raiz, atualize:

```dotenv
NEXT_PUBLIC_APP_URL=https://SEU-ENDERECO-PUBLICO
PUBLIC_BASE_URL=https://SEU-ENDERECO-PUBLICO
```

Pare e inicie `npm run dev` para carregar o novo ambiente. Volte a **Onboarding → Canais** e clique **Status** para conferir que a URL do webhook agora mostra o HTTPS do túnel. Não altere as URLs dos bancos para o endereço do túnel. Se o endereço público mudar, atualize as variáveis, reinicie e atualize os callbacks na Meta.

Abra o painel usando localhost para trabalhar; o túnel é necessário para a Meta alcançar o servidor. A máquina, Docker, servidor e túnel precisam permanecer ligados durante os testes.

### Caminho hospedado

Siga [Railway](RAILWAY.md), gere o domínio e coloque-o nas duas variáveis acima. A aplicação hospedada recebe o webhook mesmo com seu computador desligado.

## 6. Configurar os webhooks

Configure os callbacks correspondentes no painel do aplicativo Meta:

| Canal | Callback |
|---|---|
| WhatsApp | `https://SEU-DOMINIO/api/webhooks/whatsapp-cloud` |
| Instagram | `https://SEU-DOMINIO/api/webhooks/instagram` |

1. Leia `META_WEBHOOK_VERIFY_TOKEN` no `.env` gerado pelo setup, ou substitua-o por um segredo novo salvo em **Configurações → Meta / Business**. Os valores salvos no painel têm precedência sobre o `.env`. Com as demais credenciais completas, **Onboarding → Canais → Status** também exibe o Verify Token efetivo. Não inclua as aspas do `.env`.
2. Na configuração de **Webhooks do WhatsApp** do aplicativo Meta, cole o callback WhatsApp da tabela e esse Verify Token. Clique na opção de **verificar e salvar**. O CRM responde ao desafio GET mesmo com o canal desativado. Depois, assine o campo `messages`.
3. Na configuração de **Webhooks para mensagens do Instagram** do aplicativo, cole o callback Instagram da tabela e o **mesmo** Verify Token. Verifique e salve. Escolha os eventos de mensagens e postbacks compatíveis com o fluxo de Página/Facebook Login; o adaptador solicita `messages,messaging_postbacks` na Página.
4. Abra **Onboarding → Canais** no CRM. Para cada canal configurado, clique **Status** e depois **Verificar subscription**. No WhatsApp, a inscrição é na **WABA ID**; no Instagram, é na **Página Facebook**. Confira a resposta e a inscrição de cada ativo no painel Meta. A opção de status só testa a leitura de um ativo, e o botão de subscription não confirma o recebimento de uma mensagem real.
5. Se a Meta rejeitar o callback, confira exatamente URL HTTPS, túnel/servidor ativos e Verify Token. Se aceitar mas não entregar mensagens, confira campos assinados, inscrição na WABA/Página, papéis de teste e modo do aplicativo.

O POST valida `x-hub-signature-256` com App Secret. Se o segredo do app estiver incorreto, o handshake pode funcionar, mas as mensagens serão recusadas. Verify Token e App Secret têm funções distintas.

## 7. Testar atendimento

1. Confirme que há chave de IA própria válida, agente padrão e catálogo/prompt revisados. Sem isso, teste apenas a chegada da conversa e registre a resposta automática como pendente.
2. Ative **somente** o canal que vai testar em **Configurações → Geral** e salve.
3. Para WhatsApp, mande uma mensagem **do telefone autorizado** ao número de teste/negócio do aplicativo. Para Instagram, mande uma DM **de outra conta autorizada** para o perfil profissional vinculado à Página. O remetente precisa iniciar a conversa.
4. Veja se a conversa entrou no CRM e se a resposta chegou ao aplicativo de origem. A verificação só termina quando os dois lados aparecem; teste de webhook no painel Meta não equivale a mensagem real.
5. Envie três mensagens seguidas, aguarde a janela de agrupamento e confira a resposta. Peça atendimento humano e confira a transferência.
6. Faça o mesmo no outro canal se pretende utilizá-lo. Anote a etapa exata que falhou: token, status, handshake, subscription, entrada da mensagem ou resposta.

WhatsApp tem regras de janela e envio por templates aprovados para determinados contatos fora da janela. Instagram também tem políticas de mensagens e limites. O template não concede permissão para iniciar mensagens irrestritas e não aprova templates automaticamente.

Antes de atender pessoas externas, confira o modo do aplicativo, permissões com acesso necessário, revisão, verificação do negócio e políticas que a Meta exigir para o seu cenário. Modo de desenvolvimento não equivale a liberação para público externo.

## Falhas frequentes

- **Token inválido/expirado:** gere um novo token do mesmo app, com os ativos e permissões corretos; atualize o painel.
- **Página sem Instagram:** confirme vínculo e acesso de quem gerou o token.
- **Recebe webhook de teste, mas não mensagens reais:** confira campos assinados, inscrição na WABA/Página, modo do app e papéis de testador.
- **Assinatura inválida:** confira App Secret; não o confunda com Verify Token.
- **Canal desativado (403):** ative-o em Geral após preparar a configuração.
- **Recebe, mas não responde:** confira chave/saldo de IA, agente padrão, regras de pausa, transferência, Redis e logs.
- **Erro de versão Graph:** ajuste `META_GRAPH_VERSION` no servidor para uma versão suportada pelo seu app e valide os endpoints; não troque versões sem testar os dois canais.

## Referências oficiais

- [WhatsApp Cloud API — início](https://developers.facebook.com/docs/whatsapp/cloud-api/get-started)
- [Meta — coleção oficial da WhatsApp Cloud API: WABA, número e subscription](https://www.postman.com/meta/whatsapp-business-platform/documentation/wlk6lh4/whatsapp-cloud-api)
- [Instagram API com Facebook Login](https://developers.facebook.com/docs/instagram-platform/instagram-api-with-facebook-login/)
- [Mensagens do Instagram com Facebook Login](https://developers.facebook.com/docs/instagram-platform/instagram-api-with-facebook-login/messaging-api/)
- [Meta — coleção oficial: obter token de Página e ID do Instagram](https://www.postman.com/meta/instagram/request/0vuw3vk/get-access-tokens-of-pages-you-manage)
- [ngrok — instalar e obter HTTPS local](https://ngrok.com/download/windows)
- [Graph API Explorer](https://developers.facebook.com/tools/explorer/)
- [Access Token Debugger](https://developers.facebook.com/tools/debug/accesstoken/)
- [Versões da Graph API](https://developers.facebook.com/docs/graph-api/changelog/versions)

As páginas da Meta podem exigir login e apresentar menus diferentes conforme a configuração do app. Este guia acompanha os campos realmente lidos pelo template. As integrações externas precisam ser validadas com os ativos do próprio aluno; nenhum token de terceiros foi incluído para teste.
