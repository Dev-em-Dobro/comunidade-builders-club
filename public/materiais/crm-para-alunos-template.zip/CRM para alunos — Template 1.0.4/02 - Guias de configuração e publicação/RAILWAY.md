# Hospedar sua própria instalação no Railway

O código também roda em outros servidores. Aqui o Railway reúne três serviços no **projeto do aluno**: CRM, PostgreSQL com pgvector e Redis. Você usa sua conta, seus dados, seu domínio e suas credenciais. Não é necessário conectar o projeto do professor.

Não há promessa de gratuidade: consulte os preços e limites atuais. Comece pequeno, configure orçamento e acompanhe o uso de infraestrutura e das APIs de IA/Meta separadamente.

## 1. Preparar o seu repositório

1. Extraia o template e use um repositório próprio no GitHub. Se recebeu acesso a um GitHub Template, use “Use this template”.
2. Versione o código, `.env.example` e `setup.config.example.json`. **Não envie `.env`, `setup.config.json`, dumps ou volumes.** O `.gitignore` já exclui esses arquivos.
3. Antes do primeiro push, execute `npm run check:distribution` e confira `git status`. O scanner cobre padrões conhecidos, não substitui a revisão de arquivos novos.
4. Para distribuir uma instalação limpa, prefira o ZIP criado por `npm run package`.

## 2. Criar projeto e PostgreSQL com pgvector

1. Entre no Railway e crie um projeto novo seu.
2. Adicione um serviço PostgreSQL **com pgvector**, usando o template correspondente. O PostgreSQL padrão pode não incluir a biblioteca necessária.
3. Para simplificar as referências abaixo, dê ao serviço o nome `Postgres`.
4. Confira o volume persistente do banco e a variável `DATABASE_URL` fornecida pelo serviço. Use a conexão privada entre serviços, sem copiar dados de outra instalação.
5. As migrations do CRM criam a extensão `vector` se ela estiver disponível e o usuário tiver permissão. Se aparecer “extension vector is not available”, corrija o serviço/imagem; não apague a migration nem desabilite RAG esperando resolver, pois o schema exige a extensão.

## 3. Adicionar Redis

1. No mesmo projeto, adicione um serviço Redis. Nomeie-o `Redis` para seguir os exemplos.
2. Confira a variável `REDIS_URL` e a persistência do serviço/volume.
3. Configure persistência AOF e política `noeviction` conforme a imagem e opções do serviço escolhido. O Compose local já faz isso; essa configuração não é transferida automaticamente para um serviço criado pelo painel do Railway.
4. Não dê domínio HTTP público aos bancos. Só exponha um proxy TCP se realmente precisar administrar de fora e saiba quais credenciais está usando.

O Redis armazena filas importantes para o funcionamento. Não trate seus dados como cache que pode ser apagado a qualquer momento. Veja [Arquitetura](ARQUITETURA.md).

## 4. Adicionar a aplicação

1. Adicione um serviço a partir do **seu** repositório GitHub.
2. Deixe a raiz do serviço na raiz do repositório (`/`). O Dockerfile precisa ver `apps/web`, `scripts` e o exemplo de configuração.
3. Utilize o `Dockerfile` da raiz. O `railway.toml` já define builder, pre-deploy, healthcheck e política de reinício.
4. Crie um **volume de aplicação** montado em `/app/data`. Ele armazena `setup.config.json`, que o painel Geral modifica. Sem esse volume, as alterações podem desaparecer ao recriar o container.
5. Mantenha uma réplica inicialmente. O entrypoint prepara a permissão do diretório e inicia o servidor como usuário `node`; a aplicação escuta em `0.0.0.0` e usa a porta fornecida pelo Railway.

Os bancos precisam de volumes próprios, além do volume de configuração do CRM. Um volume do CRM não substitui o backup do PostgreSQL.

## 5. Variáveis do serviço CRM

Na aba Variables **do CRM**, crie referências usando o seletor do Railway:

```dotenv
DATABASE_URL=${{Postgres.DATABASE_URL}}
REDIS_URL=${{Redis.REDIS_URL}}
```

Se nomeou os serviços de outro jeito, selecione o nome real. Essas expressões pertencem ao Railway; não cole as expressões no `.env` local esperando que o Node as resolva.

Adicione:

| Variável | Como preencher |
|---|---|
| `AUTH_SECRET` | Uma chave aleatória nova para as sessões |
| `SECRETS_KEY` | Outra chave aleatória nova, para criptografar credenciais |
| `AUTH_INITIAL_EMAIL` | Seu e-mail de primeiro acesso |
| `AUTH_INITIAL_PASSWORD` | Senha inicial forte, ao menos 12 caracteres recomendados |
| `ENABLE_WORKER` | `true` |
| `SETUP_CONFIG_PATH` | `/app/data/setup.config.json` |
| `META_WEBHOOK_VERIFY_TOKEN` | Uma terceira chave aleatória para o handshake Meta |
| `META_GRAPH_VERSION` | `v25.0` como configuração inicial do template; confira compatibilidade do seu app |

Para gerar **cada** segredo no seu terminal, execute e guarde o resultado com segurança:

```sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

Gere resultados diferentes para AUTH_SECRET, SECRETS_KEY e Verify Token. Não coloque comandos literais como valor da variável e não use as chaves da instalação de outra pessoa.

As credenciais WhatsApp/Instagram podem ser cadastradas depois no painel **Meta / Business**. As chaves de conversa podem ser cadastradas em **Chaves de API**. Como alternativa, preencha as variáveis listadas no `.env.example`. Valores do painel têm prioridade sobre valores do ambiente.

Não defina `SKIP_INSTRUMENTATION=true` no serviço: essa flag serve para build/teste e desliga o início dos workers no runtime.

## 6. Migrations e seed

O arquivo `railway.toml` já configura:

```sh
npm --prefix apps/web run db:migrate:deploy && npm --prefix apps/web run db:seed
```

O Dockerfile inclui Prisma CLI, migrations e tsx para esse comando funcionar na imagem final. Não troque pelo Prisma obtido dinamicamente por `npx` com versão não fixada.

O pre-deploy roda com as variáveis do serviço e acesso à rede privada. Se falhar, resolva o erro de banco/pgvector/credenciais antes de continuar. **O volume não está montado no pre-deploy**; por isso a inicialização do arquivo de configuração acontece apenas quando o servidor inicia. O seed não depende desse arquivo e não carrega catálogo nem contatos.

As migrations e o seed são idempotentes para os registros iniciais. Depois do primeiro login e troca de senha, remova `AUTH_INITIAL_EMAIL` e `AUTH_INITIAL_PASSWORD` das variáveis. A conta existente continua no banco; o seed não reseta sua senha em cada deploy.

## 7. Domínio e primeira configuração

1. Gere um domínio público HTTPS para o serviço CRM em Settings → Networking.
2. Adicione no CRM:

```dotenv
NEXT_PUBLIC_APP_URL=https://SEU-DOMINIO
PUBLIC_BASE_URL=https://SEU-DOMINIO
```

3. Faça redeploy para aplicar as variáveis. Elas são usadas para mostrar callbacks e compor links públicos.
4. Abra `/api/health`. Uma resposta `ok` confirma que o processo HTTP está ativo; não comprova que banco, Redis, IA e Meta estão todos operacionais.
5. Entre com seu primeiro usuário, troque a senha e preencha Geral, Chaves de API e Agentes.
6. Siga [Meta](META.md) para registrar webhooks com o domínio definitivo. Ative os canais após preparar os ativos.
7. Teste mensagens reais de contas autorizadas e confira chegada/resposta/transferência.

## 8. Personalizar o JSON inicial e preservar alterações

Na primeira execução, o entrypoint copia `setup.config.example.json` para `/app/data/setup.config.json`. O painel Geral modifica esse arquivo no volume, sem precisar reconstruir a imagem.

Para uma configuração inicial avançada, você pode criar a variável `SETUP_CONFIG_JSON` com o **conteúdo JSON completo** de um arquivo de exemplo adaptado, sem credenciais. Ele é utilizado **apenas se o arquivo no volume ainda não existir**. Depois disso, editar essa variável não sobrescreve as configurações feitas no painel.

Para mudar opções ainda não expostas pelo formulário (RAG, qualificação, auditoria, follow-ups), edite com cuidado o arquivo persistente pelo acesso administrativo do seu servidor. Preserve o JSON válido e faça uma cópia de segurança antes. Não substitua a configuração do seu negócio pela do professor.

## 9. Logs, disponibilidade e escala

- Confira logs de build, pre-deploy e runtime separadamente.
- No runtime, busque `workers.started`, `schedulers.registered`, erros Redis e eventos de webhook/envio.
- Mantenha o serviço acordado para webhooks e tarefas agendadas. Um servidor que dorme ou só existe durante a requisição não executa os timers/workers continuamente.
- Comece com uma réplica com `ENABLE_WORKER=true`. Não precisa de um quarto serviço worker para o template inicial.
- Para separar workers depois, crie um entrypoint próprio, compartilhe os dados corretos e revise locks, debounce e agendamentos. Mudar `ENABLE_WORKER=false` na única instância desliga os workers.
- `cache.debounce.keyPrefix` não isola todas as filas. Use banco e Redis próprios por instalação.

## 10. Backup e atualização

Preserve PostgreSQL, dados operacionais do Redis, configuração do volume e segredos de ambiente. Mantenha `SECRETS_KEY` fora do dump do banco, em um gerenciador seguro; sem a chave correta, os tokens criptografados não poderão ser recuperados.

Não troque `SECRETS_KEY` por uma chave nova sem recriptografar ou recadastrar os tokens. Mudar `AUTH_SECRET` encerra a validade das sessões antigas. Não rode o instalador local por cima do ambiente hospedado.

Para atualizar código: faça backup, revise migrations e changelog, teste uma instância separada, envie a versão para seu repositório e acompanhe o pre-deploy. Nunca use um banco de produção para rodar testes automatizados, pois vários testes limpam tabelas.

## Fontes oficiais

- [Railway: PostgreSQL e extensões](https://docs.railway.com/databases/postgresql)
- [Railway: aplicação com pgvector](https://docs.railway.com/guides/rag-pipeline-pgvector)
- [Railway: variáveis](https://docs.railway.com/variables)
- [Railway: pre-deploy](https://docs.railway.com/deployments/pre-deploy-command)
- [Railway: volumes](https://docs.railway.com/volumes)
- [Railway: configuração em arquivo](https://docs.railway.com/config-as-code/reference)

As referências validam os recursos de infraestrutura; os comandos e campos deste guia refletem os arquivos deste template.
