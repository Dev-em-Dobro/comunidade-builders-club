# Diagnóstico local

## Docker não conecta

Abra Docker Desktop, aguarde o mecanismo Linux iniciar e execute `docker version`. Em Windows, confira WSL2 e virtualização. Ter o comando `docker` instalado não significa que o servidor Docker esteja rodando.

## Porta ocupada

Antes de subir os containers, altere `POSTGRES_PORT`, `REDIS_PORT` ou `APP_PORT` no `.env`. Atualize também as portas em `DATABASE_URL`, `REDIS_URL` e URLs públicas quando necessário. A URL do PostgreSQL continua usando usuário, senha e nome de banco gerados para sua instalação.

Exemplo: se mudar `POSTGRES_PORT` para `55440`, a URL do app precisa apontar para `127.0.0.1:55440`. Não altere a porta interna `5432` do PostgreSQL por causa disso. Redis segue o mesmo princípio.

## Senha do banco não funciona

O PostgreSQL usa `POSTGRES_PASSWORD` para inicializar um volume vazio. Editar só essa variável depois que o banco já foi criado não troca a senha dentro do banco. Volte ao valor original ou realize uma troca de senha administrativa e atualize as conexões de modo coordenado. Não apague volumes com dados para contornar uma senha incorreta.

## Prisma reclama de DATABASE_URL

Execute os comandos `npm run db:init`, `npm run db:migrate` e `npm run db:seed` **na raiz**: os wrappers carregam o `.env` correto. O Prisma chamado diretamente em `apps/web` não carrega automaticamente o `.env` da raiz.

## Erro de pgvector

Use a imagem `pgvector/pgvector:pg16` do Compose, ou uma hospedagem que disponibilize a extensão. Desligar a opção RAG não remove a exigência da extensão no schema.

## Não consigo entrar

Confirme que `npm run db:init` criou o administrador. O e-mail inicial é o fornecido ao setup; a senha é a mostrada no terminal e gravada no `.env` até você removê-la. A conta não existe antes do seed. O seed não sobrescreve uma senha já cadastrada; para troca, use Trocar senha estando autenticado. O template não oferece recuperação automática por e-mail.

## Chaves desapareceram ou não podem ser decifradas

Restaure a mesma `SECRETS_KEY` usada quando foram cadastradas. Ela não é a chave de sessão `AUTH_SECRET`. Sem ela, recadastre as credenciais válidas na nova instalação.

## Alterações do painel somem no Railway

Confirme o volume montado em `/app/data` e `SETUP_CONFIG_PATH=/app/data/setup.config.json`. `SETUP_CONFIG_JSON` só inicializa uma instalação vazia; não sobrescreve o volume a cada deploy.

## Conversa entra, mas a IA não responde

Confira canal ativo, chave de IA com saldo, provedor/modelo do agente, agente padrão, regras de pausa, transferência humana, conexão Redis e workers. Qualificação Anthropic é uma função separada do agente de conversa e fica desativada inicialmente.

## Aplicação fica recebendo erros Redis

Execute `docker compose ps`, confira se o serviço está healthy e se a URL e senha correspondem ao `.env`. `npm run doctor` testa a conexão. Não use a URL privada do Railway no seu computador: ela só resolve dentro da rede do projeto.

## npm reclama de Node ou lockfile

Use Node 22.16+ da série 22 e npm 10/11. Rode `npm run deps` para uma instalação pelo lockfile; não apague o lockfile nem use `--force` para ignorar conflitos. Há apenas um gerenciador adotado neste template.

## Testes automatizados

`npm run test:template` não usa banco nem serviços externos. Para a suíte da aplicação, execute `npm run test:app` na raiz. O comando sobe `docker-compose.test.yml` nas portas 55434 e 56381 e fixa as URLs para um banco e um Redis exclusivos de testes, sem carregar seu `.env`. Vários testes apagam tabelas. Nunca aponte `DATABASE_URL` e `REDIS_URL` dos testes para uma instância com dados que você precisa preservar.

## PowerShell bloqueia npm.ps1

Use `npm.cmd` no lugar de `npm` (por exemplo, `npm.cmd run setup`) ou abra o Prompt de Comando. Não é necessário desativar a política de execução do computador.
