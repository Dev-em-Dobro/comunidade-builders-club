# Pauta completa — configurar e publicar o CRM

**Resultado esperado:** cada aluno terá uma instância própria, com sua marca, usuário, agentes, PostgreSQL, Redis, domínio HTTPS e canais Meta configurados com seus próprios ativos. A entrega real de mensagens depende das permissões e liberações da conta Meta de cada aluno.

**Material de apoio:** [README](../README.md), [Instalação assistida por IA e prompts por etapa](http://INSTALACAO_ASSISTIDA.md), [Arquitetura](http://ARQUITETURA.md), [Agentes](http://AGENTES.md), [Meta](http://META.md), [Railway](http://RAILWAY.md), [Problemas comuns](http://PROBLEMAS.md) e [Validação](http://VALIDACAO.md).

## Preparação do professor — antes da aula

- Disponibilizar o ZIP atualizado ou um repositório de template separado. [https\://drive.google.com/drive/folders/1C7lGt5JfU85dYK1HBdGv-PUQkWZd83-d?usp=sharing](https://drive.google.com/drive/folders/1C7lGt5JfU85dYK1HBdGv-PUQkWZd83-d?usp=sharing)&nbsp;  
- Usar uma instalação demonstrativa vazia e contas próprias de demonstração. Não abrir o CRM que atende clientes reais.  
- Conferir Node, npm, Docker e Compose. Abrir o Docker Desktop antes de começar.  
- Preparar um produto fictício com descrição, preço ilustrativo, políticas e link de exemplo. Dizer claramente que são dados de exercício.  
- Preparar conta Railway, acesso ao GitHub e provedor de IA com crédito de API disponível.  
- Preparar aplicativo Meta, ativos e contas/números autorizados para teste. Verificar convites e permissões com antecedência.  
- Separar dois contextos: desenvolvimento local e hospedagem. Não compartilhar suas conexões nem as configurações preenchidas com a turma.  
- Durante a demonstração, ocultar senhas, tokens, App Secret, variáveis e dados de pagamento. Mostrar nomes de campos e o resultado de configuração, sem exibir os valores secretos.

### 

### 1\. Abertura e demonstração do resultado — 10 minutos

Opa pessoal a ideia aqui é hoje é apresentar o CRM pra vocês e já passar as diretrizes e o passo a passo de como instalar e usar ele.

a ideai é começar mas nao é terminar hj pq pra fazer tudo demoraria bastante, provavelmente umas 2 a 3 horas entao vamos começar e vamos ate onde der dentro dessa 1 hora, mas no final eu vou mandar pra voces um zip com todo o passso a passo de instalaca e os prompts pra ti rodar ai e ele vai te guiar em toda a configuração.

&nbsp;

## Sessão 1 — instalar e configurar localmente

**Explicar:** este projeto é um CRM de atendimento com IA.&nbsp;

**Fixar:** cada empresa usa uma instalação própria. Um aluno não precisa receber acesso ao Business, banco ou credenciais do professor.

&nbsp;

Explicar cada um dos menus.

### 2\. Entender a arquitetura antes dos comandos — 15 minutos

**Explicar com exemplos:**

| Peça | Exemplo do que faz |
| :---- | :---- |
| Next.js | Mostra o painel e recebe os webhooks |
| PostgreSQL | Guarda usuários, conversas, agentes, catálogo e credenciais cifradas |
| pgvector O [pgvector](https://github.com/pgvector/pgvector) é uma extensão de código aberto para o PostgreSQL que permite armazenar e realizar buscas de similaridade em vetores (embeddings) diretamente no banco de dados relacional&nbsp; | Permite buscar trechos relevantes da base de conhecimento |
| Redis | Coordena buffers de mensagens, locks e filas |
| BullMQ/workers | Executam tarefas de notificação, SLA e outras rotinas |
| API de IA | Gera respostas usando a chave do aluno |
| Meta | Entrega e recebe as mensagens dos canais autorizados |

&nbsp;

**Demonstração sugerida:** simular uma pessoa enviando três mensagens curtas. Explicar por que esperar alguns segundos pode produzir uma única resposta contextualizada.

### 3\. Conferir o ambiente e baixar o projeto — 10 minutos

baixar o zip

- [https\://drive.google.com/drive/folders/1C7lGt5JfU85dYK1HBdGv-PUQkWZd83-d?usp=sharing](https://drive.google.com/drive/folders/1C7lGt5JfU85dYK1HBdGv-PUQkWZd83-d?usp=sharing)&nbsp;

&nbsp;

fazer a instalaão assistida&nbsp;

aqui da pra abrir e fazer a instalação assistida ate o passo&nbsp;

[https\://docs.google.com/document/d/1UfYb34DWgM4AMqLU7PB9HepzC-d8zW9e/edit\#heading=h.9q1vjsr1g06t](https://docs.google.com/document/d/1UfYb34DWgM4AMqLU7PB9HepzC-d8zW9e/edit#heading=h.9q1vjsr1g06t)&nbsp;

&nbsp;

&nbsp;

&nbsp;

```sh
node --version
npm --version
docker version
docker compose version
```

Extrair o ZIP em uma pasta nova e abrir o terminal na pasta que contém README, package.json, apps e scripts. Se usar GitHub, criar uma cópia própria por “Use this template” ou clonar o repositório informado pelo professor.

**No Windows:** o ZIP já contém uma pasta `crm-alunos-template`. Abrir essa pasta no editor e usar **Terminal → Novo terminal**. Conferir que o terminal está na raiz do projeto; não entrar uma segunda vez em `crm-alunos-template` se já estiver lá.

**Checkpoint:** ferramentas respondem, Docker está ativo e o aluno consegue identificar a raiz do projeto. No PowerShell, se npm.ps1 estiver bloqueado, usar `npm.cmd` em vez de mudar a política do computador.

### 4\. Criar a configuração da instalação — 10 minutos

```sh
npm run setup
```

**Mostrar:** nome da empresa, e-mail do administrador e aviso da senha inicial. Explicar que o instalador cria `.env` e `setup.config.json` e gera chaves e senhas novas. Guardar a senha inicial sem mostrá-la na gravação ou compartilhar com a turma.

**Distinguir:**

- `.env.example` e `setup.config.example.json`: referências que podem ser distribuídas.  
- `.env` e `setup.config.json`: arquivos preenchidos de uma instalação.  
- `AUTH_SECRET`: assinatura de sessão.  
- `SECRETS_KEY`: criptografia das credenciais cadastradas no painel.  
- `META_WEBHOOK_VERIFY_TOKEN`: verificação inicial do callback Meta.

**Checkpoint:** arquivos criados, canais desligados e nenhum token externo pré-preenchido. Reexecutar setup não sobrescreve a instalação.

### 5\. Instalar dependências e subir a infraestrutura — 15 minutos

```sh
npm run deps
docker compose up -d --wait
docker compose ps
```

**Explicar:** `npm ci` instala pelo lockfile; o projeto bloqueia scripts automáticos e gera explicitamente o cliente Prisma. O Compose sobe PostgreSQL com pgvector e Redis com senhas da própria instalação.

Esperar cada comando terminar antes do seguinte. Mensagens de `funding`, depreciação ou “Update available” não indicam necessariamente erro. Não executar as sugestões de atualização de versão principal do Prisma/Next durante a aula; manter as versões do lockfile.

**Mostrar:** estados `healthy`, portas locais `55432` e `56379` e volumes persistentes. Explicar que os bancos ficam vinculados a `127.0.0.1` para uso local.

**Checkpoint:** ambos os serviços saudáveis. Se houver conflito de porta, alterar também a URL correspondente no `.env`, conforme PROBLEMAS.md.

### 6\. Criar tabelas, entrar e personalizar a empresa — 15 minutos

```sh
npm run db:init
npm run doctor
npm run dev
```

Abrir `http://localhost:3100`, entrar com a conta recém-criada e trocar a senha em **Trocar senha**. Depois, limpar `AUTH_INITIAL_EMAIL` e `AUTH_INITIAL_PASSWORD` do ambiente; o usuário já está armazenado no banco.

**Terminal do servidor:** `npm run dev` continua executando e ocupa o terminal. Mantê-lo aberto e usar um segundo terminal na mesma pasta para outros comandos. A primeira abertura de uma página pode mostrar compilação. Após editar `.env`, encerrar o servidor com `Ctrl+C`, executar `npm run dev` novamente e conferir o login com a senha nova. Em telas estreitas, abrir **Abrir menu** no topo para encontrar os itens da navegação.

**Mostrar em Geral:** marca, razão social, e-mails, URL de acesso do produto, mensagem de transferência, fuso e tempo de agrupamento. Salvar e conferir a marca no painel. Manter os canais desligados até concluir a configuração.

**Mostrar as páginas públicas:** `/privacy` e `/data-deletion`. Explicar que são modelos e devem refletir o negócio e o procedimento real de atendimento a solicitações de exclusão.

**Checkpoint:** login funciona, dashboard está vazio, doctor aprova as conexões e a marca foi salva.

### 7\. Configurar chave de IA, agente e catálogo — 25 minutos

1. Abrir **Chaves de API** e cadastrar uma chave própria, sem mostrar o token.  
2. Abrir **Agentes** e editar o SDR de exemplo.  
3. Selecionar o provedor correspondente e informar um ID de modelo disponível na API da conta.  
4. Adaptar objetivo, tom, perguntas, limites e critérios de transferência.  
5. Manter um agente padrão usando **Default?** ligado e clicar em **Salvar**; conferir que o agente aparece na lista com o provedor/modelo escolhidos.  
6. Abrir **Cursos → Novo curso** para cadastrar o produto fictício: nome, slug único em letras minúsculas/números/hífen, preço em reais, descrição, garantia e formas de pagamento. Usar conteúdo claramente ilustrativo. Deixar checkout vazio se não houver um link real; no exercício, `example.com` pode identificar explicitamente um endereço fictício. Salvar e conferir nome e preço na lista.

**Chave salva não é conexão testada:** o formulário confirma armazenamento criptografado, mas não valida saldo ou disponibilidade do modelo. Sem uma chave própria, é possível terminar a exploração local, editar o agente e cadastrar o catálogo com canais desligados; registrar a chamada real de IA como pendente.

**Fala sugerida:** “O prompt define a forma de atender. Catálogo e base de conhecimento fornecem os fatos. As permissões e ações continuam sendo controladas pelo código.”

**Explicar:** assinatura de um chat não equivale a crédito de API. Qualificação, auditoria e embeddings podem usar chamadas separadas. O template começa com as automações avançadas desligadas; ativá-las exige rever modelos, chaves e custos.

**Exercício:** adaptar o agente para o produto do aluno e escrever cinco perguntas de teste, incluindo uma informação que o catálogo não contém. Usar AGENTES.md como referência.

**Ponto de parada para ensaio somente local:** painel, configurações, agente e catálogo devem estar salvos; canais permanecem desligados. A etapa 8 começa a configuração externa da Meta e do túnel HTTPS. A instalação do painel pode ser validada antes dela.

### 8\. Preparar Meta e testar com HTTPS local — 25 a 40 minutos

**Roteiro executável:** seguir [Conectar seu Business, WhatsApp e Instagram](http://META.md) na ordem. Os 25–40 minutos pressupõem conta Meta, aplicativo e ativos já criados; análise de permissões e liberação do número podem levar mais tempo.

1. Conferir `http://localhost:3100/api/health`, acesso de administrador e canais desligados em **Geral**.  
2. Criar/selecionar o aplicativo Meta do proprietário da instalação; copiar App ID/App Secret de **Configurações → Básico** para **Meta / Business** no CRM. Se a instalação for para um cliente, o cliente precisa configurar ou delegar acesso ao aplicativo e aos ativos. O guia META.md detalha as opções para o aluno sem acesso ao portfólio dele.  
3. Para WhatsApp, anotar **Phone Number ID** e **WABA ID** distintos, autorizar um destinatário de teste e cadastrar token temporário ou de usuário de sistema com os ativos/permissões corretos. Para Instagram, vincular conta profissional à Página, obter via **Graph API Explorer → `/me/accounts?fields=id,name,access_token,tasks,instagram_business_account`** o ID e token **da Página correta** e o ID técnico do Instagram; preencher os três campos no CRM.  
4. Instalar/autenticar ngrok conforme o guia, manter `npm run dev` e `ngrok http 3100` em terminais separados, copiar a URL HTTPS e abrir `https://SEU-ENDERECO-PUBLICO/api/health`.  
5. Atualizar as duas URLs no `.env`, reiniciar `npm run dev` e conferir em **Onboarding → Canais → Status** que as URLs dos webhooks usam o túnel.  
6. Registrar os callbacks e o **mesmo Verify Token** no produto correspondente do aplicativo Meta. Verificar e salvar; assinar `messages` no WhatsApp e os eventos de mensagens/postbacks do Instagram.  
7. Em **Onboarding → Canais**, clicar **Status** e **Verificar subscription**. O WhatsApp assina a **WABA**; o Instagram assina a **Página**. Conferir também o painel Meta.  
8. Ativar um canal em **Geral** e enviar mensagem real de outra conta autorizada. Registrar evidência de entrada no CRM e de resposta no canal.

**Antes de digitar tokens:** apresentar a tabela de campos em META.md e distinguir App ID, App Secret, WABA ID, Phone Number ID, Página e Instagram profissional.

**Mostrar no CRM:** Meta / Business, campos protegidos, precedência dos valores do painel e preservação de um campo vazio. Não usar o botão de remover credenciais durante uma configuração válida.

Para um teste local, manter o CRM aberto e encaminhar um túnel HTTPS à porta 3100\. Exemplo, se ngrok já estiver instalado e autenticado:

```sh
ngrok http 3100
```

Atualizar no `.env` e reiniciar o app:

```dotenv
NEXT_PUBLIC_APP_URL=https://SEU-ENDERECO-PUBLICO
PUBLIC_BASE_URL=https://SEU-ENDERECO-PUBLICO
```

&nbsp;

**Callbacks:**

```
https://SEU-ENDERECO-PUBLICO/api/webhooks/whatsapp-cloud
https://SEU-ENDERECO-PUBLICO/api/webhooks/instagram
```

Registrar o Verify Token igual no CRM e na Meta para cada callback, assinar os eventos pertinentes e verificar a inscrição do aplicativo nos ativos. Usar **Onboarding → Canais** para conferir status e subscription. O botão de status não confirma a entrega de mensagens; o teste real do item 8 é obrigatório.

**Checkpoint:** handshake confirmado. Ativar o canal em Geral e enviar uma mensagem real de uma conta autorizada. Conferir tanto a conversa no painel quanto a resposta no aplicativo de origem.

**Se a conta ainda não estiver liberada:** registrar a pendência específica e continuar a aula com a aplicação configurada. Não afirmar que o canal está operacional só porque um teste de webhook ou uma consulta de token funcionou.

## Sessão 2 — publicar e operar no Railway

### 9\. Preparar a versão que será publicada — 15 minutos

**Explicar:** sair do desenvolvimento local significa criar serviços remotos com ambiente e persistência próprios. Não se publica o `.env` local nem os dados do professor.

**Conferir antes do envio:**

```sh
npm run audit
npm run test:security
npm run test:template
npm run check:distribution
git status
```

Para testar a aplicação completa, com Docker ativo:

```sh
npm run test:app
```

**Mostrar:** lockfile versionado, overrides de segurança documentados, ausência de configuração preenchida no conjunto de arquivos enviados e repositório de destino próprio.

Se o aluno recebeu apenas ZIP, pode criar um repositório seu usando a interface do editor/GitHub. Para quem já usa Git, na pasta correta:

```sh
git init
git add .
git diff --cached --stat
git status
git commit -m "Configura meu CRM"
```

Antes do commit, revisar o que foi adicionado. Adicionar o endereço do **próprio repositório** como remoto e enviar a branch que o aluno estiver usando. Não fornecer um comando com o remoto de outra instalação. Não ignorar arquivos suspeitos só porque a pasta tem um `.gitignore`.

### 10\. Criar projeto e banco PostgreSQL com pgvector — 15 minutos

1. Criar um projeto novo na conta Railway do aluno.  
2. Adicionar PostgreSQL por um template que inclua pgvector.  
3. Nomear o serviço `Postgres` para acompanhar os exemplos.  
4. Conferir o volume persistente e a conexão privada disponibilizada pelo serviço.  
5. Explicar que desligar RAG não elimina a exigência de pgvector no schema atual.

**Checkpoint:** banco implantado, com volume e biblioteca pgvector disponível. Não adaptar a aula para um banco sem suporte à extensão só para fazer a primeira tela abrir.

### 11\. Adicionar Redis e explicar a persistência — 10 minutos

Adicionar Redis no mesmo projeto e conferir sua `REDIS_URL`, volume, persistência AOF e política `noeviction`, conforme a imagem/serviço escolhido. A configuração do Compose local não é automaticamente aplicada a esse serviço remoto.

**Mostrar:** Redis atende filas e coordenação; apagá-lo pode perder trabalhos pendentes e estados temporários. Não compartilhar o mesmo Redis entre empresas apenas trocando o prefixo de debounce.

**Checkpoint:** serviço disponível na rede privada e configuração operacional revisada. Não gerar um domínio HTTP público para o banco ou para Redis.

### 12\. Adicionar o CRM e suas variáveis — 20 minutos

1. Adicionar o serviço CRM a partir do repositório próprio.  
2. Manter a raiz de build em `/`, pois o Dockerfile usa arquivos da raiz e de `apps/web`.  
3. Usar Dockerfile e railway.toml fornecidos.  
4. Montar um volume próprio da aplicação em `/app/data` para a configuração feita no painel.  
5. Começar com uma réplica e workers ligados.

No serviço **CRM**, criar as referências:

```dotenv
DATABASE_URL=${{Postgres.DATABASE_URL}}
REDIS_URL=${{Redis.REDIS_URL}}
```

&nbsp;

Se o serviço tiver outro nome, selecionar o nome real no painel. Essas expressões são resolvidas pelo Railway, não pelo `.env` local.

**Configurar também:** `AUTH_SECRET`, `SECRETS_KEY`, `AUTH_INITIAL_EMAIL`, `AUTH_INITIAL_PASSWORD`, `META_WEBHOOK_VERIFY_TOKEN`, `META_GRAPH_VERSION`, `ENABLE_WORKER=true` e `SETUP_CONFIG_PATH=/app/data/setup.config.json`.

Gerar chaves novas, diferentes entre si, usando o terminal sem expor o resultado na aula:

```sh
node -e "console.log(require('node:crypto').randomBytes(32).toString('hex'))"
```

**Ponto de atenção:** não colocar segredos em variáveis `NEXT_PUBLIC_*`; não manter `SKIP_INSTRUMENTATION=true` no ambiente publicado. Tokens Meta e chaves de conversa podem ser cadastrados depois pelo painel.

### 13\. Acompanhar build, migrations e primeiro início — 15 minutos

Abrir separadamente os logs de build, pre-deploy e runtime.

O pre-deploy já configurado é:

```sh
npm --prefix apps/web run db:migrate:deploy && npm --prefix apps/web run db:seed
```

**Explicar:** migrations preparam o schema antes do novo servidor; seed cria os registros iniciais sem importar dados reais. O volume não está montado no pre-deploy. O arquivo de configuração é inicializado quando o servidor começa, no volume `/app/data`.

**Checkpoint:** pre-deploy sem erro, servidor pronto, `workers.started` e `schedulers.registered` nos logs. Se uma migration falhar, resolver a causa antes de tentar liberar o canal.

### 14\. Gerar domínio HTTPS e finalizar a configuração — 15 minutos

1. Gerar um domínio público do serviço CRM no Railway.  
2. Preencher `NEXT_PUBLIC_APP_URL` e `PUBLIC_BASE_URL` com o endereço HTTPS completo.  
3. Fazer redeploy para aplicar as variáveis.  
4. Abrir `/api/health` e a tela de login.  
5. Entrar, trocar a senha inicial, remover as variáveis de bootstrap e preencher empresa, agentes e chaves no ambiente hospedado.  
6. Conferir privacidade e exclusão no domínio público.

Se quiser domínio próprio, adicioná-lo no Railway e seguir os registros DNS mostrados pelo painel do serviço. Não inventar IP ou destino CNAME. Depois de validar o domínio, atualizar as duas URLs da aplicação e os callbacks Meta.

**Checkpoint:** login por HTTPS e configuração persistente após reinício. O healthcheck confirma processo HTTP ativo; não é uma certificação de conexão com todos os serviços externos.

### 15\. Mover os callbacks Meta para a publicação — 15 a 25 minutos

Trocar os callbacks temporários do túnel pelos callbacks do domínio publicado:

```
https://SEU-DOMINIO/api/webhooks/whatsapp-cloud
https://SEU-DOMINIO/api/webhooks/instagram
```

Conferir Verify Token, assinatura com App Secret, campos inscritos e vínculo do app com WABA/Página. Revisar modo de desenvolvimento, papéis de teste, permissões e exigências Meta para atender público externo.

**Demonstração:** fechar o servidor local e enviar uma mensagem à instalação hospedada. Confirmar que a conversa e a resposta continuam acontecendo no domínio remoto. Isso distingue uma publicação funcional de um painel que ainda depende do computador do aluno.

### 16\. Testes de aceitação antes de liberar — 20 minutos

| Cenário | Evidência que o aluno deve apresentar |
| :---- | :---- |
| Login e marca | Conta própria entra e identidade está correta |
| Persistência | Configuração permanece após reinício/redeploy |
| WhatsApp | Mensagem real autorizada entra e resposta chega ao remetente |
| Instagram | Mensagem real autorizada entra e resposta chega ao remetente |
| Agrupamento | Três mensagens próximas são tratadas conforme a janela configurada |
| Informação fora do catálogo | Agente não inventa preço ou política |
| Pedido de pessoa | Transferência e pausa da IA funcionam no fluxo escolhido |
| Janela de mensagens | Respeito às regras do canal e uso de template aprovado quando aplicável |
| Mídia | Comportamento suportado ou fallback claro, sem promessa de interpretação não implementada |
| Erro de serviço | Operador identifica a falha pelo painel/log e sabe corrigir a configuração |

Só marcar um canal como concluído quando houver evidência real com a própria conta. Um canal que o aluno decidiu não usar deve permanecer desativado.

### 17\. Operação, custos e backup — 15 minutos

**Explicar:** Railway, provedor de IA e Meta têm uso e cobrança próprios. Conferir preços atuais, limites, alertas e consumo na conta de cada serviço. Não apresentar o template como hospedagem ou API gratuita garantida.

**Mostrar onde acompanhar:** logs do CRM, filas, erros Redis, disponibilidade dos serviços, painel de consumo e saldo/limites do provedor de IA. Mencionar que estimativas internas de custo podem diferir da cobrança real.

**Backup:** PostgreSQL, configuração do volume, dados operacionais do Redis e segredos do ambiente. Guardar `SECRETS_KEY` com segurança, separada do dump; sem a chave correta, as credenciais cifradas precisam ser recadastradas.

**Atualização:** testar uma cópia separada, fazer backup, revisar dependências/migrations e acompanhar pre-deploy. Os testes automatizados usam serviços próprios e nunca devem apontar para um banco que contém atendimentos reais.

## Encerramento e entrega do aluno — 10 minutos

Cada aluno entrega o endereço HTTPS, o repositório próprio se houver, um registro dos testes de aceitação e uma lista objetiva de pendências. Não deve entregar `.env`, tokens, senhas, dumps ou capturas de variáveis.

**Exercício final:** personalizar um agente e um produto próprios, publicar a instância, testar um canal autorizado e explicar com suas palavras por que PostgreSQL e Redis são serviços diferentes.

**Perguntas para revisar:**

1. Onde ficam as conversas? Onde ficam os trabalhos pendentes?  
2. Por que a Meta precisa de uma URL HTTPS pública?  
3. Qual é a diferença entre App Secret, Verify Token e token de acesso?  
4. O que acontece se trocar `SECRETS_KEY` sem recadastrar/recriptografar as chaves?  
5. Como provar que a versão hospedada funciona sem o computador local?  
6. Como preparar uma cópia limpa para outra pessoa?

## Roteiro rápido de diagnóstico durante a aula

| Sintoma | Primeira verificação |
| :---- | :---- |
| Docker não conecta | Docker Desktop/Engine realmente iniciado |
| Banco não autentica | Senha e URL correspondem ao volume já inicializado |
| pgvector indisponível | Imagem/template do PostgreSQL possui a extensão |
| Falha no build | Node suportado, lockfile, instalação completa e logs de compilação |
| Não há usuário para login | Seed e variáveis de primeiro acesso |
| Marca some após redeploy | Volume `/app/data` e SETUP\_CONFIG\_PATH |
| Handshake falha | URL HTTPS acessível e Verify Token igual nos dois lados |
| Handshake passa, mensagem é recusada | App Secret/assinatura, canal ativo e inscrição correta |
| Mensagem entra, sem resposta | Provedor, chave, saldo, modelo, agente padrão, regras, Redis e workers |
| Instagram não aparece | Conta profissional, vínculo à Página e token do fluxo correto |

## Referências e manutenção da pauta

Os comandos acompanham os arquivos desta versão. Revise telas, permissões, planos e menus dos serviços antes de gravar uma nova aula.

- [Railway: pre-deploy e acesso ao volume](https://docs.railway.com/deployments/pre-deploy-command)  
- [Railway: PostgreSQL com pgvector](https://docs.railway.com/guides/rag-pipeline-pgvector)  
- [Railway: volumes](https://docs.railway.com/volumes)  
- [Meta: WhatsApp Cloud API](https://developers.facebook.com/docs/whatsapp/cloud-api/get-started)  
- [Meta: Instagram com Facebook Login](https://developers.facebook.com/docs/instagram-platform/instagram-api-with-facebook-login/)

O professor pode demonstrar a infraestrutura com contas preparadas, mas deve distinguir essa demonstração das etapas que ainda dependem de aprovação ou configuração na conta do aluno.