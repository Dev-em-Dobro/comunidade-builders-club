# CRM com IA — template para alunos

Uma instalação independente por negócio. Você baixa o código, cria seu próprio banco e Redis, entra com seu usuário e conecta os ativos da **sua conta Meta**. O pacote contém código e exemplos genéricos; não inclui usuários, conversas, catálogo, senhas, tokens, prompts privados ou histórico Git da instalação que serviu de base.

O CRM recebe **WhatsApp Cloud API e Instagram Direct**. O Facebook Business/portfólio empresarial e a Página Facebook participam da configuração Meta. Mensagens do Facebook Messenger, anúncios, publicação de posts e importação de leads de anúncios **não são canais implementados neste template**.

**Quer instalar com ajuda de um agente de IA?** Abra [Instalação assistida por IA](docs/INSTALACAO_ASSISTIDA.md). Há um prompt único para acompanhar todo o processo e um prompt para cada etapa da pauta. O agente pode executar e conferir comandos locais; nas contas Meta e Railway ele orienta as ações que dependem do titular e registra o que foi realmente testado.

## O que você precisa

- Windows, macOS ou Linux, com terminal e acesso à internet.
- **Node.js 22 LTS, versão 22.16 ou superior da série 22**, com npm 10 ou 11.
- **Docker Desktop aberto** (Windows/macOS) ou Docker Engine com Compose v2 (Linux). No Windows, use containers Linux/WSL2.
- Editor de código, por exemplo VS Code. Git é opcional se você recebeu o ZIP.
- Para ativar atendimento: conta Meta com acesso aos próprios ativos e chave de API de Anthropic ou OpenAI. Assinatura de um aplicativo de chat não substitui crédito de API.
- Para receber webhooks: endereço HTTPS público (túnel de desenvolvimento ou hospedagem). Somente localhost permite explorar o painel; a Meta não alcança sua máquina diretamente.

Confira as ferramentas:

```sh
node --version
npm --version
docker version
docker compose version
```

## 1. Baixar e preparar

Extraia `crm-alunos-template-VERSAO.zip` (ou `crm-alunos-template.zip`) em uma pasta só sua. O ZIP já contém a pasta `crm-alunos-template`. Abra essa pasta no editor e crie um terminal **dentro da pasta que contém este README, package.json, apps e scripts**. Se já estiver nessa raiz, não execute outro `cd crm-alunos-template`.

Se o professor disponibilizou um repositório, clone o endereço informado por ele ou utilize “Use this template” no GitHub. O pacote não contém um endereço de repositório de produção.

```sh
npm run setup
```

O assistente solicita o nome da empresa e seu e-mail. Ele cria:

- `.env`: conexões locais, senha inicial de administrador e chaves aleatórias novas.
- `setup.config.json`: identidade e comportamento da sua instância.
- Uma senha de acesso mostrada uma única vez no terminal. Guarde-a em um gerenciador de senhas.

O setup se recusa a sobrescrever uma instância existente. Nenhuma credencial Meta ou de IA vem pré-configurada. Todos os canais, follow-ups, qualificação automática e auditoria começam desligados.

## 2. Instalar dependências

```sh
npm run deps
```

O comando usa `npm ci` com o lockfile e scripts de instalação desativados; depois gera explicitamente o cliente Prisma. Não misture npm, pnpm e yarn nesta instalação. Não é necessário instalar Prisma globalmente.

Aguarde o comando terminar antes de seguir. Avisos de depreciação, `funding` ou sugestões de atualização não são, por si, falhas de instalação. Não execute sugestões de atualização de versão principal do Prisma/Next durante este roteiro; mantenha o lockfile validado.

## 3. Subir PostgreSQL e Redis

Com o Docker aberto, execute na raiz:

```sh
docker compose up -d --wait
docker compose ps
```

Os dois serviços devem ficar `healthy`. O Compose cria volumes próprios, senhas próprias e portas limitadas à sua máquina:

| Serviço | Endereço local padrão | Papel |
|---|---|---|
| PostgreSQL 16 com pgvector | `127.0.0.1:55432` | Dados permanentes e busca por similaridade |
| Redis 7 | `127.0.0.1:56379` | Filas, trabalhos agendados e agrupamento de mensagens |
| CRM | `127.0.0.1:3100` | Painel, API e execução dos workers |

As senhas no `.env` são preenchidas automaticamente. Não é preciso criar tabelas manualmente. A primeira migration instala a extensão `vector` na imagem que já inclui pgvector.

Se alguma porta estiver ocupada, veja [problemas comuns](docs/PROBLEMAS.md). Para duas instalações simultâneas, altere também o nome do projeto Compose, portas e URLs; cada negócio precisa de banco e Redis independentes.

## 4. Criar tabelas e primeiro acesso

```sh
npm run db:init
npm run doctor
npm run dev
```

Abra [http://localhost:3100](http://localhost:3100). Entre com o e-mail e a senha mostrada pelo setup. O seed cria apenas o administrador, um agente SDR genérico e duas regras de exemplo; não cria leads nem produtos.

`npm run dev` mantém o terminal ocupado: isso é esperado. Deixe esse terminal aberto enquanto usa o CRM. Para outros comandos, abra um segundo terminal na mesma raiz. No primeiro acesso, aguarde a compilação da página. Se a janela for estreita, use **Abrir menu** no topo para acessar a navegação.

`doctor` verifica as conexões, extensão pgvector e existência do administrador sem mostrar senhas. Se alguma etapa falhar, resolva antes de conectar canais.

Depois do primeiro login:

1. Troque sua senha em **Trocar senha**.
2. Remova os valores de `AUTH_INITIAL_EMAIL` e `AUTH_INITIAL_PASSWORD` do `.env`. O login normal usa o hash já armazenado no banco.
3. Abra **Configurações → Geral**. Preencha marca, razão social, e-mails, fuso horário, URL de acesso do seu produto e mensagem de transferência.
4. Revise `/privacy` e `/data-deletion`. São modelos de texto e procedimento, não uma rotina automática de exclusão de dados. Ajuste-os ao processo real do seu negócio.

Depois de editar `.env`, pare o servidor com `Ctrl+C` e execute `npm run dev` novamente para carregar o ambiente atualizado. Confira que consegue entrar com a senha nova.

## 5. Configurar sua inteligência artificial

1. Crie sua chave na conta de API do provedor escolhido e habilite crédito/limites nessa conta.
2. Abra **Chaves de API** e salve a chave de Anthropic ou OpenAI. Ela fica criptografada no PostgreSQL com `SECRETS_KEY`.
3. Abra **Agentes**, edite “Agente SDR (exemplo)” e selecione o mesmo provedor da chave cadastrada.
4. Informe o **ID exato de um modelo disponível na API da sua conta**. O campo aceita um modelo personalizado; identificadores e disponibilidade mudam entre provedores.
5. Adapte o prompt: o que sua empresa oferece, tom de voz, perguntas, limites, próximos passos e situações de transferência. Mantenha um agente padrão.
6. Cadastre apenas seus próprios cursos/produtos, links e políticas no catálogo. Os nomes de telas e algumas regras de qualificação ainda seguem um domínio de venda de cursos.

O catálogo está em **Cursos → Novo curso**. Informe nome, slug único (letras minúsculas, números e hífen), preço em reais, descrição e políticas reais. Deixe o checkout vazio se ainda não existir um link válido. Salve e confira a lista. Em **Agentes**, use **Editar** no agente de exemplo e mantenha o controle **Default?** ligado para o agente principal.

“Chave salva” confirma armazenamento criptografado; não verifica saldo, acesso ao modelo nem uma resposta real do provedor. Sem uma chave própria, você pode explorar o painel, editar agentes e cadastrar o catálogo mantendo os canais desligados. O teste real de IA fica pendente até cadastrar e usar uma chave válida.

O guia [Personalizar agentes](docs/AGENTES.md) traz um exemplo de prompt, papéis de SDR/closer/suporte, regras, catálogo e RAG. Para testar atendimento sem custo inesperado, mantenha os canais desligados até concluir esse cadastro.

## 6. Conectar seu Facebook Business, WhatsApp e Instagram

Siga o [guia Meta completo](docs/META.md). Ele explica:

- Criar seu aplicativo e usar seu próprio Business/portfólio empresarial.
- Diferenciar App ID, App Secret, ID do número, WABA ID, ID da Página e ID do Instagram.
- Obter tokens com acesso aos seus ativos.
- Obter o token de Página do Instagram pelo Graph API Explorer e assinar o webhook WhatsApp na WABA correta.
- Usar **Instagram API com Facebook Login**, conta profissional e Página vinculada.
- Cadastrar e verificar os dois webhooks HTTPS.
- Testar contas autorizadas em desenvolvimento e verificar as exigências Meta antes de atender público externo.

As credenciais podem ser cadastradas em **Meta / Business** no painel. Campos vazios preservam os valores existentes. O painel mostra apenas se o campo está configurado e sua origem; não devolve os tokens gravados. Valores do painel têm prioridade sobre as variáveis de ambiente.

O setup gera `META_WEBHOOK_VERIFY_TOKEN` no `.env`. Copie esse valor para a Meta, sem as aspas do arquivo. Esse token não é o App Secret nem o token de acesso. Também é possível substituí-lo pelo painel; nesse caso atualize o mesmo valor na Meta.

Somente depois das verificações, ative os canais em **Geral** e envie uma mensagem real usando outra conta. Confira recebimento, resposta e transferência para humano. A conexão de credenciais isoladamente não comprova a entrega de um webhook.

## 7. Entender e adaptar a infraestrutura

Leia [Arquitetura, PostgreSQL e Redis](docs/ARQUITETURA.md). O guia explica por que há dois serviços, onde cada dado fica, como ajustar o debounce, quais funções dependem de workers e o que precisaria mudar para substituir algum componente.

Você pode aprender e desenvolver localmente. Para manter o CRM disponível 24 horas, use um servidor sempre ligado. O passo a passo em [Hospedar no Railway](docs/RAILWAY.md) configura:

1. Projeto próprio e três serviços: CRM, PostgreSQL **com pgvector** e Redis.
2. Variáveis de referência por rede privada.
3. Volume `/app/data` para preservar configurações feitas no painel.
4. Migrations e seed em pre-deploy, domínio HTTPS e webhooks.
5. Persistência, backup, logs, limites e atualização da instalação.

Não há deploy automático na conta do professor. Cada aluno configura e custeia sua própria infraestrutura e os provedores que utilizar.

## Comandos do dia a dia

Execute na raiz:

| Comando | O que faz |
|---|---|
| `npm run setup` | Cria uma instância local nova, sem sobrescrever arquivos |
| `npm run deps` | Instala dependências fixadas e gera o cliente Prisma |
| `docker compose up -d --wait` | Inicia banco e Redis e aguarda saúde |
| `npm run db:init` | Aplica migrations e executa seed idempotente |
| `npm run doctor` | Diagnóstico local sem mostrar credenciais |
| `npm run dev` | Desenvolvimento em localhost:3100 |
| `npm run build` | Compila a aplicação |
| `npm start` | Serve o build localmente em localhost:3100 |
| `npm run db:migrate` | Aplica migrations pendentes |
| `npm run db:seed` | Cria o admin inicial/agente se ainda não existirem |
| `docker compose stop` | Para PostgreSQL e Redis preservando dados |
| `docker compose start` | Retoma os mesmos containers e dados |
| `npm run test:app` | Sobe serviços exclusivos de teste e roda a suíte da aplicação |
| `npm run test:template` | Verifica instalador e regras de distribuição |
| `npm run test:security` | Confere dependências corrigidas e compatibilidade de Prisma/ESLint |
| `npm run audit` | Audita todas as dependências, inclusive desenvolvimento |
| `npm run check:distribution` | Inspeciona arquivos permitidos e padrões de segredos |
| `npm run package` | Exige auditoria e testes de segurança aprovados e gera ZIP em `release/` |

`Ctrl+C` encerra o servidor local. `docker compose down` remove containers e rede, preservando os volumes nomeados. **Não use `docker compose down -v` se precisar manter os dados: `-v` exclui os volumes.**

## Organização do código

```text
apps/web/src/app/          telas, ações e APIs
apps/web/src/lib/channels/ adaptadores Meta
apps/web/src/lib/llm/      provedores de IA
apps/web/src/lib/queue/    filas, workers e agendamentos
apps/web/src/lib/rag/      busca em documentos
apps/web/prisma/           schema, migrations e seed neutro
scripts/                  instalador, diagnóstico e empacotamento
docs/                     guias para alunos
.env.example              referência de variáveis, sem senhas
setup.config.example.json comportamento padrão, sem dados reais
docker-compose.yml        infraestrutura local
Dockerfile + railway.toml infraestrutura da aplicação hospedada
```

Os exemplos são pt-BR. Esta aplicação é de **uma empresa por instalação**, sem isolamento SaaS entre clientes no mesmo banco. O ponto de partida mais simples é uma única réplica do CRM com workers ligados. Algumas heurísticas e telas são orientadas a cursos; adaptar para outro mercado pode exigir mudar código além do prompt.

Para distribuir sua própria versão, siga [Empacotamento e publicação](docs/DISTRIBUICAO.md). A licença MIT mantém o aviso de autoria do código original; esse aviso público não é uma credencial nem uma conexão com o ambiente de origem.

Para ministrar uma aula ou acompanhar a instalação, use a [pauta completa de configuração e publicação](docs/PAUTA_CONFIGURACAO_PUBLICACAO.md), com demonstrações, exercícios e critérios de conclusão. As correções de dependências estão descritas em [Segurança das dependências](docs/SEGURANCA_DEPENDENCIAS.md), e os resultados das verificações em [Validação](docs/VALIDACAO.md).

Veja também o [teste de instalação do zero no Windows](docs/TESTE_INSTALACAO_LOCAL.md), realizado até o início da etapa Meta.
