# Fluxo de Trabalho

1. **Crie** um arquivo `index.html` com Tailwind CSS (via CDN), com todo o conteúdo inline. Use arquivos externos só se o usuário pedir.
2. **Tire um print** da página renderizada com Puppeteer (`npx puppeteer screenshot index.html --fullpage` ou algo equivalente). Se a página tiver seções bem definidas, faça prints separados de cada uma também.
3. **Compare** o print com a imagem de referência e procure diferenças em:
   - Cores (valores hex exatos)
   - Tamanho, peso e altura de linha das fontes
   - Espaçamentos e paddings (medidos em px)
   - Alinhamento e posicionamento
   - Tamanho e posição de imagens e ícones
   - Arredondamento de bordas, sombras e efeitos
   - Comportamento responsivo
4. **Corrija** cada diferença encontrada, editando o HTML e as classes do Tailwind.
5. **Tire um novo print** e compare de novo.
6. **Repita** os passos 3 a 5 até que tudo esteja a no máximo ~2–3px da referência.

Faça no máximo 2 rodadas (print → comparar → corrigir). Depois da 2ª, pare e liste o que ainda difere. Só continue se o usuário pedir.
