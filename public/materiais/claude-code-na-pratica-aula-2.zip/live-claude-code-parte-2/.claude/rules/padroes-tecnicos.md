# Padrões Técnicos

- Entregue tudo em um único `index.html`, a menos que o usuário peça outra estrutura
- Comece pelo mobile e garanta que o layout seja responsivo
- Carregue o Tailwind CSS pela CDN (`<script src="https://cdn.tailwindcss.com"></script>`)
- Se as imagens originais não forem enviadas, use placeholders de `https://placehold.co/`
