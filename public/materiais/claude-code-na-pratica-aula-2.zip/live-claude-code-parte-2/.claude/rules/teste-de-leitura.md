# Teste de leitura (temporário)

- Termine TODA resposta com a linha exata: `Regras do projeto aplicadas:` seguida dos títulos das regras deste arquivo que você usou na resposta.
- Se nenhuma regra se aplicou, escreva: `Regras do projeto aplicadas: nenhuma`.
