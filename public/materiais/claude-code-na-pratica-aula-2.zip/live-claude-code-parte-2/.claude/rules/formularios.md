---
paths:
  - "**/*.html"
---

# Formulários

- Todo campo deve ter um rótulo visível ligado ao input.
- Campos de e-mail devem usar type="email".