# Princípios

- Seja fiel à referência: nada de "melhorar" o design por conta própria
- Não inclua seções, recursos ou conteúdos que não aparecem na imagem de referência
- Se o usuário passar classes CSS ou tokens de estilo, aplique exatamente como vieram
- Ao comparar prints, aponte o problema com precisão (ex.: "o espaçamento entre os cards está em 16px, mas deveria ser 24px", "o título está com 32px e na referência tem 24px")
- Mantenha o código organizado, sem abstrair demais: classes do Tailwind direto no HTML estão ok
