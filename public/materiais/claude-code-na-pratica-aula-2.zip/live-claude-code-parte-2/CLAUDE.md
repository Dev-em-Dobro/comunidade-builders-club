# Recriação de Design de Site

Projeto de recriação de designs de site a partir de imagens de referência, entregue em HTML com Tailwind CSS.

As instruções detalhadas estão divididas por assunto em `.claude/rules/`.
