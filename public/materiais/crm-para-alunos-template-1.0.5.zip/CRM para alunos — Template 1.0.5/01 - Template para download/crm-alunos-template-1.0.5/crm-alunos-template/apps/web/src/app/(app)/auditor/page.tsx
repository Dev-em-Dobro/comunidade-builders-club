import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { RunAuditButton } from "./_run-audit-button";

export const dynamic = "force-dynamic";

interface ReportRow {
  id: string;
  runAt: Date;
  status: string;
  conversationCount: number;
  criticalCount: number;
  costUsd: number | null;
}

async function loadReports(): Promise<ReportRow[]> {
  const reports = await prisma.auditReport.findMany({
    orderBy: { runAt: "desc" },
    take: 50,
    select: {
      id: true,
      runAt: true,
      status: true,
      conversationIds: true,
      costUsd: true,
    },
  });
  if (reports.length === 0) return [];

  // Crítico count via groupBy (mais simples e seguro que raw SQL).
  const ids = reports.map((r) => r.id);
  const crits = await prisma.auditFinding.groupBy({
    by: ["reportId"],
    where: {
      reportId: { in: ids },
      verdict: "fail",
      severity: { gte: 4 },
    },
    _count: { _all: true },
  });
  const critMap = new Map(crits.map((c) => [c.reportId, c._count._all]));

  return reports.map((r) => ({
    id: r.id,
    runAt: r.runAt,
    status: r.status,
    conversationCount: r.conversationIds.length,
    criticalCount: critMap.get(r.id) ?? 0,
    costUsd: r.costUsd ? Number(r.costUsd) : null,
  }));
}

export default async function AuditorPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const reports = await loadReports();

  // Há report inflight? Pra desabilitar o botão.
  const since = new Date(Date.now() - 5 * 60 * 1000);
  const inflight = await prisma.auditReport.findFirst({
    where: { status: { in: ["queued", "running"] }, runAt: { gte: since } },
    select: { id: true },
  });

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Auditor de mensagens</h1>
        <div className="flex gap-2">
          <Link
            href="/auditor/criterios"
            className={buttonVariants({ variant: "outline" })}
          >
            Critérios
          </Link>
          <RunAuditButton disabled={Boolean(inflight)} inflightId={inflight?.id ?? null} />
        </div>
      </div>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Conversas</TableHead>
              <TableHead className="text-right">Críticos</TableHead>
              <TableHead className="text-right">Custo</TableHead>
              <TableHead></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {reports.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground">
                  Nenhum relatório ainda. Clica em &quot;Rodar agora&quot; pra criar o primeiro.
                </TableCell>
              </TableRow>
            )}
            {reports.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{r.runAt.toLocaleString("pt-BR")}</TableCell>
                <TableCell>
                  <StatusBadge status={r.status} />
                </TableCell>
                <TableCell className="text-right">{r.conversationCount}</TableCell>
                <TableCell className="text-right">
                  {r.criticalCount > 0 ? (
                    <span className="text-red-600 font-medium">{r.criticalCount}</span>
                  ) : (
                    <span className="text-muted-foreground">0</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  {r.costUsd != null ? `$${r.costUsd.toFixed(4)}` : "—"}
                </TableCell>
                <TableCell>
                  <Link
                    href={`/auditor/${r.id}`}
                    className={buttonVariants({ variant: "outline", size: "sm" })}
                  >
                    Abrir
                  </Link>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    queued:  { label: "na fila",   cls: "bg-gray-100 text-gray-700" },
    running: { label: "rodando",   cls: "bg-blue-100 text-blue-700" },
    done:    { label: "concluído", cls: "bg-green-100 text-green-700" },
    error:   { label: "erro",      cls: "bg-red-100 text-red-700" },
  };
  const m = map[status] ?? { label: status, cls: "bg-gray-100 text-gray-700" };
  return (
    <span className={`inline-block px-2 py-1 rounded text-xs ${m.cls}`}>
      {m.label}
    </span>
  );
}
