import { describe, it, expect } from "vitest";
import { appendUtm } from "./utm";

describe("appendUtm", () => {
  it("adiciona UTMs em URL sem query", () => {
    const url = appendUtm("https://pay.example.com/checkout", {
      utm_source: "wa",
      utm_content: "lead_123",
      utm_campaign: "ingles-avancado",
    });
    expect(url).toBe(
      "https://pay.example.com/checkout?utm_source=wa&utm_content=lead_123&utm_campaign=ingles-avancado",
    );
  });

  it("anexa com & quando URL já tem query", () => {
    const url = appendUtm("https://pay.example.com/checkout?ref=site", {
      utm_source: "wa",
    });
    expect(url).toBe("https://pay.example.com/checkout?ref=site&utm_source=wa");
  });

  it("preserva fragmento (#)", () => {
    const url = appendUtm("https://pay.example.com/checkout#step1", {
      utm_source: "wa",
    });
    expect(url).toBe("https://pay.example.com/checkout?utm_source=wa#step1");
  });

  it("encoda valores com caracteres especiais", () => {
    const url = appendUtm("https://pay.example.com/checkout", {
      utm_campaign: "café & açúcar",
    });
    expect(url).toContain("utm_campaign=caf%C3%A9%20%26%20a%C3%A7%C3%BAcar");
  });

  it("retorna a URL inalterada quando params está vazio", () => {
    const url = appendUtm("https://pay.example.com/checkout", {});
    expect(url).toBe("https://pay.example.com/checkout");
  });
});
