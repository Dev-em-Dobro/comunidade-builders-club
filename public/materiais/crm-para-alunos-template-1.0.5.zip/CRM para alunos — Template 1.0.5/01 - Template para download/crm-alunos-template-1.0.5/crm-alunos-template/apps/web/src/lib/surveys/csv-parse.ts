import Papa from "papaparse";

export interface ParsedRow {
  /** 1-indexed ignorando header. */
  rowNumber: number;
  phoneRaw: string | null;
  emailRaw: string | null;
  submittedAt: Date | null;
  answers: Record<string, string>;
}

export interface ParseError {
  rowNumber: number;
  reason: string;
}

export interface ParseResult {
  rows: ParsedRow[];
  errors: ParseError[];
}

/**
 * Aliases das colunas reservadas. Match por substring no header normalizado
 * (lower + trim) — cobre CSV brasileiro do Google Forms/Typeform/Excel sem
 * forçar o user a renomear coluna.
 *
 * Ordem importa: na ambiguidade ("e-mail confirme" matches "email"), vence o
 * primeiro encontrado, mas só o primeiro match por categoria é setado (ver
 * `parseSurveyCsv`).
 */
const PHONE_ALIASES = ["phone", "telefone", "celular", "whatsapp", "fone"];
const EMAIL_ALIASES = ["email", "e-mail", "e_mail"];
const DATE_ALIASES = [
  "submitted_at",
  "data de envio",
  "data_envio",
  "data envio",
  "timestamp",
  "data resposta",
  "data_resposta",
];

type Reserved = "phone" | "email" | "submitted_at";

/** Devolve a categoria reservada se o header der match por substring; senão null. */
function reservedKey(rawKey: string): Reserved | null {
  const k = rawKey.trim().toLowerCase();
  if (PHONE_ALIASES.some((a) => k.includes(a))) return "phone";
  if (EMAIL_ALIASES.some((a) => k.includes(a))) return "email";
  if (DATE_ALIASES.some((a) => k.includes(a))) return "submitted_at";
  return null;
}

/**
 * Tenta parsear data. Suporta:
 *  - ISO 8601 (`2026-05-12`, `2026-05-12T15:00:00Z`)
 *  - BR `dd/mm/yyyy [hh:mm[:ss] [AM/PM]]`
 * Retorna null se inválido.
 */
function parseSubmittedAt(value: string | undefined | null): Date | null {
  if (!value) return null;
  const s = value.trim();
  if (!s) return null;

  // Tenta BR primeiro: dd/mm/yyyy hh:mm [AM/PM]
  const br = s.match(
    /^(\d{1,2})\/(\d{1,2})\/(\d{4})(?:\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?)?$/i,
  );
  if (br) {
    const [, dd, mm, yyyy, hh, mi, ss, ampm] = br;
    let hours = hh ? parseInt(hh, 10) : 0;
    if (ampm) {
      const isPm = ampm.toUpperCase() === "PM";
      if (isPm && hours < 12) hours += 12;
      if (!isPm && hours === 12) hours = 0;
    }
    const d = new Date(
      parseInt(yyyy!, 10),
      parseInt(mm!, 10) - 1,
      parseInt(dd!, 10),
      hours,
      mi ? parseInt(mi, 10) : 0,
      ss ? parseInt(ss, 10) : 0,
    );
    return Number.isNaN(d.getTime()) ? null : d;
  }

  // Fallback: Date nativo (aceita ISO e variantes)
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? null : d;
}

/**
 * Parse de CSV de respostas de pesquisa.
 * - Header obrigatório; vírgula ou ponto-e-vírgula autodetectado.
 * - Trim de keys do header (`papaparse` faz por `transformHeader`).
 * - Coluna reservada (case-insensitive): `phone`, `email`, `submitted_at`.
 * - Row sem phone nem email → vai pra `errors`, não pra `rows`.
 * - Trim de células; vazias são removidas de `answers`.
 */
export function parseSurveyCsv(csvContent: string): ParseResult {
  const parsed = Papa.parse<Record<string, string>>(csvContent, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim(),
  });

  const rows: ParsedRow[] = [];
  const errors: ParseError[] = [];

  parsed.data.forEach((raw, idx) => {
    const rowNumber = idx + 1;
    let phoneRaw: string | null = null;
    let emailRaw: string | null = null;
    let submittedAt: Date | null = null;
    const answers: Record<string, string> = {};

    for (const [key, value] of Object.entries(raw)) {
      const v = (value ?? "").trim();
      const reserved = reservedKey(key);
      if (reserved === "phone") {
        phoneRaw = v || null;
      } else if (reserved === "email") {
        emailRaw = v || null;
      } else if (reserved === "submitted_at") {
        submittedAt = parseSubmittedAt(v);
      } else if (v.length > 0) {
        answers[key] = v;
      }
    }

    if (!phoneRaw && !emailRaw) {
      errors.push({ rowNumber, reason: "row sem phone nem email" });
      return;
    }

    rows.push({ rowNumber, phoneRaw, emailRaw, submittedAt, answers });
  });

  return { rows, errors };
}
