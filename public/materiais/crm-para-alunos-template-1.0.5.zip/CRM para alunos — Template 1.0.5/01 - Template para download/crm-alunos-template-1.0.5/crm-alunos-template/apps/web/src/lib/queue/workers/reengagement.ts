import { prisma } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import { qualificationConfig, outOfWindowFollowupConfig } from "@/lib/config";
import {
  isReengagementDue,
  isLostByNoResponse,
  REENGAGE_AFTER_MS,
  LOST_AFTER_MS,
  ELIGIBLE_STAGES,
  type ReengagementCandidate,
} from "@/lib/reengagement";
import type { FollowupJobData } from "@/lib/queue/types";

/** Teto de leads avaliados por scan. */
const SCAN_CAP = 500;

/**
 * Processador do job repetível `reengagement.scan` (a cada 30 min).
 *
 * Faz duas varreduras:
 *  1. Leads parados >12h dentro da janela aberta → enfileira `followup.generate`
 *     com `reason='reengagement_12h'`. Claim atômico via `Lead.reengagementSentAt`
 *     (update WHERE NULL) — só quem reivindica de fato enfileira.
 *  2. Leads parados >24h já reengajados → marca `lost(no_response)`.
 *
 * Gated por `qualificationConfig().enabled` — se a qualificação está off, a
 * cadência inteira fica off (são parte da mesma fileira comportamental).
 */
export async function reengagementScanProcessor(): Promise<void> {
  if (!qualificationConfig().enabled) {
    log("reengagement.scan_skipped", { reason: "disabled" });
    return;
  }
  const now = new Date();

  // ── 1. Reengajamento (>12h, janela aberta, não reengajado)
  const reengageCandidates = await prisma.lead.findMany({
    where: {
      stage: { in: [...ELIGIBLE_STAGES] },
      reengagementSentAt: null,
      lastActivityAt: { lt: new Date(now.getTime() - REENGAGE_AFTER_MS) },
    },
    select: {
      id: true,
      stage: true,
      lastActivityAt: true,
      reengagementSentAt: true,
      // Cross-channel: reengaja na conversa mais recente; `reengagementSentAt`
      // no Lead garante 1 tentativa total por lead, mesmo com 2+ canais.
      conversations: {
        where: {
          aiEnabled: true,
          handoffRequested: false,
          windowClosesAt: { gt: now },
        },
        orderBy: { lastMessageAt: "desc" },
        take: 1,
        select: {
          id: true,
          aiEnabled: true,
          handoffRequested: true,
          windowClosesAt: true,
        },
      },
    },
    take: SCAN_CAP,
  });

  let enqueued = 0;
  for (const lead of reengageCandidates) {
    const conv = lead.conversations[0];
    if (!conv) continue;
    const candidate: ReengagementCandidate = {
      leadId: lead.id,
      conversationId: conv.id,
      leadStage: lead.stage,
      lastActivityAt: lead.lastActivityAt,
      reengagementSentAt: lead.reengagementSentAt,
      windowClosesAt: conv.windowClosesAt,
      aiEnabled: conv.aiEnabled,
      handoffRequested: conv.handoffRequested,
    };
    if (!isReengagementDue(candidate, now)) continue;

    // Claim atômico: só prossegue quem virou reengagementSentAt null→now.
    const claimed = await prisma.lead.updateMany({
      where: { id: lead.id, reengagementSentAt: null },
      data: { reengagementSentAt: now },
    });
    if (claimed.count === 0) continue;

    const data: FollowupJobData = {
      conversationId: conv.id,
      reason: "reengagement_12h",
    };
    await enqueue("followup", "generate", data, {
      priority: 1,
      removeOnComplete: true,
      removeOnFail: 50,
    });
    enqueued++;
  }

  // ── 2. Lost por no_response (>24h após reengajamento)
  const lostCandidates = await prisma.lead.findMany({
    where: {
      stage: { in: [...ELIGIBLE_STAGES] },
      reengagementSentAt: { not: null },
      lastActivityAt: { lt: new Date(now.getTime() - LOST_AFTER_MS) },
    },
    select: {
      id: true,
      stage: true,
      lastActivityAt: true,
      reengagementSentAt: true,
      lastFollowUpStep: true,
      qualification: true,
    },
    take: SCAN_CAP,
  });

  const ow = outOfWindowFollowupConfig();
  const lostGuard = {
    enabled: ow.enabled,
    eligibleStages: ow.eligibleStages,
    intervalsDays: ow.intervalsDays,
  };

  let lostMarked = 0;
  for (const lead of lostCandidates) {
    if (
      !isLostByNoResponse(
        {
          leadStage: lead.stage,
          lastActivityAt: lead.lastActivityAt,
          reengagementSentAt: lead.reengagementSentAt,
          audience:
            (lead.qualification as { audience?: string } | null)?.audience ?? null,
          lastFollowUpStep: lead.lastFollowUpStep,
        },
        now,
        lostGuard,
      )
    ) {
      continue;
    }

    // Interactive transaction: o callback executa em uma única tx, e qualquer
    // throw dentro dele faz rollback de TUDO que foi feito antes do throw.
    // Sentinela LOST_CLAIM_LOST_RACE indica "stage já mudou" — esperado em
    // corrida, não é erro real.
    try {
      await prisma.$transaction(async (tx) => {
        const claimed = await tx.lead.updateMany({
          where: { id: lead.id, stage: { in: [...ELIGIBLE_STAGES] } },
          data: { stage: "lost", lostReason: "no_response", lostAt: now },
        });
        if (claimed.count === 0) {
          throw new Error("LOST_CLAIM_LOST_RACE");
        }
        await tx.pipelineEvent.create({
          data: {
            leadId: lead.id,
            type: "stage_change",
            payload: { from: lead.stage, to: "lost", via: "no_response" },
          },
        });
      });
      lostMarked++;
    } catch (err) {
      if ((err as Error)?.message === "LOST_CLAIM_LOST_RACE") {
        // Race esperado: outra mudança de stage chegou primeiro. Tx fez rollback.
        continue;
      }
      log("reengagement.lost_failed", {
        leadId: lead.id,
        error: String((err as Error)?.message ?? err),
      });
    }
  }

  log("reengagement.scan_done", {
    scannedReengage: reengageCandidates.length,
    enqueued,
    scannedLost: lostCandidates.length,
    lostMarked,
  });
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
