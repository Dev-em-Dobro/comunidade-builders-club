import { describe, it, expect } from "vitest";
import { deriveColumn, COLUMN_IDS } from "./columns";

describe("deriveColumn", () => {
  it("retorna 'new' pra stage=new sem follow-up", () => {
    expect(deriveColumn({ stage: "new", lastFollowUpStep: null })).toBe("new");
  });

  it("retorna 'contacted' pra stage=contacted sem follow-up", () => {
    expect(deriveColumn({ stage: "contacted", lastFollowUpStep: null })).toBe(
      "contacted",
    );
  });

  it("retorna 'qualified' pra stage=qualified sem follow-up", () => {
    expect(deriveColumn({ stage: "qualified", lastFollowUpStep: null })).toBe(
      "qualified",
    );
  });

  it("retorna 'proposal' pra stage=proposal sem follow-up", () => {
    expect(deriveColumn({ stage: "proposal", lastFollowUpStep: null })).toBe(
      "proposal",
    );
  });

  it("retorna 'closed' pra stage=won", () => {
    expect(deriveColumn({ stage: "won", lastFollowUpStep: null })).toBe(
      "closed",
    );
  });

  it("retorna 'closed' pra stage=lost", () => {
    expect(deriveColumn({ stage: "lost", lastFollowUpStep: null })).toBe(
      "closed",
    );
  });

  it("retorna 'f1' pra step=1 + stage não-terminal", () => {
    expect(
      deriveColumn({ stage: "contacted", lastFollowUpStep: 1 }),
    ).toBe("f1");
  });

  it("retorna 'f2' pra step=2 + stage qualified", () => {
    expect(
      deriveColumn({ stage: "qualified", lastFollowUpStep: 2 }),
    ).toBe("f2");
  });

  it("retorna 'f3' pra step=3 + stage proposal", () => {
    expect(
      deriveColumn({ stage: "proposal", lastFollowUpStep: 3 }),
    ).toBe("f3");
  });

  it("step não-null em stage terminal (won/lost) → ainda vai pra closed", () => {
    expect(deriveColumn({ stage: "won", lastFollowUpStep: 2 })).toBe("closed");
    expect(deriveColumn({ stage: "lost", lastFollowUpStep: 1 })).toBe("closed");
  });

  it("step inválido (0, 4) cai no stage", () => {
    expect(deriveColumn({ stage: "contacted", lastFollowUpStep: 0 })).toBe(
      "contacted",
    );
    expect(deriveColumn({ stage: "contacted", lastFollowUpStep: 4 })).toBe(
      "contacted",
    );
  });

  it("COLUMN_IDS tem 8 valores na ordem certa", () => {
    expect(COLUMN_IDS).toEqual([
      "new",
      "contacted",
      "qualified",
      "proposal",
      "f1",
      "f2",
      "f3",
      "closed",
    ]);
  });
});
