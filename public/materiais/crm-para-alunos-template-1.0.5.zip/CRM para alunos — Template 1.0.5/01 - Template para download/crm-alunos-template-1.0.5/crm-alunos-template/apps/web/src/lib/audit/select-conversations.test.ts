import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { selectConversations } from "./select-conversations";

const created = {
  contactIds: [] as string[],
  conversationIds: [] as string[],
};

afterAll(async () => {
  await prisma.message.deleteMany({
    where: { conversationId: { in: created.conversationIds } },
  });
  await prisma.conversation.deleteMany({
    where: { id: { in: created.conversationIds } },
  });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

async function mkConvWithMessages(opts: {
  displayName?: string;
  botTurns: number;
  hoursAgo?: number;
}): Promise<string> {
  const contact = await prisma.contact.create({
    data: { displayName: opts.displayName ?? "T" },
  });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud" },
  });
  created.conversationIds.push(conv.id);
  const baseAt = new Date(Date.now() - (opts.hoursAgo ?? 1) * 60 * 60 * 1000);
  for (let i = 0; i < opts.botTurns; i++) {
    await prisma.message.create({
      data: {
        conversationId: conv.id,
        direction: "outbound",
        role: "assistant",
        text: `bot msg ${i}`,
        createdAt: new Date(baseAt.getTime() + i * 1000),
      },
    });
  }
  return conv.id;
}

describe("selectConversations", () => {
  it("retorna array vazio quando não há conversas elegíveis", async () => {
    const r = await selectConversations(24, 5, 99); // minBotTurns absurdamente alto
    expect(r).toEqual([]);
  });

  it("filtra conversas com menos de minBotTurns mensagens da IA", async () => {
    const convOk = await mkConvWithMessages({ displayName: "Maria", botTurns: 3 });
    await mkConvWithMessages({ displayName: "João", botTurns: 1 });
    const r = await selectConversations(24, 5, 2);
    const ids = r.map((c) => c.conversationId);
    expect(ids).toContain(convOk);
    expect(r.find((c) => c.conversationId === convOk)?.displayName).toBe("Maria");
    expect(r.find((c) => c.conversationId === convOk)?.botTurnCount).toBeGreaterThanOrEqual(3);
  });

  it("ignora mensagens fora da janela", async () => {
    const convOld = await mkConvWithMessages({
      displayName: "Antigo",
      botTurns: 5,
      hoursAgo: 100, // muito antigo
    });
    const r = await selectConversations(24, 5, 2);
    const ids = r.map((c) => c.conversationId);
    expect(ids).not.toContain(convOld);
  });

  it("ordena por botTurnCount desc e respeita limit", async () => {
    const a = await mkConvWithMessages({ displayName: "A", botTurns: 5 });
    const b = await mkConvWithMessages({ displayName: "B", botTurns: 3 });
    const c = await mkConvWithMessages({ displayName: "C", botTurns: 4 });
    const r = await selectConversations(24, 2, 2);
    expect(r.length).toBe(2);
    expect(r[0]!.botTurnCount).toBeGreaterThanOrEqual(r[1]!.botTurnCount);
    const ids = r.map((x) => x.conversationId);
    expect(ids).toContain(a);
    expect(ids).toContain(c);
    expect(ids).not.toContain(b);
  });
});
