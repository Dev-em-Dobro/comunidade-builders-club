/**
 * Sincroniza tabela MessageTemplate com a Meta API.
 *
 * Source of truth = Meta. Locais ausentes da Meta são deletados (hard).
 * Se quiser histórico de templates antigos, ver Message.templateMetaName.
 */

import { prisma } from "@/lib/db";
import { listMetaTemplates } from "@/lib/channels/meta-templates";
import { extractBodyText, extractVariableCount } from "./parse";
import type { Prisma } from "@prisma/client";

export interface SyncResult {
  added: number;
  updated: number;
  removed: number;
  total: number;
}

export async function syncTemplatesFromMeta(): Promise<SyncResult> {
  const remote = await listMetaTemplates();

  const local = await prisma.messageTemplate.findMany({
    select: { id: true, metaName: true, language: true, status: true, bodyText: true, category: true },
  });
  const localByKey = new Map(local.map((t) => [`${t.metaName}|${t.language}`, t]));
  const remoteKeys = new Set(remote.map((t) => `${t.name}|${t.language}`));

  let added = 0;
  let updated = 0;

  for (const t of remote) {
    const bodyText = extractBodyText(t.components);
    const variableCount = bodyText ? extractVariableCount(bodyText) : 0;
    const key = `${t.name}|${t.language}`;
    const existing = localByKey.get(key);

    if (!existing) {
      // Upsert (não create) defende contra race: se outra sync paralela já
      // criou esse (metaName, language) no intervalo entre nosso findMany e o
      // write, caímos no update branch silenciosamente em vez de crashar no
      // @@unique. Counter `added` ainda reflete intenção desta call.
      await prisma.messageTemplate.upsert({
        where: {
          metaName_language: {
            metaName: t.name,
            language: t.language,
          },
        },
        create: {
          metaName: t.name,
          language: t.language,
          category: t.category,
          status: t.status,
          components: t.components as unknown as Prisma.InputJsonValue,
          bodyText,
          variableCount,
        },
        update: {
          category: t.category,
          status: t.status,
          components: t.components as unknown as Prisma.InputJsonValue,
          bodyText,
          variableCount,
          syncedAt: new Date(),
        },
      });
      added++;
    } else {
      const changed =
        existing.status !== t.status ||
        existing.bodyText !== bodyText ||
        existing.category !== t.category;
      if (changed) {
        await prisma.messageTemplate.update({
          where: { id: existing.id },
          data: {
            category: t.category,
            status: t.status,
            components: t.components as unknown as Prisma.InputJsonValue,
            bodyText,
            variableCount,
            syncedAt: new Date(),
          },
        });
        updated++;
      } else {
        await prisma.messageTemplate.update({
          where: { id: existing.id },
          data: { syncedAt: new Date() },
        });
      }
    }
  }

  const toRemove = local.filter((t) => !remoteKeys.has(`${t.metaName}|${t.language}`));
  if (toRemove.length > 0) {
    await prisma.messageTemplate.deleteMany({
      where: { id: { in: toRemove.map((t) => t.id) } },
    });
  }

  const total = await prisma.messageTemplate.count();
  return { added, updated, removed: toRemove.length, total };
}
