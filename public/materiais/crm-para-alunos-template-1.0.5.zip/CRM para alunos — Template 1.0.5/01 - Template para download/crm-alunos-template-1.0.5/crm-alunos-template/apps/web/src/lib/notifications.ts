import { prisma } from "@/lib/db";
import { sendEmail } from "@/lib/email/resend";
import { slaConfig } from "@/lib/config";

export interface UserNotice {
  /** categoria — vai pra Notification.type (ex: "sla_breach"). */
  type: string;
  title: string;
  body: string;
  /** dados extras pro payload da Notification (ex: conversationId). */
  payload?: Record<string, unknown>;
}

/**
 * Notifica um conjunto de usuários por dois canais:
 *  1. Notification in-app (1 linha por usuário).
 *  2. Email via Resend (best-effort — falha só loga, não derruba o chamador).
 *
 * `extraEmails` são endereços avulsos que entram só no email (ex: `sla.notify`).
 */
export async function notifyUsers(
  users: { id: string; email: string }[],
  notice: UserNotice,
  extraEmails: string[] = [],
): Promise<void> {
  if (users.length) {
    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        type: notice.type,
        payload: { title: notice.title, body: notice.body, ...notice.payload },
      })),
    });
  }

  const recipients = [
    ...new Set([...users.map((u) => u.email), ...extraEmails]),
  ];
  if (recipients.length) {
    try {
      await sendEmail({
        to: recipients,
        subject: notice.title,
        text: notice.body,
      });
    } catch (err) {
      console.error(
        JSON.stringify({
          event: "notify.email_failed",
          error: String((err as Error)?.message ?? err),
          at: new Date().toISOString(),
        }),
      );
    }
  }
}

/**
 * Notifica todos os admins. Destinatários do email = `sla.notify` do config
 * ∪ emails dos admins. Wrapper fino sobre `notifyUsers`.
 */
export async function notifyAdmins(notice: UserNotice): Promise<void> {
  const admins = await prisma.user.findMany({
    where: { role: "admin" },
    select: { id: true, email: true },
  });
  await notifyUsers(admins, notice, slaConfig().notify);
}

/** Marca uma notificação como lida — escopada ao dono (userId). */
export async function markRead(
  userId: string,
  notificationId: string,
): Promise<void> {
  await prisma.notification.updateMany({
    where: { id: notificationId, userId, readAt: null },
    data: { readAt: new Date() },
  });
}

/** Marca todas as notificações não lidas do usuário como lidas. */
export async function markAllRead(userId: string): Promise<void> {
  await prisma.notification.updateMany({
    where: { userId, readAt: null },
    data: { readAt: new Date() },
  });
}
