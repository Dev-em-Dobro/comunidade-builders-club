import Link from "next/link";
import { prisma } from "@/lib/db";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { ClipboardList, Upload } from "lucide-react";

export const dynamic = "force-dynamic";

interface SurveyRow {
  surveyName: string;
  responseCount: number;
  uniqueContacts: number;
  lastImportedAt: Date;
  firstImportedAt: Date;
}

async function loadSurveys(): Promise<SurveyRow[]> {
  // groupBy não pega DISTINCT contactId — fazemos em 2 queries enxutas.
  const grouped = await prisma.surveyResponse.groupBy({
    by: ["surveyName"],
    _count: { _all: true },
    _max: { createdAt: true },
    _min: { createdAt: true },
    orderBy: { _max: { createdAt: "desc" } },
  });
  if (grouped.length === 0) return [];

  // Conta unique contacts por survey via $queryRaw (mais eficiente que N queries)
  type DistinctRow = { surveyName: string; uniqueContacts: bigint };
  const distinct = await prisma.$queryRaw<DistinctRow[]>`
    SELECT "surveyName", COUNT(DISTINCT "contactId")::bigint AS "uniqueContacts"
    FROM "SurveyResponse"
    GROUP BY "surveyName"
  `;
  const distinctMap = new Map<string, number>(
    distinct.map((d) => [d.surveyName, Number(d.uniqueContacts)]),
  );

  return grouped.map((g) => ({
    surveyName: g.surveyName,
    responseCount: g._count._all,
    uniqueContacts: distinctMap.get(g.surveyName) ?? 0,
    lastImportedAt: g._max.createdAt!,
    firstImportedAt: g._min.createdAt!,
  }));
}

export default async function SurveysPage() {
  const surveys = await loadSurveys().catch(() => [] as SurveyRow[]);

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6 flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Pesquisas
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {surveys.length} pesquisa{surveys.length !== 1 ? "s" : ""}{" "}
            importada{surveys.length !== 1 ? "s" : ""}.
          </p>
        </div>
        <Link href="/surveys/import" className={buttonVariants()}>
          <Upload className="size-4" />
          Importar nova
        </Link>
      </header>

      {surveys.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <ClipboardList className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhuma pesquisa importada ainda.</p>
          <p className="text-sm text-muted-foreground mt-1">
            Faça upload de um CSV pra começar.
          </p>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pesquisa</TableHead>
                <TableHead className="text-right">Respostas</TableHead>
                <TableHead className="text-right">Contatos únicos</TableHead>
                <TableHead className="text-right">Última importação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {surveys.map((s) => (
                <TableRow key={s.surveyName}>
                  <TableCell>
                    <Link
                      href={`/surveys/${encodeURIComponent(s.surveyName)}`}
                      className="font-medium hover:text-primary"
                    >
                      {s.surveyName}
                    </Link>
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {s.responseCount}
                  </TableCell>
                  <TableCell className="text-right font-mono">
                    {s.uniqueContacts}
                  </TableCell>
                  <TableCell className="text-right text-xs text-muted-foreground font-mono">
                    {s.lastImportedAt.toISOString().slice(0, 16).replace("T", " ")}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}
