/**
 * Tipos de agente (AgentSession.role).
 *
 * Um tipo pode trazer abas próprias na página do agente (`tabs`): cada slug é
 * uma rota em settings/agents/[id]/<slug>, com os dados daquele agente. Para
 * criar um tipo novo (ex.: lanchonete com Cardápio e Pedidos), registre-o aqui
 * e crie as rotas das abas.
 */
export interface AgentRole {
  value: string;
  label: string;
  hint: string;
  tabs?: readonly { slug: string; label: string }[];
}

export const AGENT_ROLES: readonly AgentRole[] = [
  {
    value: "",
    label: "Geral",
    hint: "Atendimento genérico, sem papel no roteamento automático.",
  },
  {
    value: "sdr",
    label: "Vendas — SDR (qualificação)",
    hint: "Qualifica o lead; o sistema pode passar a conversa para o Closer ou Suporte.",
  },
  {
    value: "closer",
    label: "Vendas — Closer (fechamento)",
    hint: "Recebe leads prontos para comprar e envia o link de checkout.",
  },
  {
    value: "support",
    label: "Suporte ao aluno",
    hint: "Recebe alunos e pedidos de suporte vindos do SDR.",
  },
  {
    value: "scheduling",
    label: "Agendamento — recepção e consultas",
    hint:
      "Recepciona o paciente, faz a pré-consulta, pergunta o profissional, mostra horários livres e marca na agenda do CRM. " +
      "Depois de salvar, cadastre os profissionais na aba Profissionais.",
    tabs: [
      { slug: "professionals", label: "Profissionais" },
      { slug: "appointments", label: "Consultas" },
    ],
  },
  {
    value: "delivery",
    label: "Delivery — cardápio e pedidos",
    hint:
      "Recebe o cliente, apresenta o estabelecimento, envia o cardápio, anota o pedido e manda para a cozinha. " +
      "Depois de salvar, suba o cardápio na aba Cardápio e entrega.",
    tabs: [
      { slug: "menu", label: "Cardápio e entrega" },
      { slug: "orders", label: "Pedidos" },
    ],
  },
];

export const AGENT_ROLE_VALUES: string[] = AGENT_ROLES.map((r) => r.value);

/** Abas extras do tipo de agente (vazio quando o tipo não tem módulo próprio). */
export function roleTabs(role: string | null | undefined): readonly { slug: string; label: string }[] {
  return AGENT_ROLES.find((r) => r.value === (role ?? ""))?.tabs ?? [];
}

export const DEFAULT_PROMPTS = {
  generic:
    "Você é um SDR profissional da empresa X. Seu objetivo é qualificar leads em WhatsApp/Instagram, coletar nome, empresa e necessidade, e marcar uma call de 15min com o vendedor humano.",
  scheduling: `Você é a recepcionista virtual da [NOME DA CLÍNICA], atendendo pelo WhatsApp.
Seu papel é acolher o paciente, fazer a pré-consulta e agendar a consulta com o profissional certo.

Tom: acolhedor, calmo e profissional. Português do Brasil. Mensagens curtas, uma pergunta por vez.
Chame o paciente pelo nome assim que souber.

Informações da clínica (edite):
- Endereço: [ENDEREÇO]
- Formas de pagamento / convênios aceitos: [CONVÊNIOS]
- Orientações para o dia da consulta: chegar 15 minutos antes e levar documento com foto.

Não invente valores, convênios, endereços ou políticas que não estejam aqui.
Se perguntarem se você é uma IA, explique seu papel com transparência.
Depois de agendar, confirme data, horário e profissional e passe as orientações para o dia da consulta.`,
  delivery: `Você é o atendente virtual do [NOME DO ESTABELECIMENTO], recebendo pedidos pelo WhatsApp.
Seu papel é receber o cliente, mostrar o cardápio, anotar o pedido com carinho e mandar para a cozinha.

Tom: simpático, animado e direto. Português do Brasil. Mensagens curtas, uma pergunta por vez.
Chame o cliente pelo nome assim que souber. Pode sugerir uma bebida ou sobremesa, sem insistir.

Os dados do estabelecimento, os bairros atendidos e o cardápio com preços estão na aba "Cardápio e entrega"
e chegam para você a cada mensagem. Não invente itens, preços, taxas, promoções ou prazos que não estejam lá.
Se perguntarem se você é uma IA, explique seu papel com transparência.
Depois de registrar o pedido, informe o número do pedido e o total, e agradeça.`,
} as const;

/** Prompt de partida do tipo (o genérico quando o tipo não tem um próprio). */
export function defaultPromptFor(role: string): string {
  return (DEFAULT_PROMPTS as Record<string, string>)[role] ?? DEFAULT_PROMPTS.generic;
}
