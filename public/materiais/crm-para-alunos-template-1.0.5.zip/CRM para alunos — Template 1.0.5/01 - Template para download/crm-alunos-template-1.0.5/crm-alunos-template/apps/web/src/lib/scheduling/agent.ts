/**
 * Agente de consulta (AgentSession.role = "scheduling").
 *
 * Recepciona o paciente, faz a pré-consulta (campos configurados no agente),
 * pergunta o profissional, consulta horários livres e agenda na agenda do CRM.
 *
 * - Lista de profissionais vai no contexto (com ids) — sem tool de listagem.
 * - check_availability / book_appointment rodam no loop de tools (llm/tool-loop.ts).
 */
import type { LLMToolDef, LLMToolUse } from "@/lib/llm/types";
import { prisma } from "@/lib/db";
import { normalizeIntakeFields, type IntakeField } from "./intake";
import { bookableProfessionals, bookAppointment, checkAvailability } from "./service";
import { dayLabel, slotLabel, zonedParts } from "./time";
import { schedulingTimezone } from "./timezone";
import { normalizeWorkingHours, summarizeWorkingHours } from "./working-hours";

export const SCHEDULING_ROLE = "scheduling";
export const SCHEDULING_TOOL_NAMES = new Set(["check_availability", "book_appointment"]);

export function isSchedulingTool(name: string): boolean {
  return SCHEDULING_TOOL_NAMES.has(name);
}

export function buildSchedulingTools(
  professionalIds: string[],
  intakeFields: IntakeField[],
): LLMToolDef[] {
  const professionalId = {
    type: "string",
    enum: professionalIds,
    description: "id do profissional, da lista em '# Agendamento de consultas'.",
  };
  return [
    {
      name: "check_availability",
      description:
        "Consulta os horários LIVRES de um profissional na agenda real. Devolve os próximos dias " +
        "com horário a partir de `date` (ou de hoje). Use SEMPRE antes de oferecer horários — " +
        "nunca invente nem estime horários.",
      inputSchema: {
        type: "object",
        properties: {
          professionalId,
          date: {
            type: "string",
            description: "Dia preferido pelo paciente, formato YYYY-MM-DD. Omita para buscar a partir de hoje.",
          },
        },
        required: ["professionalId"],
      },
    },
    {
      name: "book_appointment",
      description:
        "Agenda a consulta no horário escolhido pelo paciente e grava a pré-consulta. Só chame " +
        "depois que o paciente CONFIRMAR profissional, data e hora, e quando os campos obrigatórios " +
        "da pré-consulta já tiverem sido respondidos. A consulta só está marcada se o retorno for ok:true.",
      inputSchema: {
        type: "object",
        properties: {
          professionalId,
          date: { type: "string", description: "Data no formato YYYY-MM-DD." },
          time: { type: "string", description: "Hora de início HH:MM, exatamente como veio de check_availability." },
          intake: {
            type: "object",
            description: "Respostas da pré-consulta, com as palavras do paciente.",
            properties: Object.fromEntries(
              intakeFields.map((f) => [f.key, { type: "string", description: f.label }]),
            ),
            required: intakeFields.filter((f) => f.required).map((f) => f.key),
          },
        },
        required: ["professionalId", "date", "time", "intake"],
      },
    },
  ];
}

export interface SchedulingSetup {
  /** Tools a expor pro modelo (vazio quando o agendamento está indisponível). */
  tools: LLMToolDef[];
  /** Bloco do system prompt dinâmico. */
  contextBlock: string;
  intakeFields: IntakeField[];
}

/** Prepara tools + contexto do agente de consulta pra esta conversa. */
export async function prepareScheduling(args: {
  agentSessionId: string;
  intakeFieldsRaw: unknown;
  contactId: string;
  now?: Date;
}): Promise<SchedulingSetup> {
  const tz = schedulingTimezone();
  const now = args.now ?? new Date();
  const intakeFields = normalizeIntakeFields(args.intakeFieldsRaw);
  const [professionals, upcoming] = await Promise.all([
    bookableProfessionals(args.agentSessionId),
    prisma.appointment.findMany({
      where: { contactId: args.contactId, status: "scheduled", startsAt: { gte: now } },
      orderBy: { startsAt: "asc" },
      take: 5,
    }),
  ]);
  const nowParts = zonedParts(now, tz);
  const available = professionals.length > 0;

  const lines: string[] = [
    "# Agendamento de consultas (REGRAS PRIORITÁRIAS)",
    `Agora: ${dayLabel(nowParts.date)}/${nowParts.date.slice(0, 4)} às ${nowParts.time} ` +
      `(fuso ${tz}). Hoje = ${nowParts.date}. Use isso para entender "amanhã", "sexta", etc.`,
    "",
  ];

  if (available) {
    lines.push("## Profissionais");
    for (const p of professionals) {
      lines.push(
        `- id: ${p.id} | ${p.name}${p.specialty ? ` — ${p.specialty}` : ""} | consulta de ${p.durationMin} min | ` +
          `atende: ${summarizeWorkingHours(normalizeWorkingHours(p.workingHours))}`,
      );
      if (p.description) lines.push(`  Sobre: ${p.description}`);
    }
    lines.push("");
  }

  lines.push("## Consultas já agendadas deste paciente");
  if (upcoming.length) {
    for (const a of upcoming) lines.push(`- ${slotLabel(a.startsAt, tz)} com ${a.professionalName}`);
  } else {
    lines.push("- nenhuma");
  }
  lines.push("");

  if (intakeFields.length) {
    const req = intakeFields.filter((f) => f.required);
    const opt = intakeFields.filter((f) => !f.required);
    lines.push("## Pré-consulta — colete antes de agendar");
    if (req.length) lines.push(`Obrigatórios: ${req.map((f) => f.label).join("; ")}.`);
    if (opt.length) lines.push(`Opcionais (pergunte, mas aceite se o paciente não souber): ${opt.map((f) => f.label).join("; ")}.`);
    lines.push("");
  }

  lines.push("## Como conduzir");
  lines.push(
    "1. Recepcione com cordialidade. Mensagens curtas, uma pergunta por vez. Não repita perguntas já respondidas na conversa.",
    "2. Faça a pré-consulta com os campos acima.",
    "3. Pergunte com qual profissional ou especialidade a pessoa quer consultar.",
  );
  if (available) {
    lines.push(
      "4. Chame check_availability e ofereça de 3 a 5 opções de horário. NUNCA invente, estime ou prometa horários que o tool não devolveu.",
      "5. Quando o paciente escolher, confirme profissional, data e hora e chame book_appointment com as respostas da pré-consulta.",
      "6. Só diga que a consulta está marcada se book_appointment retornar ok:true — e então informe data, hora e profissional. " +
        "Se vier slot_unavailable, ofereça os availableTimes. Se vier missing_intake, pergunte o que falta.",
      "7. Remarcação ou cancelamento: use request_handoff para a equipe resolver.",
    );
  } else {
    lines.push(
      "4. O agendamento automático está INDISPONÍVEL agora (nenhum profissional ativo cadastrado neste agente). " +
        "Não ofereça horários nem diga que marcou. Depois da pré-consulta, explique que a equipe vai confirmar o horário e use request_handoff.",
    );
  }
  lines.push(
    "Você não dá diagnóstico, prescrição nem orientação clínica. Se a pessoa descrever sinais de urgência ou emergência, " +
      "oriente procurar um pronto-socorro ou ligar 192 (SAMU) imediatamente.",
  );

  return {
    tools: available ? buildSchedulingTools(professionals.map((p) => p.id), intakeFields) : [],
    contextBlock: lines.join("\n"),
    intakeFields,
  };
}

/** Executa um tool de agendamento e devolve o JSON que volta pro modelo. */
export async function executeSchedulingTool(
  call: LLMToolUse,
  ctx: { agentSessionId: string; contactId: string; conversationId: string; intakeFields: IntakeField[] },
): Promise<string> {
  const input = call.input as Record<string, unknown>;
  try {
    if (call.name === "check_availability") {
      return JSON.stringify(
        await checkAvailability({
          agentSessionId: ctx.agentSessionId,
          professionalId: String(input.professionalId ?? ""),
          date: typeof input.date === "string" ? input.date : null,
        }),
      );
    }
    if (call.name === "book_appointment") {
      return JSON.stringify(
        await bookAppointment({
          agentSessionId: ctx.agentSessionId,
          professionalId: String(input.professionalId ?? ""),
          date: String(input.date ?? ""),
          time: String(input.time ?? ""),
          intake: input.intake,
          intakeFields: ctx.intakeFields,
          contactId: ctx.contactId,
          conversationId: ctx.conversationId,
        }),
      );
    }
    return JSON.stringify({ ok: false, error: "unknown_tool" });
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "scheduling.tool_error",
        tool: call.name,
        conversationId: ctx.conversationId,
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
    return JSON.stringify({
      ok: false,
      error: "internal_error",
      message:
        "Não foi possível acessar a agenda agora. Peça desculpas, diga que a equipe vai confirmar o horário e use request_handoff.",
    });
  }
}
