/**
 * Helper de envio outbound — single call-site pra o padrão "envia via adapter
 * do canal + persiste Message + notifica SSE + trata META_OUT_OF_WINDOW".
 *
 * Extraído de flush.ts em 2026-05-25 (Passagem SDR → Closer). Mesmo
 * comportamento — só centraliza o trecho para reuso no agent-handoff worker.
 */
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { getAdapter } from "@/lib/channels/registry";
import { ChannelSendError, META_OUT_OF_WINDOW } from "@/lib/channels/meta-graph";
import { notifyMessage } from "@/lib/realtime/notify";
import type { ChannelId } from "@/lib/channels/types";
import { splitReply, typingDelayMs, type HumanizeSettings } from "@/lib/humanize";

export interface OutboundUsage {
  tokensIn?: number;
  tokensOut?: number;
  costUsd?: number;
  modelUsed?: string;
}

export interface SendOutboundParams {
  conversationId: string;
  channel: ChannelId;
  externalId: string;
  text: string;
  usage?: OutboundUsage;
}

export interface SendOutboundResult {
  ok: boolean;
  messageId?: string;
  /** se ok=false, o motivo. "window_expired" = META 131047; "send_failed" = outro erro. */
  reason?: "empty_text" | "window_expired" | "send_failed";
  error?: string;
}

/**
 * Envia mensagem outbound via adapter do canal, persiste em Message (direction=outbound,
 * role=assistant) e notifica listeners SSE. Trata META_OUT_OF_WINDOW marcando
 * `Conversation.windowExpired = true`.
 *
 * Lança nada — devolve `{ok:false, reason}` em falhas esperadas. Erros não
 * esperados (DB indisponível, etc.) propagam pra cima.
 */
export async function sendOutboundMessage(
  params: SendOutboundParams,
): Promise<SendOutboundResult> {
  const { conversationId, channel, externalId, text, usage } = params;

  if (!text.trim()) {
    log({ event: "outbound.empty_text", conversationId });
    return { ok: false, reason: "empty_text" };
  }

  log({ event: "outbound.sending", conversationId, channel, externalId });
  try {
    const adapter = getAdapter(channel);
    await adapter.sendText(externalId, text);
  } catch (err) {
    const errMsg = String((err as Error)?.message ?? err);
    log({ event: "outbound.send_failed", conversationId, error: errMsg });
    if (err instanceof ChannelSendError && err.code === META_OUT_OF_WINDOW) {
      await prisma.conversation.update({
        where: { id: conversationId },
        data: { windowExpired: true },
      });
      log({ event: "outbound.window_expired", conversationId });
      return { ok: false, reason: "window_expired", error: errMsg };
    }
    return { ok: false, reason: "send_failed", error: errMsg };
  }
  log({ event: "outbound.sent_ok", conversationId });

  const saved = await prisma.message.create({
    data: {
      conversationId,
      direction: "outbound",
      role: "assistant",
      text,
      tokensIn: usage?.tokensIn || null,
      tokensOut: usage?.tokensOut || null,
      costUsd:
        usage?.costUsd !== undefined
          ? new Prisma.Decimal(usage.costUsd)
          : null,
      modelUsed: usage?.modelUsed ?? null,
    },
  });

  notifyMessage(conversationId, saved.id).catch((err) => {
    log({
      event: "outbound.notify_failed",
      conversationId,
      error: String((err as Error)?.message ?? err),
    });
  });

  return { ok: true, messageId: saved.id };
}

/**
 * Resposta do agente com "jeito de gente": quebra por parágrafo (se ligado) e,
 * antes de cada balão, mostra "digitando…" pelo tempo de escrever aquele texto.
 * O uso/custo do LLM fica só no primeiro balão (não conta em dobro).
 * Para no primeiro balão que falhar e devolve esse resultado.
 */
export async function sendOutboundReply(
  params: SendOutboundParams & { humanize: HumanizeSettings },
): Promise<SendOutboundResult> {
  const { humanize, ...base } = params;
  const parts = humanize.splitMessages ? splitReply(base.text) : [base.text];
  const adapter = getAdapter(base.channel);
  let result: SendOutboundResult = { ok: false, reason: "empty_text" };

  for (const [i, part] of parts.entries()) {
    if (humanize.typing && adapter.setTyping) {
      await adapter.setTyping(base.externalId, true).catch(() => undefined);
      await new Promise((resolve) => setTimeout(resolve, typingDelayMs(part)));
    }
    result = await sendOutboundMessage({ ...base, text: part, usage: i === 0 ? base.usage : undefined });
    if (humanize.typing && adapter.setTyping) {
      await adapter.setTyping(base.externalId, false).catch(() => undefined);
    }
    if (!result.ok) return result;
  }
  if (parts.length > 1) log({ event: "outbound.split_reply", conversationId: base.conversationId, bubbles: parts.length });
  return result;
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
