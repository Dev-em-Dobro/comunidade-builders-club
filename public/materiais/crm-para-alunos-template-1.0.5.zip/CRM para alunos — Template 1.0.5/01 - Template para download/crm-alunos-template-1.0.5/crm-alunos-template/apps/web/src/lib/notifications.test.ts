import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { notifyAdmins, markRead, markAllRead } from "./notifications";

const TEST_TYPE = "_test_notice_p4";
const userIds: string[] = [];

afterAll(async () => {
  await prisma.notification.deleteMany({ where: { type: TEST_TYPE } });
  await prisma.user.deleteMany({ where: { id: { in: userIds } } });
  await prisma.$disconnect();
});

describe("notifyAdmins", () => {
  it("cria Notification in-app pra cada admin", async () => {
    const admin = await prisma.user.create({
      data: { email: `admin-p4-${Date.now()}@test.local`, role: "admin" },
    });
    userIds.push(admin.id);

    await notifyAdmins({
      type: TEST_TYPE,
      title: "Teste P4",
      body: "corpo do aviso",
      payload: { conversationId: "c1" },
    });

    const notifs = await prisma.notification.findMany({
      where: { userId: admin.id, type: TEST_TYPE },
    });
    expect(notifs).toHaveLength(1);
    expect(notifs[0]!.readAt).toBeNull();
  });
});

describe("markRead / markAllRead", () => {
  it("markRead marca uma notificação como lida", async () => {
    const user = await prisma.user.create({
      data: { email: `mr-${Date.now()}@test.local`, role: "operator" },
    });
    userIds.push(user.id);
    const n = await prisma.notification.create({
      data: { userId: user.id, type: TEST_TYPE, payload: {} },
    });

    await markRead(user.id, n.id);

    const updated = await prisma.notification.findUnique({ where: { id: n.id } });
    expect(updated!.readAt).not.toBeNull();
  });

  it("markAllRead zera as não lidas do usuário", async () => {
    const user = await prisma.user.create({
      data: { email: `mar-${Date.now()}@test.local`, role: "operator" },
    });
    userIds.push(user.id);
    await prisma.notification.createMany({
      data: [
        { userId: user.id, type: TEST_TYPE, payload: {} },
        { userId: user.id, type: TEST_TYPE, payload: {} },
      ],
    });

    await markAllRead(user.id);

    const unread = await prisma.notification.count({
      where: { userId: user.id, readAt: null },
    });
    expect(unread).toBe(0);
  });
});
