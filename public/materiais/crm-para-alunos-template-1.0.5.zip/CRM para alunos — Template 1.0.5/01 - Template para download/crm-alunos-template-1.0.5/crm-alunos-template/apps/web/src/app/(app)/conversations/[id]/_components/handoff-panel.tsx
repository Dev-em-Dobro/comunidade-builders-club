"use client";

import { useTransition } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { UserCheck, Loader2 } from "lucide-react";
import { claimConversation } from "../actions";

interface Props {
  conversationId: string;
  summary: string | null;
  assignedToName: string | null;
}

/** Painel de handoff no topo da conversa: resumo gerado + botão de assumir. */
export function HandoffPanel({ conversationId, summary, assignedToName }: Props) {
  const [pending, startTransition] = useTransition();

  function claim() {
    startTransition(async () => {
      try {
        await claimConversation(conversationId);
        toast.success("Conversa atribuída a você");
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  return (
    <Card className="mb-6 border-warning/30">
      <CardContent className="pt-4 space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-sm font-medium">
            Bot solicitou humano — atendimento necessário
          </h2>
          <Button size="sm" onClick={claim} disabled={pending}>
            {pending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <UserCheck className="size-4" />
            )}
            Pegar conversa
          </Button>
        </div>
        {assignedToName && (
          <p className="text-xs text-muted-foreground">
            Atribuída a{" "}
            <span className="font-medium text-foreground">{assignedToName}</span>
          </p>
        )}
        {summary ? (
          <div className="text-sm whitespace-pre-line">{summary}</div>
        ) : (
          <p className="text-sm italic text-muted-foreground">
            Resumo não disponível.
          </p>
        )}
      </CardContent>
    </Card>
  );
}
