import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { TrendingDown } from "lucide-react";
import { buildFunnel } from "../metrics";
import { FunnelView } from "./charts";

interface FunnelData {
  stageCounts: Record<string, number>;
  lost: number;
  error: boolean;
}

async function getFunnel(launch: string): Promise<FunnelData> {
  try {
    const where = launch === "all" ? {} : { launchId: launch };
    const rows = await prisma.lead.groupBy({
      by: ["stage"],
      _count: { _all: true },
      where,
    });
    const stageCounts: Record<string, number> = {};
    let lost = 0;
    for (const r of rows) {
      if (r.stage === "lost") lost = r._count._all;
      else stageCounts[r.stage] = r._count._all;
    }
    return { stageCounts, lost, error: false };
  } catch {
    return { stageCounts: {}, lost: 0, error: true };
  }
}

export async function FunnelSection({ launch }: { launch: string }) {
  const { stageCounts, lost, error } = await getFunnel(launch);
  const levels = buildFunnel(stageCounts);
  const hasData = levels.some((l) => l.count > 0) || lost > 0;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Funil por estágio</CardTitle>
        <CardDescription>
          Leads que alcançaram cada estágio · {lost} perdido
          {lost !== 1 ? "s" : ""}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : !hasData ? (
          <p className="text-sm text-muted-foreground">Nenhum lead ainda.</p>
        ) : (
          <>
            <FunnelView levels={levels} />
            <ul className="mt-3 space-y-1.5">
              {levels.map((l) => (
                <li
                  key={l.stage}
                  className="flex items-center justify-between text-sm"
                >
                  <span className="text-muted-foreground">{l.label}</span>
                  <span className="flex items-center gap-3">
                    <span className="font-mono">{l.count}</span>
                    {l.dropoffPct !== null && (
                      <span className="flex w-16 items-center justify-end gap-1 text-xs text-muted-foreground">
                        <TrendingDown className="size-3" />
                        {l.dropoffPct.toFixed(0)}%
                      </span>
                    )}
                  </span>
                </li>
              ))}
            </ul>
          </>
        )}
      </CardContent>
    </Card>
  );
}
