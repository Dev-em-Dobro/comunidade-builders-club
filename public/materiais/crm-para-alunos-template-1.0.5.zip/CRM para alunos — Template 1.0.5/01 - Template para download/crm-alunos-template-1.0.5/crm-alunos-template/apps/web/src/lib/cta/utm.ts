/**
 * Anexa params UTM à URL preservando query existente e fragmento (#).
 * Usa URLSearchParams pra encoding correto, com `+` convertido pra `%20`
 * (encoding URL-style, não form-style).
 */
export function appendUtm(
  url: string,
  params: Record<string, string>,
): string {
  if (Object.keys(params).length === 0) return url;

  const hashIdx = url.indexOf("#");
  const base = hashIdx >= 0 ? url.slice(0, hashIdx) : url;
  const hash = hashIdx >= 0 ? url.slice(hashIdx) : "";

  const sep = base.includes("?") ? "&" : "?";
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) sp.set(k, v);

  return `${base}${sep}${sp.toString().replace(/\+/g, "%20")}${hash}`;
}
