import { PrismaClient } from "@prisma/client";

// Gotcha 0.9.24: log:[] (ou ["warn"]) — P2002 é esperado no dedup de webhooks,
// log:["error"] polui stdout e assusta operador. Eventos importantes são logados
// pelo handler semântico ("webhook.<channel>.duplicate", etc.).
const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn"] : [],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;

export type { Prisma } from "@prisma/client";
export { PrismaClient } from "@prisma/client";
