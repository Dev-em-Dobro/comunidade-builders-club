import type { Metadata } from "next";
import {
  LegalLink,
  LegalList,
  LegalPage,
  LegalSection,
  LegalStrong,
} from "../_components/legal-page";
import { businessConfig } from "@/lib/config";




export const metadata: Metadata = { title: "Política de Privacidade" };
export const dynamic = "force-dynamic";

export default function PrivacyPage() {
  const { contactEmail: CONTACT_EMAIL, legalName: LEGAL_ENTITY } = businessConfig();
  return (
    <LegalPage title="Política de Privacidade" updatedAt="22 de maio de 2026">
      <p>
        Esta Política de Privacidade descreve como a{" "}
        <LegalStrong>{LEGAL_ENTITY}</LegalStrong> coleta, usa,
        compartilha e protege os dados pessoais das pessoas que entram em contato
        conosco pelos nossos canais de atendimento no WhatsApp e no Instagram.
        Tratamos os dados em conformidade com a Lei Geral de Proteção de Dados
        (Lei nº 13.709/2018 — LGPD).
      </p>

      <LegalSection title="1. Quem é o responsável pelos dados">
        <p>
          A <LegalStrong>{LEGAL_ENTITY}</LegalStrong> é a controladora
          dos dados pessoais tratados conforme esta política. Para qualquer
          assunto relacionado à privacidade dos seus dados, fale conosco pelo
          e-mail{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>.
        </p>
      </LegalSection>

      <LegalSection title="2. A que esta política se aplica">
        <p>
          Esta política se aplica ao atendimento realizado pela {LEGAL_ENTITY}{" "}
          através do <LegalStrong>WhatsApp</LegalStrong>{" "}
          (WhatsApp Cloud API, da Meta) e do{" "}
          <LegalStrong>Instagram Direct</LegalStrong>. Ela não cobre sites,
          aplicativos ou serviços de terceiros que eventualmente sejam citados
          durante uma conversa. Nossos canais de atendimento são destinados a
          maiores de 18 anos.
        </p>
      </LegalSection>

      <LegalSection title="3. Quais dados coletamos">
        <p>
          Quando você nos envia uma mensagem pelo WhatsApp ou pelo Instagram,
          podemos coletar:
        </p>
        <LegalList
          items={[
            "Nome de perfil exibido na sua conta do WhatsApp ou do Instagram;",
            "Número de telefone (no WhatsApp) ou nome de usuário (no Instagram);",
            "Conteúdo das mensagens trocadas — texto, imagens, áudios e outros anexos que você enviar;",
            "Data e hora das mensagens;",
            "Informações de relacionamento comercial geradas durante o atendimento — por exemplo, produto ou serviço de interesse e a etapa do funil de vendas.",
          ]}
        />
        <p>
          Coletamos apenas os dados que você nos envia ou que são gerados durante
          o atendimento. Não compramos listas de contatos.
        </p>
      </LegalSection>

      <LegalSection title="4. Como e por que usamos seus dados">
        <p>Usamos os dados coletados para:</p>
        <LegalList
          items={[
            "Responder e dar continuidade ao seu atendimento;",
            "Gerar respostas automáticas por meio de um assistente de inteligência artificial;",
            "Organizar o relacionamento comercial em nosso sistema de gestão (CRM), incluindo histórico de conversas;",
            "Enviar mensagens de acompanhamento (follow-up) relacionadas ao seu atendimento;",
            "Cumprir obrigações legais e regulatórias.",
          ]}
        />
        <p>
          As bases legais para esse tratamento, conforme a LGPD, são: a execução
          de procedimentos preliminares ou de contrato a seu pedido, o legítimo
          interesse na prestação do atendimento e o consentimento, quando
          aplicável.
        </p>
      </LegalSection>

      <LegalSection title="5. Compartilhamento de dados e provedores de serviço">
        <p>
          <LegalStrong>Não vendemos seus dados pessoais.</LegalStrong>{" "}
          Compartilhamos dados apenas com provedores de serviço necessários para
          operar o atendimento:
        </p>
        <LegalList
          items={[
            <>
              <LegalStrong>Meta Platforms</LegalStrong> — operadora do WhatsApp e
              do Instagram, plataformas pelas quais a comunicação acontece;
            </>,
            <>
              <LegalStrong>Provedor de IA</LegalStrong> — provedor do modelo de
              inteligência artificial que gera as respostas automáticas (ex.:
              Anthropic ou OpenAI); o conteúdo das mensagens é enviado a esse
              provedor para que a resposta possa ser produzida;
            </>,
            <>
              <LegalStrong>Provedor de infraestrutura e hospedagem</LegalStrong>{" "}
              — responsável pelo armazenamento e pela operação técnica do
              sistema.
            </>,
          ]}
        />
        <p>
          Alguns desses provedores podem tratar dados fora do Brasil. Nesses
          casos, a transferência internacional ocorre com as salvaguardas
          previstas na LGPD. Também podemos compartilhar dados quando exigido por
          lei ou por autoridade competente.
        </p>
      </LegalSection>

      <LegalSection title="6. Por quanto tempo guardamos seus dados">
        <p>
          Mantemos os dados pelo tempo necessário para o atendimento e o
          relacionamento comercial, ou pelo prazo exigido para o cumprimento de
          obrigações legais. O histórico de conversas fica armazenado em nosso
          CRM. Você pode solicitar a exclusão dos seus dados a qualquer momento
          (veja a seção 8).
        </p>
      </LegalSection>

      <LegalSection title="7. Seus direitos como titular (LGPD)">
        <p>A qualquer momento, você pode:</p>
        <LegalList
          items={[
            "Confirmar a existência de tratamento dos seus dados e acessá-los;",
            "Corrigir dados incompletos, inexatos ou desatualizados;",
            "Solicitar a anonimização, o bloqueio ou a eliminação de dados;",
            "Revogar o consentimento, quando o tratamento se basear nele;",
            "Obter informações sobre com quem seus dados foram compartilhados.",
          ]}
        />
        <p>
          Para exercer qualquer desses direitos, escreva para{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>.
        </p>
      </LegalSection>

      <LegalSection title="8. Como solicitar a exclusão dos seus dados">
        <p>
          Você pode pedir a exclusão dos seus dados a qualquer momento. As
          instruções completas estão na página{" "}
          <LegalLink href="/data-deletion">Exclusão de Dados</LegalLink>. De
          forma resumida: basta enviar um e-mail para{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>{" "}
          solicitando a exclusão.
        </p>
      </LegalSection>

      <LegalSection title="9. Segurança da informação">
        <p>
          Adotamos medidas técnicas e administrativas razoáveis para proteger
          seus dados, incluindo acesso restrito às informações, verificação de
          autenticidade das mensagens recebidas (assinatura HMAC) e comunicação
          criptografada (HTTPS). Nenhum método de transmissão ou armazenamento é
          totalmente seguro, mas trabalhamos continuamente para proteger suas
          informações.
        </p>
      </LegalSection>

      <LegalSection title="10. Alterações nesta política">
        <p>
          Podemos atualizar esta Política de Privacidade periodicamente. A data
          de “Última atualização” no topo desta página indica a versão vigente.
          Alterações relevantes serão comunicadas pelos nossos canais sempre que
          possível.
        </p>
      </LegalSection>

      <LegalSection title="11. Contato">
        <p>
          Dúvidas sobre esta política ou sobre o tratamento dos seus dados podem
          ser enviadas para a{" "}
          <LegalStrong>{LEGAL_ENTITY}</LegalStrong> pelo e-mail{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
