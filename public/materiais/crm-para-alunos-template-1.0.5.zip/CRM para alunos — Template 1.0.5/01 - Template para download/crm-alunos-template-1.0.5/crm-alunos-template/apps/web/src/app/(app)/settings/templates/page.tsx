import { prisma } from "@/lib/db";
import { SyncButton } from "./_components/sync-button";
import { TemplatesTable } from "./_components/templates-table";

export const dynamic = "force-dynamic";

export default async function TemplatesPage() {
  const templates = await prisma.messageTemplate.findMany({
    orderBy: [{ status: "asc" }, { metaName: "asc" }],
    select: {
      id: true,
      metaName: true,
      language: true,
      category: true,
      status: true,
      bodyText: true,
      variableCount: true,
      syncedAt: true,
    },
  });

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Templates do WhatsApp
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Cache local dos templates aprovados na Meta. Crie/edite no
            Business Manager — aqui só sincroniza.
          </p>
        </div>
        <SyncButton />
      </header>

      <TemplatesTable templates={templates} />
    </div>
  );
}
