import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { findOrCreateContact } from "./find-or-create-contact";

const created = { contactIds: [] as string[] };
let existingId: string;
let existingEmail: string;

beforeAll(async () => {
  existingEmail = `foc-existing-${Date.now()}@t.local`;
  const c = await prisma.contact.create({
    data: {
      displayName: "Existente",
      email: existingEmail,
      identities: {
        create: { channel: "whatsapp_cloud", externalId: "5511955554444" },
      },
    },
  });
  existingId = c.id;
  created.contactIds.push(c.id);
});

afterAll(async () => {
  // Limpa contatos criados durante os testes
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

describe("findOrCreateContact", () => {
  it("retorna contato existente quando há match por phone (created=false)", async () => {
    const r = await findOrCreateContact({
      phoneRaw: "+5511955554444",
      emailRaw: null,
    });
    expect(r.contactId).toBe(existingId);
    expect(r.created).toBe(false);
    expect(r.via).toBe("phone");
  });

  it("retorna contato existente quando há match por email (created=false)", async () => {
    const r = await findOrCreateContact({
      phoneRaw: null,
      emailRaw: existingEmail.toUpperCase(),
    });
    expect(r.contactId).toBe(existingId);
    expect(r.created).toBe(false);
    expect(r.via).toBe("email");
  });

  it("cria contact novo com email quando não há match", async () => {
    const newEmail = `foc-new-${Date.now()}@t.local`;
    const r = await findOrCreateContact({
      phoneRaw: null,
      emailRaw: newEmail,
    });
    expect(r.contactId).not.toBeNull();
    expect(r.created).toBe(true);
    expect(r.via).toBe("created");
    created.contactIds.push(r.contactId!);

    const c = await prisma.contact.findUniqueOrThrow({ where: { id: r.contactId! } });
    expect(c.email).toBe(newEmail);
  });

  it("cria contact novo com ContactIdentity quando só tem phone", async () => {
    // Phone único: timestamp dá unicidade dentro de E.164.
    const phone = `5511${Date.now().toString().slice(-9)}`;
    const r = await findOrCreateContact({
      phoneRaw: phone,
      emailRaw: null,
    });
    expect(r.created).toBe(true);
    created.contactIds.push(r.contactId!);

    const c = await prisma.contact.findUniqueOrThrow({
      where: { id: r.contactId! },
      include: { identities: true },
    });
    expect(c.email).toBeNull();
    expect(c.identities).toHaveLength(1);
    expect(c.identities[0]!.externalId).toBe(phone);
    expect(c.identities[0]!.channel).toBe("whatsapp_cloud");
  });

  it("prepende DDI 55 quando phone tem 10-11 dígitos sem DDI", async () => {
    // 11 dígitos sem 55: matcher tentaria fallback com 55 prepended;
    // findOrCreate cria já com 55 pro padrão E.164 ficar consistente.
    const suffix = Date.now().toString().slice(-9);
    const local = `11${suffix}`; // 11 dígitos
    const r = await findOrCreateContact({
      phoneRaw: local,
      emailRaw: null,
    });
    expect(r.created).toBe(true);
    created.contactIds.push(r.contactId!);

    const c = await prisma.contact.findUniqueOrThrow({
      where: { id: r.contactId! },
      include: { identities: true },
    });
    expect(c.identities[0]!.externalId).toBe(`55${local}`);
  });

  it("retorna null quando nem email nem phone são válidos", async () => {
    const r = await findOrCreateContact({
      phoneRaw: "abc",
      emailRaw: "sem-arroba",
    });
    expect(r.contactId).toBeNull();
    expect(r.created).toBe(false);
    expect(r.via).toBeNull();
  });
});
