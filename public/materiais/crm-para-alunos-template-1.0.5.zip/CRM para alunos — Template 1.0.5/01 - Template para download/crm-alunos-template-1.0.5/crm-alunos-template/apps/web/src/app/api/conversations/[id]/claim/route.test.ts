import { describe, it, expect, beforeAll, afterAll, vi, beforeEach } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));
vi.mock("@/lib/realtime/notify", () => ({
  notifyConvEvent: vi.fn().mockResolvedValue(undefined),
}));

import { POST } from "./route";
import { auth } from "@/auth";
import { notifyConvEvent } from "@/lib/realtime/notify";

const created = { contactIds: [] as string[], userIds: [] as string[] };
let userA: string;
let userB: string;
let convId: string;

beforeAll(async () => {
  const a = await prisma.user.create({
    data: { email: `claimroute-a-${Date.now()}@t.local`, name: "User A" },
  });
  const b = await prisma.user.create({
    data: { email: `claimroute-b-${Date.now()}@t.local`, name: "User B" },
  });
  userA = a.id;
  userB = b.id;
  created.userIds.push(a.id, b.id);
  const contact = await prisma.contact.create({ data: { displayName: "T" } });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud" },
  });
  convId = conv.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(notifyConvEvent).mockClear();
  vi.mocked(auth).mockResolvedValue({ user: { id: userA } } as never);
});

function req(body: unknown): Request {
  return new Request("http://localhost/api/conversations/x/claim", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("POST /api/conversations/[id]/claim", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(401);
  });

  it("404 conversa inexistente", async () => {
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: "missing" }),
    });
    expect(res.status).toBe(404);
  });

  it("200 claim em conversa sem dono + notifyConvEvent disparado", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: null, aiEnabled: true },
    });
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.claimed).toBe(true);
    expect(body.assignedUserId).toBe(userA);
    expect(notifyConvEvent).toHaveBeenCalledTimes(1);
    const [convArg, payloadArg] = vi.mocked(notifyConvEvent).mock.calls[0]!;
    expect(convArg).toBe(convId);
    expect(payloadArg.type).toBe("claim");
  });

  it("claim auto-pausa IA + sinaliza aiPausedByClaim quando aiEnabled era true", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: null, aiEnabled: true },
    });
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.aiPausedByClaim).toBe(true);
    const after = await prisma.conversation.findUniqueOrThrow({
      where: { id: convId },
    });
    expect(after.aiEnabled).toBe(false);
    const [, payloadArg] = vi.mocked(notifyConvEvent).mock.calls[0]!;
    expect(payloadArg).toMatchObject({ type: "claim", aiPausedByClaim: true });
  });

  it("claim NÃO pausa IA quando já estava pausada (aiPausedByClaim=false)", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: null, aiEnabled: false },
    });
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: convId }),
    });
    const body = await res.json();
    expect(body.aiPausedByClaim).toBe(false);
    const after = await prisma.conversation.findUniqueOrThrow({
      where: { id: convId },
    });
    expect(after.aiEnabled).toBe(false);
  });

  it("409 claim em conversa de outro sem force", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: userB },
    });
    const res = await POST(req({ action: "claim" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.error).toBe("owned_by_other");
    expect(body.ownerId).toBe(userB);
    expect(notifyConvEvent).not.toHaveBeenCalled();
  });

  it("200 claim com force sobrescreve dono", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: userB },
    });
    const res = await POST(req({ action: "claim", force: true }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.claimed).toBe(true);
    expect(body.assignedUserId).toBe(userA);
    expect(body.previousOwnerId).toBe(userB);
    expect(notifyConvEvent).toHaveBeenCalledTimes(1);
  });

  it("200 release quando é o dono + 403 quando não é", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: userA },
    });
    const ok = await POST(req({ action: "release" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(ok.status).toBe(200);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.assignedUserId).toBeNull();
    expect(notifyConvEvent).toHaveBeenCalledTimes(1);

    vi.mocked(notifyConvEvent).mockClear();
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: userB },
    });
    const denied = await POST(req({ action: "release" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(denied.status).toBe(403);
    expect(notifyConvEvent).not.toHaveBeenCalled();
  });
});
