import { NextResponse } from "next/server";
import { getAdapterByUrlSlug } from "@/lib/channels/registry";
import { requireSession } from "@/lib/api-auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/sessions/[channel]/ensure
 * Roda subscription idempotente (GET subscribed_apps → POST se faltar).
 * Per gotcha 0.9.4 e idempotent-sessions: estado retornado vem do re-GET, não do POST.
 *
 * Next.js 16: params é Promise — precisa await.
 */
export async function POST(
  _req: Request,
  { params }: { params: Promise<{ channel: string }> },
) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  if (gate.user.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { channel } = await params;
  const adapter = getAdapterByUrlSlug(channel);
  if (!adapter) {
    return NextResponse.json({ ok: false, error: `unknown channel: ${channel}` }, { status: 404 });
  }
  try {
    const state = await adapter.ensureSession();
    return NextResponse.json({ ok: true, state });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: String((err as Error)?.message ?? err) },
      { status: 500 },
    );
  }
}
