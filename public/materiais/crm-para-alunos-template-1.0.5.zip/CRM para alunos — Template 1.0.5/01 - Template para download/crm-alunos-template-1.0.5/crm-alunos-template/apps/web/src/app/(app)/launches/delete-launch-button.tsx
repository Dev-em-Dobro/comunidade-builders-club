"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Trash2, Loader2 } from "lucide-react";
import { deleteLaunch } from "./actions";

interface Props {
  launchId: string;
  launchName: string;
}

export function DeleteLaunchButton({ launchId, launchName }: Props) {
  const [pending, start] = useTransition();

  const handleClick = () => {
    const ok = window.confirm(
      `Excluir o lançamento "${launchName}"? Leads vinculados ficam com launchId = null. Esta ação não pode ser desfeita.`,
    );
    if (!ok) return;
    start(async () => {
      await deleteLaunch(launchId);
    });
  };

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      onClick={handleClick}
      disabled={pending}
      aria-label="Excluir lançamento"
      className="text-destructive hover:text-destructive hover:bg-destructive/10"
    >
      {pending ? <Loader2 className="size-4 animate-spin" /> : <Trash2 className="size-4" />}
    </Button>
  );
}
