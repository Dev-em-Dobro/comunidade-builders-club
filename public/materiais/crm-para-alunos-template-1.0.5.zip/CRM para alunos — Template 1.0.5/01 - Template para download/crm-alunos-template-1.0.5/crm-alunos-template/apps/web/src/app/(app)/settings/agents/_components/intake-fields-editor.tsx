"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";

export interface IntakeFieldDraft {
  key?: string;
  label: string;
  required: boolean;
}

/** Lista editável dos campos da pré-consulta — serializada num input hidden. */
export function IntakeFieldsEditor({ initial }: { initial: IntakeFieldDraft[] }) {
  const [fields, setFields] = useState<IntakeFieldDraft[]>(initial);

  const update = (i: number, patch: Partial<IntakeFieldDraft>) =>
    setFields((prev) => prev.map((f, idx) => (idx === i ? { ...f, ...patch } : f)));
  const move = (i: number, dir: -1 | 1) =>
    setFields((prev) => {
      const next = [...prev];
      const j = i + dir;
      if (j < 0 || j >= next.length) return prev;
      [next[i], next[j]] = [next[j]!, next[i]!];
      return next;
    });

  return (
    <div className="space-y-3 rounded-md border border-border p-4">
      <div>
        <Label className="text-sm">Pré-consulta</Label>
        <p className="text-xs text-muted-foreground mt-1">
          O agente pergunta estes dados antes de marcar. Os obrigatórios são exigidos pelo sistema; as respostas
          ficam na consulta no CRM (e na planilha, se o Google Sheets estiver ligado).
        </p>
      </div>
      <input
        type="hidden"
        name="intakeFields"
        value={JSON.stringify(fields.filter((f) => f.label.trim()))}
      />
      <ul className="space-y-2">
        {fields.map((f, i) => (
          <li key={i} className="flex items-center gap-2">
            <Input
              value={f.label}
              onChange={(e) => update(i, { label: e.target.value })}
              placeholder="Ex.: Data de nascimento"
              aria-label={`Campo ${i + 1}`}
              maxLength={200}
            />
            <label className="flex items-center gap-1.5 text-xs whitespace-nowrap">
              <input
                type="checkbox"
                checked={f.required}
                onChange={(e) => update(i, { required: e.target.checked })}
                className="size-4 accent-primary"
              />
              obrigatório
            </label>
            <Button type="button" size="icon" variant="ghost" onClick={() => move(i, -1)} aria-label="Subir">
              <ArrowUp className="size-4" />
            </Button>
            <Button type="button" size="icon" variant="ghost" onClick={() => move(i, 1)} aria-label="Descer">
              <ArrowDown className="size-4" />
            </Button>
            <Button
              type="button"
              size="icon"
              variant="ghost"
              onClick={() => setFields((prev) => prev.filter((_, idx) => idx !== i))}
              aria-label="Remover"
            >
              <Trash2 className="size-4" />
            </Button>
          </li>
        ))}
      </ul>
      <Button
        type="button"
        variant="outline"
        size="sm"
        disabled={fields.length >= 15}
        onClick={() => setFields((prev) => [...prev, { label: "", required: false }])}
      >
        <Plus className="size-4" /> Adicionar campo
      </Button>
    </div>
  );
}
