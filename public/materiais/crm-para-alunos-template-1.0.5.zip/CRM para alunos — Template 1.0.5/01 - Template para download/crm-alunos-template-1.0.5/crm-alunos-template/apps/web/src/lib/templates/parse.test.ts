import { describe, it, expect } from "vitest";
import { extractVariableCount, extractBodyText } from "./parse";

describe("extractVariableCount", () => {
  it("retorna 0 quando não tem placeholders", () => {
    expect(extractVariableCount("texto puro sem vars")).toBe(0);
  });

  it("retorna N pro maior {{N}}", () => {
    expect(extractVariableCount("Oi {{1}}, sobre {{3}}")).toBe(3);
  });

  it("ignora {{N}} duplicado, conta o maior", () => {
    expect(extractVariableCount("{{1}} {{2}} {{1}} {{2}}")).toBe(2);
  });

  it("ignora double-brace que não é placeholder", () => {
    expect(extractVariableCount("texto {{} ou {{ abc}}")).toBe(0);
  });

  it("aceita string vazia", () => {
    expect(extractVariableCount("")).toBe(0);
  });

  it("{{0}} retorna 0 — Meta usa {{1}}+, {{0}} é tratado como inválido", () => {
    expect(extractVariableCount("{{0}}")).toBe(0);
  });
});

describe("extractBodyText", () => {
  it("retorna texto do component type=BODY", () => {
    const components = [
      { type: "HEADER", format: "TEXT", text: "Header" },
      { type: "BODY", text: "Oi {{1}}, tudo bem?" },
      { type: "FOOTER", text: "Footer" },
    ];
    expect(extractBodyText(components)).toBe("Oi {{1}}, tudo bem?");
  });

  it("retorna null quando não tem BODY", () => {
    const components = [{ type: "HEADER", format: "TEXT", text: "Só header" }];
    expect(extractBodyText(components)).toBeNull();
  });

  it("retorna null pra array vazio", () => {
    expect(extractBodyText([])).toBeNull();
  });

  it("é case-insensitive no type (BODY/body)", () => {
    const components = [{ type: "body", text: "minúsculo" }];
    expect(extractBodyText(components)).toBe("minúsculo");
  });
});
