/**
 * Canal "WhatsApp via QR" — conexão NÃO oficial (WhatsApp Web) por um provedor
 * externo. O provedor é escolhido por WAQR_PROVIDER; hoje só existe "waha".
 * Para adicionar a Uazapi: criar `uazapi.ts` implementando WhatsAppQrProvider
 * e registrá-lo em PROVIDERS.
 */
import { NextResponse } from "next/server";
import { resolveWaqrSettings } from "@/lib/settings/whatsapp-qr";
import type { ChannelAdapter, SessionState } from "../types";
import type { WaqrSettings, WhatsAppQrProvider } from "./types";
import { wahaProvider } from "./waha";

const PROVIDERS: Record<string, WhatsAppQrProvider> = {
  waha: wahaProvider,
};

export const WAQR_WEBHOOK_PATH = "/api/webhooks/whatsapp-qr";

export async function loadWaqrSettings(): Promise<WaqrSettings> {
  const v = await resolveWaqrSettings();
  const trim = (url?: string) => url?.trim().replace(/\/+$/, "") || undefined;
  const crmBase =
    trim(v.WAQR_WEBHOOK_BASE_URL) ??
    trim(process.env.NEXT_PUBLIC_APP_URL) ??
    `http://localhost:${process.env.APP_PORT || "3100"}`;
  return {
    provider: v.WAQR_PROVIDER?.trim() || "waha",
    baseUrl: trim(v.WAQR_BASE_URL),
    session: v.WAQR_SESSION?.trim() || "default",
    apiKey: v.WAQR_API_KEY,
    webhookSecret: v.WAQR_WEBHOOK_SECRET,
    webhookUrl: `${crmBase}${WAQR_WEBHOOK_PATH}`,
  };
}

function providerFor(s: WaqrSettings): WhatsAppQrProvider | null {
  return PROVIDERS[s.provider] ?? null;
}

function unknownProvider(s: WaqrSettings): SessionState {
  return {
    channel: "whatsapp_qr",
    status: "missing_credentials",
    webhookUrl: s.webhookUrl,
    message: `Provedor "${s.provider}" não suportado. Use: ${Object.keys(PROVIDERS).join(", ")}.`,
  };
}

async function withProvider<T>(fn: (p: WhatsAppQrProvider, s: WaqrSettings) => Promise<T>): Promise<T> {
  const s = await loadWaqrSettings();
  const p = providerFor(s);
  if (!p) throw new Error(unknownProvider(s).message);
  return fn(p, s);
}

export const whatsappQrAdapter: ChannelAdapter = {
  id: "whatsapp_qr",

  async ensureSession() {
    const s = await loadWaqrSettings();
    const p = providerFor(s);
    return p ? p.ensureSession(s) : unknownProvider(s);
  },

  async getSessionStatus() {
    const s = await loadWaqrSettings();
    const p = providerFor(s);
    return p ? p.status(s) : unknownProvider(s);
  },

  // Provedores via QR não fazem handshake GET como a Meta.
  async verifyWebhook() {
    return NextResponse.json({ ok: true, channel: "whatsapp_qr" });
  },

  async parseWebhook(req) {
    const rawBody = await req.text();
    return withProvider(async (p, s) => p.parseWebhook(rawBody, req.headers, s));
  },

  async sendText(externalId, text) {
    return withProvider((p, s) => p.sendText(s, externalId, text));
  },

  async sendMedia(externalId, media) {
    return withProvider(async (p, s) => {
      if (!p.sendMedia) throw new Error(`Provedor ${p.id} não envia arquivos.`);
      await p.sendMedia(s, externalId, media);
    });
  },

  async setTyping(externalId, on) {
    return withProvider(async (p, s) => {
      await p.setTyping?.(s, externalId, on);
    });
  },
};

/** Desconecta o número da sessão (rota admin). Dados do CRM ficam intactos. */
export function logoutWaqr(): Promise<SessionState> {
  return withProvider(async (p, s) => {
    if (!p.logout) throw new Error(`Provedor ${p.id} não suporta desconectar pelo CRM.`);
    return p.logout(s);
  });
}

/** Imagem do QR code da sessão (rota admin). */
export function fetchWaqrQr(): Promise<Response> {
  return withProvider((p, s) => p.qr(s));
}

/** Baixa uma mídia recebida pelo canal (rota autenticada de mídia). */
export function fetchWaqrMedia(mediaUrl: string, range: string | null): Promise<Response> {
  return withProvider((p, s) => p.fetchMedia(s, mediaUrl, range));
}
