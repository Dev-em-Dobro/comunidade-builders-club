import Link from "next/link";
import { headers } from "next/headers";
import { auth } from "@/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { secretsKeyConfigured } from "@/lib/crypto/secrets";
import { googleConnectionStatus, googleRedirectUri, originFromHeaders } from "@/lib/google/oauth";
import { SHEET_HEADER } from "@/lib/google/sheets";
import { prisma } from "@/lib/db";
import { clearSheetsTarget } from "../actions";
import { ConnectionAlert, GoogleAccountCard } from "../_components/google-account";
import { CopyField, CreateSpreadsheetButton, GoogleClientForm, SheetsTargetForm, SyncPendingButton } from "../_components/forms";
import { ArrowLeft, ExternalLink } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function GoogleSheetsIntegrationPage({
  searchParams,
}: {
  searchParams: Promise<{ connected?: string; error?: string }>;
}) {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const sp = await searchParams;
  const status = await googleConnectionStatus();
  const redirectUri = googleRedirectUri(originFromHeaders(await headers()));
  const pending = await prisma.appointment.count({ where: { sheetSyncedAt: null } }).catch(() => 0);

  return (
    <div className="p-6 md:p-8 max-w-3xl space-y-6">
      <header>
        <Link href="/integrations" className="text-xs text-muted-foreground inline-flex items-center gap-1 hover:underline">
          <ArrowLeft className="size-3" /> Integrações
        </Link>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight mt-2">Google Sheets</h1>
        <p className="text-muted-foreground mt-1">
          Opcional. Cada consulta agendada vira uma linha na planilha; cancelamentos atualizam a coluna Status. Para só
          baixar as consultas, use <strong>Baixar CSV</strong> na aba Consultas do agente — não precisa de Google.
        </p>
      </header>

      <ConnectionAlert connected={sp.connected} error={sp.error} />

      {!secretsKeyConfigured() && (
        <div role="alert" className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm">
          Configure a variável SECRETS_KEY no servidor — ela criptografa as credenciais do Google.
        </div>
      )}

      {!status.connected && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">1. Credenciais do Google Cloud</CardTitle>
            <CardDescription>
              Crie um “ID do cliente OAuth” do tipo <strong>Aplicativo da Web</strong> no Google Cloud Console, ative a API
              Google Sheets e cadastre o URI de redirecionamento abaixo. O passo a passo está em{" "}
              <code>docs/INTEGRACOES_GOOGLE.md</code>.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <p className="text-sm font-medium">URI de redirecionamento autorizado</p>
              <CopyField value={redirectUri} />
              {!process.env.PUBLIC_BASE_URL && (
                <p className="text-xs text-amber-600">
                  PUBLIC_BASE_URL não está definida — o endereço acima foi deduzido desta requisição. Defina a variável com
                  o domínio público do CRM para evitar divergência.
                </p>
              )}
            </div>
            {status.credentials === "ambiente" ? (
              <p className="text-sm text-muted-foreground">
                Usando GOOGLE_OAUTH_CLIENT_ID/SECRET do servidor ({status.clientIdHint}). Salvar abaixo substitui pelos
                valores do painel.
              </p>
            ) : null}
            <GoogleClientForm hasSecret={status.credentials === "painel"} clientIdHint={status.clientIdHint} />
          </CardContent>
        </Card>
      )}

      <GoogleAccountCard status={status} />

      {status.connected && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Planilha de agendamentos</CardTitle>
            <CardDescription>Colunas: {SHEET_HEADER.join(" · ")}.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {status.sheetsSpreadsheetId ? (
              <div className="space-y-3">
                <p className="text-sm">
                  Vinculada à aba <strong>{status.sheetsTabName}</strong>.{" "}
                  {status.sheetsSpreadsheetUrl && (
                    <a
                      href={status.sheetsSpreadsheetUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex items-center gap-1 underline"
                    >
                      Abrir planilha <ExternalLink className="size-3" />
                    </a>
                  )}
                </p>
                <SyncPendingButton pending={pending} />
                <form action={clearSheetsTarget}>
                  <Button type="submit" variant="ghost" size="sm" className="text-destructive">
                    Desvincular planilha
                  </Button>
                </form>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">Nenhuma planilha vinculada ainda.</p>
            )}

            <div className="border-t border-border pt-6 space-y-4">
              <p className="text-sm font-medium">{status.sheetsSpreadsheetId ? "Trocar de planilha" : "Vincular planilha"}</p>
              <CreateSpreadsheetButton />
              <p className="text-xs text-muted-foreground">ou use uma planilha que já existe:</p>
              <SheetsTargetForm currentTab={status.sheetsTabName} />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
