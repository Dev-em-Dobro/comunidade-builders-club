import { isChannelEnabled } from "@/lib/config";
import { NextResponse } from "next/server";
import { whatsappQrAdapter } from "@/lib/channels/whatsapp-qr";
import { HmacFailure } from "@/lib/channels/whatsapp-cloud";
import { enqueueForDebounce } from "@/lib/debounce";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return whatsappQrAdapter.verifyWebhook(req);
}

export async function POST(req: Request) {
  if (!isChannelEnabled("whatsapp_qr")) {
    log({ event: "webhook.whatsapp_qr.channel_disabled", hint: "Ative o recebimento no Onboarding ou em Configurações → Geral" });
    return NextResponse.json({ ok: false, error: "channel_disabled" }, { status: 403 });
  }
  // Responder 200 rápido: o provedor reentrega se demorar. Debounce + LLM seguem assíncronos.
  try {
    const msg = await whatsappQrAdapter.parseWebhook(req);
    if (!msg) {
      // Eventos fora do escopo: enviadas pelo próprio número, grupos, status, outra sessão.
      return NextResponse.json({ ok: true, skipped: true });
    }
    log({ event: "webhook.whatsapp_qr.recv", providerMsgId: msg.providerMsgId, contactId: msg.contactId });
    void enqueueForDebounce(msg);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof HmacFailure) {
      log({ event: "webhook.whatsapp_qr.invalid_signature" });
      return NextResponse.json({ ok: false }, { status: 401 });
    }
    log({ event: "webhook.whatsapp_qr.error", error: String((err as Error)?.message ?? err) });
    // 200 mesmo em erro, para evitar reentrega infinita.
    return NextResponse.json({ ok: true, error: "internal" });
  }
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
