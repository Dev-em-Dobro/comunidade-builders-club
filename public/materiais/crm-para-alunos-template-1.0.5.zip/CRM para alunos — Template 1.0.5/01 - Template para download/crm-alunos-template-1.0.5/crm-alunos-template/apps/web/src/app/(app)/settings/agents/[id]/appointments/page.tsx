import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { addDays, dayLabel, isValidDate, slotLabel, zonedParts, zonedToUtc } from "@/lib/scheduling/time";
import { schedulingTimezone } from "@/lib/scheduling/timezone";
import { cancelAppointmentAction } from "./actions";
import { appointmentsHref } from "./_href";
import { AppointmentsCalendar, ProfessionalFilter } from "./_components/appointments-calendar";
import { AgentHeader, requireAgentOfRole } from "../_agent";
import { CalendarCheck, Download } from "lucide-react";

export const dynamic = "force-dynamic";

type View = "calendar" | "upcoming" | "past";

/** "2026-11" → "2026-12" */
function nextMonth(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return m === 12 ? `${y! + 1}-01` : `${y}-${String(m! + 1).padStart(2, "0")}`;
}

/** Último dia do mês "2026-11" → "2026-11-30" */
function lastDayOf(month: string): string {
  return addDays(`${nextMonth(month)}-01`, -1);
}

const include = { contact: { select: { displayName: true } } } as const;

export default async function AgentAppointmentsPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ view?: string; day?: string; month?: string; professional?: string }>;
}) {
  const { id } = await params;
  const agent = await requireAgentOfRole(id, "scheduling");
  const sp = await searchParams;
  const view: View = sp.view === "upcoming" || sp.view === "past" ? sp.view : "calendar";
  const tz = schedulingTimezone();
  const now = new Date();
  const today = zonedParts(now, tz).date;
  const day = sp.day && isValidDate(sp.day) ? sp.day : today;
  const month = sp.month && /^\d{4}-(0[1-9]|1[0-2])$/.test(sp.month) ? sp.month : day.slice(0, 7);
  const professional = sp.professional || null;
  const byProfessional = { agentSessionId: agent.id, ...(professional ? { professionalId: professional } : {}) };

  const professionals = await prisma.professional
    .findMany({ where: { agentSessionId: agent.id }, orderBy: { name: "asc" }, select: { id: true, name: true } })
    .catch(() => []);

  let busyDays: string[] = [];
  let rows: Row[] = [];
  async function loadRows(where: Prisma.AppointmentWhereInput, order: "asc" | "desc"): Promise<Row[]> {
    return prisma.appointment
      .findMany({ where: { ...byProfessional, ...where }, orderBy: { startsAt: order }, take: 200, include })
      .catch(() => []);
  }

  if (view === "calendar") {
    const monthAppts = await prisma.appointment
      .findMany({
        where: {
          ...byProfessional,
          status: "scheduled",
          startsAt: {
            gte: zonedToUtc(`${month}-01`, "00:00", tz),
            lt: zonedToUtc(`${nextMonth(month)}-01`, "00:00", tz),
          },
        },
        select: { startsAt: true },
      })
      .catch(() => []);
    busyDays = [...new Set(monthAppts.map((a) => zonedParts(a.startsAt, tz).date))];
    rows = await loadRows(
      { startsAt: { gte: zonedToUtc(day, "00:00", tz), lt: zonedToUtc(addDays(day, 1), "00:00", tz) } },
      "asc",
    );
  } else {
    rows = await loadRows(
      view === "past" ? { startsAt: { lt: now } } : { startsAt: { gte: now } },
      view === "past" ? "desc" : "asc",
    );
  }

  const tabs: { key: View; label: string }[] = [
    { key: "calendar", label: "Calendário" },
    { key: "upcoming", label: "Próximas" },
    { key: "past", label: "Anteriores" },
  ];
  const keep: Record<string, string | null> =
    view === "calendar" ? { day: sp.day ?? null, month: sp.month ?? null } : {};
  const exportFrom = view === "calendar" ? `${month}-01` : today.slice(0, 8) + "01";
  const exportTo = view === "calendar" ? lastDayOf(month) : lastDayOf(today.slice(0, 7));

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <AgentHeader agent={agent} active="appointments" description={`Consultas marcadas por este agente (fuso ${tz}).`}>
        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <Link
              key={t.key}
              href={appointmentsHref(agent.id, { view: t.key === "calendar" ? null : t.key, professional })}
              className={buttonVariants({ variant: view === t.key ? "default" : "outline", size: "sm" })}
            >
              {t.label}
            </Link>
          ))}
        </div>
      </AgentHeader>

      <div className="space-y-6">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <ProfessionalFilter
            agentId={agent.id}
            professionals={professionals}
            current={professional}
            baseParams={{ view: view === "calendar" ? null : view, ...keep }}
          />
          <form action="/api/appointments/export" method="get" className="flex flex-wrap items-end gap-2">
            <input type="hidden" name="agent" value={agent.id} />
            {professional && <input type="hidden" name="professional" value={professional} />}
            <label className="text-xs text-muted-foreground space-y-1">
              <span className="block">De</span>
              <Input type="date" name="from" defaultValue={exportFrom} required className="w-auto" />
            </label>
            <label className="text-xs text-muted-foreground space-y-1">
              <span className="block">Até</span>
              <Input type="date" name="to" defaultValue={exportTo} required className="w-auto" />
            </label>
            <Button type="submit" variant="outline">
              <Download className="size-4" /> Baixar CSV
            </Button>
          </form>
        </div>

        {view === "calendar" ? (
          <div className="grid gap-6 md:grid-cols-[auto_1fr] items-start">
            <AppointmentsCalendar
              agentId={agent.id}
              day={day}
              month={month}
              busyDays={busyDays}
              professional={professional}
            />
            <section className="space-y-3 min-w-0">
              <h2 className="text-lg font-medium capitalize">
                {dayLabel(day)}
                {day === today && (
                  <span className="text-sm text-muted-foreground font-normal normal-case"> · hoje</span>
                )}
              </h2>
              {rows.length === 0 ? (
                <Card className="p-8 text-center text-sm text-muted-foreground">Nenhuma consulta neste dia.</Card>
              ) : (
                <AppointmentsTable agentId={agent.id} rows={rows} tz={tz} now={now} showDate={false} />
              )}
            </section>
          </div>
        ) : rows.length === 0 ? (
          <Card className="p-12 flex flex-col items-center text-center">
            <CalendarCheck className="size-10 text-muted-foreground mb-3" />
            <p className="font-medium">{view === "past" ? "Nenhuma consulta anterior" : "Nenhuma consulta marcada"}</p>
            <p className="text-sm text-muted-foreground mt-1">
              As consultas aparecem aqui quando o agente marca pelo WhatsApp.
            </p>
          </Card>
        ) : (
          <AppointmentsTable agentId={agent.id} rows={rows} tz={tz} now={now} showDate />
        )}
      </div>
    </div>
  );
}

type Row = Prisma.AppointmentGetPayload<{ include: typeof include }>;

function AppointmentsTable({
  agentId,
  rows,
  tz,
  now,
  showDate,
}: {
  agentId: string;
  rows: Row[];
  tz: string;
  now: Date;
  showDate: boolean;
}) {
  return (
    <Card className="overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>{showDate ? "Quando" : "Horário"}</TableHead>
            <TableHead>Profissional</TableHead>
            <TableHead>Paciente</TableHead>
            <TableHead>Pré-consulta</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((a) => {
            const intake = (a.intake ?? {}) as Record<string, string>;
            const labels = (a.intakeLabels ?? {}) as Record<string, string>;
            const entries = Object.entries(intake);
            const start = zonedParts(a.startsAt, tz).time;
            const end = zonedParts(a.endsAt, tz).time;
            return (
              <TableRow key={a.id}>
                <TableCell className="whitespace-nowrap text-sm">
                  {showDate ? slotLabel(a.startsAt, tz) : `${start}–${end}`}
                </TableCell>
                <TableCell className="text-sm">{a.professionalName}</TableCell>
                <TableCell className="text-sm">
                  {a.conversationId ? (
                    <Link href={`/conversations/${a.conversationId}`} className="underline">
                      {a.contact.displayName ?? "Paciente"}
                    </Link>
                  ) : (
                    (a.contact.displayName ?? "Paciente")
                  )}
                </TableCell>
                <TableCell className="text-xs max-w-72 whitespace-normal">
                  {entries.length ? (
                    <details>
                      <summary className="cursor-pointer text-muted-foreground">{entries.length} resposta(s)</summary>
                      <dl className="mt-2 space-y-1">
                        {entries.map(([k, v]) => (
                          <div key={k}>
                            <dt className="text-muted-foreground">{labels[k] ?? k}</dt>
                            <dd>{v}</dd>
                          </div>
                        ))}
                      </dl>
                    </details>
                  ) : (
                    <span className="text-muted-foreground">—</span>
                  )}
                </TableCell>
                <TableCell>
                  <Badge variant={a.status === "scheduled" ? "default" : "outline"}>
                    {a.status === "scheduled" ? "agendada" : "cancelada"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  {a.status === "scheduled" && a.startsAt >= now && (
                    <form action={cancelAppointmentAction.bind(null, agentId, a.id)}>
                      <Button type="submit" variant="ghost" size="sm" className="text-destructive">
                        Cancelar
                      </Button>
                    </form>
                  )}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </Card>
  );
}
