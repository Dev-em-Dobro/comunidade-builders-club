import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AgentForm } from "../_components/agent-form";
import { AgentHeader } from "./_agent";
import { normalizeIntakeFields } from "@/lib/scheduling/intake";
import { allProviderModels } from "@/lib/llm/models";
import { normalizeHumanize } from "@/lib/humanize";

export const dynamic = "force-dynamic";

export default async function EditAgentPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const agent = await safeQuery(id);
  if (!agent) notFound();

  const [creds, modelOptions] = await Promise.all([
    prisma.providerCredential
      .findMany({ select: { provider: true } })
      .catch(() => [] as { provider: string }[]),
    allProviderModels(),
  ]);
  const configuredProviders = creds.map((c) => c.provider);

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader
        agent={agent}
        active=""
        description={<span className="font-mono text-xs">{agent.id}</span>}
      />
      <AgentForm
        initial={{
          id: agent.id,
          name: agent.name,
          persona: agent.persona,
          systemPrompt: agent.systemPrompt,
          model: agent.model,
          provider: agent.provider,
          temperature: agent.temperature,
          maxTokens: agent.maxTokens,
          memoryMode: agent.memoryMode,
          isDefault: agent.isDefault,
          role: agent.role,
          intakeFields: normalizeIntakeFields(agent.intakeFields),
          humanize: normalizeHumanize(agent.humanize),
        }}
        configuredProviders={configuredProviders}
        modelOptions={modelOptions}
      />
    </div>
  );
}

async function safeQuery(id: string) {
  try {
    return await prisma.agentSession.findUnique({ where: { id } });
  } catch {
    return null;
  }
}
