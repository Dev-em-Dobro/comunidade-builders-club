/**
 * Conversão entre o chatId do WhatsApp Web e o externalId guardado no CRM.
 *
 * - Contato comum `5511999999999@c.us` → `5511999999999` (mesmo formato do wa_id
 *   da Cloud API, o que facilita casar contatos entre canais).
 * - Contato com identificador oculto `123456@lid` → mantido inteiro (`123456@lid`):
 *   não é telefone, e o envio precisa do sufixo para chegar ao destino certo.
 * - Grupos, status, canais e broadcast → null (o CRM só atende conversas 1:1).
 */
export function chatIdToExternalId(chatId: unknown): string | null {
  if (typeof chatId !== "string") return null;
  const at = chatId.lastIndexOf("@");
  if (at <= 0) return null;
  // Alguns engines anexam o dispositivo: "5511999999999:12@c.us".
  const user = chatId.slice(0, at).split(":")[0]!;
  const server = chatId.slice(at + 1);
  if (server === "c.us" || server === "s.whatsapp.net") return /^\d{6,20}$/.test(user) ? user : null;
  if (server === "lid") return /^\d{1,32}$/.test(user) ? `${user}@lid` : null;
  return null;
}

/** Inverso de `chatIdToExternalId`: telefone vira `@c.us`; `@lid` passa intacto. */
export function externalIdToChatId(externalId: string): string {
  if (/^\d{1,32}@lid$/.test(externalId)) return externalId;
  const digits = externalId.replace(/\D/g, "");
  if (!/^\d{6,20}$/.test(digits)) throw new Error("externalId de WhatsApp inválido para envio");
  return `${digits}@c.us`;
}
