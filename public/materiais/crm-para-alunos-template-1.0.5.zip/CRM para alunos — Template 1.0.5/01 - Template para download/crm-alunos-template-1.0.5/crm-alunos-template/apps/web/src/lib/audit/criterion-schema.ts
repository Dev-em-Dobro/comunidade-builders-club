/**
 * Validador único compartilhado entre API REST e Server Actions do CRUD
 * de AuditCriterion. Mensagens em PT (UI-facing). API era programmatic-only
 * (sem consumers externos), então PT é OK em ambos.
 *
 * `exampleFail`: string vazia é normalizada pra null no schema — assim API
 * e Actions concordam (M2/M4 do code review).
 */
import { z } from "zod";

const nameField = z
  .string()
  .trim()
  .min(1, "Nome obrigatório")
  .max(120, "Nome muito longo (máximo 120 caracteres)");

const descriptionField = z
  .string()
  .trim()
  .min(1, "Descrição obrigatória")
  .max(2000, "Descrição muito longa (máximo 2000 caracteres)");

/**
 * `exampleFail`: aceita string ou null. Transform empty/whitespace → null
 * (M2/M4). `.optional()` por último pra que, quando ausente, NÃO apareça no
 * parsed output — assim o refine de "patch vazio" não é enganado.
 */
const exampleFailField = z
  .string()
  .max(2000, "Exemplo de fail muito longo (máximo 2000 caracteres)")
  .nullable()
  .transform((v) => (v == null || v.trim().length === 0 ? null : v))
  .optional();

const weightField = z
  .number({ message: "Peso inválido — use 1 a 5" })
  .int("Peso inválido — use 1 a 5")
  .min(1, "Peso inválido — use 1 a 5")
  .max(5, "Peso inválido — use 1 a 5");

/** Para POST: name+description obrigatórios, weight/active com default. */
export const CriterionInputSchema = z.object({
  name: nameField,
  description: descriptionField,
  exampleFail: exampleFailField,
  weight: weightField.default(3),
  active: z.boolean().default(true),
});

/** Para PATCH: todos opcionais, mínimo 1 campo informado. */
export const CriterionPatchSchema = z
  .object({
    name: nameField.optional(),
    description: descriptionField.optional(),
    exampleFail: exampleFailField,
    weight: weightField.optional(),
    active: z.boolean().optional(),
  })
  .refine((obj) => Object.keys(obj).length > 0, {
    message: "Informe ao menos 1 campo",
  });

export type CriterionInput = z.infer<typeof CriterionInputSchema>;
export type CriterionPatch = z.infer<typeof CriterionPatchSchema>;

/**
 * Extrai a 1ª mensagem de erro do ZodError. UI mostra string única — não
 * acumulamos erros por campo (overkill pra esse form).
 */
export function firstZodError(err: z.ZodError): string {
  return err.issues[0]?.message ?? "Payload inválido";
}

/**
 * Converte FormData (Server Actions) num shape que o schema aceita.
 * - weight string → number
 * - active checkbox → boolean (checkbox desligado = field ausente = false)
 */
export function criterionFromFormData(fd: FormData): {
  id: string | null;
  payload: Record<string, unknown>;
} {
  const id = (fd.get("id") as string | null) || null;
  const weightRaw = fd.get("weight");
  const weight =
    weightRaw == null || weightRaw === "" ? undefined : Number(weightRaw);
  return {
    id,
    payload: {
      name: fd.get("name") ?? "",
      description: fd.get("description") ?? "",
      exampleFail: fd.get("exampleFail") ?? null,
      weight,
      active: fd.get("active") === "on",
    },
  };
}

/** Campos públicos do AuditCriterion (M5 — sem createdAt/updatedAt). */
export const CRITERION_PUBLIC_SELECT = {
  id: true,
  name: true,
  description: true,
  exampleFail: true,
  weight: true,
  active: true,
} as const;
