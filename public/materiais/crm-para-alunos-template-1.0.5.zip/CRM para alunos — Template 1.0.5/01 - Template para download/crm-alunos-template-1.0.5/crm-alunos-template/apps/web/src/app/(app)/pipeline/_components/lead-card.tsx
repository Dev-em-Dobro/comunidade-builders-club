"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useRouter } from "next/navigation";
import { STAGE_LABEL } from "@/app/(app)/leads/stages";
import type { Assignee, LeadView } from "./types";

const ROLE_LABEL: Record<string, string> = {
  sdr: "SDR",
  closer: "Vendas",
  support: "Suporte",
};

function assigneeLabel(a: Assignee): string {
  if (a.type === "human") return `👤 ${a.name}`;
  const role = a.role ? ROLE_LABEL[a.role] : null;
  return role ? `🤖 ${role} · ${a.name}` : `🤖 ${a.name}`;
}

function relativeTime(iso: string | null): string {
  if (!iso) return "—";
  const diffMs = Date.now() - new Date(iso).getTime();
  const hours = Math.floor(diffMs / 3_600_000);
  if (hours < 1) return "agora";
  if (hours < 24) return `${hours}h atrás`;
  const days = Math.floor(hours / 24);
  return `${days}d atrás`;
}

function channelIcon(channel: string | null): string {
  if (channel === "whatsapp_cloud") return "📱";
  if (channel === "whatsapp_qr") return "💬";
  if (channel === "instagram") return "📷";
  return "·";
}

function windowStatus(
  windowClosesAt: string | null,
  windowExpired: boolean,
): { label: string; className: string } | null {
  if (!windowClosesAt) return null;
  const closesAt = new Date(windowClosesAt).getTime();
  const remainingMs = closesAt - Date.now();
  if (windowExpired || remainingMs <= 0) {
    return {
      label: "🔒 janela fechada",
      className:
        "bg-rose-500/15 text-rose-700 border-rose-500/30 dark:text-rose-300",
    };
  }
  const totalMin = Math.floor(remainingMs / 60_000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  const remaining = h > 0 ? `${h}h${m > 0 ? ` ${m}m` : ""}` : `${m}m`;
  const closingSoon = remainingMs <= 60 * 60_000; // <1h
  return {
    label: `🟢 janela: ${remaining}`,
    className: closingSoon
      ? "bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-300"
      : "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-300",
  };
}

function scoreBadgeClass(score: number): string {
  if (score >= 70)
    return "bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-300";
  if (score >= 40)
    return "bg-amber-500/15 text-amber-700 border-amber-500/30 dark:text-amber-300";
  return "bg-slate-500/10 text-slate-600 border-slate-500/20 dark:text-slate-300";
}

export function LeadCard({
  lead,
  showStageBadge,
}: {
  lead: LeadView;
  showStageBadge: boolean;
}) {
  const router = useRouter();
  const win = windowStatus(lead.windowClosesAt, lead.windowExpired);

  function onClick() {
    if (lead.conversationId) {
      router.push(`/conversations/${lead.conversationId}`);
    }
  }

  return (
    <Card
      className="p-3 cursor-pointer hover:bg-muted/30 transition-colors space-y-1.5"
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && onClick()}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="font-medium text-sm truncate">
          {lead.contactDisplayName ?? "Sem nome"}
        </span>
        <Badge
          variant="outline"
          className={`font-mono text-[10px] shrink-0 ${scoreBadgeClass(lead.score)}`}
        >
          score {lead.score}
        </Badge>
      </div>
      {lead.courseName && (
        <div className="text-xs text-muted-foreground truncate">
          {lead.courseName}
        </div>
      )}
      {lead.assignee && (
        <div
          className={`text-[10px] truncate ${
            lead.assignee.type === "human"
              ? "text-foreground font-medium"
              : "text-muted-foreground"
          }`}
        >
          {assigneeLabel(lead.assignee)}
        </div>
      )}
      <div className="flex items-center justify-between text-[10px] text-muted-foreground font-mono">
        <span>
          {channelIcon(lead.channel)} {relativeTime(lead.lastActivityAt)}
        </span>
        {showStageBadge && (
          <Badge variant="secondary" className="text-[10px]">
            {STAGE_LABEL[lead.stage] ?? lead.stage}
          </Badge>
        )}
      </div>
      {win && (
        <Badge
          variant="outline"
          className={`font-mono text-[10px] w-full justify-center ${win.className}`}
        >
          {win.label}
        </Badge>
      )}
    </Card>
  );
}
