/**
 * Next.js 16 boot hook — chama ensureSession() de cada canal habilitado
 * uma vez por worker, após o servidor subir.
 *
 * Gotcha 0.9.20: durante `next build`, Next instancia o módulo brevemente
 * (phase-production-build). Sem o guard abaixo, ensureSession bate na Graph API
 * com credenciais possivelmente ausentes → build falha.
 *
 * Idempotente — ver patterns/idempotent-sessions.md.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;
  if (process.env.NEXT_PHASE === "phase-production-build") return;
  if (process.env.SKIP_INSTRUMENTATION === "true") return;

  try {
    const { getEnabledAdapters } = await import("./lib/channels/registry");
    const adapters = getEnabledAdapters();

    for (const adapter of adapters) {
      try {
        const state = await adapter.ensureSession({});
        console.log(JSON.stringify({
          event: "channel.ensured",
          channel: adapter.id,
          status: state.status,
          message: state.message,
          at: new Date().toISOString(),
        }));
      } catch (err) {
        // NUNCA derrubar o app — operador conserta via /onboarding.
        console.error(JSON.stringify({
          event: "channel.ensure_failed",
          channel: adapter.id,
          error: String((err as Error)?.message ?? err),
          at: new Date().toISOString(),
        }));
      }
    }
  } catch (err) {
    console.error(JSON.stringify({
      event: "instrumentation.boot_failed",
      error: String((err as Error)?.message ?? err),
      at: new Date().toISOString(),
    }));
  }

  // ── BullMQ workers (Parte 1) — guards de runtime/build já aplicados acima.
  if (process.env.ENABLE_WORKER !== "false") {
    try {
      const { startWorkers } = await import("./lib/queue/workers");
      const workers = startWorkers();
      console.log(JSON.stringify({
        event: "workers.started",
        count: workers.length,
        at: new Date().toISOString(),
      }));
    } catch (err) {
      console.error(JSON.stringify({
        event: "workers.boot_failed",
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }));
    }

    // ── Job schedulers repetíveis (Parte 7) — scan window24h a cada 15 min.
    try {
      const { registerSchedulers } = await import("./lib/queue/schedulers");
      await registerSchedulers();
      console.log(JSON.stringify({
        event: "schedulers.registered",
        at: new Date().toISOString(),
      }));
    } catch (err) {
      console.error(JSON.stringify({
        event: "schedulers.boot_failed",
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }));
    }
  }
}
