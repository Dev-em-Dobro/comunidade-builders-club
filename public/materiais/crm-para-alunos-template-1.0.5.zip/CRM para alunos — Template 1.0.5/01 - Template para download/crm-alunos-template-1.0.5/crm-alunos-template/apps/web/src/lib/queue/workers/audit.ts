import type { Job } from "bullmq";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { runAudit } from "@/lib/audit/run-audit";
import type { AuditJobData } from "@/lib/queue/types";
import { auditReapProcessor } from "./audit-reap";

/**
 * Dispatcher da fila `audit`.
 *
 * - `audit.run`  → executa o auditor pro AuditReport dado.
 * - `audit.reap` → reaper de reports running órfãos.
 *
 * Se `runAudit` lançar, marca o report como 'error' (não o job — BullMQ
 * decide retry à parte). Reaproveita o padrão best-effort do qualify.
 */
export async function auditProcessor(job: Job): Promise<void> {
  if (job.name === "audit.reap") {
    return auditReapProcessor(job);
  }
  if (job.name !== "audit.run") {
    // Guard explícito: job names desconhecidos não rodam runAudit por
    // acidente (ex: scheduler config muda no futuro e cria 'audit.foo').
    console.log(
      JSON.stringify({
        event: "audit.unknown_job_name",
        jobName: job.name,
        jobId: job.id,
        at: new Date().toISOString(),
      }),
    );
    return;
  }

  const { reportId } = job.data as AuditJobData;
  if (!reportId) return;
  try {
    await runAudit(reportId);
  } catch (err) {
    await prisma.auditReport
      .update({
        where: { id: reportId },
        data: {
          status: "error",
          errorMessage: String((err as Error)?.message ?? err),
          finishedAt: new Date(),
          costUsd: new Prisma.Decimal(0),
        },
      })
      .catch(() => {
        // Se até a marca de erro falhar (DB offline), não há muito a fazer.
      });
    throw err;
  }
}
