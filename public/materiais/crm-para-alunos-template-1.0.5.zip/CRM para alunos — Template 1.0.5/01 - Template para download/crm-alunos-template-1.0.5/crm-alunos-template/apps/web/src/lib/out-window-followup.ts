/**
 * Predicados puros da cadência de follow-up FORA da janela 24h.
 *
 * Sem Prisma — o worker carrega o estado e chama os predicados. Espelha o
 * estilo de `reengagement.ts` / `window24h.ts` (isFollowupDue).
 *
 * Âncora de tempo = `windowClosesAt` (instante em que a janela fechou). Os
 * intervalos são cumulativos a partir daí, então não há drift. Resposta do lead
 * reabre a janela e zera `lastFollowUpStep` (flush.ts), pausando a cadência.
 */

const DAY_MS = 24 * 60 * 60 * 1000;

export interface OutWindowConfig {
  intervalsDays: number[];
  eligibleStages: string[];
  lostGraceDays: number;
}

/** Campos (por conversa) que `isOutOfWindowFollowupDue` precisa. */
export interface OutWindowCandidate {
  windowClosesAt: Date | null;
  lastFollowUpStep: number | null;
  lastFollowUpAt: Date | null; // não usado por isOutOfWindowFollowupDue; conveniência do caller
  leadStage: string | null;
  audience: string | null;
  aiEnabled: boolean;
  handoffRequested: boolean;
}

/** Campos (por lead) que `isOutOfWindowCadenceExhaustedLost` precisa. */
export interface ExhaustedLostCandidate {
  leadStage: string | null;
  audience: string | null;
  lastFollowUpStep: number | null;
  lastFollowUpAt: Date | null;
}

function stageEligible(stage: string | null, eligibleStages: string[]): boolean {
  return stage != null && eligibleStages.includes(stage);
}

/**
 * Step de follow-up devido agora (1..maxSteps) ou null.
 *
 * true-ish quando: janela FECHADA, IA ativa, sem handoff, stage elegível,
 * audience === "prospect", cadência não esgotada, e o `dueAt` do próximo step
 * (= windowClosesAt + intervalsDays[step-1]) já passou.
 */
export function isOutOfWindowFollowupDue(
  c: OutWindowCandidate,
  now: Date,
  cfg: OutWindowConfig,
): number | null {
  if (c.windowClosesAt == null) return null;
  if (c.windowClosesAt.getTime() > now.getTime()) return null; // janela aberta
  if (!c.aiEnabled || c.handoffRequested) return null;
  if (!stageEligible(c.leadStage, cfg.eligibleStages)) return null;
  if (c.audience !== "prospect") return null;

  const maxSteps = cfg.intervalsDays.length;
  const current = c.lastFollowUpStep ?? 0;
  if (current >= maxSteps) return null;

  const next = current + 1;
  const dueAt = c.windowClosesAt.getTime() + cfg.intervalsDays[next - 1] * DAY_MS;
  return now.getTime() >= dueAt ? next : null;
}

/**
 * Lead já é caso de `lost(no_response)` por cadência esgotada?
 *
 * true quando: stage elegível, prospect, F3 enviado (step === maxSteps) e
 * passaram `lostGraceDays` desde o último follow-up sem o lead responder
 * (resposta zera o step em flush.ts, então step===maxSteps implica sem resposta).
 */
export function isOutOfWindowCadenceExhaustedLost(
  c: ExhaustedLostCandidate,
  now: Date,
  cfg: OutWindowConfig,
): boolean {
  if (!stageEligible(c.leadStage, cfg.eligibleStages)) return false;
  if (c.audience !== "prospect") return false;
  const maxSteps = cfg.intervalsDays.length;
  if ((c.lastFollowUpStep ?? 0) < maxSteps) return false;
  if (c.lastFollowUpAt == null) return false;
  return now.getTime() >= c.lastFollowUpAt.getTime() + cfg.lostGraceDays * DAY_MS;
}

/**
 * O lead está sob uma cadência fora-da-janela ainda ativa? Usado pela
 * reconciliação no reengajamento (não marcar lost-em-24h antes do F3).
 */
export function ownsLeadForOutWindowCadence(
  c: { leadStage: string | null; audience: string | null; lastFollowUpStep: number | null },
  cfg: Pick<OutWindowConfig, "eligibleStages" | "intervalsDays">,
): boolean {
  if (!stageEligible(c.leadStage, cfg.eligibleStages)) return false;
  if (c.audience !== "prospect") return false;
  return (c.lastFollowUpStep ?? 0) < cfg.intervalsDays.length;
}

/**
 * Variáveis do template: [primeiroNome, nomeCurso], cortadas em `variableCount`.
 * Fallbacks calorosos quando faltam dados.
 */
export function resolveTemplateVars(
  displayName: string | null,
  courseName: string | null,
  variableCount: number,
): string[] {
  const firstName = displayName?.trim().split(/\s+/)[0] || "tudo bem";
  const course = courseName?.trim() || "o curso";
  return [firstName, course].slice(0, Math.max(0, variableCount));
}
