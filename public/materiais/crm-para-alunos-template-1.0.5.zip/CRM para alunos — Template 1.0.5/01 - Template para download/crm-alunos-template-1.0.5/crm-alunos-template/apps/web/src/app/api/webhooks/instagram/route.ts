import { isChannelEnabled } from "@/lib/config";
import { NextResponse } from "next/server";
import { instagramAdapter } from "@/lib/channels/instagram";
import { HmacFailure } from "@/lib/channels/whatsapp-cloud";
import { enqueueForDebounce } from "@/lib/debounce";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return instagramAdapter.verifyWebhook(req);
}

export async function POST(req: Request) {
  if (!isChannelEnabled("instagram")) return NextResponse.json({ ok: false, error: "channel_disabled" }, { status: 403 });
  try {
    const msg = await instagramAdapter.parseWebhook(req);
    if (!msg) return NextResponse.json({ ok: true, skipped: true });
    log({ event: "webhook.instagram.recv", providerMsgId: msg.providerMsgId, contactId: msg.contactId });
    void enqueueForDebounce(msg);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof HmacFailure) {
      log({ event: "webhook.instagram.invalid_signature" });
      return NextResponse.json({ ok: false }, { status: 401 });
    }
    log({
      event: "webhook.instagram.error",
      error: String((err as Error)?.message ?? err),
    });
    return NextResponse.json({ ok: true, error: "internal" });
  }
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
