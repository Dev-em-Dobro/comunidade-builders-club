import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { slaConfig } from "@/lib/config";
import { slaCompliancePct, trendDelta } from "../metrics";

const DAY_MS = 24 * 60 * 60 * 1000;

interface SlaData {
  current: number | null;
  delta: number | null;
  error: boolean;
}

async function getSla(): Promise<SlaData> {
  try {
    const now = Date.now();
    const d7 = new Date(now - 7 * DAY_MS);
    const d14 = new Date(now - 14 * DAY_MS);

    const [curTotal, curBreached, prevTotal, prevBreached] = await Promise.all([
      prisma.lead.count({ where: { firstInboundAt: { gte: d7 } } }),
      prisma.lead.count({
        where: { firstInboundAt: { gte: d7 }, slaBreachedAt: { not: null } },
      }),
      prisma.lead.count({
        where: { firstInboundAt: { gte: d14, lt: d7 } },
      }),
      prisma.lead.count({
        where: {
          firstInboundAt: { gte: d14, lt: d7 },
          slaBreachedAt: { not: null },
        },
      }),
    ]);

    const current = slaCompliancePct(curTotal, curBreached);
    const previous = slaCompliancePct(prevTotal, prevBreached);
    const delta =
      current !== null && previous !== null
        ? trendDelta(current, previous)
        : null;
    return { current, delta, error: false };
  } catch {
    return { current: null, delta: null, error: true };
  }
}

export async function SlaSection() {
  const { current, delta, error } = await getSla();
  const threshold = slaConfig().thresholdMin;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">SLA de 1ª resposta</CardTitle>
        <CardDescription>
          Respondidos em &lt;{threshold} min · últimos 7 dias
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : current === null ? (
          <p className="text-sm text-muted-foreground">
            Sem leads no período.
          </p>
        ) : (
          <div className="flex flex-col gap-1">
            <span className="text-3xl font-mono font-semibold">
              {current.toFixed(0)}%
            </span>
            {delta !== null && <TrendBadge delta={delta} />}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function TrendBadge({ delta }: { delta: number }) {
  const rounded = Math.round(delta);
  if (rounded === 0) {
    return (
      <span className="flex items-center gap-1 text-xs text-muted-foreground">
        <Minus className="size-3" /> estável vs. 7d anteriores
      </span>
    );
  }
  const up = rounded > 0;
  return (
    <span
      className={`flex items-center gap-1 text-xs ${
        up ? "text-success" : "text-destructive"
      }`}
    >
      {up ? (
        <TrendingUp className="size-3" />
      ) : (
        <TrendingDown className="size-3" />
      )}
      {up ? "+" : ""}
      {rounded} pts vs. 7d anteriores
    </span>
  );
}
