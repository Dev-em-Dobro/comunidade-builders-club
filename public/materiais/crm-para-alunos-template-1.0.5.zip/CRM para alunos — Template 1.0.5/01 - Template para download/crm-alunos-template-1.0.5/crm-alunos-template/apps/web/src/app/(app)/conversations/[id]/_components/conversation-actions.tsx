"use client";

import { useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Bot,
  Pause,
  Play,
  UserCheck,
  UserPlus,
  UserMinus,
  UserX,
  Loader2,
} from "lucide-react";

interface Props {
  conversationId: string;
  /** Controlado pelo parent (ConversationView) pra Composer reagir sem refresh. */
  aiEnabled: boolean;
  handoffRequested: boolean;
  onAiEnabledChange: (next: boolean) => void;
  onHandoffRequestedChange: (next: boolean) => void;
  /** Dono atual da conversa. Null = sem dono. */
  assignedUserId: string | null;
  /** Nome do dono (fallback pra email/id pelo parent). */
  assignedUserName: string | null;
  /** Id do user logado pra discriminar self vs outro. */
  sessionUserId: string;
  /** Quando o handler externo (conv_event SSE) atualiza posse, o parent
   * passa novos values. Internamente só usamos optimistic update via callback. */
  onOwnershipChange?: (next: {
    assignedUserId: string | null;
    assignedUserName: string | null;
  }) => void;
}

/**
 * Header de ações da conversa:
 *  - badge "Atendente: Bot" quando IA em controle; senão "Atendente: <nome>"
 *  - botão Assumir / Roubar / Liberar conforme ownership
 *  - Pausar IA / Reativar IA / Resolver handoff
 *
 * Assumir/Roubar disparam claim que ALSO pausa IA no server — composer abre
 * sem refresh porque aiEnabled é controlado pelo parent.
 */
export function ConversationActions({
  conversationId,
  aiEnabled,
  handoffRequested,
  onAiEnabledChange,
  onHandoffRequestedChange,
  assignedUserId,
  assignedUserName,
  sessionUserId,
  onOwnershipChange,
}: Props) {
  const [pending, startTransition] = useTransition();

  const ownsSelf = assignedUserId === sessionUserId;
  const ownedByOther = assignedUserId != null && !ownsSelf;
  const noOwner = assignedUserId == null;
  const aiInControl = aiEnabled && !handoffRequested;

  async function patchConversation(patch: {
    aiEnabled?: boolean;
    handoffRequested?: boolean;
  }) {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/conversations/${conversationId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(patch),
        });
        if (!r.ok) throw new Error(`HTTP ${r.status}`);
        if (patch.aiEnabled !== undefined) onAiEnabledChange(patch.aiEnabled);
        if (patch.handoffRequested !== undefined)
          onHandoffRequestedChange(patch.handoffRequested);
        toast.success("Atualizado");
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  async function callClaim(opts: { action: "claim" | "release"; force?: boolean }) {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/conversations/${conversationId}/claim`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(opts),
        });
        const body = (await r.json().catch(() => ({}))) as {
          error?: string;
          ownerId?: string;
          claimed?: boolean;
          assignedUserId?: string;
          aiPausedByClaim?: boolean;
        };
        if (!r.ok) {
          if (body.error === "owned_by_other") {
            toast.error("Conversa pertence a outro atendente. Use 'Roubar'.");
          } else if (body.error === "not_owner") {
            toast.error("Só o dono pode liberar a conversa.");
          } else {
            toast.error(body.error ?? `HTTP ${r.status}`);
          }
          return;
        }
        if (opts.action === "release") {
          onOwnershipChange?.({ assignedUserId: null, assignedUserName: null });
          toast.success("Conversa liberada");
        } else {
          // claim: parent ainda vai receber conv_event com o userName real
          onOwnershipChange?.({
            assignedUserId: sessionUserId,
            assignedUserName: assignedUserName ?? null,
          });
          if (body.aiPausedByClaim) onAiEnabledChange(false);
          toast.success("Conversa atribuída a você");
        }
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  function onRoubarClick() {
    if (
      typeof window !== "undefined" &&
      !window.confirm(
        `Esta conversa está com ${assignedUserName ?? "outro atendente"}. Roubar mesmo assim?`,
      )
    ) {
      return;
    }
    callClaim({ action: "claim", force: true });
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {aiInControl ? (
        <Badge
          variant="outline"
          className="font-mono text-[10px] gap-1 border-primary/40 text-primary"
        >
          <Bot className="size-3" />
          Atendente: Bot
        </Badge>
      ) : assignedUserId ? (
        <Badge
          variant="outline"
          className={`font-mono text-[10px] gap-1 ${
            ownsSelf
              ? "border-primary/40 text-primary"
              : "border-muted-foreground/40 text-muted-foreground"
          }`}
        >
          <UserCheck className="size-3" />
          Atendente: {assignedUserName ?? "—"}
        </Badge>
      ) : null}

      {noOwner && (
        <Button
          size="sm"
          variant="outline"
          onClick={() => callClaim({ action: "claim" })}
          disabled={pending}
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <UserPlus className="size-4" />}
          Assumir conversa
        </Button>
      )}
      {ownedByOther && (
        <Button
          size="sm"
          variant="outline"
          onClick={onRoubarClick}
          disabled={pending}
          className="border-destructive/40 text-destructive hover:bg-destructive/10"
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <UserX className="size-4" />}
          Roubar conversa
        </Button>
      )}
      {ownsSelf && (
        <Button
          size="sm"
          variant="ghost"
          onClick={() => callClaim({ action: "release" })}
          disabled={pending}
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <UserMinus className="size-4" />}
          Liberar
        </Button>
      )}

      {handoffRequested && (
        <Badge variant="outline" className="font-mono text-[10px] border-warning/30 text-warning">
          humano solicitado
        </Badge>
      )}
      {handoffRequested ? (
        <Button
          size="sm"
          onClick={() => patchConversation({ handoffRequested: false, aiEnabled: true })}
          disabled={pending}
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <UserCheck className="size-4" />}
          Resolver solicitação
        </Button>
      ) : aiEnabled ? (
        <Button
          size="sm"
          variant="outline"
          onClick={() => patchConversation({ aiEnabled: false })}
          disabled={pending}
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Pause className="size-4" />}
          Pausar IA
        </Button>
      ) : (
        <Button
          size="sm"
          onClick={() => patchConversation({ aiEnabled: true })}
          disabled={pending}
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Play className="size-4" />}
          Reativar IA
        </Button>
      )}
    </div>
  );
}
