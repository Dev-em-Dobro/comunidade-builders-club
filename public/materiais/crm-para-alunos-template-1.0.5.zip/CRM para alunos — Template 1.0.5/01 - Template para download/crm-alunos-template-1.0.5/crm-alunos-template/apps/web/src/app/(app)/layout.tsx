import { businessConfig } from "@/lib/config";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Bot, LogOut, KeyRound } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { auth, signOut } from "@/auth";
import { prisma } from "@/lib/db";
import {
  NotificationBell,
  type BellNotification,
} from "@/components/notification-bell";
import { OnDutyToggle } from "@/components/on-duty-toggle";
import { NAV, NavGroup } from "./_nav";
import { MobileNav } from "./mobile-nav";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  // Guard defensivo — proxy.ts já cobre, mas double-check pra rotas protegidas.
  const session = await auth();
  if (!session?.user) redirect("/login");

  const notifications = await safeNotifications(session.user.id);
  const isOnDuty = await safeOnDuty(session.user.id);

  async function logoutAction() {
    "use server";
    await signOut({ redirectTo: "/login" });
  }

  return (
    <div className="min-h-screen flex">
      <aside className="hidden md:flex w-60 flex-col border-r border-border bg-sidebar text-sidebar-foreground">
        <div className="px-5 py-5 flex items-center gap-3">
          <div className="size-7 rounded-md bg-primary flex items-center justify-center">
            <Bot className="size-4 text-primary-foreground" />
          </div>
          <span className="font-mono text-sm font-semibold">{businessConfig().brandName}</span>
          <Badge variant="outline" className="font-mono text-[10px]">MVP</Badge>
          <div className="ml-auto flex items-center gap-1">
            <OnDutyToggle initial={isOnDuty} />
            <NotificationBell notifications={notifications} />
          </div>
        </div>
        <Separator />
        <nav className="flex-1 px-2 py-4 space-y-6">
          <NavGroup items={NAV.filter((n) => n.group === "main")} />
          <div>
            <p className="px-3 mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">
              Configurações
            </p>
            <NavGroup items={NAV.filter((n) => n.group === "settings")} />
          </div>
        </nav>
        <Separator />
        <div className="px-3 py-3 space-y-2">
          <div className="px-2 text-[11px] text-muted-foreground truncate">
            {session.user.email}
          </div>
          <Link
            href="/settings/password"
            className="flex items-center gap-3 rounded-md px-2 py-2 text-xs hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
          >
            <KeyRound className="size-3.5 text-primary" />
            Trocar senha
          </Link>
          <form action={logoutAction}>
            <button
              type="submit"
              className="w-full flex items-center gap-3 rounded-md px-2 py-2 text-xs text-left hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
            >
              <LogOut className="size-3.5 text-primary" />
              Sair
            </button>
          </form>
        </div>
      </aside>
      <main className="flex-1 min-w-0 flex flex-col">
        <MobileNav
          brandName={businessConfig().brandName}
          notifications={notifications}
          isOnDuty={isOnDuty}
          userEmail={session.user.email ?? ""}
          logoutAction={logoutAction}
        />
        {children}
      </main>
    </div>
  );
}

/** Últimas notificações do usuário pro sino. DB fora = lista vazia. */
async function safeNotifications(userId: string): Promise<BellNotification[]> {
  try {
    const rows = await prisma.notification.findMany({
      where: { userId },
      orderBy: { createdAt: "desc" },
      take: 15,
    });
    return rows.map((n) => {
      const p = (n.payload ?? {}) as Record<string, unknown>;
      const conversationId =
        typeof p.conversationId === "string" ? p.conversationId : null;
      return {
        id: n.id,
        title: typeof p.title === "string" ? p.title : n.type,
        body: typeof p.body === "string" ? p.body : "",
        read: n.readAt != null,
        href: conversationId ? `/conversations/${conversationId}` : null,
        createdAt: n.createdAt.toLocaleString("pt-BR", {
          day: "2-digit",
          month: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
        }),
      };
    });
  } catch {
    return [];
  }
}

/** isOnDuty do usuário logado. DB fora = false (fora de plantão). */
async function safeOnDuty(userId: string): Promise<boolean> {
  try {
    const u = await prisma.user.findUnique({
      where: { id: userId },
      select: { isOnDuty: true },
    });
    return u?.isOnDuty ?? false;
  } catch {
    return false;
  }
}
