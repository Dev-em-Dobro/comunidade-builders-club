import { describe, it, expect } from "vitest";
import { buildReengagementSystem } from "./followup";

describe("buildReengagementSystem", () => {
  it("inclui horas sem responder e horas até a janela fechar", () => {
    const s = buildReengagementSystem(20, 3);
    expect(s).toContain("20h sem responder");
    expect(s).toContain("~3h");
  });

  it("omite o trecho de horas sem responder quando hoursSince é null", () => {
    const s = buildReengagementSystem(null, 4);
    expect(s).not.toContain("sem responder");
    expect(s).toContain("~4h");
  });

  it("instrui a gerar UMA mensagem", () => {
    expect(buildReengagementSystem(10, 2)).toContain("UMA mensagem");
  });
});
