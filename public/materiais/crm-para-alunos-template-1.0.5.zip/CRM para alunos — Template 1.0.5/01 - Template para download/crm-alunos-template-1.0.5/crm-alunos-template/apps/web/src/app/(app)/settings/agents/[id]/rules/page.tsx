import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { AgentHeader } from "../_agent";
import { RulesManager } from "./rules-manager";
import type { SerializedRule } from "./types";

export const dynamic = "force-dynamic";

export default async function RulesPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const agent = await safeQuery(id);
  if (!agent) notFound();

  const rules: SerializedRule[] = agent.aiRules.map((r) => ({
    id: r.id,
    priority: r.priority,
    enabled: r.enabled,
    mode: r.mode,
    action: r.action,
    params: (r.params ?? {}) as Record<string, unknown>,
    staticReply: r.staticReply,
  }));

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader
        agent={agent}
        active="rules"
        description="Decidem, a cada mensagem recebida, se a IA responde, fica calada, ou transfere a conversa para um humano — antes de chamar o LLM."
      />

      <RulesManager agentId={agent.id} rules={rules} />
    </div>
  );
}

async function safeQuery(id: string) {
  try {
    return await prisma.agentSession.findUnique({
      where: { id },
      include: { aiRules: { orderBy: { priority: "asc" } } },
    });
  } catch {
    return null;
  }
}
