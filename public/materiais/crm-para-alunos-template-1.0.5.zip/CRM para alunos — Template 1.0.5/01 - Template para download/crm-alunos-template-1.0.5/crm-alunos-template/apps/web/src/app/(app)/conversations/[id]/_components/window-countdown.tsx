"use client";

import { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Clock } from "lucide-react";

interface Props {
  /** Quando a janela 24h fecha. null = sem inbound ainda → tratada como fechada. */
  windowClosesAt: Date | null;
}

/**
 * Mostra "Xh Ymin restantes" na janela 24h do WhatsApp/Instagram.
 * Tick a cada 60s (precisão em minutos é suficiente).
 * Cor: >6h verde, 1-6h amarelo, <1h vermelho, fechada cinza.
 */
export function WindowCountdown({ windowClosesAt }: Props) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const tick = () => setNow(Date.now());
    const id = setInterval(tick, 60_000);
    return () => clearInterval(id);
  }, []);

  if (!windowClosesAt) {
    return (
      <Badge variant="outline" className="gap-1 text-[10px] border-muted-foreground/30 text-muted-foreground">
        <Clock className="size-3" />
        janela fechada
      </Badge>
    );
  }

  const remainingMs = windowClosesAt.getTime() - now;
  if (remainingMs <= 0) {
    return (
      <Badge variant="outline" className="gap-1 text-[10px] border-destructive/40 text-destructive">
        <Clock className="size-3" />
        janela fechada
      </Badge>
    );
  }

  const totalMin = Math.floor(remainingMs / 60_000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  const label = h > 0 ? `${h}h ${m}min restantes` : `${m}min restantes`;

  let className =
    "gap-1 text-[10px] border-emerald-500/40 text-emerald-700 dark:text-emerald-400";
  if (remainingMs < 60 * 60_000) {
    className = "gap-1 text-[10px] border-destructive/40 text-destructive";
  } else if (remainingMs < 6 * 60 * 60_000) {
    className = "gap-1 text-[10px] border-amber-500/40 text-amber-700 dark:text-amber-400";
  }

  return (
    <Badge variant="outline" className={className}>
      <Clock className="size-3" />
      {label}
    </Badge>
  );
}
