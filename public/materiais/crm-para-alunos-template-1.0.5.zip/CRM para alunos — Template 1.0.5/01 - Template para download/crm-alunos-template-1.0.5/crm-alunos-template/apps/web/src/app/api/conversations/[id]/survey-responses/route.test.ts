import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "u-test" } })),
}));

import { GET } from "./route";
import { auth } from "@/auth";

const created = { contactIds: [] as string[] };
let convId: string;
let convNoResponsesId: string;

beforeAll(async () => {
  const c1 = await prisma.contact.create({
    data: { displayName: "Has responses" },
  });
  created.contactIds.push(c1.id);
  // Inserções separadas pra garantir createdAt distinto (createMany compartilha
  // statement e pode atribuir o mesmo timestamp).
  await prisma.surveyResponse.create({
    data: { contactId: c1.id, surveyName: "First", answers: { A: "1" } },
  });
  await new Promise((r) => setTimeout(r, 10));
  await prisma.surveyResponse.create({
    data: { contactId: c1.id, surveyName: "Second", answers: { B: "2" } },
  });
  const conv1 = await prisma.conversation.create({
    data: { contactId: c1.id, channel: "whatsapp_cloud" },
  });
  convId = conv1.id;

  const c2 = await prisma.contact.create({ data: { displayName: "No responses" } });
  created.contactIds.push(c2.id);
  const conv2 = await prisma.conversation.create({
    data: { contactId: c2.id, channel: "whatsapp_cloud" },
  });
  convNoResponsesId = conv2.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

function req(): Request {
  return new Request("http://localhost/test");
}

describe("GET /api/conversations/[id]/survey-responses", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await GET(req(), { params: Promise.resolve({ id: convId }) });
    expect(res.status).toBe(401);
  });

  it("404 conv inexistente", async () => {
    const res = await GET(req(), { params: Promise.resolve({ id: "nada" }) });
    expect(res.status).toBe(404);
  });

  it("200 lista ordenada desc por createdAt", async () => {
    const res = await GET(req(), { params: Promise.resolve({ id: convId }) });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { responses: Array<{ surveyName: string }> };
    expect(body.responses).toHaveLength(2);
    expect(body.responses[0]!.surveyName).toBe("Second"); // mais recente primeiro
    expect(body.responses[1]!.surveyName).toBe("First");
  });

  it("200 lista vazia se contact não tem responses", async () => {
    const res = await GET(req(), { params: Promise.resolve({ id: convNoResponsesId }) });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { responses: unknown[] };
    expect(body.responses).toHaveLength(0);
  });
});
