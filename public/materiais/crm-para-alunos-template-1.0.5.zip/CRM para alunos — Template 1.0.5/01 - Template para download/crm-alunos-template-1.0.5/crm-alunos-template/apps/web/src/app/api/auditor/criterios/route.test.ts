import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));

import { GET, POST } from "./route";
import { auth } from "@/auth";

const created: string[] = [];

afterAll(async () => {
  if (created.length > 0) {
    await prisma.auditCriterion.deleteMany({ where: { id: { in: created } } });
  }
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "test-user" } } as never);
});

describe("GET /api/auditor/criterios", () => {
  it("rejeita sem auth", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await GET();
    expect(res.status).toBe(401);
  });

  it("retorna 200 com array de criterions ordenados por weight desc, name asc", async () => {
    const res = await GET();
    expect(res.status).toBe(200);
    const body = (await res.json()) as { criteria: unknown[] };
    expect(Array.isArray(body.criteria)).toBe(true);
    // Pelo menos os 8 seeded estão lá
    expect(body.criteria.length).toBeGreaterThanOrEqual(8);
  });
});

describe("POST /api/auditor/criterios", () => {
  it("rejeita sem auth", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const req = new Request("http://test", {
      method: "POST",
      body: JSON.stringify({ name: "x", description: "y" }),
    });
    const res = await POST(req);
    expect(res.status).toBe(401);
  });

  it("rejeita payload inválido (name vazio)", async () => {
    const req = new Request("http://test", {
      method: "POST",
      body: JSON.stringify({ name: "", description: "ok" }),
    });
    const res = await POST(req);
    expect(res.status).toBe(400);
    const body = (await res.json()) as { error: string };
    // Schema compartilhado retorna mensagens em PT.
    expect(body.error).toMatch(/nome/i);
  });

  it("rejeita weight fora de 1-5", async () => {
    const req = new Request("http://test", {
      method: "POST",
      body: JSON.stringify({ name: "n", description: "d", weight: 6 }),
    });
    const res = await POST(req);
    expect(res.status).toBe(400);
  });

  it("cria criterion com defaults (weight=3, active=true) e retorna 201", async () => {
    const req = new Request("http://test", {
      method: "POST",
      body: JSON.stringify({
        name: `Teste criação ${Date.now()}`,
        description: "Descrição de teste",
      }),
    });
    const res = await POST(req);
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      criterion: {
        id: string;
        name: string;
        weight: number;
        active: boolean;
        exampleFail: string | null;
      };
    };
    created.push(body.criterion.id);
    expect(body.criterion.weight).toBe(3);
    expect(body.criterion.active).toBe(true);
    expect(body.criterion.exampleFail).toBeNull();
  });

  it("aceita campos opcionais (exampleFail, weight, active)", async () => {
    const req = new Request("http://test", {
      method: "POST",
      body: JSON.stringify({
        name: `Teste full ${Date.now()}`,
        description: "Descrição",
        exampleFail: "exemplo de fail",
        weight: 5,
        active: false,
      }),
    });
    const res = await POST(req);
    expect(res.status).toBe(201);
    const body = (await res.json()) as {
      criterion: { id: string; weight: number; active: boolean; exampleFail: string };
    };
    created.push(body.criterion.id);
    expect(body.criterion.weight).toBe(5);
    expect(body.criterion.active).toBe(false);
    expect(body.criterion.exampleFail).toBe("exemplo de fail");
  });
});
