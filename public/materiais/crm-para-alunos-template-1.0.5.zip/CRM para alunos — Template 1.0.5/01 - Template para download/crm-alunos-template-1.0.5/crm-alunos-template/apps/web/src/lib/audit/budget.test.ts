import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { exceedsRunBudget, getDailyCostUsd, exceedsDailyBudget } from "./budget";

// IDs criados por este arquivo — limpos no afterAll.
const createdReportIds: string[] = [];

afterAll(async () => {
  if (createdReportIds.length > 0) {
    await prisma.auditReport.deleteMany({ where: { id: { in: createdReportIds } } });
  }
  await prisma.$disconnect();
});

/** Cria um AuditReport com runAt e costUsd controlados. */
async function mkReport(costUsd: number, runAt: Date): Promise<string> {
  const r = await prisma.auditReport.create({
    data: {
      status: "done",
      trigger: "manual",
      costUsd,
      runAt,
      finishedAt: runAt,
    },
  });
  createdReportIds.push(r.id);
  return r.id;
}

// ── exceedsRunBudget ───────────────────────────────────────────────────────────

describe("exceedsRunBudget", () => {
  it("retorna false quando custo < cap", () => {
    expect(exceedsRunBudget(0.10, 0.20)).toBe(false);
  });

  it("retorna true quando custo > cap", () => {
    expect(exceedsRunBudget(0.25, 0.20)).toBe(true);
  });

  it("retorna true quando custo === cap (exato)", () => {
    expect(exceedsRunBudget(0.20, 0.20)).toBe(true);
  });
});

// ── getDailyCostUsd ────────────────────────────────────────────────────────────

describe("getDailyCostUsd", () => {
  it("soma só reports de hoje (UTC), ignora ontem", async () => {
    const startOfToday = new Date();
    startOfToday.setUTCHours(0, 0, 0, 0);

    const yesterday = new Date(startOfToday.getTime() - 1); // 23:59:59.999 de ontem

    // 2 reports de hoje, 1 de ontem.
    await mkReport(0.10, new Date(startOfToday.getTime() + 1000)); // hoje
    await mkReport(0.05, new Date(startOfToday.getTime() + 2000)); // hoje
    await mkReport(0.99, yesterday);                                 // ontem

    const daily = await getDailyCostUsd();
    // Pode haver outros reports de hoje de outros testes; verificamos só que
    // incluiu nossos 2 de hoje (>= 0.15) e não incluiu o de ontem (~0.99).
    expect(daily).toBeGreaterThanOrEqual(0.15);
    // Garante que o custo de ontem não está dentro.
    // Se estivesse, o valor seria >= 1.14, o que não deve ocorrer.
    expect(daily).toBeLessThan(1.0);
  });
});

// ── exceedsDailyBudget ─────────────────────────────────────────────────────────

describe("exceedsDailyBudget", () => {
  it("retorna exceeded=false quando soma fica abaixo do cap", async () => {
    const startOfToday = new Date();
    startOfToday.setUTCHours(0, 0, 0, 0);
    // Cria um estado limpo: custo atual do dia deve ser pequeno
    // Usamos cap generoso para garantir que não ultrapasse.
    const { exceeded } = await exceedsDailyBudget(0, 1000);
    expect(exceeded).toBe(false);
  });

  it("retorna exceeded=true quando soma excede o cap", async () => {
    // Cap de $0.01 — qualquer custo acumulado mais $0.05 vai exceder.
    const { exceeded } = await exceedsDailyBudget(0.05, 0.01);
    expect(exceeded).toBe(true);
  });

  it("retorna current com o custo já acumulado hoje", async () => {
    const { current } = await exceedsDailyBudget(0, 1000);
    expect(typeof current).toBe("number");
    expect(current).toBeGreaterThanOrEqual(0);
  });
});
