import type { Job } from "bullmq";
import { runAgentHandoff } from "@/lib/agent-handoff";
import type { AgentHandoffJobData } from "@/lib/queue/types";

/**
 * Processor do job `agent.handoff` — wrapper fino sobre `runAgentHandoff`.
 * Erros propagam → retry padrão da BullMQ.
 */
export async function agentHandoffProcessor(
  job: Job<AgentHandoffJobData>,
): Promise<void> {
  await runAgentHandoff(job.data.conversationId, job.data.toRole);
}
