import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import { notifyUsers } from "@/lib/notifications";
import { shouldEscalate } from "@/lib/handoff";
import { agentHandoffProcessor } from "./agent-handoff";
import type {
  SlaJobData,
  NotifyJobData,
  HandoffJobData,
} from "@/lib/queue/types";

/**
 * Processa `sla.deadline`: revalida se a conversa foi respondida no prazo.
 *
 * Revalidação: se `Conversation.slaJobId` não é mais este job, a resposta saiu
 * a tempo (`cancelSlaCheck` limpou o campo) — nada a fazer. Senão, marca o
 * breach. Idempotente: se o Lead já tem `slaBreachedAt`, sai.
 */
export async function slaProcessor(job: Job): Promise<void> {
  const { conversationId } = job.data as SlaJobData;

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { id: true, leadId: true, slaJobId: true },
  });
  if (!conv) return;

  if (conv.slaJobId !== job.id) {
    log("sla.check_resolved", { conversationId });
    return;
  }
  if (!conv.leadId) return;

  const lead = await prisma.lead.findUnique({
    where: { id: conv.leadId },
    select: { id: true, slaBreachedAt: true },
  });
  if (!lead || lead.slaBreachedAt) return;

  await prisma.lead.update({
    where: { id: lead.id },
    data: { slaBreachedAt: new Date() },
  });
  await prisma.pipelineEvent.create({
    data: { leadId: lead.id, type: "sla_breach", payload: { conversationId } },
  });
  await prisma.conversation.update({
    where: { id: conversationId },
    data: { slaJobId: null },
  });

  const notifyData: NotifyJobData = {
    kind: "sla_breach",
    conversationId,
    leadId: lead.id,
  };
  await enqueue("notify", "sla-breach", notifyData);

  log("sla.breached", { conversationId, leadId: lead.id });
}

/**
 * Processor registrado para a fila `sla` — despacha por nome de job.
 *  - `deadline`      → `slaProcessor` (Parte 4)
 *  - `handoff`       → `handoffEscalationProcessor` (Parte 8)
 *  - `agent.handoff` → `agentHandoffProcessor` (passagem SDR → closer)
 */
export async function slaQueueProcessor(job: Job): Promise<void> {
  if (job.name === "handoff") return handoffEscalationProcessor(job);
  if (job.name === "agent.handoff") return agentHandoffProcessor(job);
  return slaProcessor(job);
}

/**
 * Processa `sla.handoff`: escala um handoff que ninguém assumiu dentro do prazo.
 *
 * "Assumiu" = existe um `PipelineEvent('handoff_accepted')` posterior ao
 * `PipelineEvent('handoff')`. A decisão fica na função pura `shouldEscalate`.
 */
export async function handoffEscalationProcessor(job: Job): Promise<void> {
  const { conversationId } = job.data as HandoffJobData;

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { id: true, leadId: true, handoffRequested: true, contactId: true },
  });
  if (!conv) return;
  if (!conv.handoffRequested) {
    log("handoff.escalation_resolved", { conversationId });
    return;
  }

  let handoffAt: Date | null = null;
  let acceptedAt: Date | null = null;
  if (conv.leadId) {
    const events = await prisma.pipelineEvent.findMany({
      where: {
        leadId: conv.leadId,
        type: { in: ["handoff", "handoff_accepted"] },
      },
      orderBy: { createdAt: "desc" },
      select: { type: true, createdAt: true },
    });
    // events vem ordenado desc — o primeiro de cada tipo é o mais recente.
    handoffAt = events.find((e) => e.type === "handoff")?.createdAt ?? null;
    acceptedAt =
      events.find((e) => e.type === "handoff_accepted")?.createdAt ?? null;
  }

  if (
    !shouldEscalate({
      handoffRequested: conv.handoffRequested,
      handoffAt,
      acceptedAt,
    })
  ) {
    log("handoff.escalation_skipped", { conversationId });
    return;
  }

  // Idempotência: se já houve um escalonamento, não re-notifica — protege
  // contra re-entrega de job stalled. Espelha o slaProcessor (que checa
  // slaBreachedAt antes de agir).
  if (conv.leadId) {
    const already = await prisma.pipelineEvent.findFirst({
      where: { leadId: conv.leadId, type: "handoff_escalated" },
      select: { id: true },
    });
    if (already) {
      log("handoff.escalation_already_done", { conversationId });
      return;
    }
  }

  const contact = await prisma.contact.findUnique({
    where: { id: conv.contactId },
    select: { displayName: true },
  });
  const who = contact?.displayName ?? "Um lead";

  const team = await prisma.user.findMany({
    where: { role: { in: ["admin", "operator"] } },
    select: { id: true, email: true },
  });
  await notifyUsers(team, {
    type: "handoff_escalated",
    title: "Bot solicitou humano — ninguém assumiu (escalonado)",
    body: `${who} está aguardando atendimento e ninguém assumiu a solicitação a tempo.`,
    payload: { conversationId },
  });

  if (conv.leadId) {
    await prisma.pipelineEvent.create({
      data: {
        leadId: conv.leadId,
        type: "handoff_escalated",
        payload: { conversationId },
      },
    });
  }

  log("handoff.escalated", { conversationId });
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
