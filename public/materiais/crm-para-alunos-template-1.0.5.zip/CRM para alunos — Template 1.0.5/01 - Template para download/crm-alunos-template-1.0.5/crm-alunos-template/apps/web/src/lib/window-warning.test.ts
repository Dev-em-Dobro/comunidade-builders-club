import { describe, it, expect, beforeEach, vi } from "vitest";

const addMock = vi.fn();
const removeMock = vi.fn();
vi.mock("@/lib/queue", () => ({
  getQueue: () => ({ add: addMock, remove: removeMock }),
}));

import { scheduleWindowWarning, cancelWindowWarning } from "./window-warning";

beforeEach(() => {
  addMock.mockReset();
  addMock.mockResolvedValue({ id: "job-1" });
  removeMock.mockReset();
  removeMock.mockResolvedValue(undefined);
});

describe("scheduleWindowWarning", () => {
  it("agenda job com jobId determinístico e delay = closesAt - 60min - now", async () => {
    const closesAt = new Date(Date.now() + 5 * 60 * 60_000); // 5h
    await scheduleWindowWarning("conv-1", closesAt);
    expect(removeMock).toHaveBeenCalledWith("window-warning__conv-1");
    expect(addMock).toHaveBeenCalledTimes(1);
    const [jobName, data, opts] = addMock.mock.calls[0]!;
    expect(jobName).toBe("fire");
    expect(data).toEqual({ conversationId: "conv-1" });
    expect(opts.jobId).toBe("window-warning__conv-1");
    // delay = (5h * 60min/h - 60min) = 240min em ms (com tolerância pra now)
    expect(opts.delay).toBeGreaterThanOrEqual(239 * 60_000);
    expect(opts.delay).toBeLessThanOrEqual(241 * 60_000);
  });

  it("não agenda se fireAt já passou (closesAt <= now + 60min)", async () => {
    const closesAt = new Date(Date.now() + 30 * 60_000); // 30min
    await scheduleWindowWarning("conv-2", closesAt);
    expect(addMock).not.toHaveBeenCalled();
    // Não tenta remover também — não vale o round-trip.
  });

  it("remove job antigo antes de criar novo (idempotência cross-inbound)", async () => {
    const closesAt = new Date(Date.now() + 10 * 60 * 60_000);
    await scheduleWindowWarning("conv-3", closesAt);
    await scheduleWindowWarning("conv-3", closesAt);
    expect(removeMock).toHaveBeenCalledTimes(2);
    expect(removeMock).toHaveBeenNthCalledWith(1, "window-warning__conv-3");
  });
});

describe("cancelWindowWarning", () => {
  it("chama queue.remove com o jobId determinístico", async () => {
    await cancelWindowWarning("conv-4");
    expect(removeMock).toHaveBeenCalledWith("window-warning__conv-4");
  });
});
