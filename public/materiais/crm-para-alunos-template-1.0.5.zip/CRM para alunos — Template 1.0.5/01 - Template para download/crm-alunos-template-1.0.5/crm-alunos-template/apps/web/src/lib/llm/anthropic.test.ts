import { describe, it, expect, vi, beforeEach } from "vitest";

const createMock = vi.fn();
vi.mock("@anthropic-ai/sdk", () => {
  class BadRequestError extends Error {
    status = 400;
  }
  return {
    default: class {
      static BadRequestError = BadRequestError;
      messages = { create: createMock };
      constructor(_opts: unknown) {}
    },
  };
});

import Anthropic from "@anthropic-ai/sdk";
import { acceptsTemperature, anthropicProvider } from "./anthropic";
import type { LLMRequest } from "./types";

/** BadRequestError do mock acima (construtor simplificado: só a mensagem). */
const badRequest = (message: string) =>
  new (Anthropic.BadRequestError as unknown as new (m: string) => Error)(message);

const OK = {
  model: "x",
  content: [{ type: "text", text: "oi" }],
  usage: { input_tokens: 1, output_tokens: 1, cache_read_input_tokens: 0 },
};

beforeEach(() => {
  createMock.mockReset();
  createMock.mockResolvedValue(OK);
});

function baseReq(overrides: Partial<LLMRequest> = {}): LLMRequest {
  return {
    model: "claude-sonnet-4-6",
    temperature: 0.7,
    systemStatic: "s",
    messages: [{ role: "user", content: "oi" }],
    apiKey: "sk-test",
    ...overrides,
  };
}

describe("anthropicProvider temperature compat", () => {
  it("envia temperature para modelos que aceitam (sonnet-4-6)", async () => {
    await anthropicProvider.generateReply(baseReq({ model: "claude-sonnet-4-6" }));
    expect(createMock.mock.calls[0][0].temperature).toBe(0.7);
  });

  it("omite temperature para opus-4-8", async () => {
    await anthropicProvider.generateReply(baseReq({ model: "claude-opus-4-8" }));
    expect(createMock.mock.calls[0][0].temperature).toBeUndefined();
  });

  // Os modelos atuais recusam temperature customizada com 400 — o seletor de
  // modelo do agente oferece esses, então não podem quebrar (2026-11-14).
  it("omite temperature nos modelos atuais (Opus 5.5, Sonnet 5.5, Haiku 5.5, Fable)", async () => {
    for (const model of ["claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5", "claude-fable-5-2"]) {
      createMock.mockClear();
      await anthropicProvider.generateReply(baseReq({ model }));
      expect(createMock.mock.calls[0][0].temperature, model).toBeUndefined();
    }
  });

  it("aceita temperature só nos modelos anteriores ao Opus 4.7", () => {
    expect(acceptsTemperature("claude-sonnet-4-6")).toBe(true);
    expect(acceptsTemperature("claude-opus-4-6")).toBe(true);
    expect(acceptsTemperature("claude-haiku-4-5")).toBe(true);
    expect(acceptsTemperature("claude-sonnet-4-5-20250929")).toBe(true);
    expect(acceptsTemperature("claude-opus-4-7")).toBe(false);
    expect(acceptsTemperature("claude-opus-4-8")).toBe(false);
    expect(acceptsTemperature("claude-opus-5-5")).toBe(false);
    expect(acceptsTemperature("claude-sonnet-5")).toBe(false);
  });

  it("se a API recusar temperature, tenta 1x sem ela", async () => {
    createMock
      .mockRejectedValueOnce(badRequest("temperature: unsupported for this model"))
      .mockResolvedValueOnce(OK);
    const resp = await anthropicProvider.generateReply(baseReq({ model: "claude-sonnet-4-6" }));
    expect(createMock).toHaveBeenCalledTimes(2);
    expect(createMock.mock.calls[0][0].temperature).toBe(0.7);
    expect(createMock.mock.calls[1][0].temperature).toBeUndefined();
    expect(resp.text).toBe("oi");
  });

  it("se a API recusar tool_choice forçado, tenta 1x com auto", async () => {
    createMock
      .mockRejectedValueOnce(badRequest('tool_choice: type "tool" and "any" are not supported for this model.'))
      .mockResolvedValueOnce(OK);
    await anthropicProvider.generateReply(
      baseReq({ model: "claude-opus-5-5", toolChoice: { type: "tool", name: "record_audit" } }),
    );
    expect(createMock.mock.calls[0][0].tool_choice).toEqual({ type: "tool", name: "record_audit" });
    expect(createMock.mock.calls[1][0].tool_choice).toEqual({ type: "auto" });
  });

  it("não tenta de novo em outros erros", async () => {
    createMock.mockRejectedValueOnce(new Error("529 overloaded"));
    await expect(anthropicProvider.generateReply(baseReq())).rejects.toThrow(/overloaded/);
    expect(createMock).toHaveBeenCalledTimes(1);
  });
});
