import Link from "next/link";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { CriteriaTable } from "./_criteria-table";

export const dynamic = "force-dynamic";

export default async function CriteriosPage() {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const criteria = await prisma.auditCriterion.findMany({
    orderBy: [{ weight: "desc" }, { name: "asc" }],
    select: {
      id: true,
      name: true,
      description: true,
      exampleFail: true,
      weight: true,
      active: true,
    },
  });

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Critérios do auditor</h1>
        <Link href="/auditor" className={buttonVariants({ variant: "outline" })}>
          <ArrowLeft className="size-4" /> Voltar
        </Link>
      </div>

      <Card className="p-4 flex flex-col gap-4">
        <CriteriaTable criteria={criteria} />
      </Card>
    </div>
  );
}
