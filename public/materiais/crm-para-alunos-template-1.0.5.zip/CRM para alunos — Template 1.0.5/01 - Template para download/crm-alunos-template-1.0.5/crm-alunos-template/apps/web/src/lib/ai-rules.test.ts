import { describe, it, expect } from "vitest";
import { isSuppressedBatch } from "./ai-rules";
import type { ChannelMessage } from "@/lib/channels/types";

function msg(partial: Partial<ChannelMessage>): ChannelMessage {
  return {
    channel: "whatsapp_cloud",
    contactId: "5511999999999",
    text: "",
    receivedAt: "2026-06-09T00:00:00Z",
    raw: {},
    ...partial,
  };
}

/**
 * Reação (emoji numa msg) é registrada na inbox mas NÃO deve gerar auto-resposta.
 * O parser marca `suppressAutoReply`; o decideAction dropa o turno se TUDO no lote
 * for suprimível (mas responde normal se vier qualquer texto real junto).
 */
describe("isSuppressedBatch", () => {
  it("lote vazio → false", () => {
    expect(isSuppressedBatch([])).toBe(false);
  });

  it("só reação (suppressAutoReply) → true (não responde)", () => {
    expect(isSuppressedBatch([msg({ text: "[reação] 👍", suppressAutoReply: true })])).toBe(true);
  });

  it("reação + texto real no mesmo lote → false (responde ao texto)", () => {
    expect(
      isSuppressedBatch([
        msg({ text: "[reação] 👍", suppressAutoReply: true }),
        msg({ text: "oi, quero saber o preço" }),
      ]),
    ).toBe(false);
  });

  it("texto normal → false", () => {
    expect(isSuppressedBatch([msg({ text: "oi" })])).toBe(false);
  });
});
