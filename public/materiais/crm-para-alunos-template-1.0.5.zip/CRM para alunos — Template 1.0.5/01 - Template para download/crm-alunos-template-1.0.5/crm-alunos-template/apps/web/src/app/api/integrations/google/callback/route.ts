import { timingSafeEqual } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { completeOAuth, googleRedirectUri, originFromHeaders, publicBaseUrl } from "@/lib/google/oauth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const STATE_COOKIE = "google_oauth_state";

function sameState(a: string | undefined, b: string | null): boolean {
  if (!a || !b) return false;
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

/**
 * GET /api/integrations/google/callback
 * Retorno do consentimento do Google: confere o `state`, troca o code por
 * tokens e grava a conexão criptografada.
 */
export async function GET(req: NextRequest) {
  const back = `${publicBaseUrl(originFromHeaders(req.headers))}/integrations/google-sheets`;
  const fail = (code: string) => {
    const res = NextResponse.redirect(`${back}?error=${encodeURIComponent(code)}`);
    res.cookies.delete({ name: STATE_COOKIE, path: "/api/integrations/google" });
    return res;
  };

  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  if (gate.user.role !== "admin") return fail("forbidden");

  const params = req.nextUrl.searchParams;
  if (params.get("error")) return fail(params.get("error") === "access_denied" ? "access_denied" : "google_error");
  if (!sameState(req.cookies.get(STATE_COOKIE)?.value, params.get("state"))) return fail("invalid_state");
  const code = params.get("code");
  if (!code) return fail("missing_code");

  try {
    await completeOAuth(code, googleRedirectUri(originFromHeaders(req.headers)));
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "google.oauth_callback_failed",
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
    return fail("exchange_failed");
  }

  const res = NextResponse.redirect(`${back}?connected=1`);
  res.cookies.delete({ name: STATE_COOKIE, path: "/api/integrations/google" });
  return res;
}
