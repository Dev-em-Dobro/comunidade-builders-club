import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { claimConversation } from "@/lib/conversations/claim";
import { notifyConvEvent } from "@/lib/realtime/notify";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Body {
  action?: "claim" | "release";
  force?: boolean;
}

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { user } = gate;
  const { id: conversationId } = await params;
  const body = (await req.json().catch(() => ({}))) as Body;
  const action = body.action ?? "claim";

  // existência primeiro — claim/release ambos precisam.
  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { id: true, assignedUserId: true, aiEnabled: true },
  });
  if (!conv) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  if (action === "release") {
    if (conv.assignedUserId !== user.id) {
      return NextResponse.json({ error: "not_owner" }, { status: 403 });
    }
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { assignedUserId: null },
    });
    const lead = await prisma.conversation.findUnique({
      where: { id: conversationId },
      select: { leadId: true },
    });
    if (lead?.leadId) {
      await prisma.pipelineEvent.create({
        data: {
          leadId: lead.leadId,
          type: "handoff_released",
          payload: { userId: user.id },
        },
      });
    }
    await notifyConvEvent(conversationId, {
      type: "release",
      previousOwnerId: user.id,
    });
    return NextResponse.json({ ok: true });
  }

  // action === "claim"
  const result = await claimConversation(conversationId, user.id, {
    force: body.force === true,
  });

  if (!result.claimed && result.assignedUserId !== user.id) {
    return NextResponse.json(
      { error: "owned_by_other", ownerId: result.assignedUserId },
      { status: 409 },
    );
  }

  // Atendente humano assumindo → pausa a IA pra liberar o composer sem
  // refresh. Idempotente: só faz UPDATE se aiEnabled era true.
  let aiPausedByClaim = false;
  if (result.claimed && conv.aiEnabled) {
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { aiEnabled: false },
    });
    aiPausedByClaim = true;
  }

  if (result.claimed) {
    const actor = await prisma.user.findUnique({
      where: { id: user.id },
      select: { name: true },
    });
    await notifyConvEvent(conversationId, {
      type: "claim",
      userId: user.id,
      userName: actor?.name ?? null,
      previousOwnerId: result.previousOwnerId,
      aiPausedByClaim,
    });
  }

  return NextResponse.json({ ok: true, aiPausedByClaim, ...result });
}
