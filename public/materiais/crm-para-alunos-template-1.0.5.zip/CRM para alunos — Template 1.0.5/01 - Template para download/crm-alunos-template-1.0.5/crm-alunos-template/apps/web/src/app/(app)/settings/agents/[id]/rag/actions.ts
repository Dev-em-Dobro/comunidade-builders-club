"use server";

import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { ingestDocument } from "@/lib/rag/ingest";
import { extractPdf, extractUrl } from "@/lib/rag/extract";

export interface RagFormState {
  ok?: boolean;
  error?: string;
  message?: string;
}

type SourceType = "text" | "pdf" | "url";

export async function addRagDocument(formData: FormData): Promise<RagFormState> {
  const agentId = String(formData.get("agentId") ?? "");
  const sourceType = String(formData.get("sourceType") ?? "text") as SourceType;
  const title = String(formData.get("title") ?? "").trim();

  if (!agentId) return { error: "Agente inválido." };
  if (!title) return { error: "Título obrigatório." };

  try {
    let text = "";
    let sourceRef = "manual";

    if (sourceType === "text") {
      text = String(formData.get("text") ?? "").trim();
      if (!text) return { error: "Cole algum conteúdo no campo de texto." };
    } else if (sourceType === "pdf") {
      const file = formData.get("file");
      if (!(file instanceof File) || file.size === 0) {
        return { error: "Selecione um arquivo PDF." };
      }
      const buf = new Uint8Array(await file.arrayBuffer());
      text = await extractPdf(buf);
      sourceRef = file.name;
      if (!text.trim()) {
        return { error: "PDF sem texto extraível (provavelmente é escaneado/imagem)." };
      }
    } else if (sourceType === "url") {
      const url = String(formData.get("url") ?? "").trim();
      if (!url) return { error: "Informe a URL." };
      const extracted = await extractUrl(url);
      text = extracted.text;
      sourceRef = url;
      if (!text.trim()) return { error: "Não consegui extrair texto dessa página." };
    } else {
      return { error: "Tipo de fonte inválido." };
    }

    const result = await ingestDocument({
      agentSessionId: agentId,
      title,
      sourceType,
      sourceRef,
      text,
    });

    revalidatePath(`/settings/agents/${agentId}/rag`);
    return {
      ok: true,
      message: `"${title}" indexado — ${result.chunks} chunk${result.chunks !== 1 ? "s" : ""}.`,
    };
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
}

export async function deleteRagDocument(formData: FormData): Promise<void> {
  const docId = String(formData.get("docId") ?? "");
  const agentId = String(formData.get("agentId") ?? "");
  if (docId) {
    // RagChunk tem onDelete: Cascade — apagar o doc leva os chunks junto.
    await prisma.ragDoc.delete({ where: { id: docId } }).catch(() => {});
  }
  revalidatePath(`/settings/agents/${agentId}/rag`);
}
