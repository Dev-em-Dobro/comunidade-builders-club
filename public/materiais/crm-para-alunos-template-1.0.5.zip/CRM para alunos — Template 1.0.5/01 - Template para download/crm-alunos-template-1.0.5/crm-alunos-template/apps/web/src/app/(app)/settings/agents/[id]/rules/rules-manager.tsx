"use client";

import { useState, useTransition } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Construction, Pencil, Plus, Trash2 } from "lucide-react";
import { RuleForm } from "./rule-form";
import { deleteRule, toggleRule } from "./actions";
import { RULE_ACTIONS, RULE_MODES, type SerializedRule } from "./types";

const WEEKDAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

/** Resumo legível dos params da regra pro card. */
function summarize(rule: SerializedRule): string {
  const p = rule.params ?? {};
  switch (rule.mode) {
    case "keyword_trigger":
    case "keyword_pause": {
      const kw = Array.isArray(p.keywords) ? (p.keywords as string[]) : [];
      const mm = p.matchMode === "all" ? "todas" : "qualquer";
      return kw.length ? `${kw.join(", ")} · casa ${mm}` : "sem palavras";
    }
    case "contact_whitelist":
    case "contact_blacklist": {
      const ids = Array.isArray(p.contactIds) ? p.contactIds : [];
      return `${ids.length} contato${ids.length !== 1 ? "s" : ""}`;
    }
    case "schedule": {
      const days = Array.isArray(p.days) ? (p.days as number[]) : [];
      const ds = days
        .slice()
        .sort((a, b) => a - b)
        .map((d) => WEEKDAYS[d] ?? d)
        .join(", ");
      return `${ds || "nenhum dia"} · ${p.start ?? "?"}–${p.end ?? "?"}`;
    }
    default:
      return RULE_MODES.find((m) => m.id === rule.mode)?.desc ?? "—";
  }
}

export function RulesManager({
  agentId,
  rules,
}: {
  agentId: string;
  rules: SerializedRule[];
}) {
  // null = fechado · "new" = criando · SerializedRule = editando
  const [editing, setEditing] = useState<SerializedRule | "new" | null>(null);
  const [pending, startTransition] = useTransition();

  const close = () => setEditing(null);

  return (
    <>
      <div className="mb-4 flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          {rules.length} regra{rules.length !== 1 ? "s" : ""} · avaliadas por
          prioridade crescente
        </p>
        <Button size="sm" onClick={() => setEditing("new")}>
          <Plus className="size-4" />
          Nova regra
        </Button>
      </div>

      {rules.length === 0 ? (
        <Card className="flex flex-col items-center p-12 text-center">
          <Construction className="mb-3 size-10 text-muted-foreground" />
          <p className="font-medium">Sem regras configuradas</p>
          <p className="mt-1 max-w-md text-sm text-muted-foreground">
            Sem regras, o agente responde a tudo (<code>always_on</code>{" "}
            implícito). Crie a primeira regra para controlar quando a IA
            responde, fica calada, ou transfere para um humano.
          </p>
        </Card>
      ) : (
        <div className="space-y-2">
          {rules.map((r) => {
            const modeMeta = RULE_MODES.find((m) => m.id === r.mode);
            const actionMeta = RULE_ACTIONS.find((a) => a.id === r.action);
            return (
              <Card key={r.id} className={r.enabled ? undefined : "opacity-60"}>
                <CardContent className="flex items-center gap-3 py-3">
                  <Badge
                    variant="outline"
                    className="shrink-0 font-mono text-[10px]"
                  >
                    p{r.priority}
                  </Badge>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="truncate font-medium">
                        {modeMeta?.label ?? r.mode}
                      </span>
                      <Badge className="shrink-0 font-mono text-[10px]">
                        {actionMeta?.label ?? r.action}
                      </Badge>
                    </div>
                    <p className="truncate text-xs text-muted-foreground">
                      {summarize(r)}
                    </p>
                  </div>
                  <Switch
                    size="sm"
                    checked={r.enabled}
                    disabled={pending}
                    onCheckedChange={(checked) =>
                      startTransition(() =>
                        toggleRule(r.id, agentId, Boolean(checked)),
                      )
                    }
                    aria-label={r.enabled ? "Desativar regra" : "Ativar regra"}
                  />
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    onClick={() => setEditing(r)}
                    aria-label="Editar regra"
                  >
                    <Pencil className="size-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    className="text-destructive hover:text-destructive"
                    disabled={pending}
                    onClick={() => {
                      if (
                        window.confirm(
                          `Excluir esta regra (${modeMeta?.label ?? r.mode})?`,
                        )
                      ) {
                        startTransition(() => deleteRule(r.id, agentId));
                      }
                    }}
                    aria-label="Excluir regra"
                  >
                    <Trash2 className="size-4" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog
        open={editing !== null}
        onOpenChange={(open) => {
          if (!open) close();
        }}
      >
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editing === "new" ? "Nova regra" : "Editar regra"}
            </DialogTitle>
            <DialogDescription>
              Regras decidem, a cada mensagem, se a IA responde, fica calada,
              ou transfere para um humano.
            </DialogDescription>
          </DialogHeader>
          {editing && (
            <RuleForm
              key={editing === "new" ? "new" : editing.id}
              agentId={agentId}
              rule={editing === "new" ? undefined : editing}
              onSaved={close}
              onCancel={close}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
