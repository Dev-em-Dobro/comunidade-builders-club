import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));

import { POST } from "./route";
import { auth } from "@/auth";

const created = { contactIds: [] as string[], userIds: [] as string[] };
let userId: string;
let convId: string;

beforeAll(async () => {
  const u = await prisma.user.create({
    data: { email: `readroute-${Date.now()}@t.local`, name: "User R" },
  });
  userId = u.id;
  created.userIds.push(u.id);
  const contact = await prisma.contact.create({ data: { displayName: "T" } });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud", unreadCount: 4 },
  });
  convId = conv.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

function req(): Request {
  return new Request("http://localhost/api/conversations/x/read", { method: "POST" });
}

describe("POST /api/conversations/[id]/read", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(req(), { params: Promise.resolve({ id: convId }) });
    expect(res.status).toBe(401);
  });

  it("404 conversa inexistente", async () => {
    const res = await POST(req(), { params: Promise.resolve({ id: "missing" }) });
    expect(res.status).toBe(404);
  });

  it("200 zera o unreadCount", async () => {
    await prisma.conversation.update({ where: { id: convId }, data: { unreadCount: 4 } });
    const res = await POST(req(), { params: Promise.resolve({ id: convId }) });
    expect(res.status).toBe(200);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.unreadCount).toBe(0);
  });
});
