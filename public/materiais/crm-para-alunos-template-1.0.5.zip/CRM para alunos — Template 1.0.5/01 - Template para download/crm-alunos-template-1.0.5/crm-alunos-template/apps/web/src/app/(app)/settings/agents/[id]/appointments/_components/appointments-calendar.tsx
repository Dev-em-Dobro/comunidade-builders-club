"use client";

import { useRouter } from "next/navigation";
import { ptBR } from "react-day-picker/locale";
import { Calendar } from "@/components/ui/calendar";
import { appointmentsHref } from "../_href";

function toIso(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fromIso(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y!, m! - 1, d ?? 1);
}

/**
 * Calendário do mês (shadcn Calendar). Dias com consulta ganham um ponto;
 * clicar num dia mostra as consultas dele. Estado vive na URL.
 */
export function AppointmentsCalendar({
  agentId,
  day,
  month,
  busyDays,
  professional,
}: {
  agentId: string;
  /** Dia selecionado (YYYY-MM-DD). */
  day: string;
  /** Mês exibido (YYYY-MM). */
  month: string;
  /** Dias do mês com consulta agendada (YYYY-MM-DD). */
  busyDays: string[];
  professional: string | null;
}) {
  const router = useRouter();
  return (
    <Calendar
      mode="single"
      required
      locale={ptBR}
      selected={fromIso(day)}
      month={fromIso(`${month}-01`)}
      onSelect={(d) => {
        if (!d) return;
        const iso = toIso(d);
        router.push(appointmentsHref(agentId, { day: iso, month: iso.slice(0, 7), professional }));
      }}
      onMonthChange={(m) => {
        const iso = toIso(m);
        router.push(appointmentsHref(agentId, { day, month: iso.slice(0, 7), professional }));
      }}
      modifiers={{ busy: busyDays.map(fromIso) }}
      modifiersClassNames={{
        busy: "[&_button]:after:absolute [&_button]:after:bottom-1 [&_button]:after:left-1/2 [&_button]:after:size-1 [&_button]:after:-translate-x-1/2 [&_button]:after:rounded-full [&_button]:after:bg-primary",
      }}
      className="rounded-lg border border-border [--cell-size:--spacing(9)]"
    />
  );
}

export function ProfessionalFilter({
  agentId,
  professionals,
  current,
  baseParams,
}: {
  agentId: string;
  professionals: { id: string; name: string }[];
  current: string | null;
  /** Demais parâmetros da URL a preservar (view, day, month). */
  baseParams: Record<string, string | null>;
}) {
  const router = useRouter();
  return (
    <select
      aria-label="Filtrar por profissional"
      value={current ?? ""}
      onChange={(e) => router.push(appointmentsHref(agentId, { ...baseParams, professional: e.target.value || null }))}
      className="h-8 rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30"
    >
      <option value="">Todos os profissionais</option>
      {professionals.map((p) => (
        <option key={p.id} value={p.id}>
          {p.name}
        </option>
      ))}
    </select>
  );
}
