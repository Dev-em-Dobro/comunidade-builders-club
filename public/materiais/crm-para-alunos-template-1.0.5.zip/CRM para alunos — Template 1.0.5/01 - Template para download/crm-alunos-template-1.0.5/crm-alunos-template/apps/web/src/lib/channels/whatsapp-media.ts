import { resolveMetaSettings } from "@/lib/settings/meta";
type VisibleMediaType = "image" | "audio" | "document";
import { META_GRAPH_BASE as META_MEDIA_GRAPH_BASE } from "./meta-graph";

/** O URL retornado pela Meta expira em minutos; nunca é persistido no banco. */
export async function fetchWhatsAppMedia(
  mediaId: string,
  type: VisibleMediaType,
  range?: string | null,
): Promise<{ upstream: Response; mimeType: string }> {
  const meta = await resolveMetaSettings();
  const token = meta.META_SYSTEM_USER_TOKEN;
  const phoneNumberId = meta.META_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) throw new Error("Credenciais WhatsApp ausentes");
  if (!/^\d+$/.test(mediaId)) throw new Error("ID de mídia inválido");

  const metadataUrl = new URL(`${META_MEDIA_GRAPH_BASE}/${mediaId}`);
  metadataUrl.searchParams.set("phone_number_id", phoneNumberId);
  const metadataResponse = await fetch(metadataUrl, {
    headers: { Authorization: `Bearer ${token}` },
    cache: "no-store",
  });
  if (!metadataResponse.ok) throw new Error(`Meta não encontrou a mídia (${metadataResponse.status})`);
  const metadata = (await metadataResponse.json()) as { url?: string; mime_type?: string };
  if (!metadata.url) throw new Error("Meta não devolveu o URL da mídia");

  const mediaUrl = new URL(metadata.url);
  if (mediaUrl.protocol !== "https:" || !isMetaMediaHost(mediaUrl.hostname)) {
    throw new Error("URL de mídia da Meta inválido");
  }
  const mimeType = metadata.mime_type ?? "";
  if (!mimeType || (type !== "document" && !mimeType.toLowerCase().startsWith(`${type}/`))) {
    throw new Error("Tipo de mídia inesperado");
  }

  const upstream = await fetch(mediaUrl, {
    headers: {
      Authorization: `Bearer ${token}`,
      ...(range ? { Range: range } : {}),
    },
    cache: "no-store",
  });
  if (!upstream.ok) throw new Error(`Meta não disponibilizou a mídia (${upstream.status})`);
  return { upstream, mimeType };
}

export function isMetaMediaHost(hostname: string): boolean {
  return ["fbsbx.com", "fbcdn.net", "cdninstagram.com", "facebook.com", "whatsapp.net"]
    .some((domain) => hostname === domain || hostname.endsWith(`.${domain}`));
}
