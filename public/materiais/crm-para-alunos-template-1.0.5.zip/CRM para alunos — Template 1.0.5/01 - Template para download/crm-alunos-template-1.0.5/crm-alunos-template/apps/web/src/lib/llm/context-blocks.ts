/**
 * Blocos de contexto compartilhados que enriquecem prompts de LLM com dados
 * do banco. Usado por flush.ts (bot da conversa) e audit/run-audit.ts (auditor).
 *
 * Extraído de flush.ts em 2026-05-24 (Sub-Plan A do auditor). Mantém o
 * comportamento idêntico — só muda o lugar onde mora.
 */
import { prisma } from "@/lib/db";
import { formatAnswersForPrompt } from "@/lib/surveys/format";
import {
  renderQualChecklist,
  type AskedFieldsMap,
} from "@/lib/asked-fields";
import { getActiveLaunch, type ActiveLaunch } from "@/lib/launches/active";
import { pickPrimaryCourseId } from "@/lib/launches/multi-course";
import { renderOfferBlock } from "@/lib/launches/context-block";

const BRL = new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" });
function fmtBRL(cents: number): string {
  // Normaliza o NBSP que o Intl insere entre "R$" e dígitos pra espaço comum.
  return BRL.format(cents / 100).replace(/ /g, " ");
}
function fmtDateBR(d: Date): string {
  // Render em UTC só-data — mesma convenção de launches/context-block.ts
  // (date-only do picker não deve sofrer shift de -3h).
  return d.toLocaleDateString("pt-BR", { timeZone: "UTC" });
}

export interface BuildCatalogBlockOpts {
  /** Lead atual (pra escolher curso primário multi-interesse). Omitir = sem oferta. */
  lead?: { interestCourseIds: string[] };
  /** Mensagens recentes da conversa pra heurística multi-curso. Cada uma com texto e createdAt. */
  recentMessages?: { text: string | null; createdAt: Date }[];
  /** Pra logar quando o bloco de oferta é injetado. */
  conversationId?: string;
}

/**
 * Bloco com cursos ativos pra IA escolher o courseId ao chamar get_checkout_link.
 * Inclui `id`, `name`, `slug`, preço e marca se tem checkoutUrl. Sem URL — o
 * link curto é construído pelo tool. Retorna null se não houver cursos.
 *
 * Quando `opts.lead` + `opts.recentMessages` estão presentes e o lead tem
 * interesses, injeta o bloco OFERTA ATIVA (se houver) antes do catálogo.
 */
export async function buildCatalogBlock(
  opts?: BuildCatalogBlockOpts,
): Promise<string | null> {
  const courses = await prisma.course.findMany({
    where: { active: true },
    select: {
      id: true,
      name: true,
      slug: true,
      priceCents: true,
      checkoutUrl: true,
      description: true,
      guaranteePolicy: true,
      paymentMethods: true,
    },
    orderBy: { name: "asc" },
  });
  if (courses.length === 0) return null;

  function renderPolicy(label: string, value: string | null): string[] {
    if (!value || value.trim().length === 0) return [];
    const lines = value.split("\n");
    const head = `  - ${label}: ${lines[0]}`;
    const rest = lines.slice(1).map((l) => `    ${l}`);
    return [head, ...rest];
  }

  // Oferta ativa por curso — quando há (caminho do bot, com opts.lead), o
  // preço/condições da oferta SUBSTITUEM o preço-base no catálogo. Sem isto,
  // leads que perguntam preço antes do classificador gravar o interesse
  // recebiam o preço de tabela em vez da oferta live (bug 2026-05-29).
  // Caminho do auditor (opts ausente) mantém comportamento antigo, sem queries.
  const activeByCourse = new Map<string, ActiveLaunch>();
  if (opts?.lead) {
    await Promise.all(
      courses.map(async (c) => {
        const active = await getActiveLaunch(c.id);
        if (active) activeByCourse.set(c.id, active);
      }),
    );
  }

  const blocks = courses.map((c) => {
    const offer = activeByCourse.get(c.id);
    if (offer) {
      const planList = offer.plans
        .map((p) => `${p.name} ${fmtBRL(p.priceCents)}`)
        .join(" · ");
      const tag = offer.plans.some((p) => p.checkoutUrl)
        ? "checkout_ok"
        : "checkout_pendente";
      const pay = offer.paymentMethodsOverride ?? c.paymentMethods;
      const guar = offer.guaranteePolicyOverride ?? c.guaranteePolicy;
      const header =
        `- ${c.name} | id=${c.id} | slug=${c.slug} | ` +
        `OFERTA ATIVA "${offer.name}" até ${fmtDateBR(offer.endsAt)} ` +
        `(use ESTES preços, NUNCA o preço de tabela) | ${tag}`;
      const subs = [
        ...(planList ? [`  - planos: ${planList}`] : []),
        ...renderPolicy("descrição", c.description),
        ...renderPolicy("garantia", guar),
        ...renderPolicy("pagamento", pay),
      ];
      return [header, ...subs].join("\n");
    }
    const price = c.priceCents > 0 ? `R$ ${(c.priceCents / 100).toFixed(2)}` : "gratuito";
    const tag = c.checkoutUrl ? "checkout_ok" : "checkout_pendente";
    const header = `- ${c.name} | id=${c.id} | slug=${c.slug} | ${price} | ${tag}`;
    const subs = [
      ...renderPolicy("descrição", c.description),
      ...renderPolicy("garantia", c.guaranteePolicy),
      ...renderPolicy("pagamento", c.paymentMethods),
    ];
    return [header, ...subs].join("\n");
  });

  const catalogText =
    "# Catálogo de cursos\n" +
    "Use estes ids exatos ao chamar get_checkout_link({ courseId }).\n" +
    "`checkout_pendente` = sem URL cadastrada; o tool fará handoff humano.\n" +
    "Use APENAS os fatos listados abaixo — se algo não estiver aqui (ex.: garantia, parcelamento, conteúdo), faça handoff humano em vez de inventar.\n\n" +
    blocks.join("\n");

  // Injeção de oferta ativa — só quando lead + recentMessages são fornecidos e
  // o lead tem interesses. Ausência de opts = caminho do auditor, sem queries extras.
  if (opts?.lead && opts.recentMessages !== undefined && opts.lead.interestCourseIds.length > 0) {
    const coursesLite = courses.map((c) => ({ id: c.id, name: c.name, slug: c.slug }));
    const primaryCourseId = pickPrimaryCourseId({
      interestCourseIds: opts.lead.interestCourseIds,
      messages: opts.recentMessages,
      courses: coursesLite,
    });

    if (primaryCourseId) {
      const active = await getActiveLaunch(primaryCourseId);
      if (active) {
        console.log(
          JSON.stringify({
            ts: new Date().toISOString(),
            event: "ai.context.offer_injected",
            launchId: active.id,
            courseId: primaryCourseId,
            conversationId: opts.conversationId,
          }),
        );
        const offerBlock = renderOfferBlock(active);
        return `${offerBlock}\n\n${catalogText}`;
      }
    }
  }

  return catalogText;
}

/**
 * Resumo do que o sistema já sabe sobre o lead (Parte 10 + 11): qualification
 * estruturada, cursos de interesse já registrados e objeções ativas. Compensa
 * memoryMode `window_N` que perde respostas antigas — o classifier extrai e
 * persiste; aqui devolve pra IA na chamada seguinte.
 */
export async function buildLeadContextBlock(
  leadId: string,
  contactId: string,
): Promise<string | null> {
  const lead = await prisma.lead.findUnique({
    where: { id: leadId },
    select: {
      stage: true,
      score: true,
      qualification: true,
      interestCourseIds: true,
      // ObjectionTag não tem resolvedAt no schema; classifier re-extrai a cada
      // turno. Pegamos a snapshot mais recente por tag (limit 10 já cobre).
      objectionTags: {
        orderBy: { createdAt: "desc" },
        take: 10,
        select: { tag: true },
      },
    },
  });
  if (!lead) return null;
  const lines: string[] = [];
  lines.push(`- stage: ${lead.stage}`);
  lines.push(`- score: ${lead.score}`);
  if (lead.qualification && typeof lead.qualification === "object") {
    lines.push(`- qualification: ${JSON.stringify(lead.qualification)}`);
  }
  if (lead.interestCourseIds.length > 0) {
    const names = await prisma.course.findMany({
      where: { id: { in: lead.interestCourseIds } },
      select: { id: true, name: true },
    });
    const display = names.map((c) => `${c.name} (id=${c.id})`).join(", ");
    lines.push(`- cursos de interesse: ${display}`);
  }
  if (lead.objectionTags.length > 0) {
    const uniq = Array.from(new Set(lead.objectionTags.map((o) => o.tag)));
    lines.push(`- objeções registradas: ${uniq.join(", ")}`);
  }

  // Bloco da pesquisa (Parte 12-D): respostas declaradas valem mais que
  // inferência do classifier. Vai ANTES do contexto inferido no output final.
  const latestSurvey = await prisma.surveyResponse.findFirst({
    where: { contactId },
    orderBy: { createdAt: "desc" },
    select: { surveyName: true, answers: true, submittedAt: true },
  });
  let surveyBlock = "";
  if (latestSurvey) {
    const block = formatAnswersForPrompt(
      latestSurvey.surveyName,
      latestSurvey.answers as Record<string, unknown>,
      latestSurvey.submittedAt,
    );
    if (block.length > 0) surveyBlock = block + "\n\n";
  }

  const askedFields = (lead.qualification as { askedFields?: AskedFieldsMap } | null)
    ?.askedFields;
  const checklist = renderQualChecklist(askedFields);

  return (
    surveyBlock +
    "# Contexto do lead\n" +
    "O que o sistema já registrou sobre este lead (do classificador + parte 11).\n" +
    "Use isto pra NÃO repetir perguntas que ele já respondeu.\n\n" +
    lines.join("\n") +
    "\n\n" +
    checklist
  );
}
