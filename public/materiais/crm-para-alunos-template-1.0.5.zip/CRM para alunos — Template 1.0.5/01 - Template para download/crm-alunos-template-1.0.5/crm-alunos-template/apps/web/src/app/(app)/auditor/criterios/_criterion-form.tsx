"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { saveCriterion, type CriterionFormState } from "./actions";
import { Loader2, Save } from "lucide-react";

interface InitialCriterion {
  id?: string;
  name?: string;
  description?: string;
  exampleFail?: string | null;
  weight?: number;
  active?: boolean;
}

export function CriterionForm({
  initial,
  onSaved,
}: {
  initial?: InitialCriterion;
  onSaved?: () => void;
}) {
  const [state, action, pending] = useActionState<CriterionFormState, FormData>(
    async (_prev, formData) => {
      const result = await saveCriterion(formData);
      if (result.ok && onSaved) onSaved();
      return result;
    },
    {},
  );

  return (
    <form action={action} className="space-y-4">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <div className="space-y-2">
        <Label htmlFor="name">Nome</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initial?.name ?? ""}
          maxLength={120}
          placeholder="Não repetiu pergunta"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          name="description"
          required
          rows={5}
          defaultValue={initial?.description ?? ""}
          maxLength={2000}
          placeholder="O que o bot deve fazer (ou não fazer) pra passar esse critério..."
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="exampleFail">Exemplo de fail (opcional)</Label>
        <Textarea
          id="exampleFail"
          name="exampleFail"
          rows={3}
          defaultValue={initial?.exampleFail ?? ""}
          maxLength={2000}
          placeholder='Ex: "Bot perguntou o nome 2x sem o lead ter ignorado a 1ª"'
        />
        <p className="text-xs text-muted-foreground">
          Ajuda o LLM auditor a calibrar quando algo conta como fail.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="weight">Peso (1-5)</Label>
        <Input
          id="weight"
          name="weight"
          type="number"
          min={1}
          max={5}
          step={1}
          required
          defaultValue={initial?.weight ?? 3}
        />
        <p className="text-xs text-muted-foreground">
          Maior = mais crítico. Usado no ranking de findings.
        </p>
      </div>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div>
          <Label htmlFor="active" className="text-sm">
            Ativo?
          </Label>
          <p className="text-xs text-muted-foreground">
            Critérios inativos não vão pro próximo report.
          </p>
        </div>
        <Switch
          id="active"
          name="active"
          defaultChecked={initial?.active ?? true}
        />
      </div>

      {state?.error && (
        <p className="text-sm text-destructive font-mono">{state.error}</p>
      )}

      <div className="flex gap-2 justify-end">
        <Button type="submit" disabled={pending}>
          {pending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Save className="size-4" />
          )}
          Salvar
        </Button>
      </div>
    </form>
  );
}
