/**
 * Extração de texto puro de fontes de documento (PDF, URL).
 * Texto colado não passa por aqui — vai direto pro ingest.
 */
import * as cheerio from "cheerio";
import { extractText, getDocumentProxy } from "unpdf";

/** Extrai texto de um PDF (bytes). PDF escaneado/imagem retorna vazio. */
export async function extractPdf(data: Uint8Array): Promise<string> {
  const pdf = await getDocumentProxy(data);
  const { text } = await extractText(pdf, { mergePages: true });
  const merged = Array.isArray(text) ? text.join("\n\n") : text;
  return merged.trim();
}

export interface ExtractedUrl {
  text: string;
  title: string;
}

/** Retorna a URL de exportação TXT para links padrão de documentos do Google. */
export function googleDocsExportUrl(url: string): string | null {
  try {
    const parsed = new URL(url);
    if (parsed.hostname !== "docs.google.com") return null;

    const match = parsed.pathname.match(
      /^\/document\/(?:u\/\d+\/)?d\/([a-zA-Z0-9_-]+)(?:\/|$)/,
    );
    if (!match) return null;

    return `https://docs.google.com/document/d/${match[1]}/export?format=txt`;
  } catch {
    return null;
  }
}

async function extractGoogleDocs(exportUrl: string): Promise<ExtractedUrl> {
  let res: Response;
  try {
    res = await fetch(exportUrl, {
      headers: { "user-agent": "Mozilla/5.0 (compatible; CRM Template RAG indexer)" },
      redirect: "follow",
    });
  } catch (err) {
    throw new Error(
      `Não consegui exportar o Google Docs: ${String((err as Error)?.message ?? err)}`,
    );
  }

  if (!res.ok) {
    throw new Error(
      `O Google Docs retornou status ${res.status} ao exportar. Confira se o documento está acessível para quem tem o link.`,
    );
  }

  const raw = await res.text();
  const contentType = res.headers.get("content-type")?.toLowerCase() ?? "";
  if (contentType.includes("text/html") || /^\s*<!doctype html|^\s*<html\b/i.test(raw)) {
    throw new Error(
      "O Google Docs retornou uma página HTML em vez do documento. Confira se o compartilhamento permite acesso pelo link.",
    );
  }

  const text = raw
    .replace(/^\uFEFF/, "")
    .replace(/\r\n?/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  if (!text) {
    throw new Error("O Google Docs está vazio ou não retornou texto para indexação.");
  }

  return { text, title: "Google Docs" };
}

/** Busca uma URL e extrai o texto legível da página (remove nav, script, etc). */
export async function extractUrl(url: string): Promise<ExtractedUrl> {
  const docsExportUrl = googleDocsExportUrl(url);
  if (docsExportUrl) return extractGoogleDocs(docsExportUrl);

  let res: Response;
  try {
    res = await fetch(url, {
      headers: { "user-agent": "Mozilla/5.0 (compatible; CRM Template RAG indexer)" },
      redirect: "follow",
    });
  } catch (err) {
    throw new Error(
      `Não consegui acessar a URL: ${String((err as Error)?.message ?? err)}`,
    );
  }
  if (!res.ok) throw new Error(`A URL retornou status ${res.status}.`);

  const html = await res.text();
  const $ = cheerio.load(html);
  $("script, style, noscript, nav, footer, header, svg, iframe, form").remove();

  const title = $("title").first().text().trim() || url;
  const text = $("body")
    .text()
    .replace(/[ \t]+/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  if (!text) {
    // HTML sem texto legível — quase sempre uma SPA (React/Vue/etc.) que
    // renderiza o conteúdo via JavaScript no navegador. Este indexador busca
    // o HTML mas NÃO executa JS, então o <body> chega vazio.
    throw new Error(
      'A página não retornou texto no HTML inicial — provavelmente é uma SPA ' +
        'renderizada via JavaScript. Cole o conteúdo na aba "Texto", ou indexe ' +
        "uma URL cujo conteúdo venha pronto no HTML (com SSR).",
    );
  }

  return { text, title };
}
