import { beforeEach, describe, expect, it, vi } from "vitest";
vi.mock("@/auth", () => ({ auth: vi.fn() }));
vi.mock("@/lib/config", () => ({ loadConfig: vi.fn(), saveConfig: vi.fn() }));
vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));
import { auth } from "@/auth";
import { loadConfig, saveConfig } from "@/lib/config";
import { saveBusiness } from "./actions";
beforeEach(() => { vi.clearAllMocks(); vi.mocked(auth).mockResolvedValue({user:{role:"admin"}} as never); });
function form() { const f=new FormData(); for (const [k,v] of Object.entries({brandName:"Minha Empresa",legalName:"Empresa Exemplo",supportEmail:"",contactEmail:"",accessUrl:"",handoffNotice:"Vou chamar um atendente.",timezone:"America/Sao_Paulo",windowMs:"5000",instagram:"on"})) f.set(k,v); return f; }
describe("salvar configuração da instância", () => {
  it("rejeita alteração por operador", async () => { vi.mocked(auth).mockResolvedValue({user:{role:"operator"}} as never); expect((await saveBusiness({},form())).error).toBeTruthy(); expect(saveConfig).not.toHaveBeenCalled(); });
  it("valida URL, fuso e intervalo antes de gravar", async () => { for(const [key,value] of [["accessUrl","javascript:alert(1)"],["timezone","invalid"],["windowMs","-1"]]) {const f=form();f.set(key,value);expect((await saveBusiness({},f)).error).toBeTruthy();} expect(saveConfig).not.toHaveBeenCalled(); });
  it("ativa Instagram com o ID interno correto e preserva opções avançadas", async () => {
    vi.mocked(loadConfig).mockReturnValue({business:{language:"pt-BR"},schedule:{timezone:"UTC"},cache:{debounce:{}},channels:{whatsapp_cloud:{},instagram_direct:{}},auditor:{enabled:false}} as never);
    expect((await saveBusiness({},form())).message).toBeTruthy();
    const cfg=vi.mocked(saveConfig).mock.calls[0][0];expect(cfg.channels.enabled).toEqual(["instagram"]);expect(cfg.channels.instagram_direct.enabled).toBe(true);expect(cfg.auditor?.enabled).toBe(false);
    expect(cfg.channels.whatsapp_qr?.enabled).toBe(false);
  });
  it("ativa WhatsApp via QR em instalação antiga sem o bloco do canal", async () => {
    vi.mocked(loadConfig).mockReturnValue({business:{},schedule:{timezone:"UTC"},cache:{debounce:{}},channels:{whatsapp_cloud:{},instagram_direct:{}}} as never);
    const f=form();f.delete("instagram");f.set("whatsappQr","on");
    expect((await saveBusiness({},f)).message).toBeTruthy();
    const cfg=vi.mocked(saveConfig).mock.calls[0][0];expect(cfg.channels.enabled).toEqual(["whatsapp_qr"]);expect(cfg.channels.whatsapp_qr?.enabled).toBe(true);
  });
});
