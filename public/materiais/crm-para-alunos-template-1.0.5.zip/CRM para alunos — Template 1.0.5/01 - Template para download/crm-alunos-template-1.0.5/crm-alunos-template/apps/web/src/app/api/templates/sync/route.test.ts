import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));
vi.mock("@/lib/templates/sync", () => ({
  syncTemplatesFromMeta: vi.fn(),
}));

import { POST } from "./route";
import { auth } from "@/auth";
import { syncTemplatesFromMeta } from "@/lib/templates/sync";

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "test-user" } } as never);
  vi.mocked(syncTemplatesFromMeta).mockReset();
});

describe("POST /api/templates/sync", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST();
    expect(res.status).toBe(401);
  });

  it("200 com SyncResult quando sync OK", async () => {
    vi.mocked(syncTemplatesFromMeta).mockResolvedValueOnce({
      added: 2,
      updated: 1,
      removed: 0,
      total: 5,
    });
    const res = await POST();
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body).toMatchObject({ added: 2, updated: 1, removed: 0, total: 5 });
  });

  it("502 quando sync throw (Meta API down)", async () => {
    vi.mocked(syncTemplatesFromMeta).mockRejectedValueOnce(
      new Error("network down"),
    );
    const res = await POST();
    expect(res.status).toBe(502);
    const body = await res.json();
    expect(body.error).toMatch(/meta/i);
  });
});
