import { z } from "zod";

export const BonusSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
});
export type Bonus = z.infer<typeof BonusSchema>;

export const BonusesSchema = z.array(BonusSchema);

/**
 * Parseia o Json cru do Prisma pra Bonus[]. Resiliente — itens malformados
 * são filtrados em vez de explodir (oferta meio-cadastrada não deve quebrar
 * o bot).
 */
export function parseBonuses(raw: unknown): Bonus[] {
  if (!Array.isArray(raw)) return [];
  const out: Bonus[] = [];
  for (const item of raw) {
    const parsed = BonusSchema.safeParse(item);
    if (parsed.success) out.push(parsed.data);
  }
  return out;
}

export type LaunchStatus = "planned" | "live" | "closed";
export const LAUNCH_STATUSES: readonly LaunchStatus[] = ["planned", "live", "closed"] as const;
