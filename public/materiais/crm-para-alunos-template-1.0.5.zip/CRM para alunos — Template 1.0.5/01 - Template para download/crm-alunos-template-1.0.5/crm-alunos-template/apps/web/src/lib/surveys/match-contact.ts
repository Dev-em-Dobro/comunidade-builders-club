import { prisma } from "@/lib/db";
import { normalizePhoneToE164 } from "@/lib/phone";

export interface MatchInput {
  phoneRaw: string | null;
  emailRaw: string | null;
}

export interface MatchResult {
  contactId: string | null;
  via: "phone" | "email" | null;
}

async function tryPhone(phone: string): Promise<string | null> {
  const ident = await prisma.contactIdentity.findFirst({
    where: { channel: "whatsapp_cloud", externalId: phone },
    select: { contactId: true },
  });
  return ident?.contactId ?? null;
}

async function tryEmail(email: string): Promise<string | null> {
  const contact = await prisma.contact.findUnique({
    where: { email },
    select: { id: true },
  });
  return contact?.id ?? null;
}

/**
 * Tenta casar a linha do CSV com um Contact existente:
 *  1. phone normalizado E.164
 *  2. phone com `55` prepended se tinha 10-11 dígitos sem DDI
 *  3. email lowercase
 *
 * Retorna `{ contactId: null, via: null }` se nada bater — caller deve skippar.
 */
export async function matchContact(input: MatchInput): Promise<MatchResult> {
  if (input.phoneRaw) {
    const normalized = normalizePhoneToE164(input.phoneRaw);
    if (normalized) {
      const direct = await tryPhone(normalized);
      if (direct) return { contactId: direct, via: "phone" };

      // Tenta com DDI brasileiro prepended se faltava
      if (normalized.length === 10 || normalized.length === 11) {
        const withDdi = `55${normalized}`;
        const guessed = await tryPhone(withDdi);
        if (guessed) return { contactId: guessed, via: "phone" };
      }
    }
  }

  if (input.emailRaw) {
    const email = input.emailRaw.trim().toLowerCase();
    if (email.includes("@")) {
      const found = await tryEmail(email);
      if (found) return { contactId: found, via: "email" };
    }
  }

  return { contactId: null, via: null };
}
