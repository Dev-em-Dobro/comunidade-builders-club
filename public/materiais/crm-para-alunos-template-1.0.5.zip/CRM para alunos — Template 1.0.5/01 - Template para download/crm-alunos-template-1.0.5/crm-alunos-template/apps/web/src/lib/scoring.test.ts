import { describe, it, expect } from "vitest";
import { computeScore, type Qualification } from "./scoring";

const baseQual: Qualification = {
  interestLevel: "low",
  budgetSignal: "unknown",
  decisionTimeline: "unknown",
  courseInterestIds: [],
  rationale: "",
};

const maxQual: Qualification = {
  interestLevel: "high",
  budgetSignal: "strong",
  decisionTimeline: "short",
  courseInterestIds: ["c1"],
  rationale: "",
};

describe("computeScore", () => {
  it("qualification nula → só engajamento (2 pts por inbound)", () => {
    expect(
      computeScore({ qualification: null, inboundCount: 3, stage: "new" }),
    ).toBe(6);
  });

  it("interesse high soma 30", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, interestLevel: "high" },
        inboundCount: 0,
        stage: "new",
      }),
    ).toBe(30);
  });

  it("budgetSignal strong soma 20", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, budgetSignal: "strong" },
        inboundCount: 0,
        stage: "new",
      }),
    ).toBe(20);
  });

  it("decisionTimeline short soma 25", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, decisionTimeline: "short" },
        inboundCount: 0,
        stage: "new",
      }),
    ).toBe(25);
  });

  it("ter curso de interesse soma 9", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, courseInterestIds: ["c1"] },
        inboundCount: 0,
        stage: "new",
      }),
    ).toBe(9);
  });

  it("engajamento satura em 8 inbounds (16 pts)", () => {
    expect(
      computeScore({ qualification: null, inboundCount: 20, stage: "new" }),
    ).toBe(16);
  });

  it("inboundCount negativo não tira pontos", () => {
    expect(
      computeScore({ qualification: null, inboundCount: -5, stage: "new" }),
    ).toBe(0);
  });

  it("lead máximo satura em 100", () => {
    expect(
      computeScore({ qualification: maxQual, inboundCount: 8, stage: "qualified" }),
    ).toBe(100);
  });

  it("piso de stage: proposal nunca abaixo de 75", () => {
    expect(
      computeScore({ qualification: null, inboundCount: 0, stage: "proposal" }),
    ).toBe(75);
  });

  it("piso de stage: proposal não rebaixa um score já maior", () => {
    expect(
      computeScore({ qualification: maxQual, inboundCount: 8, stage: "proposal" }),
    ).toBe(100);
  });

  it("stage won → 100", () => {
    expect(
      computeScore({ qualification: null, inboundCount: 0, stage: "won" }),
    ).toBe(100);
  });

  it("stage lost → 0, mesmo com qualificação alta", () => {
    expect(
      computeScore({ qualification: maxQual, inboundCount: 8, stage: "lost" }),
    ).toBe(0);
  });

  it("1 objeção ativa desconta 5 pts", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, interestLevel: "high" },
        inboundCount: 0,
        stage: "new",
        activeObjections: ["preco"],
      }),
    ).toBe(25); // 30 - 5
  });

  it("4 objeções ativas batem no cap de -15 (não -20)", () => {
    expect(
      computeScore({
        qualification: { ...baseQual, interestLevel: "high" },
        inboundCount: 0,
        stage: "new",
        activeObjections: ["preco", "tempo", "medo", "conjuge"],
      }),
    ).toBe(15); // 30 - 15 (não 30 - 20)
  });

  it("piso de stage proposal ignora a penalidade de objeções", () => {
    expect(
      computeScore({
        qualification: null,
        inboundCount: 0,
        stage: "proposal",
        activeObjections: ["preco", "tempo"],
      }),
    ).toBe(75); // piso de proposal, não 75 - 10
  });
});
