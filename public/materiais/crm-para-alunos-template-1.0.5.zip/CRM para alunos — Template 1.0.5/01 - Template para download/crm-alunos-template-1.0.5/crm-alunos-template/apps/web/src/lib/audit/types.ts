/**
 * Tipos e Zod schemas do auditor (Sub-Plan A).
 * Validados na saída do LLM no `runAuditorOnConversation`.
 */
import { z } from "zod";

/** Veredito por critério. "error" é interno (LLM falhou), nunca vem do LLM. */
export type Verdict = "pass" | "fail" | "na" | "error";

/** Status do report. */
export type ReportStatus = "queued" | "running" | "done" | "error";

/**
 * 1 finding como o LLM cospe (1 entrada por critério avaliado).
 * O LLM nunca emite verdict='error' — esse é interno.
 */
export const FindingSchema = z.object({
  criterionId: z.string().min(1),
  verdict: z.enum(["pass", "fail", "na"]),
  severity: z.number().int().min(1).max(5).optional(),
  evidence: z.string().optional(),
  recommendation: z.string().optional(),
});
export type ParsedFinding = z.infer<typeof FindingSchema>;

/** Saída completa do tool `record_audit` cospida pelo LLM, por conversa. */
export const AuditOutputSchema = z.object({
  findings: z.array(FindingSchema),
  freeNotes: z.string().default(""),
  oneLineVerdict: z.string().min(1),
});
export type AuditOutput = z.infer<typeof AuditOutputSchema>;

/** Resultado interno consolidado de uma conversa avaliada (pós-validação). */
export interface ConversationAuditResult {
  conversationId: string;
  contactDisplay: string | null;
  /** Findings que vão persistir. Inclui 'error' se LLM falhou. */
  findings: Array<{
    criterionId: string | null;          // null = freeNotes synthetic finding
    criterionNameSnapshot: string;
    verdict: Verdict;
    severity?: number;
    evidence?: string;
    recommendation?: string;
    freeNotes?: string;
  }>;
  oneLineVerdict: string;
  /** Custo da call LLM dessa conversa, USD. */
  costUsd: number;
}
