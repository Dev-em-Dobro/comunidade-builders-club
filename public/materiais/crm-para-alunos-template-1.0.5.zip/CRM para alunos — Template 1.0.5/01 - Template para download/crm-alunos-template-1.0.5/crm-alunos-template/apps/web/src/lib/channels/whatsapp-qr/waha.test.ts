import { afterEach, describe, expect, it, vi } from "vitest";
import { createHmac } from "node:crypto";
import { wahaProvider } from "./waha";
import { HmacFailure } from "../whatsapp-cloud";
import type { WaqrSettings } from "./types";

const S: WaqrSettings = {
  provider: "waha",
  baseUrl: "http://waha.test:3000",
  session: "default",
  apiKey: "api-key-teste",
  webhookSecret: "segredo-hmac-teste",
  webhookUrl: "http://crm.test/api/webhooks/whatsapp-qr",
};

function signed(body: unknown, secret = S.webhookSecret!) {
  const raw = JSON.stringify(body);
  const headers = new Headers({
    "x-webhook-hmac": createHmac("sha512", secret).update(raw).digest("hex"),
    "x-webhook-hmac-algorithm": "sha512",
  });
  return { raw, headers };
}

function message(payload: Record<string, unknown>, extra: Record<string, unknown> = {}) {
  return {
    event: "message",
    session: "default",
    engine: "GOWS",
    payload: { id: "msg-1", timestamp: 1767225600, from: "5511999999999@c.us", fromMe: false, body: "Oi, quero saber do curso", hasMedia: false, ...payload },
    ...extra,
  };
}

afterEach(() => vi.restoreAllMocks());

describe("wahaProvider.parseWebhook", () => {
  it("normaliza mensagem de texto", () => {
    const { raw, headers } = signed(message({ _data: { Info: { PushName: "Maria" } } }));
    const msg = wahaProvider.parseWebhook(raw, headers, S);
    expect(msg).toMatchObject({
      channel: "whatsapp_qr",
      contactId: "5511999999999",
      contactName: "Maria",
      text: "Oi, quero saber do curso",
      providerMsgId: "msg-1",
      receivedAt: new Date(1767225600 * 1000).toISOString(),
    });
  });

  it("recusa assinatura ausente, errada ou de outro algoritmo", () => {
    const { raw, headers } = signed(message({}));
    expect(() => wahaProvider.parseWebhook(raw, new Headers(), S)).toThrow(HmacFailure);
    const wrong = signed(message({}), "outro-segredo");
    expect(() => wahaProvider.parseWebhook(raw, wrong.headers, S)).toThrow(HmacFailure);
    headers.set("x-webhook-hmac-algorithm", "sha256");
    expect(() => wahaProvider.parseWebhook(raw, headers, S)).toThrow(HmacFailure);
  });

  it("recusa corpo alterado depois de assinado", () => {
    const { headers } = signed(message({}));
    expect(() => wahaProvider.parseWebhook(JSON.stringify(message({ body: "alterado" })), headers, S)).toThrow(HmacFailure);
  });

  it("ignora enviada pelo próprio número, grupo, status, outro evento e outra sessão", () => {
    const cases = [
      message({ fromMe: true }),
      message({ from: "120363000000@g.us" }),
      message({ from: "status@broadcast" }),
      message({}, { event: "message.ack" }),
      message({}, { session: "outra" }),
    ];
    for (const body of cases) {
      const { raw, headers } = signed(body);
      expect(wahaProvider.parseWebhook(raw, headers, S)).toBeNull();
    }
  });

  it("mídia sem legenda vira placeholder e guarda a URL", () => {
    const { raw, headers } = signed(message({
      body: "", hasMedia: true,
      media: { url: "http://localhost:3000/api/files/default/abc.jpeg", mimetype: "image/jpeg" },
    }));
    const msg = wahaProvider.parseWebhook(raw, headers, S)!;
    expect(msg.text).toBe("[image]");
    expect(msg.media?.[0]).toMatchObject({ type: "image", url: "http://localhost:3000/api/files/default/abc.jpeg", mimeType: "image/jpeg" });
  });

  it("legenda da mídia vira o texto", () => {
    const { raw, headers } = signed(message({ body: "segue o comprovante", hasMedia: true, media: { url: null, mimetype: "application/pdf" } }));
    const msg = wahaProvider.parseWebhook(raw, headers, S)!;
    expect(msg.text).toBe("segue o comprovante");
    expect(msg.media?.[0]).toMatchObject({ type: "document", url: undefined });
  });

  it("mensagem sem corpo e sem mídia nunca fica vazia", () => {
    const { raw, headers } = signed(message({ body: "", location: { latitude: -23.5, longitude: -46.6, description: "Paulista" } }));
    expect(wahaProvider.parseWebhook(raw, headers, S)!.text).toContain("https://www.google.com/maps?q=-23.5,-46.6");
    const other = signed(message({ body: "" }));
    expect(wahaProvider.parseWebhook(other.raw, other.headers, S)!.text).toBe("[mensagem não suportada]");
  });

  it("contato @lid mantém o identificador completo", () => {
    const { raw, headers } = signed(message({ from: "987654321@lid" }));
    expect(wahaProvider.parseWebhook(raw, headers, S)!.contactId).toBe("987654321@lid");
  });
});

describe("wahaProvider.sendText", () => {
  it("marca como lida e envia com a chave e o chatId corretos", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("{}", { status: 201 }));
    await wahaProvider.sendText(S, "5511999999999", "Olá!");
    const calls = fetchMock.mock.calls.map(([url, init]) => ({ url: String(url), init: init as RequestInit }));
    expect(calls.map((c) => c.url)).toEqual(["http://waha.test:3000/api/sendSeen", "http://waha.test:3000/api/sendText"]);
    const send = calls[1]!;
    expect(new Headers(send.init.headers).get("X-Api-Key")).toBe("api-key-teste");
    expect(JSON.parse(String(send.init.body))).toMatchObject({ session: "default", chatId: "5511999999999@c.us", text: "Olá!" });
  });

  it("falha de envio vira erro (outbound marca send_failed)", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("bad", { status: 422 }));
    vi.spyOn(console, "error").mockImplementation(() => undefined);
    await expect(wahaProvider.sendText(S, "5511999999999", "Olá!")).rejects.toThrow("HTTP 422");
  });

  it("recusa cuid do banco no lugar do externalId", async () => {
    await expect(wahaProvider.sendText(S, "cabcdefghijklmnopqrstuvwx", "x")).rejects.toThrow("cuid");
  });
});

describe("wahaProvider.status / ensureSession", () => {
  it("sem configuração → missing_credentials, sem chamar a rede", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch");
    const state = await wahaProvider.status({ ...S, apiKey: undefined });
    expect(state.status).toBe("missing_credentials");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("WORKING → connected com nome e telefone", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(Response.json({ status: "WORKING", me: { id: "5511888888888@c.us", pushName: "Loja" } }));
    const state = await wahaProvider.status(S);
    expect(state).toMatchObject({ status: "connected", message: "Loja (5511888888888)" });
  });

  it("SCAN_QR_CODE → needs_verification", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(Response.json({ status: "SCAN_QR_CODE" }));
    expect((await wahaProvider.status(S)).status).toBe("needs_verification");
  });

  it("cria a sessão com webhook assinado quando ela não existe", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(new Response("", { status: 404 }))
      .mockResolvedValueOnce(Response.json({ name: "default" }, { status: 201 }))
      .mockResolvedValueOnce(Response.json({ status: "SCAN_QR_CODE" }));
    const state = await wahaProvider.ensureSession(S);
    const [url, init] = fetchMock.mock.calls[1]!;
    expect(String(url)).toBe("http://waha.test:3000/api/sessions");
    expect(JSON.parse(String((init as RequestInit).body))).toEqual({
      name: "default", start: true,
      config: { webhooks: [{ url: S.webhookUrl, events: ["message"], hmac: { key: S.webhookSecret } }] },
    });
    expect(state.message).toContain("sessão criada");
  });

  it("não altera sessão que já está correta", async () => {
    const current = { status: "WORKING", me: { id: "5511888888888@c.us" }, config: { webhooks: [{ url: S.webhookUrl, events: ["message"], hmac: { key: S.webhookSecret } }] } };
    const fetchMock = vi.spyOn(globalThis, "fetch").mockImplementation(async () => Response.json(current));
    const state = await wahaProvider.ensureSession(S);
    expect(fetchMock.mock.calls.every(([, init]) => !(init as RequestInit | undefined)?.method || (init as RequestInit).method === "GET")).toBe(true);
    expect(state.status).toBe("connected");
  });
});

describe("wahaProvider.logout", () => {
  it("número conectado: faz logout da sessão (sem apagá-la) e devolve o novo status", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(Response.json({ status: "WORKING", me: { id: "5511888888888@c.us" } }))
      .mockResolvedValueOnce(Response.json({}, { status: 201 }))
      .mockResolvedValueOnce(Response.json({ status: "SCAN_QR_CODE" }));
    const state = await wahaProvider.logout!(S);
    const [url, init] = fetchMock.mock.calls[1]!;
    expect(String(url)).toBe("http://waha.test:3000/api/sessions/default/logout");
    expect((init as RequestInit).method).toBe("POST");
    // nunca DELETE: a sessão e o webhook continuam configurados pra reconectar
    expect(fetchMock.mock.calls.some(([, i]) => (i as RequestInit | undefined)?.method === "DELETE")).toBe(false);
    expect(state.status).toBe("needs_verification");
  });

  it("sessão inexistente: não chama logout", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("", { status: 404 }));
    const state = await wahaProvider.logout!(S);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(state.status).toBe("needs_verification");
  });

  it("WAHA recusou o logout: devolve erro com o HTTP", async () => {
    vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(Response.json({ status: "WORKING" }))
      .mockResolvedValueOnce(new Response("nope", { status: 500 }));
    const state = await wahaProvider.logout!(S);
    expect(state).toMatchObject({ status: "error" });
    expect(state.message).toContain("HTTP 500");
  });
});

describe("wahaProvider.qr", () => {
  it("sessão FAILED (QRs expirados) é reiniciada antes de pedir o QR", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch")
      .mockResolvedValueOnce(Response.json({ status: "FAILED" }))
      .mockResolvedValueOnce(Response.json({ status: "STARTING" }))
      .mockResolvedValueOnce(Response.json({ status: "SCAN_QR_CODE" }))
      .mockResolvedValueOnce(new Response("png", { status: 200, headers: { "Content-Type": "image/png" } }));
    vi.useFakeTimers();
    try {
      const pending = wahaProvider.qr(S);
      await vi.runAllTimersAsync();
      const res = await pending;
      expect(res.headers.get("content-type")).toBe("image/png");
    } finally {
      vi.useRealTimers();
    }
    const urls = fetchMock.mock.calls.map(([url]) => String(url));
    expect(urls[1]).toBe("http://waha.test:3000/api/sessions/default/restart");
    expect(urls.at(-1)).toBe("http://waha.test:3000/api/default/auth/qr");
  });

  it("número já conectado → 409 com mensagem, sem pedir QR", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(Response.json({ status: "WORKING" }));
    const res = await wahaProvider.qr(S);
    expect(res.status).toBe(409);
    expect(((await res.json()) as { error: string }).error).toContain("já está conectado");
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });
});

describe("wahaProvider.fetchMedia", () => {
  it("usa sempre o host configurado, só com o caminho do arquivo", async () => {
    const fetchMock = vi.spyOn(globalThis, "fetch").mockResolvedValue(new Response("img", { status: 200 }));
    await wahaProvider.fetchMedia(S, "http://localhost:3000/api/files/default/abc.jpeg", null);
    expect(String(fetchMock.mock.calls[0]![0])).toBe("http://waha.test:3000/api/files/default/abc.jpeg");
  });

  it("recusa caminho fora de /api/files", async () => {
    await expect(wahaProvider.fetchMedia(S, "http://evil.test/api/sessions", null)).rejects.toThrow();
    await expect(wahaProvider.fetchMedia(S, "http://x/api/files/../sessions", null)).rejects.toThrow();
  });
});
