import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Nº de CONVERSAS não lidas (não o total de mensagens) — badge da sidebar. */
export async function GET(): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const count = await prisma.conversation.count({
    where: { unreadCount: { gt: 0 } },
  });
  return NextResponse.json({ count });
}
