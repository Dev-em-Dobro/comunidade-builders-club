import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { activateLaunch, closeLaunch } from "./transitions";
import { getActiveLaunch, _resetActiveLaunchCache } from "./active";
import { renderOfferBlock } from "./context-block";

let courseId: string;

beforeAll(async () => {
  const c = await prisma.course.create({
    data: {
      name: "Integration test course",
      slug: `int-test-${Date.now()}`,
      priceCents: 99700,
      paymentMethods: "12x sem juros",
      guaranteePolicy: "7 dias",
    },
  });
  courseId = c.id;
});

afterAll(async () => {
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId } } });
  await prisma.launch.deleteMany({ where: { courseId } });
  await prisma.course.delete({ where: { id: courseId } });
  await prisma.$disconnect();
});

beforeEach(async () => {
  _resetActiveLaunchCache();
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId } } });
  await prisma.launch.deleteMany({ where: { courseId } });
});

describe("Launch fluxo e2e — activate → query → close → changelog", () => {
  it("activate manual → getActiveLaunch retorna launch+plans → renderOfferBlock funciona → close → getActiveLaunch null → changelog tem 2 entries", async () => {
    // 1. Setup: launch planned com plano
    const launch = await prisma.launch.create({
      data: {
        name: "E2E Aniversário",
        slug: `e2e-aniv-${Date.now()}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "planned",
        courseId,
        pitchAngle: "comemoração",
        bonuses: [{ title: "Bônus E2E", description: "mentoria semanal" }],
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "1 ano", priceCents: 49700, checkoutUrl: "https://hot.com/1ano", sortOrder: 0 },
    });

    // 2. Activate manual
    const a = await activateLaunch({ launchId: launch.id, byUserId: null, reason: "manual" });
    expect(a.ok).toBe(true);

    // 3. getActiveLaunch retorna o launch
    _resetActiveLaunchCache();
    const active = await getActiveLaunch(courseId);
    expect(active).not.toBeNull();
    expect(active!.id).toBe(launch.id);
    expect(active!.plans).toHaveLength(1);
    expect(active!.plans[0]!.name).toBe("1 ano");
    expect(active!.course.id).toBe(courseId);

    // 4. renderOfferBlock produz markdown com nome + bônus + plano
    const md = renderOfferBlock(active!);
    expect(md).toContain("E2E Aniversário");
    expect(md).toContain("Bônus E2E");
    expect(md).toContain("R$ 497,00");
    expect(md).toContain("ÂNGULO: comemoração");

    // 5. Close manual
    const c = await closeLaunch({ launchId: launch.id, byUserId: null, reason: "manual" });
    expect(c.ok).toBe(true);

    // 6. getActiveLaunch volta a ser null
    _resetActiveLaunchCache();
    const none = await getActiveLaunch(courseId);
    expect(none).toBeNull();

    // 7. Changelog tem 2 entries (planned→live e live→closed)
    const changes = await prisma.launchStatusChange.findMany({
      where: { launchId: launch.id },
      orderBy: { createdAt: "asc" },
    });
    expect(changes).toHaveLength(2);
    expect(changes[0]!.fromStatus).toBe("planned");
    expect(changes[0]!.toStatus).toBe("live");
    expect(changes[0]!.reason).toBe("manual");
    expect(changes[1]!.fromStatus).toBe("live");
    expect(changes[1]!.toStatus).toBe("closed");
    expect(changes[1]!.reason).toBe("manual");
  });

  it("anti-overlap: tentar ativar 2 launches simultâneos no mesmo curso falha no 2º", async () => {
    // L1 live agora
    const l1 = await prisma.launch.create({
      data: {
        name: "L1 e2e",
        slug: `l1-e2e-${Date.now()}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 7 * 86400000),
        status: "live",
        courseId,
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: l1.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });

    // L2 planned com janela sobreposta
    const l2 = await prisma.launch.create({
      data: {
        name: "L2 e2e",
        slug: `l2-e2e-${Date.now()}`,
        startsAt: new Date(Date.now() + 86400000),
        endsAt: new Date(Date.now() + 5 * 86400000),
        status: "planned",
        courseId,
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: l2.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });

    const r = await activateLaunch({ launchId: l2.id, byUserId: null, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/conflit/i);
    expect(r.conflict?.id).toBe(l1.id);

    // L2 continua planned
    const l2After = await prisma.launch.findUniqueOrThrow({ where: { id: l2.id } });
    expect(l2After.status).toBe("planned");
  });
});
