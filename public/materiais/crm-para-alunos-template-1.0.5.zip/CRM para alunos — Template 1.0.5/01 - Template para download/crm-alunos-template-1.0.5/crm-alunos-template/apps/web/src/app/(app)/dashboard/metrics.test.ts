import { describe, it, expect } from "vitest";
import {
  buildFunnel,
  slaCompliancePct,
  trendDelta,
  pct,
  bucketConversionsByDay,
  conversionRate,
  costPerLead,
  formatWaitDuration,
  waitTier,
} from "./metrics";

describe("buildFunnel", () => {
  it("funil cumulativo é monotônico decrescente", () => {
    const levels = buildFunnel({
      new: 10,
      contacted: 6,
      qualified: 3,
      proposal: 1,
      won: 2,
    });
    expect(levels.map((l) => l.count)).toEqual([22, 12, 6, 3, 2]);
  });

  it("calcula drop-off entre níveis; primeiro nível é null", () => {
    const levels = buildFunnel({
      new: 10,
      contacted: 0,
      qualified: 0,
      proposal: 0,
      won: 0,
    });
    expect(levels[0].dropoffPct).toBeNull();
    expect(levels[1].dropoffPct).toBe(100);
  });

  it("ignora a chave `lost`", () => {
    const levels = buildFunnel({ new: 5, lost: 99 });
    expect(levels[0].count).toBe(5);
    expect(levels.map((l) => l.stage)).toEqual([
      "new",
      "contacted",
      "qualified",
      "proposal",
      "won",
    ]);
  });

  it("counts zerados → tudo 0, drop-offs null", () => {
    const levels = buildFunnel({});
    expect(levels.map((l) => l.count)).toEqual([0, 0, 0, 0, 0]);
    expect(levels.every((l) => l.dropoffPct === null)).toBe(true);
  });

  it("popula o label de cada estágio", () => {
    const levels = buildFunnel({ new: 1 });
    expect(levels.map((l) => l.label)).toEqual([
      "Novo",
      "Contatado",
      "Qualificado",
      "Proposta",
      "Ganho",
    ]);
  });
});

describe("slaCompliancePct", () => {
  it("total 0 → null", () => expect(slaCompliancePct(0, 0)).toBeNull());
  it("nenhum breach → 100%", () => expect(slaCompliancePct(10, 0)).toBe(100));
  it("metade breached → 50%", () => expect(slaCompliancePct(10, 5)).toBe(50));
});

describe("trendDelta", () => {
  it("melhora → positivo", () => expect(trendDelta(80, 60)).toBe(20));
  it("piora → negativo", () => expect(trendDelta(50, 70)).toBe(-20));
  it("igual → zero", () => expect(trendDelta(50, 50)).toBe(0));
});

describe("pct", () => {
  it("total 0 → null", () => expect(pct(0, 0)).toBeNull());
  it("calcula porcentagem", () => expect(pct(3, 4)).toBe(75));
});

describe("bucketConversionsByDay", () => {
  const now = new Date("2026-05-22T12:00:00Z");

  it("cria um bucket por dia do range", () => {
    expect(bucketConversionsByDay([], [], 7, now)).toHaveLength(7);
  });

  it("dias vazios ficam com 0", () => {
    const buckets = bucketConversionsByDay([], [], 3, now);
    expect(buckets.every((b) => b.won === 0 && b.lost === 0)).toBe(true);
  });

  it("conta won e lost no dia certo", () => {
    const won = [
      new Date("2026-05-22T08:00:00Z"),
      new Date("2026-05-22T20:00:00Z"),
    ];
    const lost = [new Date("2026-05-21T10:00:00Z")];
    const buckets = bucketConversionsByDay(won, lost, 3, now);
    expect(buckets.find((b) => b.date === "2026-05-22")?.won).toBe(2);
    expect(buckets.find((b) => b.date === "2026-05-21")?.lost).toBe(1);
  });

  it("ignora datas fora do range", () => {
    const won = [new Date("2026-01-01T08:00:00Z")];
    const buckets = bucketConversionsByDay(won, [], 3, now);
    expect(buckets.reduce((s, b) => s + b.won, 0)).toBe(0);
  });

  it("buckets em ordem cronológica crescente", () => {
    const buckets = bucketConversionsByDay([], [], 3, now);
    expect(buckets.map((b) => b.date)).toEqual([
      "2026-05-20",
      "2026-05-21",
      "2026-05-22",
    ]);
  });
});

describe("conversionRate", () => {
  it("sem resultados → null", () => expect(conversionRate(0, 0)).toBeNull());
  it("calcula taxa", () => expect(conversionRate(3, 1)).toBe(75));
});

describe("costPerLead", () => {
  it("0 leads → null", () => expect(costPerLead(10, 0)).toBeNull());
  it("calcula média", () => expect(costPerLead(10, 4)).toBe(2.5));
});

const MIN = 60_000;
const HOUR = 60 * MIN;
const DAY = 24 * HOUR;

describe("formatWaitDuration", () => {
  it("menos de 1 minuto → <1min", () => {
    expect(formatWaitDuration(0)).toBe("<1min");
    expect(formatWaitDuration(59_000)).toBe("<1min");
  });
  it("negativo → <1min", () => expect(formatWaitDuration(-5000)).toBe("<1min"));
  it("só minutos", () => expect(formatWaitDuration(47 * MIN)).toBe("47min"));
  it("horas e minutos", () =>
    expect(formatWaitDuration(2 * HOUR + 12 * MIN)).toBe("2h 12min"));
  it("hora exata → 0min", () => expect(formatWaitDuration(HOUR)).toBe("1h 0min"));
  it("dias e horas", () =>
    expect(formatWaitDuration(3 * DAY + 4 * HOUR + 30 * MIN)).toBe("3d 4h"));
});

describe("waitTier", () => {
  it("abaixo de 15min → ok", () => expect(waitTier(14 * MIN)).toBe("ok"));
  it("15min a 1h → warn", () => {
    expect(waitTier(15 * MIN)).toBe("warn");
    expect(waitTier(59 * MIN)).toBe("warn");
  });
  it("1h ou mais → urgent", () => {
    expect(waitTier(HOUR)).toBe("urgent");
    expect(waitTier(5 * HOUR)).toBe("urgent");
  });
});
