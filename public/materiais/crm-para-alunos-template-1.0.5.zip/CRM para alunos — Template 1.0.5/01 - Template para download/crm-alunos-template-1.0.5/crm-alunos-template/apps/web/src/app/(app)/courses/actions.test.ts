import { describe, it, expect, vi, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({ auth: vi.fn() }));
import { auth } from "@/auth";
beforeEach(() => { vi.mocked(auth).mockResolvedValue({ user: { id: "admin-test", role: "admin" } } as never); });

vi.mock("next/cache", () => ({
  revalidatePath: vi.fn(),
}));

vi.mock("next/navigation", () => ({
  redirect: vi.fn(),
}));

import { saveCourse } from "./actions";

function fd(fields: Record<string, string>): FormData {
  const f = new FormData();
  for (const [k, v] of Object.entries(fields)) f.set(k, v);
  return f;
}

const base = { name: "Tráfego Pago", slug: "trafego-pago", price: "497" };

describe("saveCourse — validação", () => {
  it("recusa operação de usuário sem sessão ou operador", async () => {
    for (const session of [null, { user: { role: "operator" } }]) {
      vi.mocked(auth).mockResolvedValue(session as never);
      const result = await saveCourse(fd({ ...base, slug: "unauthorized-test" }));
      expect(result.error).toMatch(/permissão/i);
    }
    expect(await prisma.course.findUnique({ where: { slug: "unauthorized-test" } })).toBeNull();
  });
  it("rejeita nome vazio", async () => {
    const r = await saveCourse(fd({ ...base, name: "" }));
    expect(r.error).toMatch(/nome/i);
  });

  it("rejeita slug com caracteres inválidos", async () => {
    const r = await saveCourse(fd({ ...base, slug: "Trafego Pago" }));
    expect(r.error).toMatch(/slug/i);
  });

  it("rejeita preço negativo", async () => {
    const r = await saveCourse(fd({ ...base, price: "-10" }));
    expect(r.error).toMatch(/preço/i);
  });

  it("rejeita preço não-numérico", async () => {
    const r = await saveCourse(fd({ ...base, price: "abc" }));
    expect(r.error).toMatch(/preço/i);
  });

  it("aceita checkoutUrl vazio (campo opcional)", async () => {
    const r = await saveCourse(fd({ ...base, checkoutUrl: "" }));
    // Validação não bloqueia campo vazio. Em sucesso, saveCourse chama redirect()
    // (mockado) e retorna undefined. O assert é sobre não-erro de validação de checkout.
    // Regex tight: só rejeita erro de validação real de checkout. DB pode falhar por outros motivos (slug duplicado em re-runs), e tudo bem.
    expect(r?.error ?? "").not.toMatch(/checkout url inválido/i);
  });

  it("rejeita checkoutUrl inválido", async () => {
    const r = await saveCourse(fd({ ...base, checkoutUrl: "not a url" }));
    expect(r.error).toMatch(/checkout/i);
  });
});

const createdSlugs: string[] = [];

afterAll(async () => {
  if (createdSlugs.length > 0) {
    await prisma.course.deleteMany({ where: { slug: { in: createdSlugs } } });
  }
  await prisma.$disconnect();
});

describe("saveCourse — policy fields", () => {
  it("persiste guaranteePolicy, paymentMethods e description quando preenchidos", async () => {
    const slug = `policy-fields-${Date.now()}`;
    createdSlugs.push(slug);
    await saveCourse(
      fd({
        ...base,
        slug,
        description: "Curso intensivo de 12 meses",
        guaranteePolicy: "7 dias incondicional",
        paymentMethods: "Pix ou cartão 12x",
      }),
    );
    const c = await prisma.course.findUnique({ where: { slug } });
    expect(c).not.toBeNull();
    expect(c!.description).toBe("Curso intensivo de 12 meses");
    expect(c!.guaranteePolicy).toBe("7 dias incondicional");
    expect(c!.paymentMethods).toBe("Pix ou cartão 12x");
  });

  it("persiste null quando policy fields chegam vazios", async () => {
    const slug = `policy-vazio-${Date.now()}`;
    createdSlugs.push(slug);
    await saveCourse(
      fd({
        ...base,
        slug,
        description: "",
        guaranteePolicy: "   ",
        paymentMethods: "",
      }),
    );
    const c = await prisma.course.findUnique({ where: { slug } });
    expect(c).not.toBeNull();
    expect(c!.description).toBeNull();
    expect(c!.guaranteePolicy).toBeNull();
    expect(c!.paymentMethods).toBeNull();
  });

  it("rejeita description acima de 5000 caracteres", async () => {
    const slug = `policy-grande-${Date.now()}`;
    const longDesc = "a".repeat(5001);
    const r = await saveCourse(fd({ ...base, slug, description: longDesc }));
    expect(r.error).toMatch(/descrição/i);
    const c = await prisma.course.findUnique({ where: { slug } });
    expect(c).toBeNull();
  });

  it("rejeita guaranteePolicy acima de 500 caracteres", async () => {
    const slug = `policy-gar-${Date.now()}`;
    const r = await saveCourse(
      fd({ ...base, slug, guaranteePolicy: "x".repeat(501) }),
    );
    expect(r.error).toMatch(/garantia/i);
    const c = await prisma.course.findUnique({ where: { slug } });
    expect(c).toBeNull();
  });

  it("rejeita paymentMethods acima de 500 caracteres", async () => {
    const slug = `policy-pay-${Date.now()}`;
    const r = await saveCourse(
      fd({ ...base, slug, paymentMethods: "y".repeat(501) }),
    );
    expect(r.error).toMatch(/pagamento/i);
    const c = await prisma.course.findUnique({ where: { slug } });
    expect(c).toBeNull();
  });

  it("bloqueia desativar um curso que tem lançamento live", async () => {
    const slug = `guard-live-${Date.now()}`;
    createdSlugs.push(slug);
    const course = await prisma.course.create({
      data: { name: "Curso Guard Live", slug, priceCents: 100000, active: true },
    });
    const launch = await prisma.launch.create({
      data: {
        name: "Oferta Guard",
        slug: `oferta-guard-${Date.now()}`,
        status: "live",
        startsAt: new Date(Date.now() - 1000),
        endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        courseId: course.id,
      },
    });
    try {
      // "active" omitido no FormData => tentativa de desativar.
      const r = await saveCourse(
        fd({ name: "Curso Guard Live", slug, price: "1000", id: course.id }),
      );
      expect(r.error).toMatch(/lançamento|desativar|live/i);
      // Curso permanece ativo — o update não rodou.
      const after = await prisma.course.findUnique({ where: { id: course.id } });
      expect(after!.active).toBe(true);
    } finally {
      await prisma.launch.delete({ where: { id: launch.id } });
    }
  });

  it("permite desativar um curso SEM lançamento live", async () => {
    const slug = `guard-nolive-${Date.now()}`;
    createdSlugs.push(slug);
    const course = await prisma.course.create({
      data: { name: "Curso Sem Live", slug, priceCents: 100000, active: true },
    });
    const r = await saveCourse(
      fd({ name: "Curso Sem Live", slug, price: "1000", id: course.id }),
    );
    expect(r?.error ?? "").not.toMatch(/lançamento|live/i);
    const after = await prisma.course.findUnique({ where: { id: course.id } });
    expect(after!.active).toBe(false);
  });

  it("update com policy fields vazios apaga valores antes preenchidos", async () => {
    const slug = `policy-update-${Date.now()}`;
    createdSlugs.push(slug);
    const created = await prisma.course.create({
      data: {
        name: "Curso Update",
        slug,
        priceCents: 10000,
        description: "antes",
        guaranteePolicy: "antes",
        paymentMethods: "antes",
      },
    });
    await saveCourse(
      fd({
        ...base,
        id: created.id,
        slug,
        description: "",
        guaranteePolicy: "",
        paymentMethods: "",
      }),
    );
    const after = await prisma.course.findUnique({ where: { slug } });
    expect(after!.description).toBeNull();
    expect(after!.guaranteePolicy).toBeNull();
    expect(after!.paymentMethods).toBeNull();
  });
});
