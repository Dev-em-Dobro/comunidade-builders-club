import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
vi.mock("@/auth", () => ({ auth: vi.fn() }));
vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));
vi.mock("@/lib/db", () => ({ prisma: { $transaction: vi.fn(), providerCredential: { upsert: vi.fn(), deleteMany: vi.fn() } } }));
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { saveMeta, clearMeta } from "./actions";
beforeEach(() => { vi.stubEnv("SECRETS_KEY","test-only-key"); vi.mocked(auth).mockResolvedValue({user:{id:"admin",role:"admin"}} as never); });
afterEach(() => { vi.unstubAllEnvs(); vi.clearAllMocks(); });
describe("configuração Meta autorizada no servidor", () => {
  it("recusa operador e usuário sem sessão antes de escrever", async () => {
    for (const session of [null,{user:{id:"operator",role:"operator"}}]) {
      vi.mocked(auth).mockResolvedValue(session as never);
      expect((await saveMeta({},new FormData())).error).toBeTruthy();
      await expect(clearMeta()).rejects.toThrow("Acesso negado");
    }
    expect(prisma.$transaction).not.toHaveBeenCalled(); expect(prisma.providerCredential.deleteMany).not.toHaveBeenCalled();
  });
  it("não sobrescreve valores quando todos os campos estão vazios", async () => {
    expect((await saveMeta({},new FormData())).message).toContain("Nenhum valor"); expect(prisma.$transaction).not.toHaveBeenCalled();
  });
  it("cifra o segredo e nunca o devolve na resposta", async () => {
    const form=new FormData(); form.set("META_APP_SECRET","secret-for-test");
    const result=await saveMeta({},form);
    const args=vi.mocked(prisma.providerCredential.upsert).mock.calls[0][0];
    expect(args.create.apiKeyEnc).not.toBe("secret-for-test"); expect(args.create.apiKeyEnc).toContain(":");
    expect(JSON.stringify(result)).not.toContain("secret-for-test");
  });
  it("recusa IDs inválidos sem gravar parte das credenciais", async () => {
    const form=new FormData(); form.set("META_APP_ID","not-an-id"); form.set("META_APP_SECRET","test-secret");
    expect((await saveMeta({},form)).error).toBeTruthy(); expect(prisma.$transaction).not.toHaveBeenCalled();
  });
});
