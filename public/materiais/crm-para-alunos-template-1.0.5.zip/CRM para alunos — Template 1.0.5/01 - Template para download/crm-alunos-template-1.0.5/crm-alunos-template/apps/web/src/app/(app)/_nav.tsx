import Link from "next/link";
import {
  LayoutDashboard,
  MessagesSquare,
  Bot,
  Wrench,
  Sparkles,
  Settings,
  Layers,
  Users,
  Rocket,
  GraduationCap,
  ClipboardList,
  MessageSquareText,
  Kanban,
  Send,
  KeyRound,
  QrCode,
  Plug,
} from "lucide-react";
import { UnreadNavBadge } from "@/components/unread-nav-badge";

export type NavItem = {
  href: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  group: "main" | "settings";
  /** componente extra à direita do label — ex: badge de não lidas. */
  trailing?: React.ComponentType;
};

/** Fonte única de verdade da navegação — usada pela sidebar (desktop) e pelo drawer mobile. */
export const NAV: NavItem[] = [
  { href: "/dashboard",      label: "Dashboard",      icon: LayoutDashboard, group: "main" },
  { href: "/conversations",  label: "Conversas",      icon: MessagesSquare,  group: "main", trailing: UnreadNavBadge },
  { href: "/leads",          label: "Leads",          icon: Users,           group: "main" },
  { href: "/pipeline",       label: "Pipeline",       icon: Kanban,          group: "main" },
  { href: "/launches",       label: "Lançamentos",    icon: Rocket,          group: "main" },
  { href: "/courses",        label: "Cursos",         icon: GraduationCap,   group: "main" },
  { href: "/surveys",        label: "Pesquisas",      icon: ClipboardList,   group: "main" },
  { href: "/onboarding",     label: "Onboarding",     icon: Sparkles,        group: "main" },
  { href: "/integrations",       label: "Integrações",        icon: Plug,               group: "settings" },
  { href: "/settings/agents",    label: "Agentes",            icon: Bot,                group: "settings" },
  { href: "/settings/tools",    label: "Tools",              icon: Wrench,             group: "settings" },
  { href: "/settings/queues",   label: "Filas",              icon: Layers,             group: "settings" },
  { href: "/settings/templates",label: "Templates WhatsApp", icon: MessageSquareText,  group: "settings" },
  { href: "/settings/followup",  label: "Follow-up auto",     icon: Send,               group: "settings" },
  { href: "/settings/credentials", label: "Chaves de API",       icon: KeyRound,           group: "settings" },
  { href: "/settings/meta", label: "Meta / Business", icon: KeyRound, group: "settings" },
  { href: "/settings/whatsapp-qr", label: "WhatsApp via QR", icon: QrCode, group: "settings" },
  { href: "/settings",          label: "Geral",              icon: Settings,           group: "settings" },
];

export function NavGroup({
  items,
  onNavigate,
}: {
  items: Array<{ href: string; label: string; icon: React.ComponentType<{ className?: string }>; trailing?: React.ComponentType }>;
  /** chamado ao clicar num item — usado no drawer mobile pra fechar o Sheet. */
  onNavigate?: () => void;
}) {
  return (
    <ul className="space-y-0.5">
      {items.map((it) => {
        const Icon = it.icon;
        const Trailing = it.trailing;
        return (
          <li key={it.href}>
            <Link
              href={it.href}
              onClick={onNavigate}
              className="flex items-center gap-3 rounded-md px-3 py-2 text-sm hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
            >
              <Icon className="size-4 text-primary" />
              {it.label}
              {Trailing ? <Trailing /> : null}
            </Link>
          </li>
        );
      })}
    </ul>
  );
}
