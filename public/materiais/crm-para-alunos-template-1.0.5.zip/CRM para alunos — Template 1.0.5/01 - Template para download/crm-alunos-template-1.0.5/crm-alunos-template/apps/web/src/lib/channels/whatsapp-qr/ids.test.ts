import { describe, it, expect } from "vitest";
import { chatIdToExternalId, externalIdToChatId } from "./ids";

describe("chatIdToExternalId", () => {
  it("contato comum vira só dígitos (mesmo formato do wa_id)", () => {
    expect(chatIdToExternalId("5511999999999@c.us")).toBe("5511999999999");
    expect(chatIdToExternalId("5511999999999@s.whatsapp.net")).toBe("5511999999999");
  });
  it("remove sufixo de dispositivo", () => {
    expect(chatIdToExternalId("5511999999999:12@c.us")).toBe("5511999999999");
  });
  it("mantém @lid inteiro", () => {
    expect(chatIdToExternalId("123456789@lid")).toBe("123456789@lid");
  });
  it("ignora grupo, status, canal e lixo", () => {
    for (const id of ["120363@g.us", "status@broadcast", "1203@newsletter", "abc@c.us", "", null, 42]) {
      expect(chatIdToExternalId(id)).toBeNull();
    }
  });
});

describe("externalIdToChatId", () => {
  it("telefone ganha @c.us; @lid passa intacto", () => {
    expect(externalIdToChatId("5511999999999")).toBe("5511999999999@c.us");
    expect(externalIdToChatId("123456789@lid")).toBe("123456789@lid");
  });
  it("recusa id que não é telefone", () => {
    expect(() => externalIdToChatId("abc")).toThrow();
  });
  it("ida e volta preserva o contato", () => {
    for (const chat of ["5511999999999@c.us", "123456789@lid"]) {
      expect(externalIdToChatId(chatIdToExternalId(chat)!)).toBe(chat);
    }
  });
});
