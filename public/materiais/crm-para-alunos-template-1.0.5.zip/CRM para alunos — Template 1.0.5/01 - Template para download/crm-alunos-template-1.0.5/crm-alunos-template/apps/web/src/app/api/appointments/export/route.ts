/**
 * GET /api/appointments/export?agent=id&from=YYYY-MM-DD&to=YYYY-MM-DD[&professional=id]
 *
 * Baixa as consultas do agente no período em CSV (abre no Excel e no Google Planilhas).
 * Datas no fuso do negócio, `to` inclusive. Exige sessão — tem dados de paciente.
 */
import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { appointmentsCsv } from "@/lib/scheduling/service";
import { isValidDate } from "@/lib/scheduling/time";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_RANGE_DAYS = 366;

export async function GET(req: Request): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const url = new URL(req.url);
  const from = url.searchParams.get("from") ?? "";
  const to = url.searchParams.get("to") ?? "";
  const agentSessionId = url.searchParams.get("agent") ?? "";
  const professionalId = url.searchParams.get("professional") || null;

  if (!agentSessionId) {
    return NextResponse.json({ error: "missing_agent", message: "Informe o agente." }, { status: 400 });
  }

  if (!isValidDate(from) || !isValidDate(to)) {
    return NextResponse.json({ error: "invalid_dates", message: "Use from e to no formato YYYY-MM-DD." }, { status: 400 });
  }
  if (to < from) {
    return NextResponse.json({ error: "invalid_range", message: "A data final é antes da inicial." }, { status: 400 });
  }
  if ((Date.parse(to) - Date.parse(from)) / 86_400_000 > MAX_RANGE_DAYS) {
    return NextResponse.json({ error: "range_too_large", message: "Período máximo: 1 ano." }, { status: 400 });
  }

  const csv = await appointmentsCsv({ agentSessionId, from, to, professionalId });
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="consultas_${from}_a_${to}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
