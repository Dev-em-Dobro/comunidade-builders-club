import { describe, it, expect, beforeAll, afterAll, vi, beforeEach } from "vitest";
import { prisma } from "@/lib/db";

const sendTextMock = vi.fn();
vi.mock("@/lib/channels/registry", () => ({
  getAdapter: () => ({ sendText: sendTextMock }),
}));
vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));
vi.mock("@/lib/realtime/notify", () => ({
  notifyMessage: vi.fn().mockResolvedValue(undefined),
  notifyConvEvent: vi.fn().mockResolvedValue(undefined),
}));

import { POST } from "./route";
import { auth } from "@/auth";
import { notifyMessage, notifyConvEvent } from "@/lib/realtime/notify";
import { ChannelSendError, META_OUT_OF_WINDOW } from "@/lib/channels/meta-graph";

const created = { contactIds: [] as string[], userIds: [] as string[] };
let convId: string;
let userId: string;

beforeAll(async () => {
  const user = await prisma.user.create({
    data: { email: `composer-${Date.now()}@test.local`, name: "Operator Test" },
  });
  userId = user.id;
  created.userIds.push(user.id);
  const contact = await prisma.contact.create({
    data: {
      displayName: "Send route test",
      identities: { create: { channel: "whatsapp_cloud", externalId: "5511900000000" } },
    },
  });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: {
      contactId: contact.id,
      channel: "whatsapp_cloud",
      // Janela aberta — 1h no futuro.
      windowClosesAt: new Date(Date.now() + 60 * 60 * 1000),
    },
  });
  convId = conv.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  sendTextMock.mockReset();
  vi.mocked(notifyMessage).mockClear();
  vi.mocked(notifyConvEvent).mockClear();
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

function postReq(body: unknown): Request {
  return new Request("http://localhost/api/conversations/x/send", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("POST /api/conversations/[id]/send", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(postReq({ text: "oi" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(401);
  });

  it("400 texto vazio", async () => {
    const res = await POST(postReq({ text: "   " }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(400);
  });

  it("400 texto longo demais (>4096)", async () => {
    const res = await POST(postReq({ text: "x".repeat(4097) }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(400);
  });

  it("409 janela 24h fechada (preventivo)", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { windowClosesAt: new Date(Date.now() - 1000) }, // fechou 1s atrás
    });
    const res = await POST(postReq({ text: "oi" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.error).toBe("window_closed");
    // Restaura pra próximos testes.
    await prisma.conversation.update({
      where: { id: convId },
      data: { windowClosesAt: new Date(Date.now() + 60 * 60 * 1000) },
    });
  });

  it("409 quando Meta retorna 131047 (janela fechada reativa)", async () => {
    sendTextMock.mockRejectedValueOnce(
      new ChannelSendError(
        {
          code: META_OUT_OF_WINDOW,
          name: "OutOf24hWindow",
          message: "fora da janela",
          action: "use template",
        },
        400,
      ),
    );
    const res = await POST(postReq({ text: "oi" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(409);
    const body = await res.json();
    expect(body.error).toBe("window_closed_meta");
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.windowExpired).toBe(true);
    // Reset windowExpired pros próximos.
    await prisma.conversation.update({
      where: { id: convId },
      data: { windowExpired: false },
    });
  });

  it("200 envia, persiste com sentByUserId, chama notify", async () => {
    sendTextMock.mockResolvedValueOnce(undefined);
    const before = await prisma.message.count({ where: { conversationId: convId } });
    const res = await POST(postReq({ text: "msg do atendente" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);

    // sendText foi chamado com externalId e texto corretos.
    expect(sendTextMock).toHaveBeenCalledWith("5511900000000", "msg do atendente");

    // Mensagem persistida com sentByUserId.
    const after = await prisma.message.count({ where: { conversationId: convId } });
    expect(after).toBe(before + 1);
    const saved = await prisma.message.findUniqueOrThrow({ where: { id: body.messageId } });
    expect(saved.sentByUserId).toBe(userId);
    expect(saved.direction).toBe("outbound");
    expect(saved.role).toBe("assistant");
    expect(saved.modelUsed).toBeNull();

    // Notify chamado com convId + msgId.
    expect(notifyMessage).toHaveBeenCalledWith(convId, body.messageId);
  });

  it("200 auto-claima conversa sem assignedUserId + dispara notifyConvEvent claim", async () => {
    // garante conv sem dono
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: null, windowClosesAt: new Date(Date.now() + 60 * 60 * 1000) },
    });
    sendTextMock.mockResolvedValueOnce(undefined);
    const res = await POST(postReq({ text: "primeira msg" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);

    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.assignedUserId).toBe(userId);

    expect(notifyConvEvent).toHaveBeenCalledWith(
      convId,
      expect.objectContaining({ type: "claim", userId }),
    );
  });

  it("200 NÃO dispara notifyConvEvent quando user já é dono", async () => {
    await prisma.conversation.update({
      where: { id: convId },
      data: { assignedUserId: userId, windowClosesAt: new Date(Date.now() + 60 * 60 * 1000) },
    });
    sendTextMock.mockResolvedValueOnce(undefined);
    const res = await POST(postReq({ text: "msg subsequente" }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    // notifyMessage chamou; notifyConvEvent NÃO.
    expect(notifyMessage).toHaveBeenCalled();
    expect(notifyConvEvent).not.toHaveBeenCalled();
  });
});
