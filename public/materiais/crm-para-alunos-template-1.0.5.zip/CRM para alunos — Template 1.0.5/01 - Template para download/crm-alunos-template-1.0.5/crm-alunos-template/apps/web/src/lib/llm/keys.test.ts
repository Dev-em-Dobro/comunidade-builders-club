import { describe, it, expect, vi, beforeEach, beforeAll } from "vitest";

vi.mock("@/lib/db", () => ({
  prisma: { providerCredential: { findUnique: vi.fn() } },
}));

import { prisma } from "@/lib/db";
import { encryptSecret } from "@/lib/crypto/secrets";
import { resolveProviderKey } from "./keys";

const findUnique = prisma.providerCredential.findUnique as unknown as ReturnType<typeof vi.fn>;

beforeAll(() => {
  process.env.SECRETS_KEY = "vitest-secret-key-para-testes";
});

beforeEach(() => {
  findUnique.mockReset();
  delete process.env.OPENAI_API_KEY;
  delete process.env.ANTHROPIC_API_KEY;
});

describe("resolveProviderKey", () => {
  it("descriptografa a chave do banco quando existe", async () => {
    findUnique.mockResolvedValue({ provider: "openai", apiKeyEnc: encryptSecret("sk-do-banco") });
    expect(await resolveProviderKey("openai")).toBe("sk-do-banco");
  });

  it("cai pra env var quando não há registro no banco", async () => {
    findUnique.mockResolvedValue(null);
    process.env.OPENAI_API_KEY = "sk-da-env";
    expect(await resolveProviderKey("openai")).toBe("sk-da-env");
  });

  it("usa ANTHROPIC_API_KEY para provider anthropic", async () => {
    findUnique.mockResolvedValue(null);
    process.env.ANTHROPIC_API_KEY = "sk-ant-env";
    expect(await resolveProviderKey("anthropic")).toBe("sk-ant-env");
  });

  it("retorna undefined quando não há nada", async () => {
    findUnique.mockResolvedValue(null);
    expect(await resolveProviderKey("openai")).toBeUndefined();
  });
});
