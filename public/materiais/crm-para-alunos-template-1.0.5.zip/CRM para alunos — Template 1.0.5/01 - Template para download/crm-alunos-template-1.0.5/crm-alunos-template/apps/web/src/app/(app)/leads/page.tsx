import Link from "next/link";
import { prisma } from "@/lib/db";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Users } from "lucide-react";
import { STAGE_LABEL, STAGE_VARIANT } from "./stages";

export const dynamic = "force-dynamic";

export default async function LeadsPage() {
  const leads = await safeQuery();

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Leads
        </h1>
        <p className="text-muted-foreground mt-1">
          Criados automaticamente na primeira mensagem de cada contato.
        </p>
      </header>

      {leads.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <Users className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhum lead ainda</p>
          <p className="text-sm text-muted-foreground mt-1">
            Aparecem aqui assim que chega a primeira mensagem de um contato.
          </p>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Contato</TableHead>
                <TableHead>Stage</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Última atividade</TableHead>
                <TableHead>Lançamento</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leads.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="font-medium">
                    {l.contact.displayName ?? "—"}
                  </TableCell>
                  <TableCell>
                    <Badge variant={STAGE_VARIANT[l.stage] ?? "outline"}>
                      {STAGE_LABEL[l.stage] ?? l.stage}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono">{l.score}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {fmtDateTime(l.lastActivityAt)}
                  </TableCell>
                  <TableCell className="text-sm">
                    {l.launch?.name ?? (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Link
                      href={`/leads/${l.id}`}
                      className={buttonVariants({ size: "sm", variant: "outline" })}
                    >
                      Ver
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}

function fmtDateTime(d: Date | null): string {
  if (!d) return "—";
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

async function safeQuery() {
  try {
    return await prisma.lead.findMany({
      orderBy: [{ lastActivityAt: { sort: "desc", nulls: "last" } }],
      include: { contact: true, launch: true },
    });
  } catch {
    return [];
  }
}
