import { resolveMetaSettings } from "@/lib/settings/meta";
import { verifyHmacSha256 } from "./hmac";
import {
  META_GRAPH_BASE,
  ensureSubscription,
  publicWebhookUrl,
  verifyMetaWebhook,
  describeMetaError,
  ChannelSendError,
} from "./meta-graph";
import type {
  ChannelAdapter,
  ChannelMessage,
  ChannelMedia,
  SessionState,
} from "./types";

async function env() {
  const meta = await resolveMetaSettings();
  return {
    appId: meta.META_APP_ID,
    appSecret: meta.META_APP_SECRET,
    phoneNumberId: meta.META_PHONE_NUMBER_ID,
    businessAccountId: meta.META_BUSINESS_ACCOUNT_ID,
    token: meta.META_SYSTEM_USER_TOKEN,
    verifyToken: meta.META_WEBHOOK_VERIFY_TOKEN,
  };
}

function missingCreds(e: Awaited<ReturnType<typeof env>>) {
  return !e.appSecret || !e.phoneNumberId || !e.token || !e.verifyToken;
}

async function detectStatus(): Promise<SessionState> {
  const e = await env();
  if (missingCreds(e)) {
    return {
      channel: "whatsapp_cloud",
      status: "missing_credentials",
      webhookUrl: publicWebhookUrl("whatsapp-cloud"),
      message: "Faltam env vars: META_APP_SECRET, META_PHONE_NUMBER_ID, META_SYSTEM_USER_TOKEN, META_WEBHOOK_VERIFY_TOKEN.",
    };
  }
  const res = await fetch(
    `${META_GRAPH_BASE}/${e.phoneNumberId}?fields=verified_name,display_phone_number`,
    { headers: { Authorization: `Bearer ${e.token}` }, cache: "no-store" },
  );
  const json = (await res.json()) as {
    verified_name?: string;
    display_phone_number?: string;
    error?: { code?: number; message?: string };
  };
  if (json.error) {
    return {
      channel: "whatsapp_cloud",
      status: "error",
      webhookUrl: publicWebhookUrl("whatsapp-cloud"),
      message: `${json.error.code}: ${json.error.message}`,
    };
  }
  return {
    channel: "whatsapp_cloud",
    status: "connected",
    webhookUrl: publicWebhookUrl("whatsapp-cloud"),
    verifyToken: e.verifyToken,
    message: `${json.verified_name ?? "—"} (${json.display_phone_number ?? "—"})`,
    details: json,
  };
}

/**
 * Texto legível para tipos NÃO-mídia e NÃO-texto (localização, contato, reação,
 * `unsupported`, ou qualquer tipo futuro). Antes o parser caía em `""` pra esses
 * — a conversa aparecia VAZIA na inbox e o bot ficava mudo (LLM sem conteúdo).
 * Embute o conteúdo recuperável NO texto (coords + link de mapa, nome/telefone
 * do contato, emoji da reação). NUNCA retorna vazio.
 *
 * Mídia (image/audio/video/document/sticker) NÃO passa por aqui — segue no
 * placeholder `[tipo]` + `unsupportedMediaReply` (ver media-fallback.ts).
 */
export function describeNonText(msg: Record<string, unknown>, msgType: string): string {
  if (msgType === "location") {
    const loc = msg.location as
      | { latitude?: number; longitude?: number; name?: string; address?: string }
      | undefined;
    const parts = ["[localização]"];
    if (loc?.name) parts.push(loc.name);
    if (loc?.address) parts.push(loc.address);
    if (loc?.latitude != null && loc?.longitude != null) {
      parts.push(`(${loc.latitude}, ${loc.longitude})`);
      parts.push(`https://www.google.com/maps?q=${loc.latitude},${loc.longitude}`);
    }
    return parts.join(" ");
  }

  if (msgType === "contacts") {
    const contacts =
      (msg.contacts as Array<{
        name?: { formatted_name?: string };
        phones?: Array<{ phone?: string }>;
      }>) ?? [];
    const rendered = contacts
      .map((ct) => {
        const name = ct.name?.formatted_name ?? "";
        const phones = (ct.phones ?? [])
          .map((p) => p.phone)
          .filter(Boolean)
          .join(", ");
        return [name, phones].filter(Boolean).join(" · ");
      })
      .filter(Boolean)
      .join(" | ");
    return rendered ? `[contato] ${rendered}` : "[contato]";
  }

  if (msgType === "reaction") {
    const emoji = (msg.reaction as { emoji?: string } | undefined)?.emoji;
    return emoji ? `[reação] ${emoji}` : "[reação]";
  }

  if (msgType === "unsupported") return "[mensagem não suportada]";

  // Tipo futuro/desconhecido — nunca vazio; inclui o tipo pra debug.
  return `[mensagem não suportada: ${msgType}]`;
}

function mediaFromMessage(
  raw: Record<string, unknown>,
): ChannelMedia[] | undefined {
  const mediaTypes: Array<keyof typeof MEDIA_MAP> = ["image", "audio", "video", "document", "sticker"];
  const MEDIA_MAP = {
    image: "image",
    audio: "audio",
    video: "video",
    document: "document",
    sticker: "sticker",
  } as const;
  const found: ChannelMedia[] = [];
  for (const t of mediaTypes) {
    const m = raw[t] as Record<string, unknown> | undefined;
    if (m && typeof m === "object") {
      found.push({
        type: MEDIA_MAP[t],
        id: typeof m.id === "string" ? m.id : undefined,
        mimeType: typeof m.mime_type === "string" ? m.mime_type : undefined,
        caption: typeof m.caption === "string" ? m.caption : undefined,
      });
    }
  }
  return found.length ? found : undefined;
}

export const whatsappCloudAdapter: ChannelAdapter = {
  id: "whatsapp_cloud",

  async ensureSession() {
    const e = await env();
    if (missingCreds(e)) return detectStatus();
    if (!e.businessAccountId) {
      return {
        channel: "whatsapp_cloud",
        status: "missing_credentials",
        webhookUrl: publicWebhookUrl("whatsapp-cloud"),
        message: "Informe o ID da conta WhatsApp Business (WABA ID) para verificar a subscription.",
      };
    }
    const result = await ensureSubscription({
      node: e.businessAccountId,
      bearerToken: e.token!,
      appId: e.appId,
    });
    const status = await detectStatus();
    return {
      ...status,
      message: result.error
        ? `subscription falhou: ${result.error}`
        : result.alreadySubscribed
          ? `${status.message} · subscription já ativa`
          : `${status.message} · app subscrito agora`,
    };
  },

  async getSessionStatus() {
    return detectStatus();
  },

  async verifyWebhook(req) {
    return verifyMetaWebhook(req, (await env()).verifyToken);
  },

  async parseWebhook(req) {
    const rawBody = await req.text();
    const sig = req.headers.get("x-hub-signature-256");
    const e = await env();
    if (!e.appSecret || !verifyHmacSha256(rawBody, sig, e.appSecret)) {
      throw new HmacFailure("invalid signature");
    }

    const payload = JSON.parse(rawBody) as {
      entry?: Array<{
        changes?: Array<{
          value?: {
            messaging_product?: string;
            metadata?: Record<string, unknown>;
            contacts?: Array<{ wa_id?: string; profile?: { name?: string } }>;
            messages?: Array<Record<string, unknown>>;
            statuses?: Array<unknown>;
          };
        }>;
      }>;
    };

    // Pega o primeiro msg event (Meta agrupa, mas no nosso fluxo processamos 1 msg por webhook).
    for (const entry of payload.entry ?? []) {
      for (const change of entry.changes ?? []) {
        const value = change.value;
        if (!value?.messages?.length) continue;
        const msg = value.messages[0]!;
        const contact = value.contacts?.[0];
        const waId = typeof msg.from === "string" ? msg.from : contact?.wa_id;
        if (!waId) continue;
        const msgType = typeof msg.type === "string" ? msg.type : "text";
        const media = mediaFromMessage(msg as Record<string, unknown>);
        // Legenda da mídia (image/document) é texto real do lead — vira o `text`
        // pra IA responder; sem legenda, cai no placeholder `[tipo]`.
        const caption = media?.find((m) => m.caption?.trim())?.caption?.trim();
        const isMedia =
          msgType === "image" || msgType === "audio" || msgType === "video" ||
          msgType === "document" || msgType === "sticker";
        const text =
          (msg.text as { body?: string } | undefined)?.body ??
          (msg.button as { text?: string } | undefined)?.text ??
          (msg.interactive as { button_reply?: { title?: string }; list_reply?: { title?: string } } | undefined)?.button_reply?.title ??
          (msg.interactive as { list_reply?: { title?: string } } | undefined)?.list_reply?.title ??
          caption ??
          (isMedia ? `[${msgType}]` : describeNonText(msg as Record<string, unknown>, msgType));

        return {
          channel: "whatsapp_cloud",
          contactId: waId,
          contactName: contact?.profile?.name,
          text,
          // Reação (emoji): fica visível na inbox como "[reação] 👍", mas não
          // dispara resposta do bot (ver ChannelMessage.suppressAutoReply).
          suppressAutoReply: msgType === "reaction",
          media,
          providerMsgId: typeof msg.id === "string" ? msg.id : undefined,
          receivedAt: typeof msg.timestamp === "string"
            ? new Date(Number(msg.timestamp) * 1000).toISOString()
            : new Date().toISOString(),
          raw: msg,
        } satisfies ChannelMessage;
      }
    }
    return null;
  },

  async sendText(externalId, text) {
    // Gotcha 0.9.27: externalId DEVE ser wa_id (E.164 sem '+'), nunca Contact.id cuid.
    if (/^c[a-z0-9]{24}$/.test(externalId)) {
      throw new Error(`sendText(whatsapp_cloud) recebeu cuid (${externalId}); use ContactIdentity.externalId.`);
    }
    const e = await env();
    if (missingCreds(e)) {
      throw new Error("Credenciais Cloud API ausentes — preencha .env antes do envio.");
    }
    const res = await fetch(`${META_GRAPH_BASE}/${e.phoneNumberId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${e.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: externalId,
        type: "text",
        text: { body: text, preview_url: true },
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      const info = describeMetaError(res.status, body);
      // Antes era um throw genérico — o erro da Meta ficava ilegível no log.
      // Agora mapeamos o code (131047 = fora da janela 24h, etc.) e a ação.
      console.error(
        JSON.stringify({
          event: "whatsapp_cloud.send_error",
          status: res.status,
          code: info.code,
          name: info.name,
          action: info.action,
          message: info.message,
          at: new Date().toISOString(),
        }),
      );
      throw new ChannelSendError(info, res.status);
    }
  },
};

export class HmacFailure extends Error {
  constructor(message: string) {
    super(message);
    this.name = "HmacFailure";
  }
}
