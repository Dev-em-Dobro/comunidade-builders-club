"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import type { Bonus } from "@/lib/launches/types";

interface Props {
  value: Bonus[];
  onChange: (v: Bonus[]) => void;
}

/**
 * Editor visual de bônus pra LaunchForm. Lista linha-a-linha com:
 *  - title (input curto)
 *  - description (textarea)
 *  - botões: subir, descer, remover
 *  - linha de "adicionar novo" no fim
 *
 * Sem persistência própria — controlled component. O LaunchForm guarda o
 * array em state local e serializa pra JSON num <input type="hidden"> que
 * o saveLaunch lê.
 */
export function BonusesEditor({ value, onChange }: Props) {
  const [draft, setDraft] = useState<Bonus>({ title: "", description: "" });

  const add = () => {
    if (!draft.title.trim() || !draft.description.trim()) return;
    onChange([...value, { title: draft.title.trim(), description: draft.description.trim() }]);
    setDraft({ title: "", description: "" });
  };
  const remove = (i: number) => onChange(value.filter((_, idx) => idx !== i));
  const move = (i: number, dir: -1 | 1) => {
    const j = i + dir;
    if (j < 0 || j >= value.length) return;
    const next = [...value];
    [next[i], next[j]] = [next[j]!, next[i]!];
    onChange(next);
  };

  return (
    <div className="space-y-3">
      {value.length === 0 && (
        <p className="text-sm text-muted-foreground italic">
          Nenhum bônus cadastrado ainda.
        </p>
      )}
      {value.map((b, i) => (
        <div key={i} className="flex items-start gap-2 rounded-md border p-3">
          <div className="flex-1 space-y-1">
            <div className="font-medium">{b.title}</div>
            <div className="text-sm text-muted-foreground whitespace-pre-wrap">
              {b.description}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => move(i, -1)}
              disabled={i === 0}
              aria-label="Subir bônus"
            >
              <ArrowUp className="size-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => move(i, 1)}
              disabled={i === value.length - 1}
              aria-label="Descer bônus"
            >
              <ArrowDown className="size-4" />
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => remove(i)}
              aria-label="Remover bônus"
            >
              <Trash2 className="size-4" />
            </Button>
          </div>
        </div>
      ))}
      <div className="rounded-md border bg-muted/30 p-3 space-y-2">
        <Input
          placeholder="Título do bônus (ex: Mentoria mensal)"
          value={draft.title}
          onChange={(e) => setDraft({ ...draft, title: e.target.value })}
        />
        <Textarea
          placeholder="Descrição (ex: 1h por mês com o time)"
          rows={2}
          value={draft.description}
          onChange={(e) => setDraft({ ...draft, description: e.target.value })}
        />
        <Button
          type="button"
          size="sm"
          variant="secondary"
          onClick={add}
          disabled={!draft.title.trim() || !draft.description.trim()}
        >
          <Plus className="size-4" /> Adicionar bônus
        </Button>
      </div>
    </div>
  );
}
