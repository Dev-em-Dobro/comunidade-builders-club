export interface CourseLite {
  id: string;
  name: string;
  slug: string;
}

export interface MessageLite {
  text: string | null;
  createdAt: Date;
}

export interface PickPrimaryInput {
  interestCourseIds: string[];
  messages: MessageLite[];
  courses: CourseLite[];
}

/**
 * Pra leads com 2+ interesses, escolhe o curso que tem oferta a aplicar
 * com prioridade no bloco de contexto.
 *
 * Heurística: itera mensagens em ordem decrescente de createdAt, retorna o
 * primeiro course (por name OU slug, case-insensitive) que apareça em
 * interestCourseIds. Se nenhuma mensagem mencionar, cai pra
 * interestCourseIds[0]. Sem NLP.
 */
export function pickPrimaryCourseId(input: PickPrimaryInput): string | null {
  if (input.interestCourseIds.length === 0) return null;

  const allowed = new Set(input.interestCourseIds);
  const candidates = input.courses.filter((c) => allowed.has(c.id));
  if (candidates.length === 0) return input.interestCourseIds[0]!;

  const sorted = [...input.messages].sort(
    (a, b) => b.createdAt.getTime() - a.createdAt.getTime(),
  );

  for (const msg of sorted) {
    if (!msg.text) continue;
    const lower = msg.text.toLowerCase();
    for (const c of candidates) {
      if (
        lower.includes(c.name.toLowerCase()) ||
        lower.includes(c.slug.toLowerCase())
      ) {
        return c.id;
      }
    }
  }

  return input.interestCourseIds[0]!;
}
