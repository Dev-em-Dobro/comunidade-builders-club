import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { sendWhatsAppMedia } from "./whatsapp-send-media";
import { inspectOutgoingMedia } from "./outgoing-media";

describe("sendWhatsAppMedia", () => {
  const originalToken = process.env.META_SYSTEM_USER_TOKEN;
  const originalPhoneId = process.env.META_PHONE_NUMBER_ID;

  beforeEach(() => {
    process.env.META_SYSTEM_USER_TOKEN = "test-token";
    process.env.META_PHONE_NUMBER_ID = "123456";
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    if (originalToken === undefined) delete process.env.META_SYSTEM_USER_TOKEN;
    else process.env.META_SYSTEM_USER_TOKEN = originalToken;
    if (originalPhoneId === undefined) delete process.env.META_PHONE_NUMBER_ID;
    else process.env.META_PHONE_NUMBER_ID = originalPhoneId;
  });

  it("faz upload e envia imagem com legenda usando o ID confirmado pela Meta", async () => {
    const mock = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ id: "media-77" }), { status: 200 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ messages: [{ id: "wamid.sent-1" }] }), { status: 200 }));
    vi.stubGlobal("fetch", mock);
    const file = new File(["bytes"], "foto.png", { type: "image/png" });

    const sent = await sendWhatsAppMedia("5511999999999", file, inspectOutgoingMedia(file), "Legenda");

    expect(sent).toEqual({ mediaId: "media-77", providerMsgId: "wamid.sent-1" });
    expect(mock.mock.calls[0]![0]).toBe("https://graph.facebook.com/v25.0/123456/media");
    expect(mock.mock.calls[1]![0]).toBe("https://graph.facebook.com/v25.0/123456/messages");
    expect(JSON.parse(mock.mock.calls[1]![1].body)).toMatchObject({
      messaging_product: "whatsapp",
      to: "5511999999999",
      type: "image",
      image: { id: "media-77", caption: "Legenda" },
    });
  });

  it("não tenta enviar se o upload falhar", async () => {
    const mock = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({
      error: { code: 100, message: "invalid media" },
    }), { status: 400 }));
    vi.stubGlobal("fetch", mock);
    const file = new File(["bad"], "voz.mp3", { type: "audio/mpeg" });

    await expect(sendWhatsAppMedia("5511999999999", file, inspectOutgoingMedia(file)))
      .rejects.toThrow("invalid media");
    expect(mock).toHaveBeenCalledTimes(1);
  });

  it("envia áudio como mídia sem legenda", async () => {
    const mock = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({ id: "media-audio" }), { status: 200 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ messages: [{ id: "wamid.audio" }] }), { status: 200 }));
    vi.stubGlobal("fetch", mock);
    const file = new File(["audio"], "voz.mp3", { type: "audio/mpeg" });

    await sendWhatsAppMedia("5511999999999", file, inspectOutgoingMedia(file));

    expect(JSON.parse(mock.mock.calls[1]![1].body)).toMatchObject({
      type: "audio",
      audio: { id: "media-audio" },
    });
  });
});
