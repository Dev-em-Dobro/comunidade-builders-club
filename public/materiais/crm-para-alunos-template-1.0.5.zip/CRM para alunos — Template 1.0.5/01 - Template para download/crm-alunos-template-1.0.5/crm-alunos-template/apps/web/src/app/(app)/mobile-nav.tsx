"use client";

import { useState } from "react";
import Link from "next/link";
import { Bot, KeyRound, LogOut, Menu } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetTitle,
} from "@/components/ui/sheet";
import {
  NotificationBell,
  type BellNotification,
} from "@/components/notification-bell";
import { OnDutyToggle } from "@/components/on-duty-toggle";
import { NAV, NavGroup } from "./_nav";

/**
 * Barra superior + drawer de navegação, só no mobile (`md:hidden`).
 * A sidebar desktop fica escondida abaixo de `md`, então aqui está toda a
 * navegação — incluindo plantão e notificações — acessível pelo hambúrguer.
 */
export function MobileNav({
  brandName,
  notifications,
  isOnDuty,
  userEmail,
  logoutAction,
}: {
  brandName: string;
  notifications: BellNotification[];
  isOnDuty: boolean;
  userEmail: string;
  logoutAction: () => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const close = () => setOpen(false);

  return (
    <header className="md:hidden sticky top-0 z-40 flex items-center gap-3 border-b border-border bg-sidebar px-4 py-3 text-sidebar-foreground">
      <Sheet open={open} onOpenChange={(o) => setOpen(o)}>
        <SheetTrigger
          aria-label="Abrir menu"
          className="inline-flex size-8 items-center justify-center rounded-md hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
        >
          <Menu className="size-5" />
        </SheetTrigger>
        <SheetContent
          side="left"
          className="w-72 bg-sidebar text-sidebar-foreground p-0"
        >
          <SheetTitle className="sr-only">Menu de navegação</SheetTitle>
          <div className="flex h-full flex-col">
            <div className="px-5 py-5 flex items-center gap-3">
              <div className="size-7 rounded-md bg-primary flex items-center justify-center">
                <Bot className="size-4 text-primary-foreground" />
              </div>
              <span className="font-mono text-sm font-semibold">{brandName}</span>
              <Badge variant="outline" className="font-mono text-[10px]">
                MVP
              </Badge>
            </div>
            <Separator />
            <nav className="flex-1 overflow-y-auto px-2 py-4 space-y-6">
              <NavGroup
                items={NAV.filter((n) => n.group === "main")}
                onNavigate={close}
              />
              <div>
                <p className="px-3 mb-2 text-[11px] uppercase tracking-wider text-muted-foreground">
                  Configurações
                </p>
                <NavGroup
                  items={NAV.filter((n) => n.group === "settings")}
                  onNavigate={close}
                />
              </div>
            </nav>
            <Separator />
            <div className="px-3 py-3 space-y-2">
              <div className="px-2 text-[11px] text-muted-foreground truncate">
                {userEmail}
              </div>
              <Link
                href="/settings/password"
                onClick={close}
                className="flex items-center gap-3 rounded-md px-2 py-2 text-xs hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
              >
                <KeyRound className="size-3.5 text-primary" />
                Trocar senha
              </Link>
              <form action={logoutAction}>
                <button
                  type="submit"
                  className="w-full flex items-center gap-3 rounded-md px-2 py-2 text-xs text-left hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
                >
                  <LogOut className="size-3.5 text-primary" />
                  Sair
                </button>
              </form>
            </div>
          </div>
        </SheetContent>
      </Sheet>

      <div className="flex items-center gap-2">
        <div className="size-7 rounded-md bg-primary flex items-center justify-center">
          <Bot className="size-4 text-primary-foreground" />
        </div>
        <span className="font-mono text-sm font-semibold">{brandName}</span>
      </div>

      <div className="ml-auto flex items-center gap-1">
        <OnDutyToggle initial={isOnDuty} />
        <NotificationBell notifications={notifications} />
      </div>
    </header>
  );
}
