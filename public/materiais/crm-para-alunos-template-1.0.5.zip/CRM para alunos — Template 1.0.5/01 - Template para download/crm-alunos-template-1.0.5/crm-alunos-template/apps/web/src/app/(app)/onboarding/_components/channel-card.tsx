"use client";

import { useState, useTransition } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { CheckCircle2, AlertCircle, KeyRound, RefreshCw, Loader2, QrCode } from "lucide-react";

type ChannelStatus = "connected" | "needs_verification" | "missing_credentials" | "error" | "unknown";

interface SessionState {
  channel: string;
  status: ChannelStatus;
  webhookUrl?: string;
  verifyToken?: string;
  message?: string;
}

const SLUG_BY_CHANNEL: Record<string, string> = {
  whatsapp_cloud: "whatsapp-cloud",
  instagram_direct: "instagram",
  instagram: "instagram",
  whatsapp_qr: "whatsapp-qr",
};

const LABEL: Record<string, string> = {
  whatsapp_cloud: "WhatsApp Cloud API",
  instagram_direct: "Instagram Direct",
  instagram: "Instagram Direct",
  whatsapp_qr: "WhatsApp via QR (não oficial)",
};

const DESCRIPTION: Record<string, string> = {
  whatsapp_qr: "provedor WAHA · pareamento por QR · HMAC SHA512",
};

export function ChannelCard({ channelId }: { channelId: string }) {
  const [state, setState] = useState<SessionState | null>(null);
  const [pending, startTransition] = useTransition();
  const [qrSrc, setQrSrc] = useState<string | null>(null);
  const slug = SLUG_BY_CHANNEL[channelId] ?? channelId;
  const isQr = channelId === "whatsapp_qr";

  async function showQr() {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/sessions/${slug}/qr`, { cache: "no-store" });
        if (!r.ok) {
          const j = (await r.json().catch(() => ({}))) as { error?: string };
          setQrSrc(null);
          toast.error(j.error ?? "QR indisponível");
          return;
        }
        const blob = await r.blob();
        setQrSrc((previous) => {
          if (previous) URL.revokeObjectURL(previous);
          return URL.createObjectURL(blob);
        });
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  async function check() {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/sessions/${slug}/status`, { cache: "no-store" });
        const j = (await r.json()) as { ok: boolean; state?: SessionState; error?: string };
        if (j.state) setState(j.state);
        else toast.error(j.error ?? "Falha ao buscar status");
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  async function ensure() {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/sessions/${slug}/ensure`, { method: "POST" });
        const j = (await r.json()) as { ok: boolean; state?: SessionState; error?: string };
        if (j.state) {
          setState(j.state);
          toast.success(isQr ? "Sessão verificada" : "Subscription verificada");
        } else {
          toast.error(j.error ?? (isQr ? "Falha ao garantir a sessão" : "Falha ao garantir subscription"));
        }
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  const statusColor =
    state?.status === "connected"
      ? "bg-success/15 text-success border-success/30"
      : state?.status === "missing_credentials"
        ? "bg-warning/15 text-warning border-warning/30"
        : state?.status === "error"
          ? "bg-destructive/15 text-destructive border-destructive/30"
          : "bg-muted text-muted-foreground border-border";

  const StatusIcon =
    state?.status === "connected"
      ? CheckCircle2
      : state?.status === "missing_credentials"
        ? KeyRound
        : AlertCircle;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">{LABEL[channelId] ?? channelId}</CardTitle>
            <CardDescription>
              {DESCRIPTION[channelId] ?? "webhook externo Meta · sem container · HMAC SHA256"}
            </CardDescription>
          </div>
          {state && (
            <Badge variant="outline" className={`font-mono text-[10px] ${statusColor}`}>
              <StatusIcon className="size-3 mr-1" />
              {state.status}
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {state?.webhookUrl && (
          <div className="text-xs space-y-1">
            <p className="text-muted-foreground">
              {isQr ? "Webhook URL (configurado automaticamente na sessão do WAHA):" : "Webhook URL (colar no Meta App Dashboard):"}
            </p>
            <code className="block bg-muted p-2 rounded break-all">{state.webhookUrl}</code>
          </div>
        )}
        {state?.verifyToken && (
          <div className="text-xs space-y-1">
            <p className="text-muted-foreground">Verify Token:</p>
            <code className="block bg-muted p-2 rounded break-all">{state.verifyToken}</code>
          </div>
        )}
        {state?.message && (
          <p className="text-sm text-muted-foreground">{state.message}</p>
        )}
        <div className="flex gap-2 pt-2">
          <Button size="sm" variant="outline" onClick={check} disabled={pending}>
            {pending ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
            Status
          </Button>
          <Button size="sm" onClick={ensure} disabled={pending}>
            {pending && <Loader2 className="size-4 animate-spin" />}
            {isQr ? "Garantir sessão" : "Verificar subscription"}
          </Button>
          {isQr && (
            <Button size="sm" variant="outline" onClick={showQr} disabled={pending}>
              <QrCode className="size-4" />
              {qrSrc ? "Atualizar QR" : "Mostrar QR"}
            </Button>
          )}
        </div>
        {isQr && qrSrc && (
          <div className="space-y-2 pt-2">
            {/* eslint-disable-next-line @next/next/no-img-element -- blob local do QR, não passa pelo otimizador */}
            <img src={qrSrc} alt="QR code para conectar o WhatsApp" className="size-56 rounded border bg-white p-2" />
            <p className="text-xs text-muted-foreground">
              No celular do número de atendimento: WhatsApp → Dispositivos conectados → Conectar dispositivo. O QR expira em ~20s; use &quot;Atualizar QR&quot; e depois &quot;Status&quot;.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
