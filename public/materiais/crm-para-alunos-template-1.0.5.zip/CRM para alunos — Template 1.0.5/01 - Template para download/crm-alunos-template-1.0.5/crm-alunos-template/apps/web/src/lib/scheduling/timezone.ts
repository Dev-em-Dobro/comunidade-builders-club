/**
 * Fuso do negócio pro agendamento. Só servidor: lê setup.config.json (node:fs).
 * Separado de ./time.ts pra que o módulo puro possa ir pro bundle do navegador.
 */
import { loadConfig } from "@/lib/config";
import { DEFAULT_TZ, isValidTimeZone } from "./time";

/** setup.config.json → schedule.timezone, com fallback America/Sao_Paulo. */
export function schedulingTimezone(): string {
  try {
    const tz = loadConfig().schedule?.timezone;
    if (tz && isValidTimeZone(tz)) return tz;
  } catch {
    // sem config → default
  }
  return DEFAULT_TZ;
}
