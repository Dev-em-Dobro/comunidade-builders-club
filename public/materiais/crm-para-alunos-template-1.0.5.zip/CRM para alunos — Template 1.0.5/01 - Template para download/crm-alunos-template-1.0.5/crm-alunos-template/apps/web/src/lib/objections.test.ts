import { describe, it, expect } from "vitest";
import {
  OBJECTION_TAGS,
  type ObjectionTag,
  normalizeObjections,
  diffObjections,
  buildObjectionsPrompt,
  detectClosedOfferReference,
} from "./objections";

describe("normalizeObjections", () => {
  it("aceita valores do enum", () => {
    expect(normalizeObjections(["preco", "tempo"])).toEqual(["preco", "tempo"]);
  });

  it("filtra valores fora do enum", () => {
    expect(normalizeObjections(["preco", "lol", "outro"])).toEqual(["preco", "outro"]);
  });

  it("faz dedup preservando ordem", () => {
    expect(normalizeObjections(["preco", "tempo", "preco"])).toEqual(["preco", "tempo"]);
  });

  it("aceita não-arrays retornando []", () => {
    expect(normalizeObjections(null)).toEqual([]);
    expect(normalizeObjections("preco")).toEqual([]);
    expect(normalizeObjections(undefined)).toEqual([]);
  });

  it("filtra entradas que não são strings", () => {
    expect(normalizeObjections(["preco", 42, null, "tempo"])).toEqual(["preco", "tempo"]);
  });
});

describe("diffObjections", () => {
  const now = new Date("2026-05-22T12:00:00Z");
  const recent = new Date("2026-05-22T06:00:00Z"); // 6h atrás
  const stale = new Date("2026-05-21T06:00:00Z");  // 30h atrás

  it("retorna só tags ainda não vistas em 24h", () => {
    const detected: ObjectionTag[] = ["preco", "tempo"];
    const existing = [{ tag: "preco", createdAt: recent }];
    expect(diffObjections(detected, existing, now)).toEqual(["tempo"]);
  });

  it("ignora tags antigas (>24h) — re-tagueia", () => {
    const detected: ObjectionTag[] = ["preco"];
    const existing = [{ tag: "preco", createdAt: stale }];
    expect(diffObjections(detected, existing, now)).toEqual(["preco"]);
  });

  it("retorna vazio quando todas estão recentes", () => {
    const detected: ObjectionTag[] = ["preco", "tempo"];
    const existing = [
      { tag: "preco", createdAt: recent },
      { tag: "tempo", createdAt: recent },
    ];
    expect(diffObjections(detected, existing, now)).toEqual([]);
  });

  it("retorna vazio quando detected é vazio", () => {
    expect(diffObjections([], [{ tag: "preco", createdAt: recent }], now)).toEqual([]);
  });
});

describe("buildObjectionsPrompt", () => {
  it("retorna string vazia para []", () => {
    expect(buildObjectionsPrompt([])).toBe("");
  });

  it("formata 1 objeção", () => {
    const s = buildObjectionsPrompt(["preco"]);
    expect(s).toContain("preço");
    expect(s).toContain("as seguintes objeções");
  });

  it("formata múltiplas objeções com vírgula", () => {
    const s = buildObjectionsPrompt(["preco", "tempo"]);
    expect(s).toContain("preço");
    expect(s).toContain("tempo");
  });

  it("snapshot — pins a frase carregada do prompt", () => {
    expect(buildObjectionsPrompt(["preco", "tempo"])).toBe(
      "# Objeções levantadas pelo lead\n" +
      "Esse lead já levantou as seguintes objeções: preço, tempo. " +
      "Ao retomar o assunto, endereça UMA delas de forma natural — " +
      "sem pedir desculpa, sem soar argumentativo, sem repetir a objeção textualmente."
    );
  });
});

describe("OBJECTION_TAGS", () => {
  it("expõe os 6 valores válidos", () => {
    expect(OBJECTION_TAGS).toEqual([
      "preco", "tempo", "conjuge", "outro_curso", "medo", "outro",
    ]);
  });
});

describe("detectClosedOfferReference", () => {
  it("detecta 'preço de aniversário'", () => {
    expect(
      detectClosedOfferReference("ainda dá pra pegar pelo preço de aniversário?"),
    ).toBe(true);
  });

  it("detecta 'aquele preço de'", () => {
    expect(
      detectClosedOfferReference("ainda vale aquele preço de R$ 497?"),
    ).toBe(true);
  });

  it("detecta menção a launch closed pelo name", () => {
    expect(
      detectClosedOfferReference(
        "tem como pegar o desconto do Aniversário 5 anos?",
        [{ name: "Aniversário 5 anos", status: "closed" }],
      ),
    ).toBe(true);
  });

  it("NÃO detecta menção a launch live com mesmo name", () => {
    expect(
      detectClosedOfferReference(
        "tem como pegar o desconto do Aniversário 5 anos?",
        [{ name: "Aniversário 5 anos", status: "live" }],
      ),
    ).toBe(false);
  });

  it("não detecta conversa sem referência temporal", () => {
    expect(detectClosedOfferReference("quanto custa o curso?")).toBe(false);
  });

  it("retorna false pra texto vazio", () => {
    expect(detectClosedOfferReference("")).toBe(false);
  });

  it("é case-insensitive", () => {
    expect(detectClosedOfferReference("AQUELE PREÇO DE ANIVERSÁRIO")).toBe(true);
  });

  it("não confunde palavra 'oferta' isolada (sem 'aquele/promo/desconto') como objeção", () => {
    // Frase neutra, sem gatilhos.
    expect(detectClosedOfferReference("vocês têm alguma oferta nova chegando?")).toBe(false);
  });
});
