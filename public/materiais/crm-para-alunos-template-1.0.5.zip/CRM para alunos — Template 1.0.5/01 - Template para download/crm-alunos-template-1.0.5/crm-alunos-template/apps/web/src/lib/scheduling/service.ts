/**
 * Serviço de agendamento: disponibilidade, reserva, cancelamento e exportação
 * (CSV e Google Sheets). Usado pelos tools do agente de consulta e pelas telas.
 *
 * A agenda é do próprio CRM: horários livres = semana padrão do profissional
 * + exceções do dia − consultas já marcadas.
 */
import type { Appointment, Prisma, Professional } from "@prisma/client";
import { prisma } from "@/lib/db";
import { appendRow, SHEET_HEADER, updateStatusById } from "@/lib/google/sheets";
import { googleConnectionStatus } from "@/lib/google/oauth";
import { computeSlots, groupSlotsByDate, type BusyRange, type Slot } from "./availability";
import { toCsv } from "./csv";
import {
  cleanIntakeAnswers,
  missingRequired,
  patientNameFrom,
  type IntakeField,
} from "./intake";
import {
  addDays,
  dayLabel,
  isValidDate,
  slotLabel,
  TIME_RE,
  zonedParts,
  zonedToUtc,
} from "./time";
import { schedulingTimezone } from "./timezone";
import { normalizeIntervals, normalizeWorkingHours, type DayOverrides } from "./working-hours";

/** Máximo de dias à frente que o agente pode agendar. */
export const BOOKING_HORIZON_DAYS = 90;
/** Antecedência mínima (minutos) pra marcar. */
export const MIN_NOTICE_MIN = 60;

type Db = Prisma.TransactionClient | typeof prisma;

function dayBounds(fromDate: string, days: number, tz: string) {
  return {
    min: zonedToUtc(fromDate, "00:00", tz),
    max: zonedToUtc(addDays(fromDate, days), "00:00", tz),
  };
}

/** Consultas já marcadas do profissional no período. */
async function busyRanges(db: Db, professionalId: string, min: Date, max: Date): Promise<BusyRange[]> {
  const rows = await db.appointment.findMany({
    where: {
      professionalId,
      status: "scheduled",
      startsAt: { lt: max },
      endsAt: { gt: min },
    },
    select: { startsAt: true, endsAt: true },
  });
  return rows.map((a) => ({ start: a.startsAt, end: a.endsAt }));
}

/** Exceções (folga, feriado, dia extra) do profissional no período. */
export async function overridesFor(
  professionalId: string,
  fromDate: string,
  days: number,
  db: Db = prisma,
): Promise<DayOverrides> {
  const rows = await db.professionalDayOverride.findMany({
    where: { professionalId, date: { gte: fromDate, lt: addDays(fromDate, days) } },
    select: { date: true, intervals: true },
  });
  return Object.fromEntries(rows.map((r) => [r.date, normalizeIntervals(r.intervals)]));
}

export async function slotsFor(
  professional: Professional,
  fromDate: string,
  days: number,
  opts: { now?: Date; db?: Db } = {},
): Promise<Slot[]> {
  const tz = schedulingTimezone();
  const db = opts.db ?? prisma;
  const { min, max } = dayBounds(fromDate, days, tz);
  // Sequencial: `db` pode ser o client de uma transação interativa.
  const busy = await busyRanges(db, professional.id, min, max);
  const overrides = await overridesFor(professional.id, fromDate, days, db);
  const now = opts.now ?? new Date();
  return computeSlots({
    workingHours: normalizeWorkingHours(professional.workingHours),
    overrides,
    durationMin: professional.durationMin,
    busy,
    fromDate,
    days,
    now,
    tz,
    minNoticeMin: MIN_NOTICE_MIN,
  });
}

/** Profissionais que o agente pode oferecer (ativos e do próprio agente). */
export async function bookableProfessionals(agentSessionId: string) {
  return prisma.professional.findMany({
    where: { agentSessionId, active: true },
    orderBy: { name: "asc" },
  });
}

export type AvailabilityResult =
  | {
      ok: true;
      professional: { id: string; name: string; durationMin: number };
      timezone: string;
      requestedDate: string;
      requestedDateHasSlots: boolean;
      days: { date: string; label: string; times: string[] }[];
    }
  | { ok: false; error: string; message: string };

/** Próximos dias com horário livre a partir de `date` (default: hoje). */
export async function checkAvailability(args: {
  agentSessionId: string;
  professionalId: string;
  date?: string | null;
  now?: Date;
  maxDays?: number;
}): Promise<AvailabilityResult> {
  const tz = schedulingTimezone();
  const now = args.now ?? new Date();
  const today = zonedParts(now, tz).date;
  const professional = await prisma.professional.findFirst({
    where: { id: args.professionalId, agentSessionId: args.agentSessionId, active: true },
  });
  if (!professional) {
    return { ok: false, error: "professional_not_found", message: "Profissional não encontrado ou inativo." };
  }
  let from = args.date && isValidDate(args.date) ? args.date : today;
  if (from < today) from = today;
  if (from > addDays(today, BOOKING_HORIZON_DAYS)) {
    return {
      ok: false,
      error: "too_far",
      message: `Só é possível agendar até ${BOOKING_HORIZON_DAYS} dias à frente.`,
    };
  }
  // Busca até 21 dias e devolve os primeiros dias com horário.
  const offsetDays = Math.round((Date.parse(from) - Date.parse(today)) / 86_400_000);
  const searchDays = Math.max(1, Math.min(21, BOOKING_HORIZON_DAYS - offsetDays + 1));
  const slots = await slotsFor(professional, from, searchDays, { now });
  const grouped = groupSlotsByDate(slots).slice(0, args.maxDays ?? 3);
  return {
    ok: true,
    professional: { id: professional.id, name: professional.name, durationMin: professional.durationMin },
    timezone: tz,
    requestedDate: from,
    requestedDateHasSlots: grouped[0]?.date === from,
    days: grouped.map((g) => ({ date: g.date, label: dayLabel(g.date), times: g.times })),
  };
}

export type BookResult =
  | {
      ok: true;
      appointmentId: string;
      professional: string;
      date: string;
      time: string;
      label: string;
      durationMin: number;
    }
  | { ok: false; error: string; message: string; missing?: string[]; availableTimes?: string[] };

function phoneFromIdentities(ids: { channel: string; externalId: string }[]): string | null {
  const wa = ids.find((i) => i.channel.startsWith("whatsapp") && /^\d{6,20}$/.test(i.externalId));
  return wa ? `+${wa.externalId}` : null;
}

function intakeLines(labels: Record<string, string>, answers: Record<string, string>): string[] {
  return Object.entries(answers).map(([k, v]) => `${labels[k] ?? k}: ${v}`);
}

export async function bookAppointment(args: {
  agentSessionId: string;
  professionalId: string;
  date: string;
  time: string;
  intake: unknown;
  intakeFields: IntakeField[];
  contactId: string;
  conversationId: string | null;
  now?: Date;
}): Promise<BookResult> {
  const tz = schedulingTimezone();
  const now = args.now ?? new Date();
  if (!isValidDate(args.date) || !TIME_RE.test(args.time)) {
    return { ok: false, error: "invalid_datetime", message: "Use date=YYYY-MM-DD e time=HH:MM." };
  }
  const answers = cleanIntakeAnswers(args.intakeFields, args.intake);
  const missing = missingRequired(args.intakeFields, answers);
  if (missing.length) {
    return {
      ok: false,
      error: "missing_intake",
      message: "Faltam dados obrigatórios da pré-consulta. Pergunte ao paciente antes de agendar.",
      missing: missing.map((f) => f.label),
    };
  }
  const professional = await prisma.professional.findFirst({
    where: { id: args.professionalId, agentSessionId: args.agentSessionId, active: true },
  });
  if (!professional) {
    return { ok: false, error: "professional_not_found", message: "Profissional não encontrado ou inativo." };
  }
  const labels = Object.fromEntries(args.intakeFields.map((f) => [f.key, f.label]));

  const result = await prisma.$transaction(
    async (tx) => {
      // Serializa reservas do MESMO profissional — dois pacientes não pegam o mesmo horário.
      await tx.$queryRaw`SELECT 1 AS locked FROM (SELECT pg_advisory_xact_lock(hashtext(${"appt:" + professional.id}))) AS l`;
      const daySlots = await slotsFor(professional, args.date, 1, { now, db: tx });
      const slot = daySlots.find((s) => s.time === args.time);
      if (!slot) {
        return {
          ok: false as const,
          error: "slot_unavailable",
          message: "Esse horário não está disponível. Ofereça um dos horários livres.",
          availableTimes: daySlots.map((s) => s.time),
        };
      }
      const appt = await tx.appointment.create({
        data: {
          professionalId: professional.id,
          professionalName: professional.name,
          agentSessionId: args.agentSessionId,
          contactId: args.contactId,
          conversationId: args.conversationId,
          startsAt: slot.start,
          endsAt: slot.end,
          intake: answers,
          intakeLabels: labels,
        },
      });
      return { ok: true as const, appt };
    },
    { timeout: 20_000, maxWait: 10_000 },
  );

  if (!result.ok) return result;
  const { appt } = result;

  // Pós-reserva — best-effort, nunca desfaz o agendamento.
  void syncAppointmentToSheet(appt.id).catch((err) =>
    log({ event: "scheduling.sheet_sync_failed", appointmentId: appt.id, error: String(err?.message ?? err) }),
  );
  const lead = await prisma.lead.findUnique({ where: { contactId: args.contactId }, select: { id: true } });
  if (lead) {
    await prisma.pipelineEvent
      .create({
        data: {
          leadId: lead.id,
          type: "appointment_booked",
          payload: {
            appointmentId: appt.id,
            professionalId: professional.id,
            professionalName: professional.name,
            startsAt: appt.startsAt.toISOString(),
          },
        },
      })
      .catch(() => {});
  }
  log({ event: "scheduling.booked", appointmentId: appt.id, professionalId: professional.id });

  return {
    ok: true,
    appointmentId: appt.id,
    professional: professional.name,
    date: args.date,
    time: args.time,
    label: slotLabel(appt.startsAt, tz),
    durationMin: professional.durationMin,
  };
}

export async function cancelAppointment(id: string): Promise<{ ok: boolean; error?: string }> {
  const appt = await prisma.appointment.findUnique({ where: { id } });
  if (!appt) return { ok: false, error: "Consulta não encontrada." };
  if (appt.status === "cancelled") return { ok: true };
  await prisma.appointment.update({ where: { id }, data: { status: "cancelled" } });
  if (appt.sheetSyncedAt) {
    void sheetTarget()
      .then((t) => (t ? updateStatusById(t.id, t.tab, id, "cancelada") : false))
      .catch((err) => log({ event: "scheduling.sheet_cancel_failed", appointmentId: id, error: String(err?.message ?? err) }));
  }
  return { ok: true };
}

async function sheetTarget(): Promise<{ id: string; tab: string } | null> {
  const s = await googleConnectionStatus();
  if (!s.connected || !s.sheetsSpreadsheetId) return null;
  return { id: s.sheetsSpreadsheetId, tab: s.sheetsTabName || "Agendamentos" };
}

function sheetRow(
  appt: Appointment & {
    professional: { specialty: string | null } | null;
    contact: { displayName: string | null; identities: { channel: string; externalId: string }[] };
  },
  tz: string,
): string[] {
  const answers = (appt.intake ?? {}) as Record<string, string>;
  const labels = (appt.intakeLabels ?? {}) as Record<string, string>;
  const start = zonedParts(appt.startsAt, tz);
  const created = zonedParts(appt.createdAt, tz);
  const fmt = (d: string) => d.split("-").reverse().join("/");
  const fields = Object.keys(labels).map((key) => ({ key, label: labels[key]!, required: false }));
  return [
    `${fmt(created.date)} ${created.time}`,
    fmt(start.date),
    start.time,
    appt.professionalName,
    appt.professional?.specialty ?? "",
    patientNameFrom(fields, answers) ?? appt.contact.displayName ?? "",
    phoneFromIdentities(appt.contact.identities) ?? "",
    appt.status === "cancelled" ? "cancelada" : "agendada",
    intakeLines(labels, answers).join("\n"),
    appt.id,
  ];
}

/** Envia a consulta pra planilha configurada. false = Sheets não configurado. */
export async function syncAppointmentToSheet(appointmentId: string): Promise<boolean> {
  const target = await sheetTarget();
  if (!target) return false;
  const appt = await prisma.appointment.findUnique({
    where: { id: appointmentId },
    include: {
      professional: { select: { specialty: true } },
      contact: { select: { displayName: true, identities: { select: { channel: true, externalId: true } } } },
    },
  });
  if (!appt || appt.sheetSyncedAt) return false;
  await appendRow(target.id, target.tab, sheetRow(appt, schedulingTimezone()));
  await prisma.appointment.update({ where: { id: appt.id }, data: { sheetSyncedAt: new Date() } });
  return true;
}

/** Reenvia consultas que ainda não foram pra planilha (ex.: Sheets configurado depois). */
export async function syncPendingToSheet(limit = 200): Promise<{ sent: number; failed: number }> {
  const pending = await prisma.appointment.findMany({
    where: { sheetSyncedAt: null },
    orderBy: { createdAt: "asc" },
    take: limit,
    select: { id: true },
  });
  let sent = 0;
  let failed = 0;
  for (const { id } of pending) {
    try {
      if (await syncAppointmentToSheet(id)) sent++;
    } catch (err) {
      failed++;
      log({ event: "scheduling.sheet_sync_failed", appointmentId: id, error: String((err as Error)?.message ?? err) });
    }
  }
  return { sent, failed };
}

/** Máximo de linhas num CSV — protege o servidor de um período gigante. */
export const CSV_MAX_ROWS = 5000;

/**
 * CSV das consultas no período [from, to] (datas YYYY-MM-DD no fuso do
 * negócio, inclusive). Mesmas colunas da planilha do Google Sheets.
 */
export async function appointmentsCsv(args: {
  agentSessionId: string;
  from: string;
  to: string;
  professionalId?: string | null;
}): Promise<string> {
  const tz = schedulingTimezone();
  const rows = await prisma.appointment.findMany({
    where: {
      agentSessionId: args.agentSessionId,
      startsAt: { gte: zonedToUtc(args.from, "00:00", tz), lt: zonedToUtc(addDays(args.to, 1), "00:00", tz) },
      ...(args.professionalId ? { professionalId: args.professionalId } : {}),
    },
    orderBy: { startsAt: "asc" },
    take: CSV_MAX_ROWS,
    include: {
      professional: { select: { specialty: true } },
      contact: { select: { displayName: true, identities: { select: { channel: true, externalId: true } } } },
    },
  });
  return toCsv([SHEET_HEADER, ...rows.map((a) => sheetRow(a, tz))]);
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
