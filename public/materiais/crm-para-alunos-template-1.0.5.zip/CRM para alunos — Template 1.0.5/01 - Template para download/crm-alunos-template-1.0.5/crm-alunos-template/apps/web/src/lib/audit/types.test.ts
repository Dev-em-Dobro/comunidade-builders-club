import { describe, it, expect } from "vitest";
import { AuditOutputSchema, FindingSchema } from "./types";

describe("FindingSchema", () => {
  it("aceita finding mínimo (só criterionId + verdict)", () => {
    const parsed = FindingSchema.parse({
      criterionId: "abc",
      verdict: "pass",
    });
    expect(parsed).toEqual({ criterionId: "abc", verdict: "pass" });
  });

  it("rejeita verdict inválido", () => {
    expect(() =>
      FindingSchema.parse({ criterionId: "abc", verdict: "maybe" }),
    ).toThrow();
  });

  it("rejeita severity fora de 1-5", () => {
    expect(() =>
      FindingSchema.parse({ criterionId: "abc", verdict: "fail", severity: 6 }),
    ).toThrow();
    expect(() =>
      FindingSchema.parse({ criterionId: "abc", verdict: "fail", severity: 0 }),
    ).toThrow();
  });
});

describe("AuditOutputSchema", () => {
  it("aceita output mínimo com freeNotes default vazio", () => {
    const parsed = AuditOutputSchema.parse({
      findings: [],
      oneLineVerdict: "bot foi ok",
    });
    expect(parsed.freeNotes).toBe("");
  });

  it("rejeita output sem oneLineVerdict", () => {
    expect(() =>
      AuditOutputSchema.parse({ findings: [], freeNotes: "x" }),
    ).toThrow();
  });
});
