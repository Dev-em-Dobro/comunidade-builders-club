import Anthropic from "@anthropic-ai/sdk";
import type { LLMProvider, LLMRequest, LLMResponse } from "./types";

let client: Anthropic | null = null;

/**
 * Client Anthropic. Se `overrideKey` vier (BYOK), constrói um client dedicado
 * (sem cachear). Sem override, usa o singleton via ANTHROPIC_API_KEY.
 */
function getClient(overrideKey?: string): Anthropic {
  if (overrideKey) {
    return new Anthropic({ apiKey: overrideKey });
  }
  if (client) return client;
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error("ANTHROPIC_API_KEY ausente. Gerar em https://console.anthropic.com/settings/keys");
  }
  client = new Anthropic({ apiKey });
  return client;
}

// Pricing público USD/MTok — atualizar a cada release.
// cached = leitura de cache (prompt caching).
const PRICING: Record<string, { in: number; out: number; cached: number }> = {
  "claude-fable-5-2":  { in: 8.0,  out: 40.0, cached: 0.2 },
  "claude-opus-5-5":   { in: 4.0,  out: 20.0, cached: 0.2 },
  "claude-opus-5":     { in: 5.0,  out: 25.0, cached: 0.5 },
  "claude-opus-4-8":   { in: 5.0,  out: 25.0, cached: 0.5 },
  "claude-opus-4-7":   { in: 5.0,  out: 25.0, cached: 0.5 },
  "claude-sonnet-5-5": { in: 2.0,  out: 10.0, cached: 0.1 },
  "claude-sonnet-5":   { in: 2.0,  out: 10.0, cached: 0.2 },
  "claude-sonnet-4-6": { in: 3.0,  out: 15.0, cached: 0.3 },
  "claude-haiku-5-5":  { in: 0.1,  out: 0.5,  cached: 0.01 },
  "claude-haiku-4-5":  { in: 1.0,  out: 5.0,  cached: 0.1 },
};

/**
 * Só os modelos anteriores ao Opus 4.7 aceitam temperature customizada. Do
 * Opus 4.7 em diante (Opus 4.8/5/5.5, Sonnet 5/5.5, Haiku 5.5, Fable) mandar
 * temperature dá 400 — então a regra é por lista de quem ACEITA, pra modelo
 * novo nunca quebrar o agente (incidente 2026-11-14, gpt-5 na OpenAI).
 */
export function acceptsTemperature(model: string): boolean {
  return /^claude-(3|(opus|sonnet|haiku)-(3|4(-[0-6])?(-\d{8})?$))/.test(model);
}

/** 400 por parâmetro recusado → qual parâmetro tirar na nova tentativa. */
export function rejectedParam(err: unknown): "temperature" | "tool_choice" | null {
  if (!(err instanceof Anthropic.BadRequestError)) return null;
  const message = String(err.message ?? "");
  if (/temperature|top_p|top_k|sampling/i.test(message)) return "temperature";
  if (/tool_choice/i.test(message)) return "tool_choice";
  return null;
}

function estimateCost(model: string, tokensIn: number, tokensOut: number, cached: number): number | undefined {
  const p = PRICING[model];
  if (!p) return undefined;
  const fresh = Math.max(0, tokensIn - cached);
  const usd = (fresh * p.in + cached * p.cached + tokensOut * p.out) / 1_000_000;
  return Number(usd.toFixed(6));
}

export const anthropicProvider: LLMProvider = {
  id: "anthropic",

  async generateReply(req: LLMRequest): Promise<LLMResponse> {
    const c = getClient(req.apiKey);
    const system: Anthropic.Messages.TextBlockParam[] = [
      {
        type: "text",
        text: req.systemStatic,
        // Prompt caching obrigatório pra system >1024 tokens (90% economia em chamadas repetidas)
        cache_control: { type: "ephemeral" },
      },
    ];
    if (req.systemDynamic) {
      system.push({ type: "text", text: req.systemDynamic });
    }

    const messages: Anthropic.Messages.MessageParam[] = req.messages
      .filter((m) => m.role === "user" || m.role === "assistant" || m.role === "tool")
      .map((m): Anthropic.Messages.MessageParam => {
        if (m.role === "assistant" && m.toolUse) {
          const blocks: Anthropic.Messages.ContentBlockParam[] = [];
          if (m.content && m.content.length > 0) {
            blocks.push({ type: "text", text: m.content });
          }
          blocks.push({
            type: "tool_use",
            id: m.toolUse.id,
            name: m.toolUse.name,
            input: m.toolUse.input,
          });
          return { role: "assistant", content: blocks };
        }
        if (m.role === "tool" && m.toolResult) {
          // A API Anthropic exige que tool_result fique dentro de um user turn.
          return {
            role: "user",
            content: [
              {
                type: "tool_result",
                tool_use_id: m.toolResult.toolUseId,
                content: m.toolResult.content,
              },
            ],
          };
        }
        // Tool turn sem toolResult é bug do caller — falha alto antes de
        // corromper a conversa com um user turn fora de sequência.
        if (m.role === "tool") {
          throw new Error("anthropic adapter: tool turn missing toolResult");
        }
        return {
          role: m.role === "assistant" ? "assistant" : "user",
          content: m.content,
        };
      });

    const tools = req.tools?.map((t) => ({
      name: t.name,
      description: t.description,
      input_schema: t.inputSchema,
    })) as Anthropic.Messages.Tool[] | undefined;

    const create = (opts: { temperature: boolean; toolChoice: Anthropic.Messages.ToolChoice | undefined }) =>
      c.messages.create({
        model: req.model,
        max_tokens: req.maxTokens ?? 1024,
        ...(opts.temperature ? { temperature: req.temperature ?? 0.7 } : {}),
        system,
        messages,
        ...(tools ? { tools } : {}),
        ...(opts.toolChoice ? { tool_choice: opts.toolChoice } : {}),
      });

    let opts = { temperature: acceptsTemperature(req.model), toolChoice: req.toolChoice as Anthropic.Messages.ToolChoice | undefined };
    let resp: Anthropic.Messages.Message;
    try {
      resp = await create(opts);
    } catch (err) {
      // Modelo com regra diferente: tira o parâmetro recusado e tenta 1x, em vez
      // de deixar o lead sem resposta. Forced tool_choice vira "auto".
      const param = rejectedParam(err);
      const retryable =
        (param === "temperature" && opts.temperature) || (param === "tool_choice" && opts.toolChoice?.type === "tool");
      if (!retryable) throw err;
      opts =
        param === "temperature"
          ? { ...opts, temperature: false }
          : { ...opts, toolChoice: { type: "auto" } };
      console.log(
        JSON.stringify({ event: "llm.anthropic.param_retry", model: req.model, dropped: param, at: new Date().toISOString() }),
      );
      resp = await create(opts);
    }

    const textBlocks = resp.content.filter(
      (b): b is Anthropic.Messages.TextBlock => b.type === "text",
    );
    const text = textBlocks.map((b) => b.text).join("\n").trim();

    const toolUses = resp.content
      .filter(
        (b): b is Anthropic.Messages.ToolUseBlock => b.type === "tool_use",
      )
      .map((b) => ({
        id: b.id,
        name: b.name,
        input: (b.input ?? {}) as Record<string, unknown>,
      }));

    const tokensIn = resp.usage.input_tokens ?? 0;
    const tokensOut = resp.usage.output_tokens ?? 0;
    const tokensCached = resp.usage.cache_read_input_tokens ?? 0;

    return {
      text,
      modelUsed: resp.model,
      tokensIn,
      tokensOut,
      tokensCached,
      costUsd: estimateCost(resp.model, tokensIn, tokensOut, tokensCached),
      toolUses: toolUses.length ? toolUses : undefined,
      raw: resp,
    };
  },
};
