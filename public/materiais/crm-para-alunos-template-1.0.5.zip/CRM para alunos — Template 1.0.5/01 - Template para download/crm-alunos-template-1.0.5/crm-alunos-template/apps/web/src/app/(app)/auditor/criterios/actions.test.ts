import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));
vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));

import { saveCriterion, toggleCriterionActive } from "./actions";
import { auth } from "@/auth";

const created: string[] = [];

function fd(fields: Record<string, string>): FormData {
  const f = new FormData();
  for (const [k, v] of Object.entries(fields)) f.set(k, v);
  return f;
}

const base = { name: "Critério teste", description: "Descrição teste", weight: "3" };

afterAll(async () => {
  if (created.length > 0) {
    await prisma.auditCriterion.deleteMany({ where: { id: { in: created } } });
  }
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "test-user" } } as never);
});

describe("saveCriterion (create)", () => {
  it("rejeita sem auth", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const r = await saveCriterion(fd(base));
    expect(r.error).toMatch(/sessão|login/i);
  });

  it("rejeita name vazio", async () => {
    const r = await saveCriterion(fd({ ...base, name: "" }));
    expect(r.error).toMatch(/nome/i);
  });

  it("rejeita weight inválido", async () => {
    const r = await saveCriterion(fd({ ...base, weight: "7" }));
    expect(r.error).toMatch(/peso/i);
  });

  it("cria criterion (active default true)", async () => {
    const name = `Criar via action ${Date.now()}`;
    await saveCriterion(fd({ ...base, name, active: "on" }));
    const c = await prisma.auditCriterion.findFirst({ where: { name } });
    expect(c).not.toBeNull();
    created.push(c!.id);
    expect(c!.active).toBe(true);
    expect(c!.weight).toBe(3);
  });

  it("cria com active=false quando checkbox desligado", async () => {
    const name = `Criar inativo ${Date.now()}`;
    // No <Switch>, omitir name=active na FormData = desligado (mesmo padrão do checkoutUrl)
    await saveCriterion(fd({ ...base, name }));
    const c = await prisma.auditCriterion.findFirst({ where: { name } });
    created.push(c!.id);
    expect(c!.active).toBe(false);
  });
});

describe("saveCriterion (update)", () => {
  it("atualiza criterion existente", async () => {
    const c = await prisma.auditCriterion.create({
      data: { name: `Update test ${Date.now()}`, description: "antes", weight: 2 },
    });
    created.push(c.id);
    await saveCriterion(
      fd({
        id: c.id,
        name: "Depois",
        description: "descrição nova",
        weight: "5",
        active: "on",
      }),
    );
    const after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after?.name).toBe("Depois");
    expect(after?.weight).toBe(5);
    expect(after?.active).toBe(true);
  });
});

describe("toggleCriterionActive", () => {
  it("alterna active de true pra false e vice-versa", async () => {
    const c = await prisma.auditCriterion.create({
      data: { name: `Toggle test ${Date.now()}`, description: "d", active: true },
    });
    created.push(c.id);
    const r1 = await toggleCriterionActive(c.id);
    expect(r1.ok).toBe(true);
    let after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after?.active).toBe(false);
    const r2 = await toggleCriterionActive(c.id);
    expect(r2.ok).toBe(true);
    after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after?.active).toBe(true);
  });

  it("retorna ok=false com erro quando id não existe (sem throw)", async () => {
    const r = await toggleCriterionActive("cmnonexistent00000");
    expect(r.ok).toBe(false);
    expect(r.error).toMatch(/encontrado/i);
  });

  it("retorna ok=false com erro de auth quando sessão expirou", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const r = await toggleCriterionActive("any-id");
    expect(r.ok).toBe(false);
    expect(r.error).toMatch(/sessão|login/i);
  });
});
