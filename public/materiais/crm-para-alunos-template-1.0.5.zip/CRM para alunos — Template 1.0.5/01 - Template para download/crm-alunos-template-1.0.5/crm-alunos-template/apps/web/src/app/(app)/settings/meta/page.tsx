import { auth } from "@/auth";
import Link from "next/link";
import { metaSettingsStatus } from "@/lib/settings/meta";
import { MetaForm } from "./meta-form";
import { clearMeta } from "./actions";
export const dynamic = "force-dynamic";
export default async function MetaSettingsPage() {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const status = await metaSettingsStatus();
  return <div className="p-6 md:p-8 max-w-3xl space-y-6">
    <header><h1 className="text-3xl font-semibold">Conectar seu Business</h1><p className="text-muted-foreground mt-2">Use os ativos e o aplicativo da sua própria conta Meta. O guia docs/META.md explica onde obter cada valor.</p></header>
    <p className="text-sm">O Facebook fornece a Página e o Business usados pela integração. Este CRM atende WhatsApp e Instagram Direct. Para Instagram, use o fluxo com Facebook Login e uma conta profissional vinculada a uma Página.</p>
    <p className="text-sm text-muted-foreground">Campos vazios preservam os valores atuais. Valores do painel têm precedência sobre variáveis do servidor e são guardados com criptografia. Tokens salvos não são devolvidos ao navegador.</p>
    <MetaForm status={status} />
    <Link className="underline block" href="/onboarding">Testar conexão e webhooks</Link><Link className="underline block" href="/settings">Ativar canais em Geral</Link>
    <details className="border rounded p-4 text-sm"><summary>Remover credenciais cadastradas no painel</summary><p className="my-3">Remove todos os valores Meta deste formulário. Se houver credenciais no ambiente do servidor, elas voltam a ser usadas. Para desconectar completamente, desative os canais e remova também as variáveis Meta do servidor.</p>
      <form action={clearMeta}><button type="submit" className="underline text-destructive">Remover valores Meta do painel</button></form>
    </details>
  </div>;
}
