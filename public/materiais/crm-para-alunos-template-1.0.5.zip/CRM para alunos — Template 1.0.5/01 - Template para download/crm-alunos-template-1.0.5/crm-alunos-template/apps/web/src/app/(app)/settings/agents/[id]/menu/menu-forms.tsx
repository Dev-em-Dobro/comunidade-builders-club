"use client";

import { useActionState, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save, Upload } from "lucide-react";
import { saveMenuItems, saveStoreSettings, type MenuFormState } from "./actions";

function Feedback({ state }: { state: MenuFormState }) {
  if (state.error) return <p className="text-sm text-destructive">{state.error}</p>;
  if (state.ok) return <p className="text-sm text-primary">{state.ok}</p>;
  return null;
}

export function StoreSettingsForm({
  agentId,
  initial,
}: {
  agentId: string;
  initial: { description: string; hours: string; pickupEnabled: boolean; pickupAddress: string; areasText: string };
}) {
  const [state, action, pending] = useActionState(saveStoreSettings.bind(null, agentId), {} as MenuFormState);
  return (
    <form action={action} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="description">Sobre o estabelecimento</Label>
        <Textarea
          id="description"
          name="description"
          rows={4}
          maxLength={2000}
          defaultValue={initial.description}
          placeholder="Hamburgueria artesanal desde 2015. Pão brioche feito na casa, carne de 180 g…"
        />
        <p className="text-xs text-muted-foreground">O agente usa este texto para apresentar o estabelecimento.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="hours">Horário de funcionamento</Label>
          <Input id="hours" name="hours" maxLength={200} defaultValue={initial.hours} placeholder="Ter a dom, 18h às 23h" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="pickupAddress">Endereço para retirada</Label>
          <Input id="pickupAddress" name="pickupAddress" maxLength={300} defaultValue={initial.pickupAddress} placeholder="Rua das Flores, 120 — Centro" />
        </div>
      </div>
      <div className="flex items-center justify-between gap-4 rounded-md border border-border p-3">
        <div>
          <Label htmlFor="pickupEnabled" className="text-sm">Aceita retirada no local</Label>
          <p className="text-xs text-muted-foreground">Desligado: o agente só oferece entrega.</p>
        </div>
        <Switch id="pickupEnabled" name="pickupEnabled" defaultChecked={initial.pickupEnabled} />
      </div>
      <div className="space-y-2">
        <Label htmlFor="areas">Bairros atendidos e taxa de entrega</Label>
        <Textarea
          id="areas"
          name="areas"
          rows={6}
          defaultValue={initial.areasText}
          placeholder={"Centro: 5,00\nJardim América: 7,50\nVila Nova: 0"}
          className="font-mono text-xs"
        />
        <p className="text-xs text-muted-foreground">
          Um bairro por linha, no formato <code>Bairro: 5,00</code>. Use 0 para entrega grátis. Fora da lista, o agente avisa
          que não entrega.
        </p>
      </div>
      <Feedback state={state} />
      <Button type="submit" disabled={pending}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Salvar
      </Button>
    </form>
  );
}

const MENU_MAX_MB = 8;

/**
 * Upload do cardápio por fetch numa rota de API (não server action): controle
 * total do envio e qualquer falha — inclusive de rede ou do servidor antes do
 * código do CRM — aparece na tela.
 */
export function MenuUploadForm({ agentId, hasMenu }: { agentId: string; hasMenu: boolean }) {
  const router = useRouter();
  const [state, setState] = useState<MenuFormState>({});
  const [pending, setPending] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const file = (form.elements.namedItem("file") as HTMLInputElement | null)?.files?.[0];
    if (!file) return setState({ error: "Escolha o arquivo do cardápio (PDF ou foto)." });
    if (file.size > MENU_MAX_MB * 1024 * 1024) {
      return setState({ error: `Arquivo de ${(file.size / 1024 / 1024).toFixed(1)} MB — o máximo é ${MENU_MAX_MB} MB.` });
    }
    setPending(true);
    setState({});
    try {
      const body = new FormData();
      body.append("file", file, file.name);
      const res = await fetch(`/api/agents/${agentId}/menu`, { method: "POST", body });
      const json = (await res.json().catch(() => null)) as { ok?: boolean; count?: number; error?: string } | null;
      if (!res.ok || !json?.ok) {
        setState({ error: json?.error ?? `O servidor recusou o envio (HTTP ${res.status}).` });
        return;
      }
      setState({ ok: `Cardápio lido: ${json.count} itens. Confira os preços abaixo.` });
      form.reset();
      router.refresh();
    } catch (err) {
      setState({ error: `Falha no envio: ${String((err as Error)?.message ?? err)}` });
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-3">
      <input
        name="file"
        type="file"
        accept="application/pdf,image/png,image/jpeg,image/webp"
        required
        disabled={pending}
        className="block w-full rounded-lg border border-input bg-transparent px-2.5 py-1.5 text-sm file:mr-3 file:rounded-md file:border-0 file:bg-muted file:px-3 file:py-1 file:text-sm file:font-medium file:text-foreground disabled:opacity-50 dark:bg-input/30"
      />
      <p className="text-xs text-muted-foreground">
        PDF ou foto do cardápio (até {MENU_MAX_MB} MB). A IA lê uma vez e guarda os itens com preço; o arquivo é o que o cliente
        recebe no WhatsApp. {hasMenu && "Subir de novo substitui o cardápio atual."}
      </p>
      <Feedback state={state} />
      <Button type="submit" disabled={pending}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
        {pending ? "A IA está lendo o cardápio… (até 1 minuto)" : "Enviar cardápio"}
      </Button>
    </form>
  );
}

export function MenuItemsForm({ agentId, initialText }: { agentId: string; initialText: string }) {
  const [state, action, pending] = useActionState(saveMenuItems.bind(null, agentId), {} as MenuFormState);
  return (
    <form action={action} className="space-y-3">
      <Textarea name="items" rows={12} defaultValue={initialText} className="font-mono text-xs" />
      <p className="text-xs text-muted-foreground">
        Um item por linha: <code>Categoria | Nome | 25,90 | descrição</code> (descrição opcional). Os preços daqui são os que o
        agente cobra.
      </p>
      <Feedback state={state} />
      <Button type="submit" variant="outline" disabled={pending}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Salvar correções
      </Button>
    </form>
  );
}
