"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import {
  CriterionInputSchema,
  CriterionPatchSchema,
  criterionFromFormData,
  firstZodError,
} from "@/lib/audit/criterion-schema";

export interface CriterionFormState {
  ok?: boolean;
  error?: string;
}

export interface ToggleResult {
  ok: boolean;
  error?: string;
}

const AUTH_ERROR = "Sessão expirada — faça login de novo";

/**
 * Cria ou atualiza um AuditCriterion. Update se FormData tem `id`, senão
 * create. Usa o mesmo schema Zod do API REST — diferença é só extração de
 * FormData vs JSON.
 */
export async function saveCriterion(
  formData: FormData,
): Promise<CriterionFormState> {
  const session = await auth();
  if (!session?.user?.id) return { error: AUTH_ERROR };

  const { id, payload } = criterionFromFormData(formData);

  if (id) {
    const parsed = CriterionPatchSchema.safeParse(payload);
    if (!parsed.success) return { error: firstZodError(parsed.error) };
    try {
      await prisma.auditCriterion.update({
        where: { id },
        data: parsed.data,
      });
    } catch (err) {
      return { error: String((err as Error)?.message ?? err) };
    }
  } else {
    const parsed = CriterionInputSchema.safeParse(payload);
    if (!parsed.success) return { error: firstZodError(parsed.error) };
    try {
      await prisma.auditCriterion.create({ data: parsed.data });
    } catch (err) {
      return { error: String((err as Error)?.message ?? err) };
    }
  }

  revalidatePath("/auditor/criterios");
  return { ok: true };
}

/**
 * Alterna `active` do criterion de forma atômica via UPDATE … SET active =
 * NOT active. Sem TOCTOU window entre leitura e escrita (M3).
 *
 * Retorna { ok, error? } pra UI poder mostrar toast quando sessão expirou —
 * antes era void e falhava em silêncio (M2/M6).
 */
export async function toggleCriterionActive(id: string): Promise<ToggleResult> {
  const session = await auth();
  if (!session?.user?.id) return { ok: false, error: AUTH_ERROR };

  const affected = await prisma.$executeRaw`
    UPDATE "AuditCriterion" SET active = NOT active WHERE id = ${id}
  `;
  if (affected === 0) return { ok: false, error: "Critério não encontrado" };

  revalidatePath("/auditor/criterios");
  return { ok: true };
}
