import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, ChevronLeft, ChevronRight, MessagesSquare } from "lucide-react";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 25;

export default async function SurveyDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ name: string }>;
  searchParams: Promise<{ page?: string }>;
}) {
  const { name: rawName } = await params;
  const surveyName = decodeURIComponent(rawName);

  const total = await prisma.surveyResponse.count({ where: { surveyName } });
  if (total === 0) notFound();

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const { page: rawPage } = await searchParams;
  const parsedPage = Number.parseInt(rawPage ?? "1", 10);
  const page = Number.isFinite(parsedPage)
    ? Math.min(Math.max(parsedPage, 1), totalPages)
    : 1;

  const responses = await prisma.surveyResponse.findMany({
    where: { surveyName },
    orderBy: { createdAt: "desc" },
    skip: (page - 1) * PAGE_SIZE,
    take: PAGE_SIZE,
    include: {
      contact: {
        include: {
          identities: { where: { channel: "whatsapp_cloud" }, take: 1 },
          conversations: {
            orderBy: { lastMessageAt: { sort: "desc", nulls: "last" } },
            take: 1,
            select: { id: true },
          },
        },
      },
    },
  });

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6">
        <Link
          href="/surveys"
          className={buttonVariants({ variant: "ghost", size: "sm", className: "mb-3 -ml-3" })}
        >
          <ArrowLeft className="size-4" />
          voltar pra pesquisas
        </Link>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          {surveyName}
        </h1>
        <p className="text-muted-foreground mt-1 text-sm">
          {total} resposta{total !== 1 ? "s" : ""}{" "}
          {total !== 1 ? "registradas" : "registrada"}.
        </p>
      </header>

      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Contato</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>WhatsApp</TableHead>
              <TableHead>Respondida em</TableHead>
              <TableHead className="text-right">Conversa</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {responses.map((r) => {
              const phone = r.contact.identities[0]?.externalId ?? null;
              const conv = r.contact.conversations[0];
              const displayName =
                r.contact.displayName ?? r.contact.email ?? phone ?? "—";
              const ts = (r.submittedAt ?? r.createdAt).toISOString();
              return (
                <TableRow key={r.id}>
                  <TableCell className="font-medium">{displayName}</TableCell>
                  <TableCell className="font-mono text-xs">
                    {r.contact.email ?? (
                      <span className="text-muted-foreground/60">—</span>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    {phone ?? (
                      <span className="text-muted-foreground/60">—</span>
                    )}
                  </TableCell>
                  <TableCell className="font-mono text-xs">
                    {ts.slice(0, 16).replace("T", " ")}
                  </TableCell>
                  <TableCell className="text-right">
                    {conv ? (
                      <Link
                        href={`/conversations/${conv.id}`}
                        className="inline-flex"
                      >
                        <Badge variant="outline" className="gap-1 text-[10px]">
                          <MessagesSquare className="size-3" />
                          abrir
                        </Badge>
                      </Link>
                    ) : (
                      <span className="text-muted-foreground/60 text-xs">
                        sem conversa
                      </span>
                    )}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Card>

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            Página {page} de {totalPages}
          </span>
          <div className="flex items-center gap-2">
            {page > 1 ? (
              <Link
                href={`/surveys/${rawName}?page=${page - 1}`}
                scroll={false}
                className={buttonVariants({ variant: "outline", size: "sm" })}
              >
                <ChevronLeft className="size-4" /> Anterior
              </Link>
            ) : (
              <span
                aria-disabled
                className={`${buttonVariants({ variant: "outline", size: "sm" })} pointer-events-none opacity-40`}
              >
                <ChevronLeft className="size-4" /> Anterior
              </span>
            )}
            {page < totalPages ? (
              <Link
                href={`/surveys/${rawName}?page=${page + 1}`}
                scroll={false}
                className={buttonVariants({ variant: "outline", size: "sm" })}
              >
                Próxima <ChevronRight className="size-4" />
              </Link>
            ) : (
              <span
                aria-disabled
                className={`${buttonVariants({ variant: "outline", size: "sm" })} pointer-events-none opacity-40`}
              >
                Próxima <ChevronRight className="size-4" />
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
