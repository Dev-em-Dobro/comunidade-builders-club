import { Suspense } from "react";
import { prisma } from "@/lib/db";
import { DashboardControls } from "./_components/dashboard-controls";
import { SectionSkeleton } from "./_components/skeletons";
import { FunnelSection } from "./_components/funnel-section";
import { SlaSection } from "./_components/sla-section";
import { WindowSection } from "./_components/window-section";
import { ConversionsSection } from "./_components/conversions-section";
import { CostSection } from "./_components/cost-section";
import { AttentionSection } from "./_components/attention-section";
import { HumanQueueSection } from "./_components/human-queue-section";
import { ObjectionsSection } from "./_components/objections-section";

export const dynamic = "force-dynamic";

const RANGES = new Set(["7", "30", "90"]);

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ launch?: string; range?: string }>;
}) {
  const { launch: rawLaunch, range: rawRange } = await searchParams;
  const launch = rawLaunch && rawLaunch.length > 0 ? rawLaunch : "all";
  const range = rawRange && RANGES.has(rawRange) ? rawRange : "30";
  const rangeDays = Number(range);

  let launches: { id: string; name: string }[] = [];
  try {
    launches = await prisma.launch.findMany({
      select: { id: true, name: true },
      orderBy: { createdAt: "desc" },
    });
  } catch {
    launches = [];
  }

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Funil de conversão · últimos {rangeDays} dias
          </p>
        </div>
        <DashboardControls
          launches={launches}
          launch={launch}
          range={range}
        />
      </header>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-2">
          <Suspense
            key={`funnel:${launch}`}
            fallback={<SectionSkeleton height={300} />}
          >
            <FunnelSection launch={launch} />
          </Suspense>
        </div>
        <div className="flex flex-col gap-4">
          <Suspense fallback={<SectionSkeleton height={70} />}>
            <SlaSection />
          </Suspense>
          <Suspense fallback={<SectionSkeleton height={160} />}>
            <WindowSection />
          </Suspense>
        </div>

        <div className="md:col-span-2">
          <Suspense
            key={`conv:${range}`}
            fallback={<SectionSkeleton height={220} />}
          >
            <ConversionsSection rangeDays={rangeDays} />
          </Suspense>
        </div>
        <Suspense
          key={`cost:${range}`}
          fallback={<SectionSkeleton height={90} />}
        >
          <CostSection rangeDays={rangeDays} />
        </Suspense>

        <div className="md:col-span-2">
          <Suspense fallback={<SectionSkeleton height={140} />}>
            <AttentionSection />
          </Suspense>
        </div>
        <Suspense fallback={<SectionSkeleton height={140} />}>
          <HumanQueueSection />
        </Suspense>

        <Suspense
          key={`obj:${range}:${launch}`}
          fallback={<SectionSkeleton height={140} />}
        >
          <ObjectionsSection rangeDays={rangeDays} launch={launch} />
        </Suspense>
      </div>
    </div>
  );
}
