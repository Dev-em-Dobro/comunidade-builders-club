import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import {
  CRITERION_PUBLIC_SELECT,
  CriterionInputSchema,
  firstZodError,
} from "@/lib/audit/criterion-schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const criteria = await prisma.auditCriterion.findMany({
    orderBy: [{ weight: "desc" }, { name: "asc" }],
    select: CRITERION_PUBLIC_SELECT,
  });
  return NextResponse.json({ criteria });
}

export async function POST(req: Request): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const raw = await req.json().catch(() => null);
  const parsed = CriterionInputSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: firstZodError(parsed.error) },
      { status: 400 },
    );
  }
  const criterion = await prisma.auditCriterion.create({
    data: parsed.data,
    select: CRITERION_PUBLIC_SELECT,
  });
  return NextResponse.json({ criterion }, { status: 201 });
}
