import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { normalizePhoneToE164 } from "@/lib/phone";
import { matchContact } from "./match-contact";

export interface FindOrCreateInput {
  phoneRaw: string | null;
  emailRaw: string | null;
}

export interface FindOrCreateResult {
  contactId: string | null;
  /** true = um novo Contact foi criado. false = match com existente ou skip. */
  created: boolean;
  /** "phone"/"email" = match; "created" = novo; null = não pôde resolver. */
  via: "phone" | "email" | "created" | null;
}

/**
 * Acha um Contact por phone/email; se não casar, cria um novo.
 * Decisão #4 da Parte 12-D (revisada em 2026-05-23): pesquisa enriquece
 * funil mesmo quando o lead ainda não mandou WhatsApp.
 *
 * Edge cases:
 *  - Phone com 10-11 dígitos é guardado COM DDI 55 (padrão E.164 do projeto).
 *  - Sem email válido e sem phone normalizável → contactId=null, via=null.
 *  - Race com outra linha do mesmo CSV (P2002) → refaz match e devolve a row.
 */
export async function findOrCreateContact(
  input: FindOrCreateInput,
): Promise<FindOrCreateResult> {
  const match = await matchContact(input);
  if (match.contactId) {
    return { contactId: match.contactId, created: false, via: match.via };
  }

  // Normaliza pra criar com valores limpos
  let phone = input.phoneRaw ? normalizePhoneToE164(input.phoneRaw) : null;
  if (phone && (phone.length === 10 || phone.length === 11)) {
    phone = `55${phone}`;
  }
  const normEmail = input.emailRaw?.trim().toLowerCase();
  const email = normEmail && normEmail.includes("@") ? normEmail : null;

  if (!phone && !email) {
    return { contactId: null, created: false, via: null };
  }

  try {
    const contact = await prisma.contact.create({
      data: {
        displayName: email ?? phone ?? null,
        email: email ?? undefined,
        identities: phone
          ? { create: { channel: "whatsapp_cloud", externalId: phone } }
          : undefined,
      },
    });
    return { contactId: contact.id, created: true, via: "created" };
  } catch (err) {
    // P2002 = race com outra linha do mesmo CSV. Refaz match.
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      err.code === "P2002"
    ) {
      const retry = await matchContact(input);
      if (retry.contactId) {
        return { contactId: retry.contactId, created: false, via: retry.via };
      }
    }
    throw err;
  }
}
