"use client";

import { useDroppable } from "@dnd-kit/core";
import type { ColumnId } from "@/lib/pipeline/columns";
import { COLUMN_LABEL } from "@/lib/pipeline/columns";
import { DraggableLead } from "./pipeline-board";
import type { LeadView } from "./types";

interface Props {
  id: ColumnId;
  leads: LeadView[];
}

export function Column({ id, leads }: Props) {
  const { isOver, setNodeRef } = useDroppable({ id });
  const showStageBadge = id === "f1" || id === "f2" || id === "f3";

  return (
    <div
      ref={setNodeRef}
      className={`min-w-[260px] w-[260px] flex flex-col gap-2 p-2 rounded-md border ${
        isOver ? "border-primary bg-primary/5" : "border-border bg-muted/20"
      }`}
    >
      <div className="flex items-center justify-between px-1">
        <h2 className="text-sm font-medium">{COLUMN_LABEL[id]}</h2>
        <span className="text-xs text-muted-foreground font-mono">
          {leads.length}
        </span>
      </div>
      <div className="flex flex-col gap-2 min-h-[100px] overflow-y-auto">
        {leads.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-4">
            Vazio
          </p>
        )}
        {leads.map((lead) => (
          <DraggableLead
            key={lead.id}
            lead={lead}
            showStageBadge={showStageBadge}
          />
        ))}
      </div>
    </div>
  );
}
