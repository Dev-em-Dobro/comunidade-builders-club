-- AlterTable
ALTER TABLE "Launch" ADD COLUMN     "bonuses" JSONB NOT NULL DEFAULT '[]',
ADD COLUMN     "courseId" TEXT,
ADD COLUMN     "guaranteePolicyOverride" TEXT,
ADD COLUMN     "paymentMethodsOverride" TEXT,
ADD COLUMN     "pitchAngle" TEXT;

-- AlterTable
ALTER TABLE "ShortLink" ADD COLUMN     "launchPlanId" TEXT;

-- CreateTable
CREATE TABLE "LaunchPlan" (
    "id" TEXT NOT NULL,
    "launchId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "priceCents" INTEGER NOT NULL,
    "checkoutUrl" TEXT,
    "description" TEXT,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LaunchPlan_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LaunchStatusChange" (
    "id" TEXT NOT NULL,
    "launchId" TEXT NOT NULL,
    "fromStatus" TEXT NOT NULL,
    "toStatus" TEXT NOT NULL,
    "byUserId" TEXT,
    "reason" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LaunchStatusChange_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "LaunchPlan_launchId_sortOrder_idx" ON "LaunchPlan"("launchId", "sortOrder");

-- CreateIndex
CREATE INDEX "LaunchStatusChange_launchId_createdAt_idx" ON "LaunchStatusChange"("launchId", "createdAt");

-- CreateIndex
CREATE INDEX "Launch_courseId_status_startsAt_endsAt_idx" ON "Launch"("courseId", "status", "startsAt", "endsAt");

-- AddForeignKey
ALTER TABLE "Launch" ADD CONSTRAINT "Launch_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "Course"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LaunchPlan" ADD CONSTRAINT "LaunchPlan_launchId_fkey" FOREIGN KEY ("launchId") REFERENCES "Launch"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LaunchStatusChange" ADD CONSTRAINT "LaunchStatusChange_launchId_fkey" FOREIGN KEY ("launchId") REFERENCES "Launch"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LaunchStatusChange" ADD CONSTRAINT "LaunchStatusChange_byUserId_fkey" FOREIGN KEY ("byUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ShortLink" ADD CONSTRAINT "ShortLink_launchPlanId_fkey" FOREIGN KEY ("launchPlanId") REFERENCES "LaunchPlan"("id") ON DELETE SET NULL ON UPDATE CASCADE;
