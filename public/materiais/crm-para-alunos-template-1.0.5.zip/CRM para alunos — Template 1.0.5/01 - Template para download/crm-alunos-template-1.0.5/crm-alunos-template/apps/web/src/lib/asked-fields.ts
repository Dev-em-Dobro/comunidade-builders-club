/**
 * Tracking estruturado das 4 perguntas de qualificação que o bot deve fazer.
 *
 * Persistido em `Lead.qualification.askedFields` (JSON, sem migration).
 * Populado pelo classifier (qualification.ts) e lido pelo bot via
 * buildLeadContextBlock (context-blocks.ts).
 *
 * Invariantes de merge:
 * - `askedAt` jamais regride: uma vez populado, fica.
 * - `answeredAt`/`answer` só são preenchidos quando antes estavam vazios.
 * - Classifier omitindo um campo (fora da window) ⇒ preserve o que tinha.
 */

// 4 campos que o SDR coleta antes de passar pro closer. Nome e email NÃO
// estão aqui — o closer pode pegar depois se precisar; pedir esses dados
// no SDR confundia o LLM (interpretava como "tô pronto pra fechar" e
// chamava CTA tool ou request_handoff por iniciativa).
export const QUAL_FIELDS = [
  "objetivo",
  "nivel",
  "urgencia",
  "tempo_disponivel",
] as const;

export type QualField = (typeof QUAL_FIELDS)[number];

export interface AskedField {
  askedAt: string;          // ISO; obrigatório uma vez populado
  answeredAt?: string;      // ISO; ausente se ainda sem resposta
  answer?: string;          // texto curto (truncado em 80 chars)
}

export type AskedFieldsMap = Partial<Record<QualField, AskedField>>;

/**
 * Renderiza o checklist das 4 perguntas para injetar no prompt do bot.
 * O bot lê isto e decide qual perguntar a seguir (sem repetir).
 *
 * Formato:
 *   [ ] field — NÃO PERGUNTADA AINDA
 *   [!] field — PERGUNTADA EM {iso}. SEM RESPOSTA ainda. NÃO REPERGUNTAR.
 *   [x] field — respondido: "{answer truncado em 80}"
 */
export function renderQualChecklist(asked: AskedFieldsMap | undefined): string {
  const lines: string[] = [
    "# Perguntas de qualificação (estado atual)",
    "Use isto pra decidir qual perguntar a seguir. NUNCA pergunte de novo o que já está marcado [x] ou [!].",
    "",
  ];
  for (const field of QUAL_FIELDS) {
    const f = asked?.[field];
    if (!f) {
      lines.push(`[ ] ${field} — NÃO PERGUNTADA AINDA`);
    } else if (f.answeredAt) {
      const ans = (f.answer ?? "").slice(0, 80);
      lines.push(`[x] ${field} — respondido: "${ans}"`);
    } else {
      lines.push(
        `[!] ${field} — PERGUNTADA EM ${f.askedAt}. SEM RESPOSTA ainda. NÃO REPERGUNTAR.`,
      );
    }
  }
  const pending = QUAL_FIELDS.find((f) => !asked?.[f]);
  if (pending) {
    lines.push("", `Próxima a perguntar: ${pending}.`);
  } else {
    lines.push("", "Todas as 4 perguntas já foram feitas. Foque em fechamento.");
  }
  return lines.join("\n");
}

export function mergeAskedFields(
  old: AskedFieldsMap | undefined,
  fresh: AskedFieldsMap | undefined,
): AskedFieldsMap | undefined {
  if (!old && !fresh) return undefined;
  const merged: AskedFieldsMap = { ...(old ?? {}) };
  for (const field of QUAL_FIELDS) {
    const o = old?.[field];
    const n = fresh?.[field];
    if (!o && !n) continue;
    if (!o && n) {
      merged[field] = n;
      continue;
    }
    if (o && !n) {
      // classifier não viu (pode estar fora da window): preserve
      merged[field] = o;
      continue;
    }
    // ambos existem: preserve askedAt antigo, atualiza answer só se vazio antes
    merged[field] = {
      askedAt: o!.askedAt,
      answeredAt: o!.answeredAt ?? n!.answeredAt,
      answer: o!.answer ?? n!.answer,
    };
  }
  return Object.keys(merged).length > 0 ? merged : undefined;
}
