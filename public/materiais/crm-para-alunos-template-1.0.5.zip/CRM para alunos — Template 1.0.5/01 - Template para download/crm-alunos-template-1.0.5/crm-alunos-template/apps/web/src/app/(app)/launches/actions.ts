"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { auth } from "@/auth";
import { activateLaunch as libActivate, closeLaunch as libClose } from "@/lib/launches/transitions";
import { BonusesSchema } from "@/lib/launches/types";

export interface LaunchFormState {
  ok?: boolean;
  error?: string;
}

async function ensureAdmin(): Promise<{ ok: true; userId: string | null } | { ok: false; error: string }> {
  const session = await auth();
  const role = (session?.user as { role?: string } | undefined)?.role;
  if (role !== "admin") {
    return { ok: false, error: "Sem permissão. Apenas admins podem alterar lançamentos." };
  }
  const userId = (session?.user as { id?: string } | undefined)?.id ?? null;
  return { ok: true, userId };
}

const SLUG_RE = /^[a-z0-9-]+$/;
const STATUSES = ["planned", "live", "closed"];

/** Cria ou atualiza um Lançamento. Validação antes de qualquer escrita. */
export async function saveLaunch(formData: FormData): Promise<LaunchFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const id = formData.get("id") as string | null;
  const name = String(formData.get("name") ?? "").trim();
  const slug = String(formData.get("slug") ?? "").trim().toLowerCase();
  const startsAt = String(formData.get("startsAt") ?? "").trim();
  const endsAt = String(formData.get("endsAt") ?? "").trim();
  const status = String(formData.get("status") ?? "planned").trim();

  if (!name) return { error: "Nome obrigatório" };
  if (!SLUG_RE.test(slug)) {
    return { error: "Slug inválido — só letras minúsculas, números e hífen" };
  }
  if (!startsAt || !endsAt) return { error: "Datas de início e fim obrigatórias" };
  const start = new Date(startsAt);
  const end = new Date(endsAt);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime())) {
    return { error: "Datas inválidas" };
  }
  if (end < start) return { error: "Data de fim antes do início" };
  if (!STATUSES.includes(status)) return { error: "Status inválido" };

  const courseIdRaw = String(formData.get("courseId") ?? "").trim();
  const courseId = courseIdRaw.length > 0 && courseIdRaw !== "__none__" ? courseIdRaw : null;
  const pitchAngleRaw = String(formData.get("pitchAngle") ?? "").trim();
  const pitchAngle = pitchAngleRaw.length > 0 ? pitchAngleRaw : null;
  const paymentMethodsOverrideRaw = String(formData.get("paymentMethodsOverride") ?? "").trim();
  const paymentMethodsOverride = paymentMethodsOverrideRaw.length > 0 ? paymentMethodsOverrideRaw : null;
  const guaranteePolicyOverrideRaw = String(formData.get("guaranteePolicyOverride") ?? "").trim();
  const guaranteePolicyOverride = guaranteePolicyOverrideRaw.length > 0 ? guaranteePolicyOverrideRaw : null;

  // bonuses: vem como JSON string. Default '[]' se vazio.
  const bonusesRaw = String(formData.get("bonuses") ?? "[]").trim();
  let bonuses: { title: string; description: string }[] = [];
  if (bonusesRaw.length > 0) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(bonusesRaw);
    } catch {
      return { error: "Bônus em formato inválido (JSON)" };
    }
    const result = BonusesSchema.safeParse(parsed);
    if (!result.success) {
      const msg = result.error.issues?.[0]?.message ?? result.error.message ?? "formato inválido";
      return { error: "Bônus inválidos: " + msg };
    }
    bonuses = result.data;
  }

  try {
    if (id) {
      await prisma.launch.update({
        where: { id },
        data: { name, slug, startsAt: start, endsAt: end, status, courseId, pitchAngle, bonuses, paymentMethodsOverride, guaranteePolicyOverride },
      });
    } else {
      await prisma.launch.create({
        data: { name, slug, startsAt: start, endsAt: end, status, courseId, pitchAngle, bonuses, paymentMethodsOverride, guaranteePolicyOverride },
      });
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }

  revalidatePath("/launches");
  redirect("/launches");
}

/** Remove um Lançamento. Leads vinculados ficam com launchId = null. */
export async function deleteLaunch(id: string): Promise<void> {
  const gate = await ensureAdmin();
  if (!gate.ok) {
    redirect("/launches");
    return;
  }
  await prisma.launch.delete({ where: { id } }).catch(() => {});
  revalidatePath("/launches");
  redirect("/launches");
}

export async function activateLaunchAction(launchId: string): Promise<LaunchFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const r = await libActivate({ launchId, byUserId: gate.userId, reason: "manual" });
  if ("error" in r && r.error) return { error: r.error };
  revalidatePath(`/launches/${launchId}`);
  revalidatePath("/launches");
  return { ok: true };
}

export async function closeLaunchAction(launchId: string): Promise<LaunchFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const r = await libClose({ launchId, byUserId: gate.userId, reason: "manual" });
  if ("error" in r && r.error) return { error: r.error };
  revalidatePath(`/launches/${launchId}`);
  revalidatePath("/launches");
  return { ok: true };
}

const PlanInputSchema = z.object({
  id: z.string().optional(),
  name: z.string().min(1, "Nome do plano obrigatório"),
  priceCents: z.number().int().nonnegative("Preço inválido"),
  checkoutUrl: z
    .union([z.string().url("URL inválida"), z.literal("").transform(() => null)])
    .nullable(),
  description: z.string().nullable().optional(),
  sortOrder: z.number().int().nonnegative(),
});

export type PlanInput = z.input<typeof PlanInputSchema>;

/**
 * Cria ou atualiza um LaunchPlan. Se o lançamento tá live e o operador tenta
 * salvar plano sem checkoutUrl, salva mesmo assim — o bot dispara handoff em
 * runtime se o plano for escolhido. Validação semântica é responsabilidade do
 * fluxo de ativação (Task 10).
 */
export async function savePlan(
  launchId: string,
  raw: unknown,
): Promise<LaunchFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const parsed = PlanInputSchema.safeParse(raw);
  if (!parsed.success) {
    const msg = parsed.error.issues?.[0]?.message ?? "Plano inválido";
    return { error: msg };
  }
  const data = parsed.data;

  try {
    if (data.id) {
      await prisma.launchPlan.update({
        where: { id: data.id },
        data: {
          name: data.name,
          priceCents: data.priceCents,
          checkoutUrl: data.checkoutUrl,
          description: data.description ?? null,
          sortOrder: data.sortOrder,
        },
      });
    } else {
      await prisma.launchPlan.create({
        data: {
          launchId,
          name: data.name,
          priceCents: data.priceCents,
          checkoutUrl: data.checkoutUrl,
          description: data.description ?? null,
          sortOrder: data.sortOrder,
        },
      });
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }

  revalidatePath(`/launches/${launchId}`);
  return { ok: true };
}

/**
 * Remove um LaunchPlan. Bloqueia remoção do último plano se o lançamento
 * estiver live (sem plano, oferta vira inválida em runtime e bot pode quebrar).
 */
export async function deletePlan(
  launchId: string,
  planId: string,
): Promise<LaunchFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const launch = await prisma.launch.findUnique({
    where: { id: launchId },
    select: { status: true, plans: { select: { id: true } } },
  });
  if (!launch) return { error: "Lançamento não encontrado" };
  if (launch.status === "live" && launch.plans.length <= 1) {
    return {
      error: "Não dá pra remover o último plano de um lançamento live. Encerre antes.",
    };
  }
  await prisma.launchPlan.delete({ where: { id: planId } });
  revalidatePath(`/launches/${launchId}`);
  return { ok: true };
}
