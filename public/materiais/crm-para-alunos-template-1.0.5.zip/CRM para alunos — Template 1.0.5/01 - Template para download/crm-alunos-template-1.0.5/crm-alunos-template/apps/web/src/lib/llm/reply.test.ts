import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("./index", () => ({ generateReply: vi.fn() }));
vi.mock("./keys", () => ({ resolveProviderKey: vi.fn() }));

import { generateReply } from "./index";
import { resolveProviderKey } from "./keys";
import { generateReplyWithKey } from "./reply";

const genMock = generateReply as unknown as ReturnType<typeof vi.fn>;
const resolveMock = resolveProviderKey as unknown as ReturnType<typeof vi.fn>;

beforeEach(() => {
  genMock.mockReset();
  resolveMock.mockReset();
});

describe("generateReplyWithKey", () => {
  it("resolve a chave do provider e injeta como apiKey no request", async () => {
    resolveMock.mockResolvedValue("sk-resolved");
    genMock.mockResolvedValue({ text: "ok" });

    await generateReplyWithKey("openai", {
      model: "gpt-5-mini",
      systemStatic: "s",
      messages: [{ role: "user", content: "oi" }],
    });

    expect(resolveMock).toHaveBeenCalledWith("openai");
    expect(genMock).toHaveBeenCalledWith(
      "openai",
      expect.objectContaining({ model: "gpt-5-mini", apiKey: "sk-resolved" }),
    );
  });

  it("passa apiKey undefined quando o provider não tem chave", async () => {
    resolveMock.mockResolvedValue(undefined);
    genMock.mockResolvedValue({ text: "ok" });

    await generateReplyWithKey("anthropic", { model: "claude-sonnet-4-6", systemStatic: "s", messages: [] });

    expect(genMock).toHaveBeenCalledWith(
      "anthropic",
      expect.objectContaining({ apiKey: undefined }),
    );
  });
});
