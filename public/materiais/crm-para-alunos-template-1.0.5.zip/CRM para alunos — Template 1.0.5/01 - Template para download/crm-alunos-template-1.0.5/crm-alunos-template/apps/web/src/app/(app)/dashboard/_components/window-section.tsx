import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { pct } from "../metrics";
import { WindowGauge } from "./charts";

const FOUR_HOURS_MS = 4 * 60 * 60 * 1000;

interface WindowData {
  total: number;
  healthy: number;
  error: boolean;
}

async function getWindow(): Promise<WindowData> {
  try {
    const now = new Date();
    const healthyThreshold = new Date(now.getTime() + FOUR_HOURS_MS);
    const [total, healthy] = await Promise.all([
      prisma.conversation.count({ where: { windowClosesAt: { gt: now } } }),
      prisma.conversation.count({
        where: { windowClosesAt: { gt: healthyThreshold } },
      }),
    ]);
    return { total, healthy, error: false };
  } catch {
    return { total: 0, healthy: 0, error: true };
  }
}

export async function WindowSection() {
  const { total, healthy, error } = await getWindow();
  const healthyPct = pct(healthy, total);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Saúde da janela 24h</CardTitle>
        <CardDescription>Conversas com &gt;4h de janela</CardDescription>
      </CardHeader>
      <CardContent>
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : (
          <div className="flex flex-col items-center">
            <WindowGauge pct={healthyPct} />
            <p className="-mt-4 text-sm text-muted-foreground">
              {healthyPct === null
                ? "—"
                : `${healthyPct.toFixed(0)}% saudáveis`}{" "}
              <span className="font-mono">
                ({healthy}/{total})
              </span>
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
