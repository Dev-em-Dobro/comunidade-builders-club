"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { WEEKDAYS, formatDayIntervals, type WorkingHours } from "@/lib/scheduling/working-hours";
import { saveProfessional, type ProfessionalFormState } from "./actions";
import { Loader2, Save } from "lucide-react";

export interface InitialProfessional {
  id?: string;
  name?: string;
  specialty?: string | null;
  description?: string | null;
  durationMin?: number;
  active?: boolean;
  workingHours?: WorkingHours;
}

export function ProfessionalForm({ agentId, initial }: { agentId: string; initial?: InitialProfessional }) {
  const [state, action, pending] = useActionState<ProfessionalFormState, FormData>(
    async (_prev, formData) => saveProfessional(agentId, formData),
    {},
  );

  return (
    <form action={action} className="space-y-6 max-w-2xl">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">Nome</Label>
          <Input id="name" name="name" required defaultValue={initial?.name ?? ""} placeholder="Dra. Ana Lima" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="specialty">Especialidade</Label>
          <Input id="specialty" name="specialty" defaultValue={initial?.specialty ?? ""} placeholder="Dermatologia" />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Sobre o profissional</Label>
        <Textarea
          id="description"
          name="description"
          rows={3}
          maxLength={1000}
          defaultValue={initial?.description ?? ""}
          placeholder="Atende adultos e crianças a partir de 12 anos. Foco em acne e dermatologia estética."
        />
        <p className="text-xs text-muted-foreground">O agente usa este texto para apresentar o profissional ao paciente.</p>
      </div>

      <div className="space-y-2 max-w-xs">
        <Label htmlFor="durationMin">Duração da consulta (min)</Label>
        <Input
          id="durationMin"
          name="durationMin"
          type="number"
          min={5}
          max={480}
          step={5}
          required
          defaultValue={initial?.durationMin ?? 30}
        />
      </div>

      <fieldset className="space-y-3 rounded-md border border-border p-4">
        <legend className="px-1 text-sm font-medium">Semana padrão</legend>
        <p className="text-xs text-muted-foreground">
          Um ou mais intervalos por dia, separados por vírgula (ex.: <code>08:00-12:00, 14:00-18:00</code>). Deixe vazio
          nos dias sem atendimento. Folgas, feriados e dias extras você marca depois, em “Exceções”.
        </p>
        <div className="grid gap-2">
          {WEEKDAYS.map(({ day, label }) => (
            <div key={day} className="grid grid-cols-[6rem_1fr] items-center gap-3">
              <Label htmlFor={`wh_${day}`} className="text-sm">
                {label}
              </Label>
              <Input
                id={`wh_${day}`}
                name={`wh_${day}`}
                defaultValue={formatDayIntervals(initial?.workingHours?.[String(day)])}
                placeholder="não atende"
                className="font-mono text-xs"
              />
            </div>
          ))}
        </div>
      </fieldset>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div>
          <Label htmlFor="active" className="text-sm">Ativo</Label>
          <p className="text-xs text-muted-foreground">Inativos não aparecem para o agente.</p>
        </div>
        <Switch id="active" name="active" defaultChecked={initial?.active ?? true} />
      </div>

      {state?.error && <p className="text-sm text-destructive">{state.error}</p>}

      <Button type="submit" disabled={pending}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Salvar
      </Button>
    </form>
  );
}
