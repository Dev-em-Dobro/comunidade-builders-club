import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { costPerLead } from "../metrics";

const DAY_MS = 24 * 60 * 60 * 1000;

interface CostData {
  totalUsd: number;
  leadCount: number;
  error: boolean;
}

async function getCost(rangeDays: number): Promise<CostData> {
  try {
    const since = new Date(Date.now() - rangeDays * DAY_MS);
    const [agg, leadCount] = await Promise.all([
      prisma.usageDaily.aggregate({
        _sum: { costUsd: true },
        where: { date: { gte: since } },
      }),
      prisma.lead.count({ where: { createdAt: { gte: since } } }),
    ]);
    return {
      totalUsd: agg._sum.costUsd?.toNumber() ?? 0,
      leadCount,
      error: false,
    };
  } catch {
    return { totalUsd: 0, leadCount: 0, error: true };
  }
}

export async function CostSection({ rangeDays }: { rangeDays: number }) {
  const { totalUsd, leadCount, error } = await getCost(rangeDays);
  const perLead = costPerLead(totalUsd, leadCount);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Custo de LLM</CardTitle>
        <CardDescription>
          {error ? (
            "Custo de LLM no período"
          ) : (
            <>
              {leadCount} lead{leadCount !== 1 ? "s" : ""} novo
              {leadCount !== 1 ? "s" : ""} no período
            </>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : (
          <>
            <div className="text-2xl font-mono font-semibold">
              {perLead === null ? "—" : `$${perLead.toFixed(4)}`}
            </div>
            <p className="text-xs text-muted-foreground">
              por lead · ${totalUsd.toFixed(2)} no total
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
