import { describe, it, expect, beforeEach, afterEach, afterAll, vi } from "vitest";
import { prisma } from "@/lib/db";

// Mock do LLM ANTES de importar run-audit.
vi.mock("@/lib/llm", async () => {
  return {
    generateReply: vi.fn(),
  };
});

import { generateReply } from "@/lib/llm";
import { runAudit } from "./run-audit";

const mockGenerate = generateReply as unknown as ReturnType<typeof vi.fn>;

const created = {
  contactIds: [] as string[],
  conversationIds: [] as string[],
  criterionIds: [] as string[],
  reportIds: [] as string[],
};

afterAll(async () => {
  await prisma.auditFinding.deleteMany({
    where: { reportId: { in: created.reportIds } },
  });
  await prisma.auditReport.deleteMany({ where: { id: { in: created.reportIds } } });
  await prisma.auditCriterion.deleteMany({
    where: { id: { in: created.criterionIds } },
  });
  await prisma.message.deleteMany({
    where: { conversationId: { in: created.conversationIds } },
  });
  await prisma.conversation.deleteMany({
    where: { id: { in: created.conversationIds } },
  });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

beforeEach(async () => {
  mockGenerate.mockReset();
  // Isolamento entre testes: limpa artefatos criados em testes anteriores.
  // Sem isso, conversas com 3+ turnos do bot leakam pro selectConversations
  // do próximo teste e quebram as asserções (esperam contagens exatas).
  if (created.reportIds.length > 0) {
    await prisma.auditFinding.deleteMany({
      where: { reportId: { in: created.reportIds } },
    });
    await prisma.auditReport.deleteMany({
      where: { id: { in: created.reportIds } },
    });
    created.reportIds.length = 0;
  }
  if (created.conversationIds.length > 0) {
    await prisma.message.deleteMany({
      where: { conversationId: { in: created.conversationIds } },
    });
    await prisma.conversation.deleteMany({
      where: { id: { in: created.conversationIds } },
    });
    created.conversationIds.length = 0;
  }
  if (created.contactIds.length > 0) {
    await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
    created.contactIds.length = 0;
  }
});

afterEach(() => {
  vi.clearAllMocks();
});

async function mkConvWithMessages(botTurns: number, displayName = "T"): Promise<string> {
  const contact = await prisma.contact.create({ data: { displayName } });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud" },
  });
  created.conversationIds.push(conv.id);
  for (let i = 0; i < botTurns; i++) {
    await prisma.message.create({
      data: {
        conversationId: conv.id,
        direction: "outbound",
        role: "assistant",
        text: `bot turn ${i}`,
      },
    });
  }
  return conv.id;
}

async function mkCriterion(name: string, weight = 3): Promise<string> {
  const c = await prisma.auditCriterion.create({
    data: { name, description: `desc ${name}`, weight, active: true },
  });
  created.criterionIds.push(c.id);
  return c.id;
}

async function mkReport(conversationIds: string[] = []): Promise<string> {
  const r = await prisma.auditReport.create({
    data: { status: "queued", trigger: "manual", conversationIds },
  });
  created.reportIds.push(r.id);
  return r.id;
}

describe("runAudit", () => {
  it("zero conversas elegíveis → status='done', summary específico", async () => {
    const reportId = await mkReport();
    await runAudit(reportId);
    const report = await prisma.auditReport.findUniqueOrThrow({
      where: { id: reportId },
    });
    expect(report.status).toBe("done");
    expect(report.summary).toMatch(/Nenhuma conversa elegível/i);
    expect(report.finishedAt).not.toBeNull();
    expect(mockGenerate).not.toHaveBeenCalled();
  });

  it("zero critérios ativos → status='done', summary específico", async () => {
    await mkConvWithMessages(3);
    await prisma.auditCriterion.updateMany({ data: { active: false } });
    try {
      const reportId = await mkReport();
      await runAudit(reportId);
      const report = await prisma.auditReport.findUniqueOrThrow({ where: { id: reportId } });
      expect(report.status).toBe("done");
      expect(report.summary).toMatch(/Nenhum critério ativo/i);
      expect(mockGenerate).not.toHaveBeenCalled();
    } finally {
      await prisma.auditCriterion.updateMany({ data: { active: true } });
    }
  });

  it("happy path: 1 conversa, 1 critério, LLM responde valid → 2 findings (1 + freeNotes)", async () => {
    const critId = await mkCriterion("Tom adequado");
    const convId = await mkConvWithMessages(3, "Maria");
    const reportId = await mkReport();

    mockGenerate.mockResolvedValueOnce({
      text: "",
      toolUses: [
        {
          id: "t1",
          name: "record_audit",
          input: {
            findings: [
              {
                criterionId: critId,
                verdict: "pass",
                evidence: "tom OK ao longo dos turnos",
              },
            ],
            freeNotes: "bot poderia ser mais proativo no fechamento",
            oneLineVerdict: "bot foi educado mas passivo",
          },
        },
      ],
      tokensIn: 1000,
      tokensOut: 200,
      costUsd: 0.01,
      modelUsed: "claude-sonnet-4-6",
    });
    mockGenerate.mockResolvedValueOnce({
      text: "## Visão geral\n1 conversa avaliada. Tudo passou.",
      toolUses: [],
      tokensIn: 200,
      tokensOut: 100,
      costUsd: 0.005,
      modelUsed: "claude-sonnet-4-6",
    });

    await runAudit(reportId);

    const report = await prisma.auditReport.findUniqueOrThrow({ where: { id: reportId } });
    expect(report.status).toBe("done");
    expect(report.summary).toContain("Visão geral");
    expect(report.modelUsed).toBe("claude-sonnet-4-6");
    expect(report.conversationIds).toEqual([convId]);

    const findings = await prisma.auditFinding.findMany({ where: { reportId } });
    expect(findings.length).toBe(2);
    const crit = findings.find((f) => f.criterionId === critId);
    expect(crit?.verdict).toBe("pass");
    expect(crit?.criterionNameSnapshot).toBe("Tom adequado");
    expect(crit?.contactDisplaySnapshot).toBe("Maria");
    const free = findings.find((f) => f.criterionId === null);
    expect(free?.criterionNameSnapshot).toBe("Observações livres");
    expect(free?.freeNotes).toContain("proativo");
  });

  it("LLM falha numa conversa → finding error, report done", async () => {
    await mkCriterion("Preço correto");
    await mkConvWithMessages(3);
    const reportId = await mkReport();

    mockGenerate.mockRejectedValueOnce(new Error("rate limited"));
    mockGenerate.mockResolvedValueOnce({
      text: "Summary com 1 erro.",
      toolUses: [],
      tokensIn: 100,
      tokensOut: 50,
      costUsd: 0.002,
      modelUsed: "claude-sonnet-4-6",
    });

    await runAudit(reportId);
    const report = await prisma.auditReport.findUniqueOrThrow({ where: { id: reportId } });
    expect(report.status).toBe("done");

    const findings = await prisma.auditFinding.findMany({ where: { reportId } });
    expect(findings.length).toBeGreaterThanOrEqual(1);
    const err = findings.find((f) => f.verdict === "error");
    expect(err).toBeDefined();
    expect(err?.freeNotes).toContain("rate limited");
  });

  it("reusa conversationIds quando report já vem com eles populados", async () => {
    await mkCriterion("Tom adequado");
    const reuseConvId = await mkConvWithMessages(1); // só 1 turno (não passaria no select)
    const reportId = await mkReport([reuseConvId]);

    mockGenerate.mockResolvedValueOnce({
      text: "",
      toolUses: [{ id: "t1", name: "record_audit", input: { findings: [], freeNotes: "", oneLineVerdict: "ok" } }],
      tokensIn: 100,
      tokensOut: 50,
      costUsd: 0.001,
      modelUsed: "claude-sonnet-4-6",
    });
    mockGenerate.mockResolvedValueOnce({
      text: "Summary.",
      toolUses: [],
      tokensIn: 50,
      tokensOut: 50,
      costUsd: 0.001,
      modelUsed: "claude-sonnet-4-6",
    });

    await runAudit(reportId);
    const report = await prisma.auditReport.findUniqueOrThrow({ where: { id: reportId } });
    expect(report.conversationIds).toEqual([reuseConvId]);
    expect(mockGenerate).toHaveBeenCalledTimes(2);
  });
});
