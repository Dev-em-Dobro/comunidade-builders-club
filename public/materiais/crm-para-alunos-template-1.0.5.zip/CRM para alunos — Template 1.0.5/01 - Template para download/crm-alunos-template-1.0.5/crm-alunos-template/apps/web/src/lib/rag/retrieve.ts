/**
 * Retrieval: busca os chunks mais similares à mensagem do lead.
 * Usa cosine distance do pgvector (operador <=>), restrito aos docs do agente.
 */
import { prisma } from "@/lib/db";
import { embedText, toVectorLiteral } from "./embeddings";

export interface RetrievedChunk {
  text: string;
  score: number;
}

// Abaixo disso o chunk é provavelmente irrelevante — não injeta ruído no prompt.
const MIN_SCORE = 0.35;

export async function retrieveContext(
  agentSessionId: string,
  query: string,
  k = 5,
): Promise<RetrievedChunk[]> {
  const q = query.trim();
  if (!q) return [];

  const vec = await embedText(q, "RETRIEVAL_QUERY");
  const literal = toVectorLiteral(vec);

  // 1 - cosine_distance = cosine_similarity (vetores L2-normalizados).
  const rows = await prisma.$queryRaw<{ text: string; score: number }[]>`
    SELECT rc.text AS text, 1 - (rc.embedding <=> ${literal}::vector) AS score
    FROM "RagChunk" rc
    JOIN "RagDoc" rd ON rd.id = rc."docId"
    WHERE rd."agentSessionId" = ${agentSessionId}
      AND rc.embedding IS NOT NULL
    ORDER BY rc.embedding <=> ${literal}::vector
    LIMIT ${k}
  `;

  return rows
    .map((r) => ({ text: r.text, score: Number(r.score) }))
    .filter((r) => r.score >= MIN_SCORE);
}
