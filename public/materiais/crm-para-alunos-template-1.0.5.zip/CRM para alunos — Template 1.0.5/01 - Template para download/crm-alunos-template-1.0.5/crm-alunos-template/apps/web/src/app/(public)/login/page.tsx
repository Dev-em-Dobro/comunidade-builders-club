import { businessConfig } from "@/lib/config";
import { redirect } from "next/navigation";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Lock, Bot } from "lucide-react";
import { auth } from "@/auth";
import { LoginForm } from "./login-form";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ callbackUrl?: string }>;
}) {
  // Se já está logado, manda direto pro dashboard.
  const session = await auth();
  if (session?.user) redirect("/dashboard");

  const { callbackUrl } = await searchParams;

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-6">
      <div className="mb-8 flex items-center gap-3">
        <div className="size-9 rounded-md bg-primary flex items-center justify-center glow-primary">
          <Bot className="size-5 text-primary-foreground" />
        </div>
        <span className="font-mono font-semibold text-lg">{businessConfig().brandName}</span>
      </div>
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Lock className="size-4 text-primary" /> Entrar
          </CardTitle>
          <CardDescription>
            Use seu email e senha cadastrados.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <LoginForm callbackUrl={callbackUrl} />
        </CardContent>
      </Card>
    </main>
  );
}
