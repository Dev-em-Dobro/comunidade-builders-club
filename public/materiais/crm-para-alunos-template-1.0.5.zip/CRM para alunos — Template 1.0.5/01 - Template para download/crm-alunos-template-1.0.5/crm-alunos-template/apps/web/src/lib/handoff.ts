/**
 * Domínio de handoff humano (Parte 8).
 *
 * Este arquivo tem duas camadas:
 *  - funções puras (`rankAssignees`, `shouldEscalate`) — testadas em handoff.test.ts;
 *  - o orquestrador (`runHandoff`) e os helpers de resumo/aviso/atribuição.
 */

import type { Conversation } from "@prisma/client";
import { prisma } from "@/lib/db";
import { loadMemory } from "@/lib/memory";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { notifyUsers } from "@/lib/notifications";
import { handoffConfig } from "@/lib/config";
import { enqueue } from "@/lib/queue";
import type { HandoffJobData } from "@/lib/queue/types";
import { getAdapter } from "@/lib/channels/registry";
import type { ChannelId } from "@/lib/channels/types";

/** Algo que pode receber a atribuição — só precisa de um `id`. */
export interface Assignable {
  id: string;
}

/** Um registro de atribuição passada (deriva de PipelineEvent 'owner_assigned'). */
export interface AssignEvent {
  userId: string;
  createdAt: Date;
}

/**
 * Rodízio justo (least-recently-assigned): ordena `users` para que o próximo a
 * receber um handoff seja o primeiro da lista.
 *
 * Regra: quem nunca foi atribuído vem primeiro (preservando a ordem de entrada,
 * já que `Array.prototype.sort` é estável); entre os já atribuídos, o de
 * atribuição mais antiga vem primeiro.
 */
export function rankAssignees<T extends Assignable>(
  users: T[],
  events: AssignEvent[],
): T[] {
  const lastAssigned = new Map<string, number>();
  for (const ev of events) {
    const t = ev.createdAt.getTime();
    const prev = lastAssigned.get(ev.userId);
    if (prev === undefined || t > prev) lastAssigned.set(ev.userId, t);
  }
  return [...users].sort((a, b) => {
    const ta = lastAssigned.get(a.id);
    const tb = lastAssigned.get(b.id);
    if (ta === undefined && tb === undefined) return 0;
    if (ta === undefined) return -1;
    if (tb === undefined) return 1;
    return ta - tb;
  });
}

/** Estado relevante para decidir se um handoff deve ser escalado. */
export interface EscalationState {
  handoffRequested: boolean;
  /** createdAt do PipelineEvent 'handoff' mais recente do lead. */
  handoffAt: Date | null;
  /** createdAt do PipelineEvent 'handoff_accepted' mais recente do lead. */
  acceptedAt: Date | null;
}

/**
 * Decide se o job de escalonamento deve disparar.
 *
 * Escala quando o handoff ainda está aberto (`handoffRequested`) E ninguém o
 * assumiu — ou seja, não há um `handoff_accepted` posterior ao `handoff`.
 */
export function shouldEscalate(s: EscalationState): boolean {
  if (!s.handoffRequested) return false;
  if (s.acceptedAt && s.handoffAt && s.acceptedAt >= s.handoffAt) return false;
  if (s.acceptedAt && !s.handoffAt) return false;
  return true;
}

/** Papéis que entram no rodízio de plantão. */
const ASSIGNABLE_ROLES = ["admin", "operator"];

/** System prompt do resumo de handoff. */
const SUMMARY_SYSTEM =
  "Você resume conversas de vendas para um operador humano que vai assumir o " +
  "atendimento. Gere um resumo objetivo em 3 a 5 bullets (cada linha começando " +
  "com '- ') cobrindo: o que o lead quer, em que ponto a conversa está, " +
  "objeções ou sinais relevantes, e o próximo passo sugerido. Seja conciso e " +
  "factual. Responda só com os bullets.";

/** Turn sintético que dispara a geração quando o histórico termina no assistant. */
const SUMMARY_TRIGGER =
  "[Instrução interna: gere agora o resumo do handoff conforme as instruções " +
  "do sistema. Responda só com os bullets.]";

/**
 * Orquestra a entrada em handoff humano. Chamado por `flush.ts` quando
 * `decideAction` retorna `handoff` ou o LLM usa a tool `request_handoff`.
 *
 * 1. Liga `handoffRequested` / desliga `aiEnabled` (idempotente — guarda no topo).
 * 2. Escolhe um operador de plantão por rodízio justo (`pickOnDutyAssignee`).
 * 3. Gera o `handoffSummary` via LLM (best-effort).
 * 4. Envia o aviso de handoff ao cliente e persiste a mensagem (best-effort).
 * 5. Registra PipelineEvents (`handoff`, `owner_assigned`).
 * 6. Notifica o assignee — ou todos os admins, se ninguém estiver de plantão.
 * 7. Agenda o job de escalonamento `sla.handoff`.
 */
export async function runHandoff(conv: Conversation, notice: string): Promise<void> {
  if (conv.handoffRequested) {
    log("handoff.skip_already", { conversationId: conv.id });
    return;
  }

  await prisma.conversation.update({
    where: { id: conv.id },
    data: { handoffRequested: true, aiEnabled: false },
  });

  const assignee = await pickOnDutyAssignee();
  if (assignee) {
    await prisma.conversation.update({
      where: { id: conv.id },
      data: { assignedUserId: assignee.id },
    });
    // O lead ganha um dono de vendas — sem sobrescrever um dono já existente.
    if (conv.leadId) {
      await prisma.lead.updateMany({
        where: { id: conv.leadId, ownerId: null },
        data: { ownerId: assignee.id },
      });
    }
  }

  const summary = await buildHandoffSummary(conv);
  if (summary) {
    await prisma.conversation.update({
      where: { id: conv.id },
      data: { handoffSummary: summary },
    });
  }

  await sendHandoffNotice(conv, notice);

  if (conv.leadId) {
    await prisma.pipelineEvent.create({
      data: {
        leadId: conv.leadId,
        type: "handoff",
        payload: { conversationId: conv.id },
      },
    });
    if (assignee) {
      await prisma.pipelineEvent.create({
        data: {
          leadId: conv.leadId,
          type: "owner_assigned",
          payload: { conversationId: conv.id, userId: assignee.id },
        },
      });
    }
  }

  // Escalonamento agendado ANTES de notificar: se notifyUsers falhar (ex: erro
  // de DB no createMany), a rede de segurança (job sla.handoff) já está garantida.
  const data: HandoffJobData = { conversationId: conv.id };
  await enqueue("sla", "handoff", data, {
    delay: handoffConfig().slaHandoffMin * 60_000,
    removeOnComplete: true,
    removeOnFail: 50,
  });

  const who = await contactDisplayName(conv.contactId);
  if (assignee) {
    await notifyUsers([assignee], {
      type: "handoff",
      title: "Bot solicitou humano — assuma a conversa",
      body: `${who} precisa de atendimento humano. A IA foi pausada.`,
      payload: { conversationId: conv.id, leadId: conv.leadId ?? undefined },
    });
  } else {
    // Ninguém de plantão — escala na hora para os admins.
    const admins = await prisma.user.findMany({
      where: { role: "admin" },
      select: { id: true, email: true },
    });
    await notifyUsers(admins, {
      type: "handoff",
      title: "Bot solicitou humano — sem operador de plantão",
      body: `${who} precisa de atendimento humano e ninguém está de plantão.`,
      payload: { conversationId: conv.id, leadId: conv.leadId ?? undefined },
    });
  }

  log("handoff.done", {
    conversationId: conv.id,
    assigneeId: assignee?.id ?? null,
    summary: summary != null,
  });
}

/**
 * Escolhe o próximo operador de plantão pelo rodízio justo. `null` se ninguém
 * estiver de plantão.
 */
async function pickOnDutyAssignee(): Promise<
  { id: string; email: string } | null
> {
  const users = await prisma.user.findMany({
    where: { isOnDuty: true, role: { in: ASSIGNABLE_ROLES } },
    select: { id: true, email: true },
  });
  if (!users.length) return null;

  const rows = await prisma.pipelineEvent.findMany({
    where: { type: "owner_assigned" },
    orderBy: { createdAt: "desc" },
    take: 200,
    select: { createdAt: true, payload: true },
  });
  const events: AssignEvent[] = [];
  for (const r of rows) {
    const uid = (r.payload as Record<string, unknown> | null)?.userId;
    if (typeof uid === "string") events.push({ userId: uid, createdAt: r.createdAt });
  }

  return rankAssignees(users, events)[0] ?? null;
}

/**
 * Gera o resumo da conversa via LLM. Best-effort: qualquer falha (ou ausência
 * de histórico) retorna `null` — o handoff continua sem resumo.
 */
async function buildHandoffSummary(conv: Conversation): Promise<string | null> {
  try {
    const agent = conv.agentSessionId
      ? await prisma.agentSession.findUnique({ where: { id: conv.agentSessionId } })
      : await prisma.agentSession.findFirst({ where: { isDefault: true } });
    if (!agent) return null;

    const memory = await loadMemory(conv.id, agent.memoryMode);
    if (!memory.length) return null;

    const last = memory[memory.length - 1];
    const messages =
      last && last.role === "assistant"
        ? [...memory, { role: "user" as const, content: SUMMARY_TRIGGER }]
        : memory;

    const resp = await generateReplyWithKey(agent.provider, {
      model: agent.model,
      temperature: 0.3,
      maxTokens: 400,
      systemStatic: SUMMARY_SYSTEM,
      messages,
    });
    return resp.text.trim() || null;
  } catch (err) {
    log("handoff.summary_failed", {
      conversationId: conv.id,
      error: String((err as Error)?.message ?? err),
    });
    return null;
  }
}

/** displayName do contato, com fallback. */
async function contactDisplayName(contactId: string): Promise<string> {
  const c = await prisma.contact.findUnique({
    where: { id: contactId },
    select: { displayName: true },
  });
  return c?.displayName ?? "Um lead";
}

/**
 * Avisa o cliente que vai ser transferido para um humano e persiste a mensagem.
 *
 * Chamado já com a conversa flagada (handoffRequested=true, aiEnabled=false):
 * flagar antes evita uma corrida com a IA respondendo junto do aviso. O envio
 * é best-effort — falha não impede o handoff (atribuição/escalonamento já
 * correm).
 */
async function sendHandoffNotice(conv: Conversation, notice: string): Promise<void> {
  if (!notice.trim()) {
    log("handoff.notice_empty", { conversationId: conv.id });
    return;
  }
  try {
    const channel = conv.channel as ChannelId;
    const ident = await prisma.contactIdentity.findFirst({
      where: { contactId: conv.contactId, channel },
    });
    if (!ident) {
      log("handoff.notice_no_identity", { conversationId: conv.id });
      return;
    }
    await getAdapter(channel).sendText(ident.externalId, notice);
    await prisma.message.create({
      data: {
        conversationId: conv.id,
        direction: "outbound",
        role: "assistant",
        text: notice,
      },
    });
    log("handoff.notice_sent", { conversationId: conv.id });
  } catch (err) {
    log("handoff.notice_failed", {
      conversationId: conv.id,
      error: String((err as Error)?.message ?? err),
    });
  }
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
