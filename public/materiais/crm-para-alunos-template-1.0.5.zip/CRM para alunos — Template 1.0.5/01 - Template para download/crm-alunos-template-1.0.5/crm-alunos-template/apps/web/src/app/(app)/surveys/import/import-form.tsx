"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";
import { Loader2, Upload } from "lucide-react";

interface Result {
  totalRows: number;
  matched: number;
  created: number;
  skipped: number;
  skippedDetails: Array<{ rowNumber: number; reason: string }>;
  /** Nome da pesquisa importada (pra montar o link de detalhes). */
  surveyName: string;
}

export function ImportForm() {
  const [surveyName, setSurveyName] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [pending, startTransition] = useTransition();
  const [result, setResult] = useState<Result | null>(null);

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !surveyName.trim()) {
      toast.error("Selecione um arquivo e dê um nome à pesquisa.");
      return;
    }
    startTransition(async () => {
      try {
        const fd = new FormData();
        fd.append("file", file);
        fd.append("surveyName", surveyName.trim());
        const r = await fetch("/api/surveys/import", { method: "POST", body: fd });
        const body = (await r.json().catch(() => ({}))) as Result & { error?: string };
        if (!r.ok) {
          toast.error(body.error ?? `HTTP ${r.status}`);
          return;
        }
        setResult({
          totalRows: body.totalRows,
          matched: body.matched,
          created: body.created,
          skipped: body.skipped,
          skippedDetails: body.skippedDetails,
          surveyName: surveyName.trim(),
        });
        const total = body.matched + body.created;
        toast.success(`${total} respostas importadas`);
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  return (
    <div className="space-y-6">
      <form onSubmit={submit} className="space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="surveyName">Nome da pesquisa</Label>
          <Input
            id="surveyName"
            placeholder="ex: Lançamento maio/26"
            value={surveyName}
            onChange={(e) => setSurveyName(e.target.value)}
            maxLength={200}
            disabled={pending}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="file">Arquivo CSV</Label>
          <Input
            id="file"
            type="file"
            accept=".csv,text/csv"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            disabled={pending}
          />
        </div>
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Upload className="size-4" />}
          Importar
        </Button>
      </form>

      {result && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-3">
            <CardTitle className="text-base">
              {result.matched + result.created} respostas importadas
              {result.created > 0 &&
                ` (${result.matched} casadas + ${result.created} contatos novos)`}
              {result.skipped > 0 && ` · ${result.skipped} linhas puladas`}
            </CardTitle>
            {result.matched + result.created > 0 && (
              <Link
                href={`/surveys/${encodeURIComponent(result.surveyName)}`}
                className={buttonVariants({ variant: "outline", size: "sm" })}
              >
                Ver respondentes
              </Link>
            )}
          </CardHeader>
          {result.skippedDetails.length > 0 && (
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-24">Linha</TableHead>
                    <TableHead>Motivo</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {result.skippedDetails.map((d) => (
                    <TableRow key={`${d.rowNumber}-${d.reason}`}>
                      <TableCell className="font-mono">{d.rowNumber}</TableCell>
                      <TableCell>{d.reason}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          )}
        </Card>
      )}
    </div>
  );
}
