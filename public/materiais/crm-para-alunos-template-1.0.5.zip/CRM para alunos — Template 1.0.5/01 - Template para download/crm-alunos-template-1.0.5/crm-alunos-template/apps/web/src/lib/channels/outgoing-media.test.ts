import { describe, expect, it } from "vitest";
import { inspectOutgoingMedia } from "./outgoing-media";

describe("inspectOutgoingMedia", () => {
  it("aceita imagem e áudio nos formatos da Cloud API", () => {
    expect(inspectOutgoingMedia({ name: "foto.jpg", type: "image/jpeg", size: 100 }).kind).toBe("image");
    expect(inspectOutgoingMedia({ name: "voz.m4a", type: "audio/x-m4a", size: 100 })).toMatchObject({
      kind: "audio",
      mimeType: "audio/mp4",
    });
  });

  it("rejeita arquivo fora do limite antes do upload", () => {
    expect(() => inspectOutgoingMedia({ name: "foto.png", type: "image/png", size: 5_000_001 }))
      .toThrow("5 MB");
    expect(() => inspectOutgoingMedia({ name: "voz.webm", type: "audio/webm", size: 100 }))
      .toThrow("Formato não aceito");
  });
});
