-- AlterTable
ALTER TABLE "Contact" ADD COLUMN "email" TEXT;
CREATE UNIQUE INDEX "Contact_email_key" ON "Contact"("email");

-- CreateTable
CREATE TABLE "SurveyResponse" (
    "id" TEXT NOT NULL,
    "contactId" TEXT NOT NULL,
    "surveyName" TEXT NOT NULL,
    "answers" JSONB NOT NULL,
    "submittedAt" TIMESTAMP(3),
    "source" TEXT NOT NULL DEFAULT 'csv_import',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "SurveyResponse_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SurveyResponse_contactId_createdAt_idx" ON "SurveyResponse"("contactId", "createdAt");

-- AddForeignKey
ALTER TABLE "SurveyResponse" ADD CONSTRAINT "SurveyResponse_contactId_fkey"
    FOREIGN KEY ("contactId") REFERENCES "Contact"("id") ON DELETE CASCADE ON UPDATE CASCADE;
