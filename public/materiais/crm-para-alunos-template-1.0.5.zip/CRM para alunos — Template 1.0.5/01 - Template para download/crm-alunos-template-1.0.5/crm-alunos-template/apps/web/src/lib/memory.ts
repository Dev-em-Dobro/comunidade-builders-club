import { prisma } from "@/lib/db";
import type { LLMTurn } from "@/lib/llm/types";

export type MemoryMode = "stateless" | `window_${number}` | `summary_plus_${number}`;

/**
 * Carrega o histórico relevante pra alimentar o LLM.
 *
 * - `window_N` → últimas N msgs (default 20)
 * - `summary_plus_N` → resumo persistente + últimas N (sumarização lazy — TODO)
 * - `stateless` → array vazio
 */
export async function loadMemory(
  conversationId: string,
  mode: string = "window_20",
): Promise<LLMTurn[]> {
  if (mode === "stateless") return [];

  const m = /^window_(\d+)$/.exec(mode) ?? /^summary_plus_(\d+)$/.exec(mode);
  const n = m ? Number(m[1]) : 20;

  const msgs = await prisma.message.findMany({
    where: {
      conversationId,
      role: { in: ["user", "assistant"] },
    },
    orderBy: { createdAt: "desc" },
    take: n,
  });

  // Inverter pra ordem cronológica e mapear pro shape do LLM.
  return msgs
    .reverse()
    .map((m) => ({
      role: m.role === "assistant" ? ("assistant" as const) : ("user" as const),
      content: m.text,
    }));
}
