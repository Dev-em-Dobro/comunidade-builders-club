import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { extractEmails, mergeByEmailFromInbound } from "./merge-by-email";

describe("extractEmails", () => {
  it("extrai email simples de texto livre", () => {
    expect(extractEmails("meu email é aluno@example.com obrigado")).toEqual([
      "aluno@example.com",
    ]);
  });

  it("lowercaseia e dedupa preservando ordem da 1ª ocorrência", () => {
    expect(
      extractEmails("ALUNO@example.com e tb aluno@example.com e maria@x.io"),
    ).toEqual(["aluno@example.com", "maria@x.io"]);
  });

  it("retorna [] quando não há email", () => {
    expect(extractEmails("oi tudo bem?")).toEqual([]);
    expect(extractEmails("")).toEqual([]);
  });
});

const created = {
  contactIds: [] as string[],
};

afterAll(async () => {
  // Leads têm FK pra Contact; deleta-os primeiro pra evitar P2003.
  await prisma.lead.deleteMany({
    where: { contactId: { in: created.contactIds } },
  });
  await prisma.contact.deleteMany({
    where: { id: { in: created.contactIds } },
  });
  await prisma.$disconnect();
});

/** Helper: cria um Contact e registra pra cleanup. */
async function mkContact(data: {
  email?: string | null;
  displayName?: string;
}): Promise<string> {
  const c = await prisma.contact.create({
    data: {
      email: data.email ?? null,
      displayName: data.displayName ?? "T",
    },
  });
  created.contactIds.push(c.id);
  return c.id;
}

/** Helper: cria uma SurveyResponse num Contact. */
async function mkSurvey(contactId: string, surveyName = "teste"): Promise<string> {
  const s = await prisma.surveyResponse.create({
    data: {
      contactId,
      surveyName,
      answers: { q: "a" },
      source: "csv_import",
    },
  });
  return s.id;
}

/** Helper: cria uma ContactIdentity num Contact. */
async function mkIdentity(
  contactId: string,
  channel = "whatsapp_cloud",
  externalId?: string,
): Promise<void> {
  await prisma.contactIdentity.create({
    data: {
      contactId,
      channel,
      externalId: externalId ?? `id-${Date.now()}-${Math.random()}`,
    },
  });
}

/** Helper: gera email único por teste pra não colidir com `@unique`. */
function uniqueEmail(tag: string): string {
  return `12e-${tag}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}@t.local`;
}

describe("mergeByEmailFromInbound", () => {
  it("retorna no_email_in_text quando o texto não tem email", async () => {
    const currentId = await mkContact({ email: null });
    const r = await mergeByEmailFromInbound(currentId, "oi tudo bem?");
    expect(r).toEqual({
      merged: false,
      movedSurveyResponses: 0,
      emailUsed: null,
      reason: "no_email_in_text",
    });
  });

  it("retorna current_has_email quando o contact atual já tem email", async () => {
    const currentId = await mkContact({ email: uniqueEmail("cur") });
    const r = await mergeByEmailFromInbound(currentId, "meu email é aluno@example.org");
    expect(r.merged).toBe(false);
    expect(r.reason).toBe("current_has_email");
    expect(r.movedSurveyResponses).toBe(0);

    // O contact atual não foi alterado.
    const after = await prisma.contact.findUniqueOrThrow({ where: { id: currentId } });
    expect(after.email).not.toBe("aluno@example.org");
  });

  it("retorna no_match quando nenhum contact tem o email do texto", async () => {
    const currentId = await mkContact({ email: null });
    // Email inventado, garantido único.
    const r = await mergeByEmailFromInbound(
      currentId,
      `meu email é ${uniqueEmail("ghost")}`,
    );
    expect(r.merged).toBe(false);
    expect(r.reason).toBe("no_match");
  });

  it("funde other-só-email no current quando other está limpo (sem identities, sem lead)", async () => {
    const email = uniqueEmail("happy");
    // 1) other: contact-só-email com 1 SurveyResponse
    const otherId = await mkContact({ email });
    const surveyId = await mkSurvey(otherId, "abandono-2026");
    // 2) current: contact com identity (mas sem email)
    const currentId = await mkContact({ email: null });
    await mkIdentity(currentId, "whatsapp_cloud");

    const r = await mergeByEmailFromInbound(currentId, `oi! meu email é ${email}`);

    expect(r.merged).toBe(true);
    expect(r.movedSurveyResponses).toBe(1);
    expect(r.emailUsed).toBe(email);

    // current ganhou o email
    const after = await prisma.contact.findUniqueOrThrow({ where: { id: currentId } });
    expect(after.email).toBe(email);

    // survey migrou pro current
    const survey = await prisma.surveyResponse.findUniqueOrThrow({
      where: { id: surveyId },
    });
    expect(survey.contactId).toBe(currentId);

    // other foi apagado
    const gone = await prisma.contact.findUnique({ where: { id: otherId } });
    expect(gone).toBeNull();
  });

  it("skipa merge quando other tem identities (outro canal já grudado)", async () => {
    const email = uniqueEmail("shared");
    const otherId = await mkContact({ email });
    await mkIdentity(otherId, "whatsapp_cloud"); // outro lead tem WA dessa pessoa
    const surveyId = await mkSurvey(otherId);

    const currentId = await mkContact({ email: null });
    await mkIdentity(currentId, "whatsapp_cloud");

    const r = await mergeByEmailFromInbound(currentId, `meu email é ${email}`);

    expect(r.merged).toBe(false);
    expect(r.reason).toBe("other_has_identities");

    // other intacto
    const otherAfter = await prisma.contact.findUniqueOrThrow({
      where: { id: otherId },
    });
    expect(otherAfter.email).toBe(email);
    const survey = await prisma.surveyResponse.findUniqueOrThrow({
      where: { id: surveyId },
    });
    expect(survey.contactId).toBe(otherId);
  });

  it("skipa merge quando other tem lead (funil próprio)", async () => {
    const email = uniqueEmail("ownlead");
    const otherId = await mkContact({ email });
    // Cria lead no other; registramos pra cleanup ANTES do contact (afterAll
    // deleta leads via contactId, então basta ter o contactId em `created`).
    await prisma.lead.create({ data: { contactId: otherId } });
    const surveyId = await mkSurvey(otherId);

    const currentId = await mkContact({ email: null });

    const r = await mergeByEmailFromInbound(currentId, `email: ${email}`);

    expect(r.merged).toBe(false);
    expect(r.reason).toBe("other_has_lead");

    // other intacto
    const survey = await prisma.surveyResponse.findUniqueOrThrow({
      where: { id: surveyId },
    });
    expect(survey.contactId).toBe(otherId);
  });

  it("com múltiplos emails, pula o que falha guard e mergea o próximo safe", async () => {
    const emailBlocked = uniqueEmail("blk");
    const emailSafe = uniqueEmail("safe");

    // 1º email: tem identity (vai falhar o guard)
    const blockedId = await mkContact({ email: emailBlocked });
    await mkIdentity(blockedId, "whatsapp_cloud");

    // 2º email: safe (vai mergear)
    const safeId = await mkContact({ email: emailSafe });
    const safeSurveyId = await mkSurvey(safeId);

    const currentId = await mkContact({ email: null });
    await mkIdentity(currentId, "whatsapp_cloud");

    const r = await mergeByEmailFromInbound(
      currentId,
      `tenho dois: ${emailBlocked} e ${emailSafe}`,
    );

    expect(r.merged).toBe(true);
    expect(r.emailUsed).toBe(emailSafe);
    expect(r.movedSurveyResponses).toBe(1);

    // blocked intacto
    const blockedAfter = await prisma.contact.findUniqueOrThrow({
      where: { id: blockedId },
    });
    expect(blockedAfter.email).toBe(emailBlocked);

    // safe sumiu, survey foi pro current
    expect(await prisma.contact.findUnique({ where: { id: safeId } })).toBeNull();
    const survey = await prisma.surveyResponse.findUniqueOrThrow({
      where: { id: safeSurveyId },
    });
    expect(survey.contactId).toBe(currentId);

    // current ganhou o email safe
    const currentAfter = await prisma.contact.findUniqueOrThrow({
      where: { id: currentId },
    });
    expect(currentAfter.email).toBe(emailSafe);
  });
});
