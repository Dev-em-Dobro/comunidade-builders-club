export type LLMRole = "system" | "user" | "assistant" | "tool";

export interface LLMTurn {
  role: Exclude<LLMRole, "system">;
  /** Texto da mensagem. Pode ser string vazia quando toolUse/toolResult está presente. */
  content: string;
  /**
   * Quando presente em um turn assistant, indica que a IA chamou esta tool.
   * O adapter emite um bloco `tool_use` (Anthropic) no lugar de `text`.
   */
  toolUse?: {
    id: string;
    name: string;
    input: Record<string, unknown>;
  };
  /**
   * Quando presente em um turn `role: "tool"`, indica o resultado da execução
   * da tool. O adapter emite um bloco `tool_result` (dentro de um user turn,
   * que é como a API Anthropic espera).
   */
  toolResult?: {
    toolUseId: string;
    /** Conteúdo serializado (JSON string ou texto) que volta pro modelo. */
    content: string;
  };
}

/** Definição de uma tool exposta ao LLM. */
export interface LLMToolDef {
  name: string;
  description: string;
  /** JSON Schema do input (objeto). */
  inputSchema: Record<string, unknown>;
}

/** Tool que o modelo decidiu chamar na resposta. */
export interface LLMToolUse {
  id: string;
  name: string;
  input: Record<string, unknown>;
}

export interface LLMRequest {
  model: string;
  temperature?: number;
  maxTokens?: number;
  /**
   * Static portion do system prompt — vai com cache_control: ephemeral (Anthropic)
   * pra reduzir custo em ~90% em chamadas repetidas.
   */
  systemStatic: string;
  /** Conteúdo dinâmico (memória curta, contexto da sessão) — sem cache. */
  systemDynamic?: string;
  /** Histórico já enxugado pela memoryMode (ex: últimas 20 msgs). */
  messages: LLMTurn[];
  /** Tools disponíveis ao modelo nesta chamada (ex: request_handoff). */
  tools?: LLMToolDef[];
  /** Força ou libera o uso de tools. Ausente = comportamento default do provider. */
  toolChoice?: { type: "auto" } | { type: "tool"; name: string };
  /**
   * Chave de API do provider (BYOK). Quando presente, o provider usa esta chave
   * em vez da env var. Resolvida em runtime a partir de ProviderCredential.
   */
  apiKey?: string;
}

export interface LLMResponse {
  text: string;
  modelUsed: string;
  tokensIn: number;
  tokensOut: number;
  /** Tokens reaproveitados de cache (Anthropic apenas). */
  tokensCached?: number;
  /** Estimativa em USD baseada em pricing público — referência, não billing. */
  costUsd?: number;
  raw?: unknown;
  /** Tools que o modelo decidiu chamar nesta resposta. */
  toolUses?: LLMToolUse[];
}

export interface LLMProvider {
  id: string;
  generateReply(req: LLMRequest): Promise<LLMResponse>;
}
