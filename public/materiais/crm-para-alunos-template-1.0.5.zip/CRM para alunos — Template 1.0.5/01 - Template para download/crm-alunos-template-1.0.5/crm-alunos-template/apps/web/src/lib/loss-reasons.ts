/**
 * Vocabulário de motivo da perda (manual won/lost na tela de conversa).
 *
 * Códigos canônicos pra agregação. Reaproveita o vocabulário de objeções
 * (preco/tempo/conjuge/outro_curso/medo/outro) + `no_response` — o mesmo código
 * que os workers de reengajamento/out-window já gravam em `Lead.lostReason`,
 * então perda manual e perda automática batem nas métricas.
 *
 * - `label`: texto longo/descritivo pro dropdown e pro detalhe do lead.
 * - `short`: texto curto, minúsculo, pro selo na listagem/header.
 *
 * Módulo puro — sem deps de runtime.
 */

export const LOSS_REASONS = [
  { code: "preco", label: "Preço", short: "preço" },
  { code: "tempo", label: "Tempo / agenda", short: "tempo" },
  { code: "conjuge", label: "Cônjuge / decisão familiar", short: "cônjuge" },
  { code: "outro_curso", label: "Escolheu outro curso", short: "outro curso" },
  { code: "medo", label: "Medo / insegurança", short: "medo" },
  { code: "no_response", label: "Sem resposta", short: "sem resposta" },
  { code: "outro", label: "Outro", short: "outro" },
] as const;

export type LossReasonCode = (typeof LOSS_REASONS)[number]["code"];

/** Tupla de códigos — formato que `z.enum` exige. */
export const LOSS_REASON_CODES = LOSS_REASONS.map((r) => r.code) as [
  LossReasonCode,
  ...LossReasonCode[],
];

const BY_CODE = new Map(LOSS_REASONS.map((r) => [r.code as string, r]));

/** Label longo. Código desconhecido (legado) → o próprio código. */
export function lossReasonLabel(code: string | null | undefined): string | null {
  if (!code) return null;
  return BY_CODE.get(code)?.label ?? code;
}

/** Label curto pro selo. Código desconhecido (legado) → o próprio código. */
export function lossReasonShort(code: string | null | undefined): string | null {
  if (!code) return null;
  return BY_CODE.get(code)?.short ?? code;
}
