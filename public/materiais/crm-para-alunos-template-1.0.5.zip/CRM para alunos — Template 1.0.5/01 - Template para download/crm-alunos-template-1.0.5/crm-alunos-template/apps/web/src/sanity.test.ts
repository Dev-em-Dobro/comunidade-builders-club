import { describe, it, expect } from "vitest";
import { loadConfig } from "@/lib/config";

describe("sanity", () => {
  it("vitest roda e o alias @/ resolve", () => {
    const config = loadConfig();
    expect(config.version).toBe(2);
    expect(config.project.slug).toMatch(/^[a-z0-9-]+$/);
    expect(Array.isArray(config.channels.enabled)).toBe(true);
  });
});
