import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { listMetaTemplates, sendTemplateMessage } from "./meta-templates";
import { ChannelSendError } from "./meta-graph";

const originalEnv = { ...process.env };
let fetchMock: ReturnType<typeof vi.fn>;

beforeEach(() => {
  process.env.META_BUSINESS_ACCOUNT_ID = "WABA123";
  process.env.META_PHONE_NUMBER_ID = "PHONE456";
  process.env.META_SYSTEM_USER_TOKEN = "TOKEN789";
  fetchMock = vi.fn();
  global.fetch = fetchMock as unknown as typeof fetch;
});

afterEach(() => {
  process.env = { ...originalEnv };
  vi.restoreAllMocks();
});

describe("listMetaTemplates", () => {
  it("chama GET /{waba}/message_templates com Bearer token", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify({ data: [] }), { status: 200 }),
    );
    await listMetaTemplates();
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toContain("/WABA123/message_templates");
    expect((init as RequestInit).headers).toMatchObject({
      Authorization: "Bearer TOKEN789",
    });
  });

  it("retorna array parseado", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({
          data: [
            {
              name: "hello",
              language: "pt_BR",
              category: "UTILITY",
              status: "APPROVED",
              components: [{ type: "BODY", text: "Oi" }],
            },
          ],
        }),
        { status: 200 },
      ),
    );
    const out = await listMetaTemplates();
    expect(out).toHaveLength(1);
    expect(out[0]).toMatchObject({ name: "hello", status: "APPROVED" });
  });

  it("segue paginação via cursor `next`", async () => {
    fetchMock
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: [{ name: "a", language: "pt_BR", category: "UTILITY", status: "APPROVED", components: [] }],
            paging: { next: "https://graph.facebook.com/page2" },
          }),
          { status: 200 },
        ),
      )
      .mockResolvedValueOnce(
        new Response(
          JSON.stringify({
            data: [{ name: "b", language: "pt_BR", category: "UTILITY", status: "APPROVED", components: [] }],
          }),
          { status: 200 },
        ),
      );
    const out = await listMetaTemplates();
    expect(out).toHaveLength(2);
    expect(out.map((t) => t.name)).toEqual(["a", "b"]);
  });

  it("throws quando env var faltando", async () => {
    delete process.env.META_BUSINESS_ACCOUNT_ID;
    await expect(listMetaTemplates()).rejects.toThrow(/credenciais/i);
  });

  it("throws ChannelSendError em HTTP não-2xx", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({ error: { code: 100, message: "Invalid token" } }),
        { status: 400 },
      ),
    );
    await expect(listMetaTemplates()).rejects.toBeInstanceOf(ChannelSendError);
  });
});

describe("sendTemplateMessage", () => {
  it("monta body correto com components.body.parameters", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({ messages: [{ id: "wamid.abc" }] }),
        { status: 200 },
      ),
    );
    const out = await sendTemplateMessage({
      externalId: "5511999999999",
      templateName: "reativacao",
      language: "pt_BR",
      variables: ["João", "Curso X"],
    });
    expect(out.providerMsgId).toBe("wamid.abc");
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toContain("/PHONE456/messages");
    const body = JSON.parse((init as RequestInit).body as string);
    expect(body).toMatchObject({
      messaging_product: "whatsapp",
      to: "5511999999999",
      type: "template",
      template: {
        name: "reativacao",
        language: { code: "pt_BR" },
        components: [
          {
            type: "body",
            parameters: [
              { type: "text", text: "João" },
              { type: "text", text: "Curso X" },
            ],
          },
        ],
      },
    });
  });

  it("omite components quando variables é vazio (template sem vars)", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({ messages: [{ id: "wamid.xyz" }] }),
        { status: 200 },
      ),
    );
    await sendTemplateMessage({
      externalId: "5511999999999",
      templateName: "hello",
      language: "pt_BR",
      variables: [],
    });
    const [, init] = fetchMock.mock.calls[0];
    const body = JSON.parse((init as RequestInit).body as string);
    expect(body.template.components).toBeUndefined();
  });

  it("rejeita externalId cuid (defensa do gotcha 0.9.27)", async () => {
    await expect(
      sendTemplateMessage({
        externalId: "cabcdefghijklmnopqrstuvw0",
        templateName: "x",
        language: "pt_BR",
        variables: [],
      }),
    ).rejects.toThrow(/cuid/i);
  });

  it("throws quando resposta da Meta vier sem messages[0].id", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(JSON.stringify({ messages: [{}] }), { status: 200 }),
    );
    await expect(
      sendTemplateMessage({
        externalId: "5511999999999",
        templateName: "x",
        language: "pt_BR",
        variables: [],
      }),
    ).rejects.toThrow(/messages\[0\]\.id/);
  });

  it("throws ChannelSendError quando Meta rejeita o template (132xxx)", async () => {
    fetchMock.mockResolvedValueOnce(
      new Response(
        JSON.stringify({ error: { code: 132000, message: "Template paused" } }),
        { status: 400 },
      ),
    );
    await expect(
      sendTemplateMessage({
        externalId: "5511999999999",
        templateName: "x",
        language: "pt_BR",
        variables: [],
      }),
    ).rejects.toBeInstanceOf(ChannelSendError);
  });
});
