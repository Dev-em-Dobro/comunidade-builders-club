"use client";

import { useEffect, useState, useTransition } from "react";
import { Ban, Loader2, ShieldOff } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface Props {
  conversationId: string;
  onAiPaused: () => void;
}

export function WhatsAppBlockAction({ conversationId, onAiPaused }: Props) {
  const [blocked, setBlocked] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    const controller = new AbortController();
    fetch(`/api/conversations/${conversationId}/whatsapp-block`, { signal: controller.signal })
      .then(async (response) => {
        const body = (await response.json()) as { blocked?: boolean; error?: string };
        if (!response.ok) throw new Error(body.error ?? `HTTP ${response.status}`);
        setBlocked(body.blocked === true);
      })
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        toast.error(`Não foi possível consultar o bloqueio: ${(error as Error).message}`);
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, [conversationId]);

  function changeBlock() {
    if (blocked === null) return;
    const next = !blocked;
    if (
      !window.confirm(
        next
          ? "Bloquear este número na Meta? A pessoa não poderá enviar mensagens para este WhatsApp."
          : "Desbloquear este número na Meta? A pessoa poderá voltar a enviar mensagens.",
      )
    ) return;

    startTransition(async () => {
      try {
        const response = await fetch(`/api/conversations/${conversationId}/whatsapp-block`, {
          method: next ? "POST" : "DELETE",
        });
        const body = (await response.json()) as { blocked?: boolean; aiPaused?: boolean; error?: string };
        if (!response.ok) throw new Error(body.error ?? `HTTP ${response.status}`);
        setBlocked(body.blocked === true);
        if (next && body.aiPaused) onAiPaused();
        if (next && body.aiPaused === false) {
          toast.warning("Número bloqueado na Meta, mas não foi possível pausar a IA no CRM.");
        } else {
          toast.success(next ? "Número bloqueado na Meta" : "Número desbloqueado na Meta");
        }
      } catch (error) {
        toast.error((error as Error).message);
      }
    });
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {blocked && (
        <Badge variant="outline" className="gap-1 border-destructive/40 text-destructive">
          <Ban className="size-3" />
          Número bloqueado na Meta
        </Badge>
      )}
      <Button
        size="sm"
        variant="outline"
        onClick={changeBlock}
        disabled={loading || pending || blocked === null}
        className={blocked ? "" : "border-destructive/40 text-destructive hover:bg-destructive/10"}
        title={blocked ? "Desbloquear na WhatsApp Cloud API da Meta" : "Bloquear na WhatsApp Cloud API da Meta"}
      >
        {loading || pending ? <Loader2 className="size-4 animate-spin" /> : blocked ? <ShieldOff className="size-4" /> : <Ban className="size-4" />}
        {loading ? "Consultando bloqueio" : blocked ? "Desbloquear número" : "Bloquear número"}
      </Button>
    </div>
  );
}
