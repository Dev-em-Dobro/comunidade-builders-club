"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { RefreshCw, Loader2 } from "lucide-react";

export function SyncButton() {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  function onClick() {
    startTransition(async () => {
      try {
        const r = await fetch("/api/templates/sync", { method: "POST" });
        const body = (await r.json().catch(() => ({}))) as {
          added?: number;
          updated?: number;
          removed?: number;
          total?: number;
          error?: string;
        };
        if (!r.ok) {
          toast.error(body.error ?? `Falha (HTTP ${r.status})`);
          return;
        }
        toast.success(
          `Sincronizado: ${body.added ?? 0} adicionados, ${body.updated ?? 0} atualizados, ${body.removed ?? 0} removidos.`,
        );
        router.refresh();
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  return (
    <Button onClick={onClick} disabled={pending} aria-label="Sincronizar com Meta">
      {pending ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <RefreshCw className="size-4" />
      )}
      Sincronizar com Meta
    </Button>
  );
}
