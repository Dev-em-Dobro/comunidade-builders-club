"use client";

import { useState, useCallback } from "react";
import { toast } from "sonner";
import { ConversationActions } from "./conversation-actions";
import { WhatsAppBlockAction } from "./whatsapp-block-action";
import { LeadOutcomeActions } from "./lead-outcome-actions";
import { HandoffPanel } from "./handoff-panel";
import { MessagesPane, type MessageView } from "./messages-pane";
import { WindowCountdown } from "./window-countdown";
import { channelHasMessagingWindow } from "@/lib/window24h";
import { Composer } from "./composer";
import { SurveyResponsesDrawer } from "./survey-responses-drawer";
import { useConversationStream } from "../_hooks/use-conversation-stream";
import { playWindowWarningSound } from "@/lib/audio";
import type { ConvEventClientPayload } from "@/lib/realtime/notify";

interface Props {
  conversationId: string;
  channel: string;
  externalId: string;
  aiEnabled: boolean;
  handoffRequested: boolean;
  handoffSummary: string | null;
  windowClosesAt: string | null;
  initialMessages: MessageView[];
  /** Posse inicial vinda do server. Pode mudar em runtime via conv_event. */
  initialAssignedUserId: string | null;
  initialAssignedUserName: string | null;
  /** Id do user logado pra discriminar self vs outro nas ações. */
  sessionUserId: string;
  /** Contact da conversa tem ao menos 1 SurveyResponse — habilita botão Pesquisa. */
  hasResponses: boolean;
  /** Lead vinculado à conversa (pode não existir). Habilita os botões ganho/perdido. */
  leadId: string | null;
  leadStage: string | null;
  leadLostReason: string | null;
}

export function ConversationView({
  conversationId,
  channel,
  aiEnabled: initialAiEnabled,
  handoffRequested: initialHandoffRequested,
  handoffSummary,
  windowClosesAt,
  initialMessages,
  initialAssignedUserId,
  initialAssignedUserName,
  sessionUserId,
  hasResponses,
  leadId,
  leadStage,
  leadLostReason,
}: Props) {
  const [messages, setMessages] = useState<MessageView[]>(initialMessages);
  const [assignedUserId, setAssignedUserId] = useState<string | null>(
    initialAssignedUserId,
  );
  const [assignedUserName, setAssignedUserName] = useState<string | null>(
    initialAssignedUserName,
  );
  // aiEnabled e handoffRequested ficam aqui (não em ConversationActions) pra
  // que o Composer reaja a mudanças sem precisar de refresh — ex: quando o
  // próprio claim auto-pausa a IA.
  const [aiEnabled, setAiEnabled] = useState(initialAiEnabled);
  const [handoffRequested, setHandoffRequested] = useState(
    initialHandoffRequested,
  );
  const windowDate = windowClosesAt ? new Date(windowClosesAt) : null;
  const aiInControl = aiEnabled && !handoffRequested;

  const onMsgNotif = useCallback(
    async (messageId: string) => {
      // Conversa aberta na tela: re-zera o contador (msg_new chega tanto de
      // inbound — emitido no flush — quanto de outbound).
      void fetch(`/api/conversations/${conversationId}/read`, { method: "POST" }).catch(
        () => {},
      );
      if (messages.some((m) => m.id === messageId)) return;
      const lastId = messages[messages.length - 1]?.id;
      const url = lastId
        ? `/api/conversations/${conversationId}/messages?since=${lastId}`
        : `/api/conversations/${conversationId}/messages`;
      try {
        const r = await fetch(url);
        if (!r.ok) return;
        const body = (await r.json()) as { messages: MessageView[] };
        if (body.messages.length === 0) return;
        setMessages((prev) => {
          const seen = new Set(prev.map((m) => m.id));
          const additions = body.messages.filter((m) => !seen.has(m.id));
          return additions.length ? [...prev, ...additions] : prev;
        });
      } catch {
        // silencioso
      }
    },
    [conversationId, messages],
  );

  const onConvEvent = useCallback(
    (payload: ConvEventClientPayload) => {
      if (payload.type === "claim") {
        setAssignedUserId(payload.userId);
        setAssignedUserName(payload.userName);
        if (payload.aiPausedByClaim) setAiEnabled(false);
        if (payload.userId !== sessionUserId) {
          toast.info(
            `${payload.userName ?? "Outro atendente"} assumiu esta conversa.`,
          );
        }
      } else if (payload.type === "release") {
        setAssignedUserId(null);
        setAssignedUserName(null);
      } else if (payload.type === "window_warning") {
        toast.warning(
          `Janela 24h fecha em ${payload.minutesLeft}min — responda agora.`,
          { duration: 15_000 },
        );
        playWindowWarningSound();
      }
    },
    [sessionUserId],
  );

  useConversationStream(conversationId, onMsgNotif, onConvEvent);

  return (
    <>
      <div className="flex items-center gap-2 mb-3 flex-wrap">
        {channelHasMessagingWindow(channel) && <WindowCountdown windowClosesAt={windowDate} />}
        <ConversationActions
          conversationId={conversationId}
          aiEnabled={aiEnabled}
          handoffRequested={handoffRequested}
          onAiEnabledChange={setAiEnabled}
          onHandoffRequestedChange={setHandoffRequested}
          assignedUserId={assignedUserId}
          assignedUserName={assignedUserName}
          sessionUserId={sessionUserId}
          onOwnershipChange={(next) => {
            setAssignedUserId(next.assignedUserId);
            setAssignedUserName(next.assignedUserName);
          }}
        />
        {channel === "whatsapp_cloud" && (
          <WhatsAppBlockAction
            conversationId={conversationId}
            onAiPaused={() => setAiEnabled(false)}
          />
        )}
        <SurveyResponsesDrawer
          conversationId={conversationId}
          hasResponses={hasResponses}
        />
        {leadId && (
          <LeadOutcomeActions
            leadId={leadId}
            conversationId={conversationId}
            initialStage={leadStage ?? "new"}
            initialLostReason={leadLostReason}
            onAiPaused={() => setAiEnabled(false)}
          />
        )}
      </div>

      {handoffRequested && (
        <HandoffPanel
          conversationId={conversationId}
          summary={handoffSummary}
          assignedToName={assignedUserName}
        />
      )}

      <MessagesPane messages={messages} />

      <Composer
        conversationId={conversationId}
        channel={channel}
        windowClosesAt={windowDate}
        aiInControl={aiInControl}
      />
    </>
  );
}
