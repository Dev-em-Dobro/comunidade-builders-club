-- CreateTable
CREATE TABLE "FollowupCadenceStep" (
    "id" TEXT NOT NULL,
    "step" INTEGER NOT NULL,
    "metaName" TEXT,
    "language" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "FollowupCadenceStep_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "FollowupCadenceStep_step_key" ON "FollowupCadenceStep"("step");

-- Seed das 3 linhas fixas (sem template configurado ainda)
INSERT INTO "FollowupCadenceStep" ("id", "step", "createdAt", "updatedAt") VALUES
  ('foll_cadence_step_1', 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('foll_cadence_step_2', 2, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('foll_cadence_step_3', 3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
