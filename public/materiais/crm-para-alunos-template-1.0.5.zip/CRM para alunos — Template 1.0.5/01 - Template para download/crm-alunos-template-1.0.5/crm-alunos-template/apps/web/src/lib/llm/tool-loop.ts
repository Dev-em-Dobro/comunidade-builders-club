/**
 * Loop de tools com várias idas e voltas no MESMO turno.
 *
 * O round-trip do get_checkout_link (flush.ts) faz 1 ida e volta e a 2ª
 * chamada vai sem tools. O agendamento precisa encadear (ex.: consultar
 * horários → paciente já escolheu → reservar), então aqui a IA pode chamar
 * tools "locais" várias vezes até responder em texto ou bater `maxSteps`.
 *
 * Tools que o loop NÃO trata (ex.: request_handoff) encerram o loop e ficam
 * em `toolUses` da resposta final pro chamador decidir.
 */
import type { LLMResponse, LLMToolUse, LLMTurn } from "./types";

export interface ToolLoopArgs {
  first: LLMResponse;
  messages: LLMTurn[];
  /** true = este loop executa a tool. */
  handles: (name: string) => boolean;
  execute: (call: LLMToolUse) => Promise<string>;
  /** Nova chamada ao LLM com o histórico ampliado (com tools habilitadas). */
  call: (messages: LLMTurn[]) => Promise<LLMResponse>;
  maxSteps?: number;
}

export interface ToolLoopResult {
  resp: LLMResponse;
  steps: number;
  executed: { name: string; input: Record<string, unknown>; result: string }[];
}

function sumOpt(a?: number, b?: number): number | undefined {
  if (a == null && b == null) return undefined;
  return Number(((a ?? 0) + (b ?? 0)).toFixed(6));
}

export async function runToolLoop(args: ToolLoopArgs): Promise<ToolLoopResult> {
  const maxSteps = args.maxSteps ?? 4;
  const history = [...args.messages];
  const executed: ToolLoopResult["executed"] = [];
  let resp = args.first;
  let total = { ...args.first };
  let lastText = args.first.text.trim();
  let steps = 0;

  while (steps < maxSteps) {
    const uses = resp.toolUses ?? [];
    // Tool não-local (handoff) tem prioridade: devolve pro chamador.
    if (uses.some((u) => !args.handles(u.name))) break;
    const call = uses.find((u) => args.handles(u.name));
    if (!call) break;

    const result = await args.execute(call);
    executed.push({ name: call.name, input: call.input, result });
    history.push(
      { role: "assistant", content: resp.text ?? "", toolUse: { id: call.id, name: call.name, input: call.input } },
      { role: "tool", content: "", toolResult: { toolUseId: call.id, content: result } },
    );
    steps++;

    resp = await args.call(history);
    total = {
      ...resp,
      tokensIn: (total.tokensIn ?? 0) + (resp.tokensIn ?? 0),
      tokensOut: (total.tokensOut ?? 0) + (resp.tokensOut ?? 0),
      tokensCached: (total.tokensCached ?? 0) + (resp.tokensCached ?? 0),
      costUsd: sumOpt(total.costUsd, resp.costUsd),
    };
    if (resp.text.trim()) lastText = resp.text.trim();
  }

  // Remove chamadas locais pendentes (estourou maxSteps) — só sobra o que o
  // chamador precisa tratar (ex.: request_handoff).
  const remaining = (resp.toolUses ?? []).filter((u) => !args.handles(u.name));
  // Nunca engole o turno: se a última resposta veio vazia, usa o último texto útil.
  const text = resp.text.trim() || lastText;
  return {
    resp: { ...total, text, toolUses: remaining.length ? remaining : undefined },
    steps,
    executed,
  };
}
