import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import { CourseForm } from "../course-form";
import { deleteCourse } from "../actions";

export const dynamic = "force-dynamic";

export default async function EditCoursePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const course = await prisma.course
    .findUnique({ where: { id } })
    .catch(() => null);
  if (!course) notFound();

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Editar curso
        </h1>
      </header>

      <CourseForm
        initial={{
          id: course.id,
          name: course.name,
          slug: course.slug,
          price: course.priceCents / 100,
          active: course.active,
          checkoutUrl: course.checkoutUrl,
          description: course.description,
          guaranteePolicy: course.guaranteePolicy,
          paymentMethods: course.paymentMethods,
        }}
      />

      <form
        action={deleteCourse.bind(null, course.id)}
        className="mt-10 border-t border-border pt-6"
      >
        <Button type="submit" variant="destructive" size="sm">
          <Trash2 className="size-4" /> Excluir curso
        </Button>
      </form>
    </div>
  );
}
