"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { CheckCircle2, AlertCircle, Loader2, QrCode, Power, RefreshCw, Unplug } from "lucide-react";
import { setWhatsappQrEnabled } from "../actions";

type ChannelStatus = "connected" | "needs_verification" | "missing_credentials" | "error" | "unknown";
interface SessionState { status: ChannelStatus; message?: string; webhookUrl?: string }

const STATUS_LABEL: Record<ChannelStatus, string> = {
  connected: "Conectado",
  needs_verification: "Aguardando QR",
  missing_credentials: "Falta configurar",
  error: "Erro",
  unknown: "Verificando…",
};

/** O QR do WhatsApp muda a cada ~20s; o pareamento desiste depois de 3 min sem leitura. */
const POLL_MS = 3000;
const QR_REFRESH_MS = 18000;
const PAIRING_TIMEOUT_MS = 180000;

async function getJson<T>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, { cache: "no-store", ...init });
  return (await r.json().catch(() => ({}))) as T;
}

/**
 * Fluxo completo do WhatsApp via QR num card só:
 * Conectar → QR na tela (renova sozinho) → ao ler, liga o recebimento automaticamente.
 */
export function WhatsappQrCard({ initialEnabled }: { initialEnabled: boolean }) {
  const [state, setState] = useState<SessionState | null>(null);
  const [enabled, setEnabled] = useState(initialEnabled);
  const [pairing, setPairing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [qrSrc, setQrSrc] = useState<string | null>(null);
  const qrRef = useRef<string | null>(null);

  const replaceQr = useCallback((next: string | null) => {
    if (qrRef.current) URL.revokeObjectURL(qrRef.current);
    qrRef.current = next;
    setQrSrc(next);
  }, []);

  const loadStatus = useCallback(async (): Promise<SessionState | null> => {
    const j = await getJson<{ state?: SessionState; error?: string }>("/api/sessions/whatsapp-qr/status");
    if (j.state) setState(j.state);
    return j.state ?? null;
  }, []);

  const loadQr = useCallback(async (): Promise<boolean> => {
    const r = await fetch("/api/sessions/whatsapp-qr/qr", { cache: "no-store" });
    if (!r.ok) {
      const j = (await r.json().catch(() => ({}))) as { error?: string };
      // Já conectado entre uma checagem e outra: o polling resolve.
      if (!j.error?.includes("já está conectado")) toast.error(j.error ?? "QR indisponível");
      return false;
    }
    replaceQr(URL.createObjectURL(await r.blob()));
    return true;
  }, [replaceQr]);

  const changeEnabled = useCallback(async (next: boolean, silent = false) => {
    setBusy(true);
    const res = await setWhatsappQrEnabled(next);
    setBusy(false);
    if (!res.ok) { toast.error(res.error ?? "Falha ao salvar"); return; }
    setEnabled(next);
    if (!silent) toast.success(next ? "Recebimento ativado" : "Recebimento pausado");
  }, []);

  // Estado inicial ao abrir a página.
  useEffect(() => {
    let alive = true;
    getJson<{ state?: SessionState }>("/api/sessions/whatsapp-qr/status")
      .then((j) => { if (alive && j.state) setState(j.state); })
      .catch(() => undefined);
    const qr = qrRef;
    return () => {
      alive = false;
      if (qr.current) URL.revokeObjectURL(qr.current);
    };
  }, []);

  // Durante o pareamento: confere o status a cada 3s e renova o QR antes de expirar.
  useEffect(() => {
    if (!pairing) return;
    const startedAt = Date.now();
    let lastQr = startedAt;
    let stopped = false;
    const timer = setInterval(async () => {
      if (stopped) return;
      const s = await loadStatus().catch(() => null);
      if (stopped) return;
      if (s?.status === "connected") {
        stopped = true;
        setPairing(false);
        replaceQr(null);
        if (!enabled) await changeEnabled(true, true);
        toast.success("WhatsApp conectado. O CRM já está recebendo mensagens.");
        return;
      }
      if (Date.now() - startedAt > PAIRING_TIMEOUT_MS) {
        stopped = true;
        setPairing(false);
        replaceQr(null);
        toast.error("O QR expirou sem leitura. Clique em Conectar WhatsApp para tentar de novo.");
        return;
      }
      if (Date.now() - lastQr > QR_REFRESH_MS) {
        lastQr = Date.now();
        await loadQr().catch(() => false);
      }
    }, POLL_MS);
    return () => { stopped = true; clearInterval(timer); };
  }, [pairing, enabled, loadStatus, loadQr, changeEnabled, replaceQr]);

  async function connect() {
    setBusy(true);
    try {
      const j = await getJson<{ state?: SessionState; error?: string }>("/api/sessions/whatsapp-qr/ensure", { method: "POST" });
      if (!j.state) { toast.error(j.error ?? "Falha ao preparar a sessão"); return; }
      setState(j.state);
      if (j.state.status === "connected") {
        if (!enabled) await changeEnabled(true, true);
        toast.success("Este número já está conectado.");
        return;
      }
      if (j.state.status === "missing_credentials" || j.state.status === "error") {
        toast.error(j.state.message ?? "Configure o WhatsApp via QR antes de conectar.");
        return;
      }
      if (await loadQr()) setPairing(true);
    } catch (e) {
      toast.error(String((e as Error)?.message ?? e));
    } finally {
      setBusy(false);
    }
  }

  function cancel() {
    setPairing(false);
    replaceQr(null);
  }

  async function disconnect() {
    const ok = window.confirm(
      "Desconectar este número do CRM?\n\n" +
        "O WhatsApp sai dos aparelhos conectados e o CRM para de receber e enviar mensagens por ele.\n\n" +
        "Nada é apagado: agentes, conversas, contatos, consultas e pedidos continuam no CRM. " +
        "Para voltar, clique em Conectar WhatsApp e leia o QR de novo (o mesmo número ou outro).",
    );
    if (!ok) return;
    setBusy(true);
    try {
      const j = await getJson<{ ok?: boolean; state?: SessionState; error?: string }>("/api/sessions/whatsapp-qr/logout", {
        method: "POST",
      });
      if (j.state) setState(j.state);
      if (!j.ok) {
        toast.error(j.state?.message ?? j.error ?? "Não foi possível desconectar.");
        return;
      }
      replaceQr(null);
      toast.success("Número desconectado. Agentes e conversas continuam no CRM — conecte de novo quando quiser.");
    } catch (e) {
      toast.error(String((e as Error)?.message ?? e));
    } finally {
      setBusy(false);
    }
  }

  const status = state?.status ?? "unknown";
  const connected = status === "connected";
  const badgeColor = connected
    ? "bg-success/15 text-success border-success/30"
    : status === "missing_credentials"
      ? "bg-warning/15 text-warning border-warning/30"
      : status === "error"
        ? "bg-destructive/15 text-destructive border-destructive/30"
        : "bg-muted text-muted-foreground border-border";

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-3">
          <div>
            <CardTitle className="text-base">WhatsApp via QR (não oficial)</CardTitle>
            <CardDescription>Conecte o número lendo um QR code. Sem aprovação da Meta.</CardDescription>
          </div>
          <Badge variant="outline" className={`text-[11px] ${badgeColor}`}>
            {connected ? <CheckCircle2 className="size-3 mr-1" /> : <AlertCircle className="size-3 mr-1" />}
            {STATUS_LABEL[status]}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <ol className="grid gap-2 text-sm sm:grid-cols-3">
          <Step n={1} done={connected || pairing} label="Gerar o QR" />
          <Step n={2} done={connected} label="Ler com o celular" />
          <Step n={3} done={connected && enabled} label="Receber mensagens" />
        </ol>

        {state?.message && <p className="text-sm text-muted-foreground">{state.message}</p>}

        {status === "missing_credentials" && (
          <p className="text-sm">
            Preencha as credenciais em <Link className="underline" href="/settings/whatsapp-qr">Configurações → WhatsApp via QR</Link> (ou nas variáveis WAQR_* do servidor).
          </p>
        )}

        {connected && (
          <div className={`flex flex-wrap items-center justify-between gap-3 rounded-md border p-3 ${enabled ? "border-success/30 bg-success/10" : "border-warning/40 bg-warning/10"}`}>
            <p className="text-sm">
              {enabled
                ? "Recebendo mensagens. Novas conversas aparecem em Conversas."
                : "Número conectado, mas o recebimento está pausado: as mensagens são recusadas."}
            </p>
            <Button size="sm" variant={enabled ? "outline" : "default"} onClick={() => changeEnabled(!enabled)} disabled={busy}>
              {busy ? <Loader2 className="size-4 animate-spin" /> : <Power className="size-4" />}
              {enabled ? "Pausar recebimento" : "Ativar recebimento"}
            </Button>
          </div>
        )}

        {connected && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-md border border-border p-3">
            <p className="text-xs text-muted-foreground">
              Trocar de número ou tirar este do CRM? Desconectar não apaga agentes, conversas nem contatos.
            </p>
            <Button size="sm" variant="ghost" className="text-destructive" onClick={disconnect} disabled={busy}>
              {busy ? <Loader2 className="size-4 animate-spin" /> : <Unplug className="size-4" />}
              Desconectar número
            </Button>
          </div>
        )}

        {!connected && (
          <div className="flex flex-wrap gap-2">
            {!pairing ? (
              <Button onClick={connect} disabled={busy || status === "missing_credentials"}>
                {busy ? <Loader2 className="size-4 animate-spin" /> : <QrCode className="size-4" />}
                Conectar WhatsApp
              </Button>
            ) : (
              <Button variant="outline" onClick={cancel}>Cancelar</Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => void loadStatus()} disabled={busy}>
              <RefreshCw className="size-4" /> Atualizar status
            </Button>
          </div>
        )}

        {pairing && qrSrc && (
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            {/* eslint-disable-next-line @next/next/no-img-element -- blob local do QR, não passa pelo otimizador */}
            <img src={qrSrc} alt="QR code para conectar o WhatsApp" className="size-56 shrink-0 rounded border bg-white p-2" />
            <div className="space-y-2 text-sm">
              <p className="font-medium">No celular do número de atendimento:</p>
              <ol className="list-decimal ml-5 space-y-1 text-muted-foreground">
                <li>Abra o WhatsApp → <strong>Aparelhos conectados</strong>.</li>
                <li>Toque em <strong>Conectar aparelho</strong> e aponte para o QR.</li>
              </ol>
              <p className="flex items-center gap-2 text-xs text-muted-foreground">
                <Loader2 className="size-3 animate-spin" /> Aguardando a leitura. O QR se renova sozinho.
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function Step({ n, done, label }: { n: number; done: boolean; label: string }) {
  return (
    <li className={`flex items-center gap-2 rounded-md border px-3 py-2 ${done ? "border-success/30 text-success" : "text-muted-foreground"}`}>
      {done ? <CheckCircle2 className="size-4" /> : <span className="grid size-4 place-items-center rounded-full border text-[10px]">{n}</span>}
      {label}
    </li>
  );
}
