import { notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { dayLabel, zonedParts } from "@/lib/scheduling/time";
import { schedulingTimezone } from "@/lib/scheduling/timezone";
import { formatDayIntervals, normalizeIntervals, normalizeWorkingHours } from "@/lib/scheduling/working-hours";
import { Trash2, X } from "lucide-react";
import { ProfessionalForm } from "../professional-form";
import { DayOverridesForm } from "../day-overrides-form";
import { deleteDayOverride, deleteProfessional } from "../actions";
import { AgentHeader, requireAgentOfRole } from "../../_agent";

export const dynamic = "force-dynamic";

export default async function EditProfessionalPage({ params }: { params: Promise<{ id: string; pid: string }> }) {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const { id: agentId, pid } = await params;
  const agent = await requireAgentOfRole(agentId, "scheduling");
  const p = await prisma.professional.findFirst({ where: { id: pid, agentSessionId: agent.id } }).catch(() => null);
  if (!p) notFound();
  const today = zonedParts(new Date(), schedulingTimezone()).date;
  const overrides = await prisma.professionalDayOverride
    .findMany({
      where: { professionalId: p.id, date: { gte: today } },
      orderBy: { date: "asc" },
      take: 200,
    })
    .catch(() => []);
  const existing = overrides.map((o) => {
    const intervals = normalizeIntervals(o.intervals);
    return {
      id: o.id,
      date: o.date,
      intervals,
      closed: intervals.length === 0,
      note: o.note,
    };
  });

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader agent={agent} active="professionals" description={`Editar profissional: ${p.name}`} />
      <div className="space-y-10">
        <section>
          <ProfessionalForm
            agentId={agent.id}
            initial={{
              id: p.id,
              name: p.name,
              specialty: p.specialty,
              description: p.description,
              durationMin: p.durationMin,
              active: p.active,
              workingHours: normalizeWorkingHours(p.workingHours),
            }}
          />
        </section>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Exceções — folgas, feriados e dias extras</CardTitle>
            <CardDescription>
              Num dia com exceção, vale o que estiver aqui em vez da semana padrão. O agente só oferece horários livres
              depois de descontar as exceções e as consultas já marcadas.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <DayOverridesForm
              agentId={agent.id}
              professionalId={p.id}
              today={today}
              existing={existing.map((e) => ({
                date: e.date,
                closed: e.closed,
              }))}
            />

            <div className="space-y-2">
              <p className="text-sm font-medium">Próximas exceções</p>
              {existing.length === 0 ? (
                <p className="text-sm text-muted-foreground">Nenhuma — vale a semana padrão todos os dias.</p>
              ) : (
                <ul className="divide-y divide-border rounded-md border border-border">
                  {existing.map((e) => (
                    <li key={e.id} className="flex items-center justify-between gap-3 px-3 py-2 text-sm">
                      <span className="min-w-0">
                        <span className="font-medium capitalize">{dayLabel(e.date)}</span>{" "}
                        <span className={e.closed ? "text-destructive" : "text-muted-foreground"}>
                          {e.closed ? "não atende" : formatDayIntervals(e.intervals)}
                        </span>
                        {e.note && <span className="text-muted-foreground"> · {e.note}</span>}
                      </span>
                      <form action={deleteDayOverride.bind(null, agent.id, p.id, e.id)}>
                        <Button type="submit" variant="ghost" size="icon-sm" aria-label="Remover exceção">
                          <X className="size-4" />
                        </Button>
                      </form>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </CardContent>
        </Card>

        <form action={deleteProfessional.bind(null, agent.id, p.id)} className="border-t border-border pt-6 space-y-2">
          <p className="text-xs text-muted-foreground">
            As consultas já marcadas continuam no CRM. Para só tirar do agente, desative.
          </p>
          <Button type="submit" variant="destructive" size="sm">
            <Trash2 className="size-4" /> Excluir profissional
          </Button>
        </form>
      </div>
    </div>
  );
}
