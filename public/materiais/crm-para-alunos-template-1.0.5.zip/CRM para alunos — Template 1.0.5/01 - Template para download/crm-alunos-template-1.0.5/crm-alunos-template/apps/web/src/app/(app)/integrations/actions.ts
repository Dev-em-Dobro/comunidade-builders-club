"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { secretsKeyConfigured } from "@/lib/crypto/secrets";
import { disconnectGoogle, GoogleApiError, saveClientCredentials } from "@/lib/google/oauth";
import { createSpreadsheet, DEFAULT_TAB, ensureTabAndHeader, parseSpreadsheetId } from "@/lib/google/sheets";
import { syncPendingToSheet } from "@/lib/scheduling/service";
import { businessConfig } from "@/lib/config";

export interface FormResult {
  error?: string;
  message?: string;
}

async function isAdmin(): Promise<boolean> {
  const session = await auth();
  return session?.user?.role === "admin";
}

function googleErrorMessage(err: unknown): string {
  if (err instanceof GoogleApiError) {
    if (err.status === 403) return "O Google recusou o acesso. Confira se a API está ativada no projeto do Google Cloud e se a conta conectada tem permissão de edição.";
    if (err.status === 404) return "Planilha não encontrada. Confira o link e se a conta conectada tem acesso a ela.";
    return `Erro do Google: ${err.message}`;
  }
  return String((err as Error)?.message ?? err);
}

function revalidateAll() {
  revalidatePath("/integrations");
  revalidatePath("/integrations/google-sheets");
}

export async function saveGoogleClient(_prev: FormResult, form: FormData): Promise<FormResult> {
  if (!(await isAdmin())) return { error: "Somente o administrador pode alterar integrações." };
  if (!secretsKeyConfigured()) return { error: "Configure SECRETS_KEY no servidor antes de salvar." };
  const clientId = String(form.get("clientId") ?? "").trim();
  const clientSecret = String(form.get("clientSecret") ?? "").trim();
  if (!/^[\w.-]+\.apps\.googleusercontent\.com$/.test(clientId)) {
    return { error: "Client ID inválido — ele termina com .apps.googleusercontent.com" };
  }
  if (clientSecret && /\s/.test(clientSecret)) return { error: "Client Secret não pode conter espaços." };
  try {
    await saveClientCredentials(clientId, clientSecret || null);
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
  revalidateAll();
  return { message: "Credenciais salvas. Agora clique em “Conectar com Google”." };
}

export async function disconnectGoogleAction(): Promise<void> {
  if (!(await isAdmin())) throw new Error("Acesso negado");
  await disconnectGoogle();
  revalidateAll();
}

export async function saveSheetsTarget(_prev: FormResult, form: FormData): Promise<FormResult> {
  if (!(await isAdmin())) return { error: "Somente o administrador pode alterar integrações." };
  const id = parseSpreadsheetId(String(form.get("spreadsheet") ?? ""));
  const tab = String(form.get("tab") ?? "").trim() || DEFAULT_TAB;
  if (!id) return { error: "Cole o link da planilha (https://docs.google.com/spreadsheets/d/…)." };
  if (tab.length > 100) return { error: "Nome da aba muito longo." };
  try {
    const { url, title } = await ensureTabAndHeader(id, tab);
    await prisma.googleConnection.update({
      where: { id: "singleton" },
      data: { sheetsSpreadsheetId: id, sheetsSpreadsheetUrl: url, sheetsTabName: tab },
    });
    revalidateAll();
    return { message: `Planilha “${title}” vinculada. Novas consultas entram na aba “${tab}”.` };
  } catch (err) {
    return { error: googleErrorMessage(err) };
  }
}

export async function createSheetsSpreadsheet(): Promise<FormResult> {
  if (!(await isAdmin())) return { error: "Somente o administrador pode alterar integrações." };
  try {
    const { id, url } = await createSpreadsheet(`Agendamentos — ${businessConfig().brandName}`);
    await prisma.googleConnection.update({
      where: { id: "singleton" },
      data: { sheetsSpreadsheetId: id, sheetsSpreadsheetUrl: url, sheetsTabName: DEFAULT_TAB },
    });
    revalidateAll();
    return { message: "Planilha criada no seu Google Drive e vinculada." };
  } catch (err) {
    return { error: googleErrorMessage(err) };
  }
}

export async function clearSheetsTarget(): Promise<void> {
  if (!(await isAdmin())) throw new Error("Acesso negado");
  await prisma.googleConnection.update({
    where: { id: "singleton" },
    data: { sheetsSpreadsheetId: null, sheetsSpreadsheetUrl: null, sheetsTabName: null },
  });
  revalidateAll();
}

export async function syncPendingSheets(): Promise<FormResult> {
  if (!(await isAdmin())) return { error: "Somente o administrador pode alterar integrações." };
  try {
    const { sent, failed } = await syncPendingToSheet();
    revalidateAll();
    if (!sent && !failed) return { message: "Nenhuma consulta pendente de envio." };
    return failed
      ? { error: `${sent} enviada(s), ${failed} com erro. Veja os logs do servidor.` }
      : { message: `${sent} consulta(s) enviada(s) para a planilha.` };
  } catch (err) {
    return { error: googleErrorMessage(err) };
  }
}
