import Redis from "ioredis";

declare global {
  // eslint-disable-next-line no-var
  var __redis: Redis | undefined;
}

/**
 * Gotcha 0.9.12: NUNCA instanciar Redis no top-level — quebra `next build` (Collecting page data).
 * Lazy init no primeiro uso. Singleton via globalThis pra sobreviver HMR em dev.
 */
export function getRedis(): Redis {
  if (globalThis.__redis) return globalThis.__redis;

  const url = process.env.REDIS_URL;
  if (!url) {
    throw new Error(
      "REDIS_URL ausente. Plugin Railway expõe via ${{Redis.REDIS_URL}}. Em dev: execute docker compose up -d --wait na raiz do template",
    );
  }

  const client = new Redis(url, {
    maxRetriesPerRequest: 3,
    enableReadyCheck: true,
    lazyConnect: false,
    reconnectOnError(err) {
      // Reconnect em transient errors (failover, replica promotion)
      return err.message.includes("READONLY");
    },
  });

  client.on("error", (err) => {
    console.error(
      JSON.stringify({
        event: "redis.error",
        message: String(err?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
  });

  if (process.env.NODE_ENV !== "production") {
    globalThis.__redis = client;
  }
  return client;
}

/** True se Redis estiver configurado — útil pra decidir fallback síncrono. */
export function hasRedis(): boolean {
  return !!process.env.REDIS_URL;
}
