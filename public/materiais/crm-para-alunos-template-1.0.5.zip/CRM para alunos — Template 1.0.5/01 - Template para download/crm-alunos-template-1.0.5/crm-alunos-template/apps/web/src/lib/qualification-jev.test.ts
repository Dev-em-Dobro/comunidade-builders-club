import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { buildJevRequest, classifyWithJev, type JevInput } from "./qualification-jev";
import { jevQualificationConfig } from "./config";

const input: JevInput = {
  messages: [
    { direction: "outbound", text: "Qual seu objetivo com programação?", createdAt: new Date("2026-09-28T12:00:00Z") },
    { direction: "inbound", text: "Quero mudar de carreira, meu email é teste@example.com, CPF 123.456.789-01, telefone (11) 99999-1234", createdAt: new Date("2026-09-28T12:01:00Z") },
  ],
  courses: [{ id: "c1", name: "Programação" }],
};
const settings = { enabled: true, model: "jev-1.13.0", minConfidence: 0.8, audienceMinConfidence: 0.9, timeoutMs: 2000 };
const fetchMock = vi.fn();

function responseFor(data: JevInput = input, overrides: Record<string, string> = {}) {
  const request = buildJevRequest(data, settings.model);
  return {
    model: settings.model,
    usage: { input_tokens: 3000 },
    answers: Object.fromEntries(Object.entries(request.questions).map(([key, question]) => {
      const choice = overrides[key] ?? ({ audience: "prospect", interestLevel: "medium", budgetSignal: "unknown", decisionTimeline: "unknown" }[key] ??
        (key.startsWith("asked_") || key.startsWith("answered_") ? "none" : "no"));
      return [key, { type: "choice", choice, confidence: 0.99,
        probabilities: Object.fromEntries(Object.keys(question.criteria).map((option) => [option, option === choice ? 1 : 0])),
      }];
    })),
  };
}

beforeEach(() => {
  vi.stubEnv("TYPESAFE_API_KEY", "test-key");
  vi.stubGlobal("fetch", fetchMock);
  fetchMock.mockReset();
});
afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); vi.useRealTimers(); });

describe("Jev qualification", () => {
  it("qualifica em uma chamada e recupera respostas/horários das mensagens originais", async () => {
    fetchMock.mockResolvedValue(new Response(JSON.stringify(responseFor(input, {
      asked_objetivo: "m0", answered_objetivo: "m1", course_0: "yes", objection_preco: "yes",
    }))));
    const result = await classifyWithJev(input, settings);
    expect(fetchMock).toHaveBeenCalledTimes(1);
    expect(result.qualification).toMatchObject({ audience: "prospect", courseInterestIds: ["c1"], objections: ["preco"],
      askedFields: { objetivo: { askedAt: "2026-09-28T12:00:00.000Z", answeredAt: "2026-09-28T12:01:00.000Z", answer: input.messages[1].text.slice(0, 80) } },
    });
    expect(result.costUsd).toBeCloseTo(0.000126);
    const body = fetchMock.mock.calls[0][1].body as string;
    expect(body).not.toContain("teste@example.com");
    expect(body).not.toContain("123.456.789-01");
    expect(body).not.toContain("99999-1234");
    expect(body).toContain("[email]");
  });

  it("mantém a pergunta fora da janela e não reclassifica campos já respondidos", async () => {
    const data = { ...input, previousAsked: {
      objetivo: { askedAt: "2026-09-27T12:00:00Z" },
      nivel: { askedAt: "2026-09-27T12:01:00Z", answeredAt: "2026-09-27T12:02:00Z", answer: "zero" },
    } };
    expect(buildJevRequest(data, settings.model).questions).not.toHaveProperty("asked_nivel");
    fetchMock.mockResolvedValue(new Response(JSON.stringify(responseFor(data, { answered_objetivo: "m1" }))));
    const result = await classifyWithJev(data, settings);
    expect(result.qualification.askedFields?.objetivo?.askedAt).toBe("2026-09-27T12:00:00Z");
  });

  it.each(["audience", "interestLevel", "objection_preco", "course_0", "asked_objetivo"])("recusa baixa confiança em %s", async (field) => {
    const response = responseFor();
    response.answers[field].confidence = 0.79;
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    await expect(classifyWithJev(input, settings)).rejects.toThrow(`jev_low_confidence:${field}`);
  });

  it("aplica limiar mais alto para audiência", async () => {
    const response = responseFor();
    response.answers.audience.confidence = 0.85;
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    await expect(classifyWithJev(input, settings)).rejects.toThrow("jev_low_confidence:audience");
  });

  it("registra uso também quando a resposta aciona fallback por confiança", async () => {
    const response = responseFor();
    response.answers.audience.confidence = 0.5;
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    const onUsage = vi.fn();
    await expect(classifyWithJev(input, settings, onUsage)).rejects.toThrow("jev_low_confidence:audience");
    expect(onUsage).toHaveBeenCalledWith(expect.objectContaining({ inputTokens: 3000 }));
    expect(onUsage.mock.calls[0][0].costUsd).toBeCloseTo(0.000126);
  });

  it("confiança alta não supera probabilidade baixa da opção selecionada", async () => {
    const response = responseFor();
    response.answers.audience.probabilities = { prospect: 0.6, student: 0.4, support: 0, refund: 0 };
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    await expect(classifyWithJev(input, settings)).rejects.toThrow("jev_low_confidence:audience");
  });

  it("recusa referência a mensagem de direção incorreta", async () => {
    const response = responseFor();
    response.answers.asked_objetivo.choice = "m1";
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    await expect(classifyWithJev(input, settings)).rejects.toThrow("jev_invalid_answer:asked_objetivo");
  });

  it("recusa resposta anterior à pergunta mesmo quando os horários coincidem", async () => {
    const data = { ...input, messages: [
      { ...input.messages[1], createdAt: input.messages[0].createdAt },
      input.messages[0],
    ] };
    fetchMock.mockResolvedValue(new Response(JSON.stringify(responseFor(data, { asked_objetivo: "m1", answered_objetivo: "m0" }))));
    await expect(classifyWithJev(data, settings)).rejects.toThrow("jev_invalid_tracking:objetivo");
  });

  it("sem chave não faz chamada HTTP", async () => {
    vi.stubEnv("TYPESAFE_API_KEY", "");
    await expect(classifyWithJev(input, settings)).rejects.toThrow("jev_missing_key");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it.each(["missing", "invalid", "probabilities", "nan"])("recusa resposta %s", async (kind) => {
    const response = responseFor();
    if (kind === "missing") delete response.answers.audience;
    if (kind === "invalid") response.answers.audience.choice = "inventado";
    if (kind === "probabilities") response.answers.audience.probabilities.prospect = 0.1;
    if (kind === "nan") response.answers.audience.confidence = NaN;
    fetchMock.mockResolvedValue(new Response(JSON.stringify(response)));
    await expect(classifyWithJev(input, settings)).rejects.toThrow(/jev_invalid/);
  });

  it("recusa resposta sem pergunta anterior", async () => {
    fetchMock.mockResolvedValue(new Response(JSON.stringify(responseFor(input, { answered_objetivo: "m1" }))));
    await expect(classifyWithJev(input, settings)).rejects.toThrow("jev_invalid_tracking:objetivo");
  });

  it.each([401, 429, 500])("não repete chamada HTTP %i e não expõe o corpo do erro", async (status) => {
    fetchMock.mockResolvedValue(new Response("conteúdo privado", { status }));
    await expect(classifyWithJev(input, settings)).rejects.toThrow(`jev_http_${status}`);
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("limita o tempo inclusive durante a leitura do corpo", async () => {
    vi.useFakeTimers();
    fetchMock.mockImplementation(async (_url, options) => ({ ok: true, json: () => new Promise((_resolve, reject) => {
      options.signal.addEventListener("abort", () => reject(new Error("aborted")));
    }) }));
    const promise = classifyWithJev(input, { ...settings, timeoutMs: 100 });
    const assertion = expect(promise).rejects.toThrow("jev_timeout");
    await vi.advanceTimersByTimeAsync(100);
    await assertion;
  });
});

describe("configuração Jev", () => {
  it("habilita com chave e permite desligar", () => {
    vi.stubEnv("JEV_QUALIFICATION_ENABLED", "true");
    expect(jevQualificationConfig().enabled).toBe(true);
    vi.stubEnv("JEV_QUALIFICATION_ENABLED", "false");
    expect(jevQualificationConfig().enabled).toBe(false);
    vi.stubEnv("JEV_QUALIFICATION_ENABLED", "true");
    vi.stubEnv("TYPESAFE_API_KEY", "");
    expect(jevQualificationConfig().enabled).toBe(false);
  });
  it("usa defaults seguros para valores inválidos", () => {
    vi.stubEnv("JEV_MIN_CONFIDENCE", "0");
    vi.stubEnv("JEV_TIMEOUT_MS", "NaN");
    expect(jevQualificationConfig()).toMatchObject({ minConfidence: 0.8, timeoutMs: 2000 });
  });
});
