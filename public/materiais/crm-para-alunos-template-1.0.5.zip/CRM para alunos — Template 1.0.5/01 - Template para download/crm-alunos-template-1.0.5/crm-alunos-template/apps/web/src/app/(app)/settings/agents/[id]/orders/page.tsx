import Link from "next/link";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { DELIVERY_ROLE } from "@/lib/delivery/agent";
import {
  formatBRL,
  ORDER_STATUS_LABEL,
  PAYMENT_LABEL,
  type OrderLine,
  type OrderStatus,
  type PaymentMethod,
} from "@/lib/delivery/menu";
import { zonedParts, zonedToUtc } from "@/lib/scheduling/time";
import { schedulingTimezone } from "@/lib/scheduling/timezone";
import { ShoppingBag } from "lucide-react";
import { AgentHeader, requireAgentOfRole } from "../_agent";
import { setOrderStatus } from "./actions";
import { OrdersAutoRefresh } from "./auto-refresh";

export const dynamic = "force-dynamic";

type View = "open" | "today" | "all";
const OPEN: OrderStatus[] = ["new", "preparing", "out_for_delivery"];
/** Próximo passo de cada status (botão principal do card). */
const NEXT: Partial<Record<OrderStatus, OrderStatus>> = {
  new: "preparing",
  preparing: "out_for_delivery",
  out_for_delivery: "delivered",
};

export default async function AgentOrdersPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ view?: string }>;
}) {
  const { id } = await params;
  const agent = await requireAgentOfRole(id, DELIVERY_ROLE);
  const { view: rawView } = await searchParams;
  const view: View = rawView === "today" || rawView === "all" ? rawView : "open";
  const tz = schedulingTimezone();
  const today = zonedParts(new Date(), tz).date;

  const where: Prisma.OrderWhereInput = {
    agentSessionId: agent.id,
    ...(view === "open"
      ? { status: { in: OPEN } }
      : view === "today"
        ? { createdAt: { gte: zonedToUtc(today, "00:00", tz) } }
        : {}),
  };
  const [orders, newCount] = await Promise.all([
    prisma.order
      .findMany({ where, orderBy: { createdAt: view === "open" ? "asc" : "desc" }, take: 200 })
      .catch(() => []),
    prisma.order.count({ where: { agentSessionId: agent.id, status: "new" } }).catch(() => 0),
  ]);

  const base = `/settings/agents/${agent.id}/orders`;
  const tabs: { key: View; label: string }[] = [
    { key: "open", label: "Em aberto" },
    { key: "today", label: "Hoje" },
    { key: "all", label: "Todos" },
  ];

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <OrdersAutoRefresh newCount={newCount} />
      <AgentHeader
        agent={agent}
        active="orders"
        description="Pedidos feitos pelo agente. A lista se atualiza sozinha e toca um som quando chega pedido novo."
      >
        <div className="flex flex-wrap gap-2">
          {tabs.map((t) => (
            <Link
              key={t.key}
              href={t.key === "open" ? base : `${base}?view=${t.key}`}
              className={buttonVariants({ variant: view === t.key ? "default" : "outline", size: "sm" })}
            >
              {t.label}
            </Link>
          ))}
        </div>
      </AgentHeader>

      {orders.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <ShoppingBag className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">{view === "open" ? "Nenhum pedido em aberto" : "Nenhum pedido"}</p>
          <p className="text-sm text-muted-foreground mt-1">Os pedidos aparecem aqui assim que o cliente confirma no WhatsApp.</p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {orders.map((o) => {
            const status = o.status as OrderStatus;
            const items = (Array.isArray(o.items) ? o.items : []) as unknown as OrderLine[];
            const next = NEXT[status];
            const when = zonedParts(o.createdAt, tz);
            return (
              <Card key={o.id} className={`p-4 space-y-3 ${status === "new" ? "border-primary" : ""}`}>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <p className="font-semibold">
                      #{o.number} · {o.customerName ?? "Cliente"}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {when.date === today ? "hoje" : when.date.split("-").reverse().join("/")} às {when.time}
                    </p>
                  </div>
                  <Badge variant={status === "new" ? "default" : "outline"}>{ORDER_STATUS_LABEL[status] ?? o.status}</Badge>
                </div>

                <ul className="text-sm space-y-0.5">
                  {items.map((l, i) => (
                    <li key={i} className="flex justify-between gap-3">
                      <span>
                        {l.quantity}x {l.name}
                        {l.notes && <span className="block text-xs text-amber-600">↳ {l.notes}</span>}
                      </span>
                      <span className="whitespace-nowrap text-muted-foreground">{formatBRL(l.unitPriceCents * l.quantity)}</span>
                    </li>
                  ))}
                </ul>

                <div className="border-t border-border pt-2 text-sm space-y-0.5">
                  {o.deliveryFeeCents > 0 && (
                    <p className="flex justify-between text-muted-foreground">
                      <span>Taxa de entrega</span>
                      <span>{formatBRL(o.deliveryFeeCents)}</span>
                    </p>
                  )}
                  <p className="flex justify-between font-semibold">
                    <span>Total</span>
                    <span>{formatBRL(o.totalCents)}</span>
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {PAYMENT_LABEL[o.paymentMethod as PaymentMethod] ?? o.paymentMethod}
                    {o.changeForCents ? ` · troco para ${formatBRL(o.changeForCents)}` : ""}
                  </p>
                </div>

                <div className="text-xs space-y-0.5">
                  {o.fulfillment === "pickup" ? (
                    <p className="font-medium">Retirada no local</p>
                  ) : (
                    <p>
                      <span className="font-medium">Entrega · {o.neighborhood}</span>
                      <span className="block text-muted-foreground">{o.address}</span>
                    </p>
                  )}
                  {o.notes && <p className="text-amber-600">Obs.: {o.notes}</p>}
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  {next && (
                    <form action={setOrderStatus.bind(null, agent.id, o.id, next)}>
                      <Button type="submit" size="sm">
                        {ORDER_STATUS_LABEL[next]}
                      </Button>
                    </form>
                  )}
                  {OPEN.includes(status) && (
                    <form action={setOrderStatus.bind(null, agent.id, o.id, "cancelled")}>
                      <Button type="submit" size="sm" variant="ghost" className="text-destructive">
                        Cancelar
                      </Button>
                    </form>
                  )}
                  {o.conversationId && (
                    <Link href={`/conversations/${o.conversationId}`} className="ml-auto text-xs underline">
                      Conversa
                    </Link>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
