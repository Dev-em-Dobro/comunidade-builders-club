import type { Worker, Job } from "bullmq";
import { createWorker } from "./worker-factory";
import { QUEUE_NAMES, type QueueName } from "./types";
import { slaQueueProcessor } from "./workers/sla";
import { notifyProcessor } from "./workers/notify";
import { window24hScanProcessor } from "./workers/window24h";
import { followupProcessor } from "./workers/followup";
import { qualifyProcessor } from "./workers/qualify";
import { reengagementScanProcessor } from "./workers/reengagement";
import { windowWarningProcessor } from "./workers/window-warning";
import { auditProcessor } from "./workers/audit";
import { launchTransitionsProcessor } from "./workers/launch-transitions";
import { outWindowFollowupProcessor } from "./workers/out-window-followup";

/** Processadores reais por fila. Filas sem entrada usam o placeholder. */
const PROCESSORS: Partial<Record<QueueName, (job: Job) => Promise<void>>> = {
  sla: slaQueueProcessor,
  notify: notifyProcessor,
  window24h: window24hScanProcessor,
  followup: followupProcessor,
  qualify: qualifyProcessor,
  reengagement: reengagementScanProcessor,
  "out-window-followup": outWindowFollowupProcessor,
  "window-warning": windowWarningProcessor,
  audit: auditProcessor,
  "launch-transitions": launchTransitionsProcessor,
};

declare global {
  var __bullWorkers: Worker[] | undefined;
}

/**
 * Processador placeholder da Parte 1 — só registra que o job foi consumido.
 * As próximas partes substituem por processadores reais (SLA, follow-up, etc.).
 */
function placeholderProcessor(queue: QueueName) {
  return async (job: Job) => {
    console.log(
      JSON.stringify({
        event: "job.placeholder",
        queue,
        jobId: job.id,
        jobName: job.name,
        at: new Date().toISOString(),
      }),
    );
  };
}

/** Inicia 1 worker por fila. Idempotente — não duplica em chamadas repetidas. */
export function startWorkers(): Worker[] {
  if (globalThis.__bullWorkers) return globalThis.__bullWorkers;
  const workers = QUEUE_NAMES.map((name) =>
    createWorker(name, PROCESSORS[name] ?? placeholderProcessor(name)),
  );
  globalThis.__bullWorkers = workers;
  return workers;
}

/** Fecha todos os workers. Usado em teardown de teste e shutdown. */
export async function stopWorkers(): Promise<void> {
  if (!globalThis.__bullWorkers) return;
  await Promise.all(globalThis.__bullWorkers.map((w) => w.close()));
  globalThis.__bullWorkers = undefined;
}
