"use client";

import { useState, useTransition, useRef, useEffect, useLayoutEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Send, Loader2, Paperclip, X, ImageIcon, AudioLines } from "lucide-react";
import { TemplatePicker } from "./template-picker";
import { inspectOutgoingMedia } from "@/lib/channels/outgoing-media";
import { channelHasMessagingWindow } from "@/lib/window24h";

interface Props {
  conversationId: string;
  channel: string;
  /** Quando a janela 24h fecha. null = fora da janela. */
  windowClosesAt: Date | null;
  /** True = IA está controlando; composer não aparece (cenário reativo). */
  aiInControl: boolean;
}

const MAX_LEN = 4096;
const MIN_PX = 44;
const MAX_PX = 160;
const draftKey = (id: string) => `composer-draft:${id}`;

/** Wrap localStorage com try/catch (modo privado, quota cheia, SSR). */
function safeGetDraft(id: string): string {
  try {
    return localStorage.getItem(draftKey(id)) ?? "";
  } catch {
    return "";
  }
}
function safeSetDraft(id: string, value: string): void {
  try {
    if (value) localStorage.setItem(draftKey(id), value);
    else localStorage.removeItem(draftKey(id));
  } catch {
    // silencioso
  }
}

export function Composer({ conversationId, channel, windowClosesAt, aiInControl }: Props) {
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [pending, startTransition] = useTransition();
  const taRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  // Hidrata rascunho no mount (só client — evita hydration mismatch).
  useEffect(() => {
    const saved = safeGetDraft(conversationId);
    if (saved) setText(saved);
  }, [conversationId]);

  // Persiste rascunho a cada mudança de texto.
  useEffect(() => {
    safeSetDraft(conversationId, text);
  }, [text, conversationId]);

  // Auto-grow do textarea via altura computada do scrollHeight.
  useLayoutEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = `${Math.min(Math.max(ta.scrollHeight, MIN_PX), MAX_PX)}px`;
  }, [text]);

  // Cenário reativo (decisão #1 do spec): só renderiza se IA pausada/handoff.
  if (aiInControl) return null;

  // Sem dependência de Date.now() no render — calculado UMA vez por render
  // pra evitar bugs de timing. Composer re-renderiza em mudanças de state.
  // Canais sem janela de 24h (WhatsApp via QR) ficam sempre liberados.
  const windowOpen =
    !channelHasMessagingWindow(channel) ||
    (windowClosesAt != null && windowClosesAt.getTime() > Date.now());
  const selectedKind = file ? inspectOutgoingMedia(file).kind : null;

  if (!windowOpen) {
    return <TemplatePicker conversationId={conversationId} />;
  }

  function send() {
    const t = text.trim();
    if ((!t && !file) || pending) return;
    if (selectedKind === "image" && t.length > 1024) {
      toast.error("A legenda da imagem pode ter no máximo 1024 caracteres.");
      return;
    }
    startTransition(async () => {
      try {
        let r: Response;
        if (file) {
          const info = inspectOutgoingMedia(file);
          const form = new FormData();
          form.set("file", file);
          if (info.kind === "image" && t) form.set("caption", t);
          r = await fetch(`/api/conversations/${conversationId}/send-media`, {
            method: "POST",
            body: form,
          });
        } else {
          r = await fetch(`/api/conversations/${conversationId}/send`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: t }),
          });
        }
        if (!r.ok) {
          const body = (await r.json().catch(() => ({}))) as {
            error?: string;
            detail?: string;
          };
          if (
            body.error === "window_closed" ||
            body.error === "window_closed_meta"
          ) {
            toast.error(
              "Janela 24h fechada — lead precisa enviar uma msg primeiro.",
            );
            return;
          }
          if (body.error === "text_too_long") {
            toast.error(`Mensagem longa demais (máx ${MAX_LEN}).`);
            return;
          }
          if (body.error === "owned_by_other") {
            toast.error("Esta conversa está com outro atendente.");
            return;
          }
          if (body.error === "ai_active") {
            toast.error("Pause a IA antes de enviar mídia.");
            return;
          }
          throw new Error(body.detail ?? body.error ?? `HTTP ${r.status}`);
        }
        if (!file || inspectOutgoingMedia(file).kind === "image") {
          setText("");
          safeSetDraft(conversationId, "");
        }
        setFile(null);
        if (fileRef.current) fileRef.current.value = "";
        taRef.current?.focus();
        // SSE traz a msg de volta — sem optimistic update.
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  function onKeyDown(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  }

  return (
    <div className="border-t bg-background p-3 sticky bottom-0">
      {file && (
        <div className="mb-2 flex items-center gap-2 rounded border px-2 py-1.5 text-xs max-w-full">
          {selectedKind === "image" ? <ImageIcon className="size-4 shrink-0" /> : <AudioLines className="size-4 shrink-0" />}
          <span className="truncate">{file.name}</span>
          <Button
            type="button"
            size="icon"
            variant="ghost"
            className="size-6 ml-auto shrink-0"
            onClick={() => {
              setFile(null);
              if (fileRef.current) fileRef.current.value = "";
            }}
            aria-label="Remover anexo"
            disabled={pending}
          >
            <X className="size-3" />
          </Button>
        </div>
      )}
      <div className="flex gap-2 items-end">
        {channel === "whatsapp_cloud" && (
          <>
            <input
              ref={fileRef}
              type="file"
              accept=".jpg,.jpeg,.png,.mp3,.m4a,.mp4,.aac,.ogg,.amr"
              className="sr-only"
              onChange={(event) => {
                const next = event.target.files?.[0];
                if (!next) return;
                try {
                  inspectOutgoingMedia(next);
                  setFile(next);
                } catch (error) {
                  toast.error((error as Error).message);
                  event.target.value = "";
                }
              }}
              aria-label="Selecionar imagem ou áudio"
            />
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => fileRef.current?.click()}
              disabled={pending}
              aria-label="Anexar imagem ou áudio"
              title="Anexar imagem ou áudio"
            >
              <Paperclip className="size-4" />
            </Button>
          </>
        )}
        <Textarea
          ref={taRef}
          value={text}
          onChange={(e) => setText(e.target.value.slice(0, MAX_LEN))}
          onKeyDown={onKeyDown}
          placeholder={selectedKind === "image"
            ? "Legenda da imagem (opcional)…"
            : selectedKind === "audio"
              ? "Mensagem separada do áudio (fica no rascunho)…"
              : "Mensagem como atendente humano…"}
          disabled={pending}
          rows={1}
          className="resize-none overflow-y-auto"
          style={{ minHeight: MIN_PX, maxHeight: MAX_PX }}
        />
        <Button
          size="sm"
          onClick={send}
          disabled={pending || (text.trim().length === 0 && !file)}
        >
          {pending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Send className="size-4" />
          )}
        </Button>
      </div>
      <div className="flex justify-between text-[10px] text-muted-foreground mt-1 font-mono">
        <span>
          {text.length}/{MAX_LEN}
        </span>
        <span>{selectedKind === "audio" ? "Áudio envia separado · texto fica no rascunho" : "Enter envia · Shift+Enter quebra linha"}</span>
      </div>
    </div>
  );
}
