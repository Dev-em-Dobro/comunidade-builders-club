import { loadConfig } from "@/lib/config";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Search, Database, Webhook } from "lucide-react";

const TOOLS = [
  { key: "calendar",  label: "Calendar",    icon: Calendar,  description: "Agenda própria do CRM para o agente de agendamento — configure nas abas do agente. Este flag não é necessário." },
  { key: "webSearch", label: "Web search",  icon: Search,    description: "Tavily — busca real-time" },
  { key: "rag",       label: "RAG",         icon: Database,  description: "Upload PDFs/docs + embeddings (pgvector). Multimodal via gemini-embedding-2." },
  { key: "webhook",   label: "Webhook",     icon: Webhook,   description: "POST custom pra CRM/Zapier" },
] as const;

export default function ToolsPage() {
  const cfg = loadConfig();
  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">Tools</h1>
        <p className="text-muted-foreground mt-1">
          Flipping em <code>setup.config.json</code> · UI de credenciais por tool no roadmap.
        </p>
      </header>
      <div className="grid gap-3 md:grid-cols-2">
        {TOOLS.map((t) => {
          const Icon = t.icon;
          const enabled = (cfg.tools as Record<string, boolean>)[t.key] === true;
          return (
            <Card key={t.key}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Icon className="size-4 text-primary" /> {t.label}
                  </CardTitle>
                  <Badge variant={enabled ? "default" : "outline"} className="font-mono text-[10px]">
                    {enabled ? "on" : "off"}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>{t.description}</CardDescription>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
