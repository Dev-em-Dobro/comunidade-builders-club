"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

interface Props {
  reportId: string;
  initialStatus: string;
}

const POLL_MS = 2000;
const STUCK_MS = 10 * 60 * 1000;

export function PollingClient({ reportId, initialStatus }: Props) {
  const router = useRouter();
  const [status, setStatus] = useState(initialStatus);
  const startedAtRef = useRef<number>(Date.now());

  useEffect(() => {
    if (status === "done" || status === "error") return;
    const id = setInterval(async () => {
      try {
        const res = await fetch(`/api/auditor/run/${reportId}/state`);
        if (!res.ok) return;
        const data = (await res.json()) as { status: string };
        if (data.status !== status) {
          setStatus(data.status);
          if (data.status === "done" || data.status === "error") {
            router.refresh();
          }
        }
      } catch {
        // ignora — próximo poll tenta de novo
      }
    }, POLL_MS);
    return () => clearInterval(id);
  }, [status, reportId, router]);

  const isStuck =
    (status === "queued" || status === "running") &&
    Date.now() - startedAtRef.current > STUCK_MS;

  async function markStuck() {
    if (!confirm("Marcar este relatório como erro? Use só se ele estiver preso.")) return;
    await fetch(`/api/auditor/run/${reportId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: "error",
        errorMessage: "marked as stuck by user",
      }),
    });
    router.refresh();
  }

  if (status === "done" || status === "error") return null;

  return (
    <div className="bg-blue-50 border border-blue-200 rounded p-3 flex items-center justify-between">
      <span className="text-sm text-blue-800">
        ⏳ Auditoria em andamento... (atualiza automaticamente)
      </span>
      {isStuck && (
        <Button variant="outline" size="sm" onClick={markStuck}>
          Marcar como erro
        </Button>
      )}
    </div>
  );
}
