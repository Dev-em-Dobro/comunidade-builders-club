"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Bot, Loader2 } from "lucide-react";
import { AGENT_ROLES } from "@/app/(app)/settings/agents/_roles";
import { setConversationAgent } from "../actions";

export interface AgentOption {
  id: string;
  name: string;
  role: string | null;
  isDefault: boolean;
}

function typeLabel(role: string | null): string {
  return AGENT_ROLES.find((r) => r.value === (role ?? ""))?.label.split(" — ")[0] ?? "Geral";
}

/**
 * Escolhe qual agente atende a conversa. "" = agente padrão (isDefault).
 * A troca vale a partir da próxima mensagem do contato.
 */
export function AgentPicker({
  conversationId,
  current,
  agents,
}: {
  conversationId: string;
  /** Conversation.agentSessionId (null = usa o padrão). */
  current: string | null;
  agents: AgentOption[];
}) {
  const [value, setValue] = useState(current ?? "");
  const [pending, startTransition] = useTransition();
  const fallback = agents.find((a) => a.isDefault);

  function change(next: string) {
    const previous = value;
    setValue(next);
    startTransition(async () => {
      const res = await setConversationAgent(conversationId, next || null);
      if (res.error) {
        setValue(previous);
        toast.error(res.error);
        return;
      }
      const name = next ? agents.find((a) => a.id === next)?.name : fallback?.name;
      toast.success(`Agora quem atende é ${name ?? "o agente padrão"}. Vale a partir da próxima mensagem.`);
    });
  }

  return (
    <label className="flex items-center gap-2 text-xs text-muted-foreground">
      {pending ? <Loader2 className="size-3.5 animate-spin" /> : <Bot className="size-3.5" />}
      <span>Agente</span>
      <select
        aria-label="Agente que atende a conversa"
        value={value}
        disabled={pending}
        onChange={(e) => change(e.target.value)}
        className="h-8 max-w-64 rounded-lg border border-input bg-transparent px-2.5 text-sm text-foreground outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:opacity-60 dark:bg-input/30"
      >
        <option value="">Padrão{fallback ? ` — ${fallback.name}` : " (nenhum definido)"}</option>
        {agents.map((a) => (
          <option key={a.id} value={a.id}>
            {a.name} · {typeLabel(a.role)}
          </option>
        ))}
      </select>
    </label>
  );
}
