import { NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";
import { LOSS_REASON_CODES } from "@/lib/loss-reasons";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Fecha um Lead manualmente como ganho ou perdido — disparado pelos botões
 * da tela de conversa. Diferente de `/stage`, este endpoint:
 *  - grava os campos de resultado (`wonAt`/`lostAt`/`lostReason`);
 *  - exige `reason` quando perdido;
 *  - NÃO tem guard de stage terminal — permite correção (lost↔won) e o
 *    fechamento de uma `proposal`;
 *  - opcionalmente pausa a IA da conversa de onde a ação partiu.
 */
const BodySchema = z
  .object({
    outcome: z.enum(["won", "lost"]),
    reason: z.enum(LOSS_REASON_CODES).optional(),
    note: z.string().trim().max(1000).optional(),
    conversationId: z.string().optional(),
  })
  .refine((o) => o.outcome !== "lost" || !!o.reason, {
    message: "Motivo da perda é obrigatório",
    path: ["reason"],
  });

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const { id } = await params;
  const parsed = BodySchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Payload inválido" },
      { status: 400 },
    );
  }
  const { outcome, reason, note, conversationId } = parsed.data;

  const lead = await prisma.lead.findUnique({
    where: { id },
    select: { id: true, stage: true },
  });
  if (!lead) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });
  }

  const now = new Date();
  const updates: Prisma.LeadUpdateInput =
    outcome === "won"
      ? { stage: "won", wonAt: now, lostAt: null, lostReason: null }
      : { stage: "lost", lostAt: now, lostReason: reason, wonAt: null };

  let aiPaused = false;
  await prisma.$transaction(async (tx) => {
    await tx.lead.update({ where: { id: lead.id }, data: updates });

    if (lead.stage !== outcome) {
      await tx.pipelineEvent.create({
        data: {
          leadId: lead.id,
          type: "stage_change",
          payload: {
            from: lead.stage,
            to: outcome,
            reason: reason ?? null,
            note: note ?? null,
            via: "manual_conversation",
          },
        },
      });
    }

    if (conversationId) {
      const r = await tx.conversation.updateMany({
        where: { id: conversationId },
        data: { aiEnabled: false },
      });
      aiPaused = r.count > 0;
    }
  });

  return NextResponse.json({ ok: true, stage: outcome, aiPaused });
}
