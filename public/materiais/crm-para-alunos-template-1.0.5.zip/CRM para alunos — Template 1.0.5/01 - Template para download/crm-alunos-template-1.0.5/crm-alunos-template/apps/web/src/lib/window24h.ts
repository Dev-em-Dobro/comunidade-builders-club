/**
 * Janela de mensagens livres do WhatsApp/Instagram: 24h após o último inbound.
 * Fora dela, a Meta só aceita templates aprovados (HSM).
 */

const WINDOW_MS = 24 * 60 * 60 * 1000;

/**
 * Só os canais oficiais da Meta têm janela de 24h. O WhatsApp via QR (não
 * oficial) não tem: conversas desse canal ficam com `windowClosesAt = null`
 * (sem contador, sem alerta, sem bloqueio de envio manual, sem template).
 */
export function channelHasMessagingWindow(channel: string): boolean {
  return channel === "whatsapp_cloud" || channel === "instagram";
}

/** Quando a janela de 24h fecha, dado o instante do último inbound. */
export function computeWindowClose(lastInboundAt: Date): Date {
  return new Date(lastInboundAt.getTime() + WINDOW_MS);
}

/** True se ainda dá pra enviar mensagem livre (dentro da janela de 24h). */
export function isWithin24hWindow(
  windowClosesAt: Date | null | undefined,
  now: Date = new Date(),
): boolean {
  return windowClosesAt != null && windowClosesAt.getTime() > now.getTime();
}

/**
 * Horas até a janela fechar — negativo se já fechou, `null` se nunca houve
 * inbound (conversa sem janela).
 */
export function hoursUntilClose(
  windowClosesAt: Date | null | undefined,
  now: Date = new Date(),
): number | null {
  if (windowClosesAt == null) return null;
  return (windowClosesAt.getTime() - now.getTime()) / 3_600_000;
}
