import { describe, it, expect } from "vitest";
import {
  formatAnswersForPrompt,
  formatAnswersForDisplay,
} from "./format";

describe("formatAnswersForPrompt", () => {
  it("monta bloco completo com surveyName, submittedAt e linhas pergunta/resposta", () => {
    const out = formatAnswersForPrompt(
      "Lançamento maio/26",
      {
        Objetivo: "dobrar a renda",
        Renda: "5-10k",
      },
      new Date("2026-05-12T15:00:00Z"),
    );
    expect(out).toContain('## Resposta da pesquisa "Lançamento maio/26"');
    expect(out).toContain("(respondida em 2026-05-12)");
    expect(out).toContain("- Objetivo: dobrar a renda");
    expect(out).toContain("- Renda: 5-10k");
  });

  it("trunca valor longo em 200 chars com '…'", () => {
    const long = "x".repeat(300);
    const out = formatAnswersForPrompt("X", { Q: long }, null);
    const valueLine = out.split("\n").find((l) => l.startsWith("- Q:"))!;
    // 200 chars de x + "…" = 201 chars + "- Q: " (5 chars) = 206
    expect(valueLine.length).toBe(5 + 200 + 1);
    expect(valueLine.endsWith("…")).toBe(true);
  });

  it("trunca bloco total em 1200 chars com suffix de omissão", () => {
    const answers: Record<string, string> = {};
    for (let i = 0; i < 50; i++) {
      answers[`Pergunta ${i}`] = "x".repeat(50); // ~70 chars por linha
    }
    const out = formatAnswersForPrompt("X", answers, null);
    expect(out.length).toBeLessThanOrEqual(1300); // 1200 + suffix
    expect(out).toMatch(/respostas omitidas/);
  });

  it("pula valores null, undefined ou string vazia", () => {
    const out = formatAnswersForPrompt(
      "X",
      { A: "tem", B: "", C: null as unknown as string, D: undefined as unknown as string },
      null,
    );
    expect(out).toContain("- A: tem");
    expect(out).not.toContain("- B:");
    expect(out).not.toContain("- C:");
    expect(out).not.toContain("- D:");
  });

  it("submittedAt nulo: omite a linha '(respondida em ...)'", () => {
    const out = formatAnswersForPrompt("X", { A: "tem" }, null);
    expect(out).not.toContain("respondida em");
  });

  it("answers totalmente vazio retorna string vazia", () => {
    expect(formatAnswersForPrompt("X", {}, null)).toBe("");
    expect(formatAnswersForPrompt("X", { A: "" }, null)).toBe("");
  });
});

describe("formatAnswersForDisplay", () => {
  it("preserva ordem das keys e não trunca", () => {
    const long = "x".repeat(500);
    const out = formatAnswersForDisplay({
      Primeiro: "1",
      Segundo: long,
      Terceiro: "3",
    });
    expect(out.map((e) => e.question)).toEqual([
      "Primeiro",
      "Segundo",
      "Terceiro",
    ]);
    expect(out[1]!.answer).toBe(long); // sem truncar
  });

  it("pula valores vazios também", () => {
    const out = formatAnswersForDisplay({ A: "tem", B: "", C: null as unknown as string });
    expect(out).toEqual([{ question: "A", answer: "tem" }]);
  });
});
