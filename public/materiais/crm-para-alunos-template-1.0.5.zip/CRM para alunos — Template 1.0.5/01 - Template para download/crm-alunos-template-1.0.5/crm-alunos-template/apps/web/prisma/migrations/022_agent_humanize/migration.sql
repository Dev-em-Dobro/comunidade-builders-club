-- "Jeito de gente" nas respostas do agente (espera, digitando…, balões).
ALTER TABLE "AgentSession" ADD COLUMN "humanize" JSONB NOT NULL DEFAULT '{}';
