/**
 * Integração com o Postgres de teste: agenda própria do CRM (semana padrão +
 * exceções − consultas), profissionais por agente, reserva sem duplicidade,
 * cancelamento e CSV.
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { addDays, weekdayOf, zonedParts } from "./time";
import { schedulingTimezone } from "./timezone";
import { appointmentsCsv, bookAppointment, cancelAppointment, checkAvailability } from "./service";

let agentSessionId: string;
let otherAgentId: string;
let professionalId: string;
let contactId: string;
let monday: string;

beforeAll(async () => {
  // Segunda-feira pelo menos 3 dias à frente (fora da antecedência mínima).
  monday = addDays(zonedParts(new Date(), schedulingTimezone()).date, 3);
  while (weekdayOf(monday) !== 1) monday = addDays(monday, 1);

  const stamp = Date.now();
  agentSessionId = (
    await prisma.agentSession.create({
      data: { name: `Agenda teste ${stamp}`, systemPrompt: "x", role: "scheduling" },
    })
  ).id;
  otherAgentId = (
    await prisma.agentSession.create({
      data: { name: `Agenda outra ${stamp}`, systemPrompt: "x", role: "scheduling" },
    })
  ).id;

  const p = await prisma.professional.create({
    data: {
      agentSessionId,
      name: `Dra. Teste ${stamp}`,
      specialty: "Clínica geral",
      durationMin: 30,
      workingHours: { "1": [{ start: "08:00", end: "10:00" }] },
    },
  });
  professionalId = p.id;
  contactId = (await prisma.contact.create({ data: { displayName: "Paciente Teste" } })).id;
});

afterAll(async () => {
  await prisma.appointment.deleteMany({ where: { contactId } });
  await prisma.agentSession.deleteMany({ where: { id: { in: [agentSessionId, otherAgentId] } } });
  await prisma.contact.deleteMany({ where: { id: contactId } });
  await prisma.$disconnect();
});

const book = (time: string, agent = agentSessionId) =>
  bookAppointment({
    agentSessionId: agent,
    professionalId,
    date: monday,
    time,
    intake: { motivo: "Check-up" },
    intakeFields: [{ key: "motivo", label: "Motivo", required: true }],
    contactId,
    conversationId: null,
  });

describe("agenda do CRM", () => {
  it("oferece os horários da semana padrão", async () => {
    const res = await checkAvailability({ agentSessionId, professionalId, date: monday });
    expect(res.ok).toBe(true);
    if (!res.ok) return;
    expect(res.requestedDateHasSlots).toBe(true);
    expect(res.days[0]).toMatchObject({ date: monday, times: ["08:00", "08:30", "09:00", "09:30"] });
  });

  it("exceção fecha o dia e horário diferente substitui a semana padrão", async () => {
    await prisma.professionalDayOverride.create({ data: { professionalId, date: monday, intervals: [] } });
    const closed = await checkAvailability({ agentSessionId, professionalId, date: monday });
    expect(closed.ok && closed.requestedDateHasSlots).toBe(false);

    await prisma.professionalDayOverride.update({
      where: { professionalId_date: { professionalId, date: monday } },
      data: { intervals: [{ start: "14:00", end: "15:00" }] },
    });
    const custom = await checkAvailability({ agentSessionId, professionalId, date: monday });
    expect(custom.ok && custom.days[0]).toMatchObject({ date: monday, times: ["14:00", "14:30"] });

    await prisma.professionalDayOverride.deleteMany({ where: { professionalId } });
  });

  it("outro agente não enxerga nem agenda o profissional", async () => {
    const res = await checkAvailability({ agentSessionId: otherAgentId, professionalId, date: monday });
    expect(res).toMatchObject({ ok: false, error: "professional_not_found" });
    expect(await book("08:00", otherAgentId)).toMatchObject({ ok: false, error: "professional_not_found" });
  });

  it("exige a pré-consulta obrigatória", async () => {
    const res = await bookAppointment({
      agentSessionId,
      professionalId,
      date: monday,
      time: "08:00",
      intake: {},
      intakeFields: [{ key: "motivo", label: "Motivo", required: true }],
      contactId,
      conversationId: null,
    });
    expect(res).toMatchObject({ ok: false, error: "missing_intake", missing: ["Motivo"] });
  });

  it("marca, bloqueia o mesmo horário e libera ao cancelar", async () => {
    const first = await book("08:00");
    expect(first.ok).toBe(true);

    const again = await book("08:00");
    expect(again).toMatchObject({ ok: false, error: "slot_unavailable" });
    if (!again.ok) expect(again.availableTimes).not.toContain("08:00");

    if (!first.ok) return;
    expect(await cancelAppointment(first.appointmentId)).toEqual({ ok: true });
    const after = await checkAvailability({ agentSessionId, professionalId, date: monday });
    expect(after.ok && after.days[0]?.times).toContain("08:00");
  });

  it("duas reservas simultâneas no mesmo horário: só uma passa", async () => {
    const results = await Promise.all([book("09:00"), book("09:00")]);
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.error === "slot_unavailable")).toHaveLength(1);
  });

  it("exporta o período em CSV", async () => {
    const csv = await appointmentsCsv({ agentSessionId, from: monday, to: monday, professionalId });
    const other = await appointmentsCsv({ agentSessionId: otherAgentId, from: monday, to: monday });
    expect(other.replace(/^\uFEFF/, "").trim().split("\r\n")).toHaveLength(1); // só o cabeçalho
    const lines = csv.replace(/^﻿/, "").trim().split("\r\n");
    expect(lines[0]).toBe(
      "Agendado em;Data;Hora;Profissional;Especialidade;Paciente;Telefone;Status;Pré-consulta;ID no CRM",
    );
    // 08:00 cancelada + 09:00 agendada
    expect(lines).toHaveLength(3);
    expect(lines[1]).toContain(";08:00;");
    expect(lines[1]).toContain(";cancelada;");
    expect(lines[2]).toContain(";09:00;");
    expect(lines[2]).toContain("Paciente Teste");
    expect(lines[2]).toContain("Motivo: Check-up");
  });
});
