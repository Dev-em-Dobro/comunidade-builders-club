/**
 * Lê o cardápio enviado (PDF ou foto) com a IA, UMA vez, no upload — e devolve
 * os itens com preço. Só servidor.
 *
 *  - PDF com texto: o texto é extraído localmente (unpdf) e a IA só organiza.
 *  - PDF escaneado / foto: o arquivo vai pro modelo do agente (visão).
 *
 * Usa o provedor e o modelo do próprio agente (escolha do usuário) com a chave
 * salva em Chaves de API.
 */
import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";
import { resolveProviderKey } from "@/lib/llm/keys";
import { reasoningEffortFor } from "@/lib/llm/openai";
import { extractPdf } from "@/lib/rag/extract";
import { normalizeMenuItems, type MenuItem } from "./menu";

export const MENU_MAX_BYTES = 8 * 1024 * 1024;
export const MENU_MIME_TYPES = ["application/pdf", "image/png", "image/jpeg", "image/webp"] as const;

const INSTRUCTIONS = `Você recebe o cardápio de um restaurante, lanchonete ou delivery.
Extraia TODOS os itens vendidos que têm preço e responda SOMENTE com JSON, neste formato:
{"items":[{"category":"Lanches","name":"X-Burguer","description":"pão, carne, queijo","price":25.9}]}
Regras:
- price em reais, como número (25.9 — nada de "R$").
- Item com tamanhos ou variações de preço diferente vira um item por variação: "Pizza Calabresa (Grande)".
- category é a seção do cardápio (Lanches, Bebidas, Pizzas…). description é curta e opcional.
- Copie os nomes como estão no cardápio. Não invente itens nem preços; ignore o que não tem preço.`;

/** Primeiro objeto JSON do texto (o modelo às vezes embrulha em ```json). */
function parseItems(text: string): MenuItem[] {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("A IA não devolveu a lista de itens. Tente de novo.");
  const json = JSON.parse(text.slice(start, end + 1)) as { items?: unknown };
  return normalizeMenuItems(json.items);
}

async function withOpenAI(apiKey: string, model: string, content: OpenAI.Chat.Completions.ChatCompletionContentPart[]) {
  const client = new OpenAI({ apiKey, timeout: 120_000, maxRetries: 1 });
  const effort = reasoningEffortFor(model);
  const resp = await client.chat.completions.create({
    model,
    ...(effort ? { reasoning_effort: effort } : {}),
    max_completion_tokens: 16_000,
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: INSTRUCTIONS },
      { role: "user", content },
    ],
  });
  return resp.choices[0]?.message?.content ?? "";
}

async function withAnthropic(apiKey: string, model: string, content: Anthropic.Messages.ContentBlockParam[]) {
  const client = new Anthropic({ apiKey, timeout: 180_000, maxRetries: 1 });
  const resp = await client.messages.create({
    model,
    max_tokens: 16_000,
    system: INSTRUCTIONS,
    messages: [{ role: "user", content }],
  });
  if (resp.stop_reason === "refusal") throw new Error("A IA recusou ler este arquivo.");
  return resp.content
    .filter((b): b is Anthropic.Messages.TextBlock => b.type === "text")
    .map((b) => b.text)
    .join("\n");
}

export async function extractMenuItems(args: {
  provider: string;
  model: string;
  file: Uint8Array;
  mimeType: string;
}): Promise<MenuItem[]> {
  const apiKey = await resolveProviderKey(args.provider);
  if (!apiKey) throw new Error(`Cadastre a chave da ${args.provider} em Chaves de API para a IA ler o cardápio.`);

  const isPdf = args.mimeType === "application/pdf";
  const pdfText = isPdf ? (await extractPdf(args.file).catch(() => "")).trim() : "";
  const base64 = Buffer.from(args.file).toString("base64");
  const prompt = "Extraia os itens deste cardápio.";
  let raw: string;

  if (args.provider === "anthropic") {
    const content: Anthropic.Messages.ContentBlockParam[] =
      pdfText.length > 40
        ? [{ type: "text", text: `${prompt}\n\n${pdfText.slice(0, 60_000)}` }]
        : isPdf
          ? [
              { type: "document", source: { type: "base64", media_type: "application/pdf", data: base64 } },
              { type: "text", text: prompt },
            ]
          : [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: args.mimeType as "image/png" | "image/jpeg" | "image/webp",
                  data: base64,
                },
              },
              { type: "text", text: prompt },
            ];
    raw = await withAnthropic(apiKey, args.model, content);
  } else {
    const content: OpenAI.Chat.Completions.ChatCompletionContentPart[] =
      pdfText.length > 40
        ? [{ type: "text", text: `${prompt}\n\n${pdfText.slice(0, 60_000)}` }]
        : isPdf
          ? [
              { type: "file", file: { filename: "cardapio.pdf", file_data: `data:application/pdf;base64,${base64}` } },
              { type: "text", text: prompt },
            ]
          : [
              { type: "image_url", image_url: { url: `data:${args.mimeType};base64,${base64}` } },
              { type: "text", text: prompt },
            ];
    raw = await withOpenAI(apiKey, args.model, content);
  }

  const items = parseItems(raw);
  if (!items.length) throw new Error("A IA não encontrou itens com preço neste arquivo. Confira se o cardápio está legível.");
  return items;
}
