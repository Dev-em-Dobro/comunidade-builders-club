"use client";

import {
  FunnelChart,
  Funnel,
  LabelList,
  RadialBarChart,
  RadialBar,
  PolarAngleAxis,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import type { FunnelLevel, DayBucket } from "../metrics";

const FUNNEL_COLORS = ["#6366f1", "#818cf8", "#a5b4fc", "#c7d2fe", "#22c55e"];

/** Funil em trapézios. Os números/drop-off ficam na lista da seção. */
export function FunnelView({ levels }: { levels: FunnelLevel[] }) {
  const data = levels.map((l, i) => ({
    name: l.label,
    value: l.count,
    fill: FUNNEL_COLORS[i] ?? FUNNEL_COLORS[FUNNEL_COLORS.length - 1],
  }));
  return (
    <ResponsiveContainer width="100%" height={220}>
      <FunnelChart>
        <Tooltip />
        <Funnel dataKey="value" data={data} isAnimationActive={false}>
          <LabelList
            position="right"
            dataKey="name"
            className="fill-foreground text-xs"
            stroke="none"
          />
        </Funnel>
      </FunnelChart>
    </ResponsiveContainer>
  );
}

function gaugeColor(value: number): string {
  if (value >= 70) return "#22c55e";
  if (value >= 40) return "#f59e0b";
  return "#ef4444";
}

/** Gauge radial (meia-lua) da % de conversas com janela saudável. */
export function WindowGauge({ pct }: { pct: number | null }) {
  if (pct === null) {
    return (
      <div className="flex h-[160px] items-center justify-center text-sm text-muted-foreground">
        Nenhuma janela aberta
      </div>
    );
  }
  const value = Math.round(pct);
  const data = [{ name: "Saudáveis", value, fill: gaugeColor(value) }];
  return (
    <ResponsiveContainer width="100%" height={160}>
      <RadialBarChart
        data={data}
        innerRadius="65%"
        outerRadius="100%"
        startAngle={180}
        endAngle={0}
      >
        <PolarAngleAxis
          type="number"
          domain={[0, 100]}
          tick={false}
          axisLine={false}
        />
        <RadialBar
          dataKey="value"
          background
          cornerRadius={6}
          isAnimationActive={false}
        />
      </RadialBarChart>
    </ResponsiveContainer>
  );
}

/** Barras diárias de won/lost. */
export function ConversionsChart({ buckets }: { buckets: DayBucket[] }) {
  const data = buckets.map((b) => ({
    date: b.date.slice(5), // MM-DD
    Ganhos: b.won,
    Perdas: b.lost,
  }));
  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.3} />
        <XAxis
          dataKey="date"
          tick={{ fontSize: 11 }}
          interval="preserveStartEnd"
        />
        <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={28} />
        <Tooltip />
        <Legend />
        <Bar
          dataKey="Ganhos"
          fill="#22c55e"
          radius={[2, 2, 0, 0]}
          isAnimationActive={false}
        />
        <Bar
          dataKey="Perdas"
          fill="#ef4444"
          radius={[2, 2, 0, 0]}
          isAnimationActive={false}
        />
      </BarChart>
    </ResponsiveContainer>
  );
}
