import { randomBytes } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { requireSession } from "@/lib/api-auth";
import {
  buildAuthUrl,
  googleRedirectUri,
  originFromHeaders,
  publicBaseUrl,
  resolveClientCredentials,
} from "@/lib/google/oauth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const GOOGLE_STATE_COOKIE = "google_oauth_state";

/**
 * GET /api/integrations/google/connect
 * Redireciona o admin pro consentimento do Google. O `state` aleatório fica num
 * cookie httpOnly e é conferido no callback (proteção CSRF do OAuth).
 */
export async function GET(req: NextRequest) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const back = `${publicBaseUrl(originFromHeaders(req.headers))}/integrations/google-sheets`;
  if (gate.user.role !== "admin") return NextResponse.redirect(`${back}?error=forbidden`);

  const creds = await resolveClientCredentials().catch(() => null);
  if (!creds) return NextResponse.redirect(`${back}?error=missing_client`);

  const state = randomBytes(24).toString("base64url");
  const redirectUri = googleRedirectUri(originFromHeaders(req.headers));
  const res = NextResponse.redirect(buildAuthUrl({ clientId: creds.clientId, redirectUri, state }));
  res.cookies.set(GOOGLE_STATE_COOKIE, state, {
    httpOnly: true,
    sameSite: "lax",
    secure: redirectUri.startsWith("https://"),
    path: "/api/integrations/google",
    maxAge: 600,
  });
  return res;
}
