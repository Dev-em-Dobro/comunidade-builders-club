import { auth } from "@/auth";
import { DEFAULT_WORKING_HOURS } from "@/lib/scheduling/working-hours";
import { ProfessionalForm } from "../professional-form";
import { AgentHeader, requireAgentOfRole } from "../../_agent";

export const dynamic = "force-dynamic";

export default async function NewProfessionalPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const { id } = await params;
  const agent = await requireAgentOfRole(id, "scheduling");
  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader agent={agent} active="professionals" description="Novo profissional" />
      <ProfessionalForm agentId={agent.id} initial={{ workingHours: DEFAULT_WORKING_HOURS }} />
    </div>
  );
}
