import { describe, expect, it } from "vitest";
import { withChannelEnabled, type SetupConfig } from "./config";

function cfg(enabled: string[]): SetupConfig {
  return {
    channels: {
      enabled,
      whatsapp_cloud: { enabled: enabled.includes("whatsapp_cloud") },
      instagram_direct: { enabled: enabled.includes("instagram") || enabled.includes("instagram_direct") },
    },
  } as unknown as SetupConfig;
}

describe("withChannelEnabled", () => {
  it("liga o WhatsApp via QR sem mexer nos outros canais", () => {
    const next = withChannelEnabled(cfg(["whatsapp_cloud"]), "whatsapp_qr", true);
    expect(next.channels.enabled).toEqual(["whatsapp_cloud", "whatsapp_qr"]);
    expect(next.channels.whatsapp_qr).toEqual({ enabled: true });
    expect(next.channels.whatsapp_cloud.enabled).toBe(true);
  });

  it("é idempotente e desliga removendo da lista", () => {
    const on = withChannelEnabled(withChannelEnabled(cfg([]), "whatsapp_qr", true), "whatsapp_qr", true);
    expect(on.channels.enabled).toEqual(["whatsapp_qr"]);
    const off = withChannelEnabled(on, "whatsapp_qr", false);
    expect(off.channels.enabled).toEqual([]);
    expect(off.channels.whatsapp_qr).toEqual({ enabled: false });
  });

  it("não altera o objeto original", () => {
    const original = cfg([]);
    withChannelEnabled(original, "whatsapp_qr", true);
    expect(original.channels.enabled).toEqual([]);
    expect(original.channels.whatsapp_qr).toBeUndefined();
  });

  it("instagram remove também o id legado instagram_direct", () => {
    const off = withChannelEnabled(cfg(["instagram_direct"]), "instagram", false);
    expect(off.channels.enabled).toEqual([]);
    expect(off.channels.instagram_direct.enabled).toBe(false);
  });
});
