import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { id: conversationId } = await params;
  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { contactId: true },
  });
  if (!conv) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  const responses = await prisma.surveyResponse.findMany({
    where: { contactId: conv.contactId },
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      surveyName: true,
      answers: true,
      submittedAt: true,
      createdAt: true,
    },
  });
  return NextResponse.json({ responses });
}
