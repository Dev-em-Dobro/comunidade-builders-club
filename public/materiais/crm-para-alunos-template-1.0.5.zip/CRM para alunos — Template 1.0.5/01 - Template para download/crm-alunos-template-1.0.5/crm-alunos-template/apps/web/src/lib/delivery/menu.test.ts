import { describe, expect, it } from "vitest";
import {
  findMenuItem,
  formatAreasText,
  formatBRL,
  formatMenuLines,
  normalizeMenuItems,
  parseAreasText,
  parseMenuLines,
  parseMoneyToCents,
  priceOrder,
  type MenuItem,
} from "./menu";

const MENU: MenuItem[] = [
  { category: "Lanches", name: "X-Burguer", priceCents: 2500 },
  { category: "Lanches", name: "X-Salada", priceCents: 2700 },
  { category: "Pizzas", name: "Pizza Calabresa (Grande)", priceCents: 5900 },
  { category: "Pizzas", name: "Pizza Calabresa (Média)", priceCents: 4500 },
  { category: "Bebidas", name: "Coca-Cola 2L", priceCents: 1200 },
];
const AREAS = [
  { name: "Centro", feeCents: 500 },
  { name: "Jardim América", feeCents: 750 },
];
const STORE = { menu: MENU, areas: AREAS, pickupEnabled: true };

describe("valores", () => {
  it("converte reais em centavos", () => {
    expect(parseMoneyToCents("5,50")).toBe(550);
    expect(parseMoneyToCents("R$ 25")).toBe(2500);
    expect(parseMoneyToCents(25.9)).toBe(2590);
    expect(parseMoneyToCents("abc")).toBeNull();
    expect(parseMoneyToCents(-1)).toBeNull();
  });

  it("formata em reais", () => {
    expect(formatBRL(2590).replace(/\s/g, " ")).toBe("R$ 25,90");
  });
});

describe("bairros", () => {
  it("lê uma linha por bairro em formatos variados", () => {
    expect(parseAreasText("Centro: 5,00\nJardim América - 7,5\n\nVila Nova | R$ 0")).toEqual([
      { name: "Centro", feeCents: 500 },
      { name: "Jardim América", feeCents: 750 },
      { name: "Vila Nova", feeCents: 0 },
    ]);
  });

  it("aponta a linha errada e recusa bairro repetido", () => {
    expect(() => parseAreasText("Centro: 5\nSem taxa")).toThrow(/Linha 2/);
    expect(() => parseAreasText("Centro: 5\ncentro: 6")).toThrow(/repetido/);
  });

  it("ida e volta texto ↔ lista", () => {
    expect(parseAreasText(formatAreasText(AREAS))).toEqual(AREAS);
  });
});

describe("itens do cardápio", () => {
  it("acha por nome sem acento/caixa ou por trecho único", () => {
    expect(findMenuItem(MENU, "x-burguer")).toEqual({ item: MENU[0] });
    expect(findMenuItem(MENU, "coca")).toEqual({ item: MENU[4] });
    expect(findMenuItem(MENU, "pizza calabresa")).toEqual({
      ambiguous: ["Pizza Calabresa (Grande)", "Pizza Calabresa (Média)"],
    });
    expect(findMenuItem(MENU, "sushi")).toBeNull();
  });

  it("normaliza o JSON da IA (preço em reais vira centavos; sem preço é descartado)", () => {
    expect(
      normalizeMenuItems([
        { name: "X-Tudo", price: 32.5, category: "Lanches" },
        { name: "Sem preço" },
        "lixo",
      ]),
    ).toEqual([{ name: "X-Tudo", priceCents: 3250, category: "Lanches" }]);
  });

  it("ida e volta texto editável ↔ itens", () => {
    expect(parseMenuLines(formatMenuLines(MENU))).toEqual(MENU);
    expect(parseMenuLines("Suco | 8,00")).toEqual([{ name: "Suco", priceCents: 800 }]);
    expect(() => parseMenuLines("Lanches | X-Burguer | caro")).toThrow(/Linha 1/);
  });
});

describe("priceOrder", () => {
  it("calcula com o preço do cardápio e a taxa do bairro", () => {
    const r = priceOrder(
      { items: [{ name: "x-burguer", quantity: 2, notes: "sem cebola" }, { name: "Coca-Cola 2L", quantity: 1 }], fulfillment: "delivery", neighborhood: "centro" },
      STORE,
    );
    expect(r).toMatchObject({
      ok: true,
      subtotalCents: 6200,
      deliveryFeeCents: 500,
      totalCents: 6700,
      neighborhood: "Centro",
      lines: [
        { name: "X-Burguer", quantity: 2, unitPriceCents: 2500, notes: "sem cebola" },
        { name: "Coca-Cola 2L", quantity: 1, unitPriceCents: 1200 },
      ],
    });
  });

  it("retirada não cobra taxa", () => {
    expect(priceOrder({ items: [{ name: "X-Salada", quantity: 1 }], fulfillment: "pickup" }, STORE)).toMatchObject({
      ok: true,
      deliveryFeeCents: 0,
      totalCents: 2700,
    });
  });

  it("recusa item fora do cardápio, item ambíguo, bairro não atendido e retirada desligada", () => {
    expect(priceOrder({ items: [{ name: "Sushi", quantity: 1 }], fulfillment: "pickup" }, STORE)).toMatchObject({
      ok: false,
      error: "unknown_items",
      unknownItems: ["Sushi"],
    });
    expect(priceOrder({ items: [{ name: "pizza calabresa", quantity: 1 }], fulfillment: "pickup" }, STORE)).toMatchObject({
      ok: false,
      error: "ambiguous_items",
    });
    expect(
      priceOrder({ items: [{ name: "X-Salada", quantity: 1 }], fulfillment: "delivery", neighborhood: "Copacabana" }, STORE),
    ).toMatchObject({ ok: false, error: "area_not_served", servedNeighborhoods: ["Centro", "Jardim América"] });
    expect(
      priceOrder({ items: [{ name: "X-Salada", quantity: 1 }], fulfillment: "pickup" }, { ...STORE, pickupEnabled: false }),
    ).toMatchObject({ ok: false, error: "pickup_unavailable" });
  });

  it("recusa pedido vazio, quantidade inválida e loja sem cardápio", () => {
    expect(priceOrder({ items: [], fulfillment: "pickup" }, STORE)).toMatchObject({ ok: false, error: "empty_order" });
    expect(priceOrder({ items: [{ name: "X-Salada", quantity: 0 }], fulfillment: "pickup" }, STORE)).toMatchObject({
      ok: false,
      error: "invalid_quantity",
    });
    expect(priceOrder({ items: [{ name: "X-Salada", quantity: 1 }], fulfillment: "pickup" }, { ...STORE, menu: [] })).toMatchObject({
      ok: false,
      error: "no_menu",
    });
  });
});
