import { prisma } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import { followupConfig } from "@/lib/config";
import {
  isQuietHours,
  effectiveFollowupDeadline,
  type QuietHours,
} from "@/lib/quiet-hours";
import type { FollowupJobData } from "@/lib/queue/types";

/** Quanto antes do deadline o follow-up é disparado. */
const LEAD_TIME_MS = 4 * 60 * 60 * 1000;
/** Stages de Lead que ainda valem a pena reengajar. */
const ELIGIBLE_STAGES = ["new", "contacted", "qualified"];
/** Teto de conversas avaliadas por scan. */
const SCAN_CAP = 500;

/** Campos de uma conversa que `isFollowupDue` precisa. */
export interface FollowupCandidate {
  windowClosesAt: Date | null;
  windowClosingSoon: boolean;
  followupCount: number;
  aiEnabled: boolean;
  handoffRequested: boolean;
  leadStage: string | null;
}

/**
 * Predicado puro: esta conversa deve receber um follow-up agora?
 *
 * `true` quando a janela está aberta, a conversa nunca foi reivindicada nem
 * recebeu follow-up, a IA está ativa, não há handoff, o lead está num stage
 * elegível, e o deadline efetivo (ciente de quiet hours) está dentro do lead
 * time a partir de `now`.
 */
export function isFollowupDue(
  c: FollowupCandidate,
  now: Date,
  cfg: { maxPerWindow: number; leadTimeMs: number; quietHours: QuietHours | null },
): boolean {
  if (c.windowClosesAt == null) return false;
  if (c.windowClosesAt.getTime() <= now.getTime()) return false;
  if (c.windowClosingSoon) return false;
  if (c.followupCount >= cfg.maxPerWindow) return false;
  if (!c.aiEnabled) return false;
  if (c.handoffRequested) return false;
  if (c.leadStage == null || !ELIGIBLE_STAGES.includes(c.leadStage)) return false;
  const deadline = effectiveFollowupDeadline(c.windowClosesAt, cfg.quietHours);
  return deadline.getTime() <= now.getTime() + cfg.leadTimeMs;
}

/**
 * Processador do job repetível `window24h.scan` (a cada 15 min).
 *
 * Dois early-outs: se o follow-up está desligado, ou se `now` está em quiet
 * hours — o scan nunca enfileira `generate` durante o quiet hours, porque o
 * lead time de 4h poderia alcançar para trás dentro dele. A conversa é pega
 * no primeiro scan após o quiet hours terminar.
 *
 * Para cada candidata: claim atômico via `updateMany` (windowClosingSoon
 * false→true) — só quem reivindica de fato enfileira o `followup.generate`.
 * Isso evita que o scan a cada 15 min re-pegue a mesma conversa.
 */
export async function window24hScanProcessor(): Promise<void> {
  const cfg = followupConfig();
  if (!cfg.enabled) {
    log("window24h.scan_skipped", { reason: "disabled" });
    return;
  }
  const now = new Date();
  if (isQuietHours(now, cfg.quietHours)) {
    log("window24h.scan_skipped", { reason: "quiet_hours" });
    return;
  }

  const convs = await prisma.conversation.findMany({
    where: {
      windowClosesAt: { gt: now },
      windowClosingSoon: false,
      aiEnabled: true,
      handoffRequested: false,
      followupCount: { lt: cfg.maxPerWindow },
      lead: { stage: { in: ELIGIBLE_STAGES } },
    },
    select: {
      id: true,
      windowClosesAt: true,
      windowClosingSoon: true,
      followupCount: true,
      aiEnabled: true,
      handoffRequested: true,
      leadId: true,
      lead: { select: { stage: true } },
    },
    take: SCAN_CAP,
  });

  let enqueued = 0;
  for (const conv of convs) {
    const due = isFollowupDue(
      {
        windowClosesAt: conv.windowClosesAt,
        windowClosingSoon: conv.windowClosingSoon,
        followupCount: conv.followupCount,
        aiEnabled: conv.aiEnabled,
        handoffRequested: conv.handoffRequested,
        leadStage: conv.lead?.stage ?? null,
      },
      now,
      {
        maxPerWindow: cfg.maxPerWindow,
        leadTimeMs: LEAD_TIME_MS,
        quietHours: cfg.quietHours,
      },
    );
    if (!due) continue;

    // Claim atômico: só prossegue quem virou windowClosingSoon de false→true.
    const claimed = await prisma.conversation.updateMany({
      where: { id: conv.id, windowClosingSoon: false },
      data: { windowClosingSoon: true },
    });
    if (claimed.count === 0) continue;

    if (conv.leadId) {
      await prisma.pipelineEvent.create({
        data: {
          leadId: conv.leadId,
          type: "window_closing",
          payload: { conversationId: conv.id },
        },
      });
    }

    const data: FollowupJobData = { conversationId: conv.id };
    await enqueue("followup", "generate", data, {
      priority: 1,
      removeOnComplete: true,
      removeOnFail: 50,
    });
    enqueued++;
  }

  log("window24h.scan_done", { scanned: convs.length, enqueued });
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
