import Link from "next/link";
import { prisma } from "@/lib/db";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { normalizeWorkingHours, summarizeWorkingHours } from "@/lib/scheduling/working-hours";
import { Plus, Stethoscope } from "lucide-react";
import { AgentHeader, requireAgentOfRole } from "../_agent";

export const dynamic = "force-dynamic";

export default async function AgentProfessionalsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const agent = await requireAgentOfRole(id, "scheduling");
  const base = `/settings/agents/${agent.id}/professionals`;
  const professionals = await prisma.professional
    .findMany({ where: { agentSessionId: agent.id }, orderBy: [{ active: "desc" }, { name: "asc" }] })
    .catch(() => []);

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <AgentHeader
        agent={agent}
        active="professionals"
        description="Quem este agente pode agendar — cada um com a semana padrão e as exceções (folgas, feriados)."
      >
        <Link href={`${base}/new`} className={buttonVariants()}>
          <Plus className="size-4" /> Novo profissional
        </Link>
      </AgentHeader>

      {professionals.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <Stethoscope className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhum profissional neste agente</p>
          <p className="text-sm text-muted-foreground mt-1">
            Sem profissional ativo, o agente faz a pré-consulta e transfere para a equipe marcar o horário.
          </p>
          <Link href={`${base}/new`} className={buttonVariants({ className: "mt-4" })}>
            <Plus className="size-4" /> Cadastrar profissional
          </Link>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Semana padrão</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {professionals.map((p) => (
                <TableRow key={p.id}>
                  <TableCell>
                    <div className="font-medium">{p.name}</div>
                    <div className="text-xs text-muted-foreground">
                      {[p.specialty, `${p.durationMin} min`].filter(Boolean).join(" · ")}
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground max-w-64 whitespace-normal">
                    {summarizeWorkingHours(normalizeWorkingHours(p.workingHours))}
                  </TableCell>
                  <TableCell>
                    <Badge variant={p.active ? "default" : "outline"}>{p.active ? "ativo" : "inativo"}</Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Link href={`${base}/${p.id}`} className={buttonVariants({ size: "sm", variant: "outline" })}>
                      Editar
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}
