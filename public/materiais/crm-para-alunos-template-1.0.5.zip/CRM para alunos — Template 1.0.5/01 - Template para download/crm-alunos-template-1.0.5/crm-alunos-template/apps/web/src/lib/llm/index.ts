import { anthropicProvider } from "./anthropic";
import { openaiProvider } from "./openai";
import type { LLMProvider, LLMRequest, LLMResponse } from "./types";

const PROVIDERS: Record<string, LLMProvider> = {
  anthropic: anthropicProvider,
  openai: openaiProvider,
  // google/groq plugam aqui no futuro — interface compartilhada em ./types.ts
};

export function getProvider(id: string): LLMProvider {
  const p = PROVIDERS[id];
  if (!p) {
    const available = Object.keys(PROVIDERS).join(", ");
    throw new Error(`Provider LLM "${id}" não implementado. Disponíveis: ${available}`);
  }
  return p;
}

export async function generateReply(
  providerId: string,
  req: LLMRequest,
): Promise<LLMResponse> {
  return getProvider(providerId).generateReply(req);
}

export type { LLMProvider, LLMRequest, LLMResponse } from "./types";
export type { LLMTurn, LLMRole, LLMToolDef, LLMToolUse } from "./types";
