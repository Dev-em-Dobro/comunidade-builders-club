import { describe, it, expect } from "vitest";
import { isFollowupDue, type FollowupCandidate } from "./window24h";

const NOW = new Date("2026-05-21T12:00:00.000Z");
const CFG = { maxPerWindow: 1, leadTimeMs: 4 * 3_600_000, quietHours: null };

/** Candidata elegível por padrão — cada teste vira um campo. */
function candidate(over: Partial<FollowupCandidate> = {}): FollowupCandidate {
  return {
    windowClosesAt: new Date("2026-05-21T14:00:00.000Z"), // fecha em 2h
    windowClosingSoon: false,
    followupCount: 0,
    aiEnabled: true,
    handoffRequested: false,
    leadStage: "contacted",
    ...over,
  };
}

describe("isFollowupDue", () => {
  it("true: janela fechando dentro do lead time, conversa elegível", () => {
    expect(isFollowupDue(candidate(), NOW, CFG)).toBe(true);
  });

  it("false: janela ainda longe (> lead time)", () => {
    expect(
      isFollowupDue(
        candidate({ windowClosesAt: new Date("2026-05-21T20:00:00.000Z") }),
        NOW,
        CFG,
      ),
    ).toBe(false);
  });

  it("false: janela já fechada", () => {
    expect(
      isFollowupDue(
        candidate({ windowClosesAt: new Date("2026-05-21T10:00:00.000Z") }),
        NOW,
        CFG,
      ),
    ).toBe(false);
  });

  it("false: windowClosesAt null", () => {
    expect(isFollowupDue(candidate({ windowClosesAt: null }), NOW, CFG)).toBe(false);
  });

  it("false: windowClosingSoon já true (já reivindicada)", () => {
    expect(isFollowupDue(candidate({ windowClosingSoon: true }), NOW, CFG)).toBe(false);
  });

  it("false: followupCount já no limite", () => {
    expect(isFollowupDue(candidate({ followupCount: 1 }), NOW, CFG)).toBe(false);
  });

  it("false: aiEnabled false", () => {
    expect(isFollowupDue(candidate({ aiEnabled: false }), NOW, CFG)).toBe(false);
  });

  it("false: handoff solicitado", () => {
    expect(isFollowupDue(candidate({ handoffRequested: true }), NOW, CFG)).toBe(false);
  });

  it("false: stage fora do conjunto elegível", () => {
    expect(isFollowupDue(candidate({ leadStage: "won" }), NOW, CFG)).toBe(false);
  });

  it("false: leadStage null", () => {
    expect(isFollowupDue(candidate({ leadStage: null }), NOW, CFG)).toBe(false);
  });

  it("true: janela fecha de madrugada — deadline antecipado p/ antes do quiet hours", () => {
    const qhCfg = {
      maxPerWindow: 1,
      leadTimeMs: 4 * 3_600_000,
      quietHours: { start: "21:00", end: "08:00" },
    };
    const now = new Date("2026-05-21T23:30:00.000Z"); // 20:30 SP
    // janela fecha 05:00Z dia 22 (02:00 SP) → deadline efetivo = 00:00Z dia 22 (21:00 SP)
    const c = candidate({ windowClosesAt: new Date("2026-05-22T05:00:00.000Z") });
    expect(isFollowupDue(c, now, qhCfg)).toBe(true);
  });
});
