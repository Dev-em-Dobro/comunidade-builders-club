import { describe, it, expect, beforeEach, vi } from "vitest";
import { getActiveLaunch, _resetActiveLaunchCache } from "./active";
import { prisma } from "@/lib/db";

vi.mock("@/lib/db", () => ({
  prisma: {
    launch: { findMany: vi.fn() },
  },
}));

const findMany = prisma.launch.findMany as unknown as ReturnType<typeof vi.fn>;
const COURSE_ID = "course_abc";
const AT = new Date("2026-06-15T10:00:00Z");

function fixture(overrides: Partial<{
  id: string;
  status: string;
  startsAt: Date;
  endsAt: Date;
  updatedAt: Date;
}> = {}) {
  return {
    id: "launch_1",
    courseId: COURSE_ID,
    status: "live",
    startsAt: new Date("2026-06-10T00:00:00Z"),
    endsAt: new Date("2026-06-20T23:59:59Z"),
    updatedAt: new Date("2026-06-10T00:00:00Z"),
    plans: [],
    course: { id: COURSE_ID },
    ...overrides,
  };
}

beforeEach(() => {
  _resetActiveLaunchCache();
  findMany.mockReset();
});

describe("getActiveLaunch", () => {
  it("retorna launch live dentro da janela", async () => {
    findMany.mockResolvedValueOnce([fixture()]);
    const r = await getActiveLaunch(COURSE_ID, AT);
    expect(r?.id).toBe("launch_1");
  });

  it("retorna null quando query não acha nada", async () => {
    findMany.mockResolvedValueOnce([]);
    const r = await getActiveLaunch(COURSE_ID, AT);
    expect(r).toBeNull();
  });

  it("retorna o primeiro (DB ordena por updatedAt DESC) e loga warning quando há 2 lives — estado inválido", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    // Fixture já vem na ordem que Prisma retornaria (DESC por updatedAt).
    findMany.mockResolvedValueOnce([
      fixture({ id: "b", updatedAt: new Date("2026-06-14") }),
      fixture({ id: "a", updatedAt: new Date("2026-06-10") }),
    ]);
    const r = await getActiveLaunch(COURSE_ID, AT);
    expect(r?.id).toBe("b");
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
  });

  it("usa cache em chamada subsequente dentro do TTL", async () => {
    findMany.mockResolvedValueOnce([fixture()]);
    await getActiveLaunch(COURSE_ID, AT);
    await getActiveLaunch(COURSE_ID, AT);
    expect(findMany).toHaveBeenCalledTimes(1);
  });

  it("re-consulta depois do TTL expirar", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(AT);
    findMany.mockResolvedValueOnce([fixture()]);
    await getActiveLaunch(COURSE_ID);
    vi.setSystemTime(new Date(AT.getTime() + 61_000));
    findMany.mockResolvedValueOnce([fixture()]);
    await getActiveLaunch(COURSE_ID);
    expect(findMany).toHaveBeenCalledTimes(2);
    vi.useRealTimers();
  });

  it("monta a query com status=live, janela, courseId, ordenação por updatedAt DESC", async () => {
    findMany.mockResolvedValueOnce([]);
    await getActiveLaunch(COURSE_ID, AT);
    expect(findMany).toHaveBeenCalledWith({
      where: {
        courseId: COURSE_ID,
        status: "live",
        startsAt: { lte: AT },
        endsAt: { gt: AT },
      },
      include: {
        plans: { orderBy: { sortOrder: "asc" } },
        course: true,
      },
      orderBy: { updatedAt: "desc" },
    });
  });
});
