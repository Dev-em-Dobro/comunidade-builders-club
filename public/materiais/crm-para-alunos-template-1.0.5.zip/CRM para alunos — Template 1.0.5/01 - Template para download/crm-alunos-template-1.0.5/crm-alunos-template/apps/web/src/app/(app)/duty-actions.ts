"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

/** Liga/desliga o plantão do usuário logado. Entra no rodízio de handoff. */
export async function setOnDuty(value: boolean): Promise<void> {
  const session = await auth();
  if (!session?.user?.id) return;
  await prisma.user.update({
    where: { id: session.user.id },
    data: { isOnDuty: value },
  });
  revalidatePath("/", "layout");
}
