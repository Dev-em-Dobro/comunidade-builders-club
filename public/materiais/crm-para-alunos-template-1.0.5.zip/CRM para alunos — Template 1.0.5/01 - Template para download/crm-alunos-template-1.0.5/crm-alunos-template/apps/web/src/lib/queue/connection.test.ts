import { describe, it, expect, afterEach, vi } from "vitest";
import {
  getQueueConnection,
  closeQueueConnection,
  queueConnectionOptions,
} from "./connection";

afterEach(() => {
  closeQueueConnection();
  vi.unstubAllEnvs();
});

describe("getQueueConnection", () => {
  it("lança erro se REDIS_URL estiver ausente", () => {
    vi.stubEnv("REDIS_URL", "");
    expect(() => getQueueConnection()).toThrow(/REDIS_URL/);
  });

  it("retorna sempre a mesma instância (singleton)", () => {
    vi.stubEnv("REDIS_URL", "redis://127.0.0.1:56381");
    const a = getQueueConnection();
    const b = getQueueConnection();
    expect(b).toBe(a);
  });
});

describe("queueConnectionOptions", () => {
  it("lança erro se REDIS_URL estiver ausente", () => {
    vi.stubEnv("REDIS_URL", "");
    expect(() => queueConnectionOptions()).toThrow(/REDIS_URL/);
  });

  it("parseia host, port e exige maxRetriesPerRequest null", () => {
    vi.stubEnv("REDIS_URL", "redis://127.0.0.1:56381");
    const o = queueConnectionOptions();
    expect(o.host).toBe("127.0.0.1");
    expect(o.port).toBe(56381);
    expect(o.maxRetriesPerRequest).toBeNull();
  });

  it("extrai credenciais e db da URL", () => {
    vi.stubEnv("REDIS_URL", "redis://user:pass@10.0.0.1:6380/2");
    const o = queueConnectionOptions();
    expect(o.host).toBe("10.0.0.1");
    expect(o.port).toBe(6380);
    expect(o.username).toBe("user");
    expect(o.password).toBe("pass");
    expect(o.db).toBe(2);
  });
});
