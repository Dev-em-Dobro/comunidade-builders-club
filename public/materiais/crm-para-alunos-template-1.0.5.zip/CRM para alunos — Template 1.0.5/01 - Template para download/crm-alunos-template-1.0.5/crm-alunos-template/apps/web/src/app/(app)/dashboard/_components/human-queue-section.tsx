import Link from "next/link";
import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { ChevronRight, UserCheck } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatWaitDuration, waitTier, type WaitTier } from "../metrics";

/** Quantas conversas listar antes de colapsar no link "ver todas". */
const MAX_LISTED = 6;

interface WaitingItem {
  id: string;
  name: string;
  waitingMs: number;
}

interface HumanQueueData {
  items: WaitingItem[];
  error: boolean;
}

/**
 * Conversas aguardando atendimento humano: bot pediu handoff e ninguém assumiu
 * (mesma definição do card "Exigindo atenção" / filtro `handoff`).
 * O "há quanto tempo" vem do PipelineEvent `handoff` mais recente do lead;
 * na ausência dele, cai para a criação da conversa.
 */
async function getHumanQueue(): Promise<HumanQueueData> {
  try {
    const now = Date.now();
    const rows = await prisma.conversation.findMany({
      where: {
        handoffRequested: true,
        lead: {
          pipelineEvents: { none: { type: "handoff_accepted" } },
        },
      },
      select: {
        id: true,
        createdAt: true,
        contact: { select: { displayName: true } },
        lead: {
          select: {
            pipelineEvents: {
              where: { type: "handoff" },
              orderBy: { createdAt: "desc" },
              take: 1,
              select: { createdAt: true },
            },
          },
        },
      },
    });

    const items = rows
      .map((r): WaitingItem => {
        const since = r.lead?.pipelineEvents[0]?.createdAt ?? r.createdAt;
        return {
          id: r.id,
          name: r.contact?.displayName?.trim() || "Sem nome",
          waitingMs: Math.max(0, now - since.getTime()),
        };
      })
      .sort((a, b) => b.waitingMs - a.waitingMs);

    return { items, error: false };
  } catch {
    return { items: [], error: true };
  }
}

const TIER_TEXT: Record<WaitTier, string> = {
  ok: "text-muted-foreground",
  warn: "text-amber-600 dark:text-amber-400",
  urgent: "text-destructive",
};

export async function HumanQueueSection() {
  const { items, error } = await getHumanQueue();
  const total = items.length;
  const oldest = items[0];
  const hasWaiting = !error && total > 0;

  return (
    <Card
      className={cn(
        hasWaiting && "bg-destructive/10 ring-destructive/40",
      )}
    >
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Aguardando atendimento</CardTitle>
        <CardDescription>
          {error
            ? "Conversas com humano solicitado"
            : total === 0
              ? "Ninguém na fila no momento"
              : `${total} ${total === 1 ? "conversa" : "conversas"} · mais antiga ${formatWaitDuration(oldest.waitingMs)}`}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : total === 0 ? (
          <p className="flex items-center gap-2 px-2 py-2 text-sm text-muted-foreground">
            <UserCheck className="size-4 text-emerald-600 dark:text-emerald-400" />
            Tudo em dia — nenhuma conversa aguardando humano.
          </p>
        ) : (
          <>
            {items.slice(0, MAX_LISTED).map((item) => (
              <Link
                key={item.id}
                href={`/conversations/${item.id}`}
                className="flex items-center justify-between gap-2 rounded-md px-2 py-2 text-sm transition-colors hover:bg-muted/50"
              >
                <span className="truncate">{item.name}</span>
                <span className="flex shrink-0 items-center gap-1.5">
                  <span
                    className={`font-mono ${TIER_TEXT[waitTier(item.waitingMs)]}`}
                  >
                    {formatWaitDuration(item.waitingMs)}
                  </span>
                  <ChevronRight className="size-4 text-muted-foreground" />
                </span>
              </Link>
            ))}
            {total > MAX_LISTED && (
              <Link
                href="/conversations?filter=handoff"
                className="flex items-center justify-between rounded-md px-2 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted/50"
              >
                <span>+{total - MAX_LISTED} aguardando</span>
                <ChevronRight className="size-4" />
              </Link>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
