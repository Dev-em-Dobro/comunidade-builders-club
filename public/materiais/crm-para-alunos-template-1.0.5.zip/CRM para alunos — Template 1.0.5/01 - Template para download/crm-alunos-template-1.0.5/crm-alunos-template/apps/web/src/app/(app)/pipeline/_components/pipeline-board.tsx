"use client";

import { useState } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  useDraggable,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import { toast } from "sonner";
import { Column } from "./column";
import { LeadCard } from "./lead-card";
import { COLUMN_IDS, type ColumnId } from "@/lib/pipeline/columns";
import type { LeadView } from "./types";

interface Props {
  grouped: Record<ColumnId, LeadView[]>;
}

const STAGE_BY_COLUMN: Partial<Record<ColumnId, string>> = {
  new: "new",
  contacted: "contacted",
  qualified: "qualified",
  proposal: "proposal",
};
const FOLLOWUP_BY_COLUMN: Partial<Record<ColumnId, number>> = {
  f1: 1,
  f2: 2,
  f3: 3,
};

export function DraggableLead({
  lead,
  showStageBadge,
}: {
  lead: LeadView;
  showStageBadge: boolean;
}) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: lead.id,
  });
  return (
    <div
      ref={setNodeRef}
      style={{ opacity: isDragging ? 0.3 : 1 }}
      {...listeners}
      {...attributes}
    >
      <LeadCard lead={lead} showStageBadge={showStageBadge} />
    </div>
  );
}

export function PipelineBoard({ grouped: initial }: Props) {
  const [grouped, setGrouped] = useState(initial);
  const [activeId, setActiveId] = useState<string | null>(null);
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } }),
  );

  const activeLead = activeId
    ? COLUMN_IDS.flatMap((c) => grouped[c]).find((l) => l.id === activeId)
    : null;

  function onDragStart(event: DragStartEvent) {
    setActiveId(String(event.active.id));
  }

  async function onDragEnd(event: DragEndEvent) {
    setActiveId(null);
    const { active, over } = event;
    if (!over || !active) return;
    const leadId = String(active.id);
    const targetCol = String(over.id) as ColumnId;
    if (!COLUMN_IDS.includes(targetCol)) return;

    // Acha o lead + sua coluna atual
    let sourceCol: ColumnId | null = null;
    let lead: LeadView | null = null;
    for (const col of COLUMN_IDS) {
      const found = grouped[col].find((l) => l.id === leadId);
      if (found) {
        sourceCol = col;
        lead = found;
        break;
      }
    }
    if (!lead || !sourceCol || sourceCol === targetCol) return;

    // Drop em "closed" precisa de decisão won/lost
    let stageOverride: string | undefined;
    if (targetCol === "closed") {
      const choice =
        typeof window !== "undefined"
          ? window.prompt(
              "Marcar como ganho ou perdido? Digite 'ganho' ou 'perdido':",
              "perdido",
            )
          : null;
      if (!choice) return;
      if (choice.toLowerCase().startsWith("g")) stageOverride = "won";
      else if (choice.toLowerCase().startsWith("p")) stageOverride = "lost";
      else {
        toast.error("Resposta inválida — drop cancelado");
        return;
      }
    }

    // Calcula payload
    const body: { stage?: string; lastFollowUpStep?: number | null } = {};
    if (targetCol === "closed") {
      body.stage = stageOverride;
      body.lastFollowUpStep = null;
    } else if (FOLLOWUP_BY_COLUMN[targetCol] !== undefined) {
      body.lastFollowUpStep = FOLLOWUP_BY_COLUMN[targetCol]!;
    } else {
      const targetStage = STAGE_BY_COLUMN[targetCol]!;
      body.stage = targetStage;
      if (FOLLOWUP_BY_COLUMN[sourceCol] !== undefined) {
        body.lastFollowUpStep = null;
      }
    }

    // Optimistic UI
    const optimisticLead: LeadView = {
      ...lead,
      stage: body.stage ?? lead.stage,
      lastFollowUpStep:
        body.lastFollowUpStep !== undefined
          ? body.lastFollowUpStep
          : lead.lastFollowUpStep,
    };
    setGrouped((prev) => {
      const next = { ...prev };
      next[sourceCol!] = next[sourceCol!].filter((l) => l.id !== leadId);
      next[targetCol] = [optimisticLead, ...next[targetCol]];
      return next;
    });

    try {
      const r = await fetch(`/api/leads/${leadId}/stage`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const respBody = (await r.json().catch(() => ({}))) as {
          error?: string;
        };
        toast.error(respBody.error ?? `Falha (HTTP ${r.status})`);
        // Reverte
        setGrouped((prev) => {
          const next = { ...prev };
          next[targetCol] = next[targetCol].filter((l) => l.id !== leadId);
          next[sourceCol!] = [lead!, ...next[sourceCol!]];
          return next;
        });
      } else {
        toast.success("Movido");
      }
    } catch (e) {
      toast.error(String((e as Error)?.message ?? e));
      setGrouped((prev) => {
        const next = { ...prev };
        next[targetCol] = next[targetCol].filter((l) => l.id !== leadId);
        next[sourceCol!] = [lead!, ...next[sourceCol!]];
        return next;
      });
    }
  }

  return (
    <DndContext
      sensors={sensors}
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      onDragCancel={() => setActiveId(null)}
    >
      <div className="flex gap-3 overflow-x-auto pb-4">
        {COLUMN_IDS.map((col) => (
          <Column key={col} id={col} leads={grouped[col]} />
        ))}
      </div>
      <DragOverlay>
        {activeLead ? (
          <div className="rotate-2 cursor-grabbing">
            <LeadCard lead={activeLead} showStageBadge={false} />
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );
}
