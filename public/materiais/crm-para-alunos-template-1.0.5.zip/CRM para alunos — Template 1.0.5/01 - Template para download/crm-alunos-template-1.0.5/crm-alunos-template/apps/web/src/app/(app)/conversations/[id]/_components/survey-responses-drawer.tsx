"use client";

import { useState } from "react";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ClipboardList, Loader2 } from "lucide-react";
import { formatAnswersForDisplay } from "@/lib/surveys/format";

interface SurveyResponseDTO {
  id: string;
  surveyName: string;
  answers: Record<string, unknown>;
  submittedAt: string | null;
  createdAt: string;
}

interface Props {
  conversationId: string;
  /** Mostrar botão habilitado vs desabilitado (SSR sabe se tem resposta). */
  hasResponses: boolean;
}

export function SurveyResponsesDrawer({ conversationId, hasResponses }: Props) {
  const [open, setOpen] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [responses, setResponses] = useState<SurveyResponseDTO[]>([]);
  const [showOlder, setShowOlder] = useState(false);

  async function onOpenChange(next: boolean) {
    setOpen(next);
    if (next && !loaded && !loading) {
      setLoading(true);
      try {
        const r = await fetch(
          `/api/conversations/${conversationId}/survey-responses`,
        );
        if (r.ok) {
          const body = (await r.json()) as { responses: SurveyResponseDTO[] };
          setResponses(body.responses);
          setLoaded(true);
        }
      } finally {
        setLoading(false);
      }
    }
  }

  const visible = showOlder ? responses : responses.slice(0, 1);
  const olderCount = Math.max(0, responses.length - 1);

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        disabled={!hasResponses}
        onClick={() => onOpenChange(true)}
      >
        <ClipboardList className="size-4" />
        Pesquisa
      </Button>
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" className="w-[400px] sm:w-[480px] overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Respostas de pesquisa</SheetTitle>
        </SheetHeader>
        {loading && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground mt-4">
            <Loader2 className="size-4 animate-spin" /> carregando…
          </div>
        )}
        {!loading && loaded && responses.length === 0 && (
          <p className="text-sm text-muted-foreground mt-4">
            Sem respostas ainda.
          </p>
        )}
        <div className="space-y-4 mt-4">
          {visible.map((r) => {
            const entries = formatAnswersForDisplay(r.answers);
            const ts = r.submittedAt ?? r.createdAt;
            return (
              <Card key={r.id}>
                <CardHeader className="py-3">
                  <CardTitle className="text-sm flex items-center justify-between gap-2">
                    <span className="truncate">{r.surveyName}</span>
                    <Badge variant="outline" className="font-mono text-[10px]">
                      {ts.slice(0, 10)}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  {entries.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">
                      sem respostas registradas
                    </p>
                  ) : (
                    <dl className="space-y-2">
                      {entries.map((e) => (
                        <div key={e.question}>
                          <dt className="text-xs font-medium text-muted-foreground">
                            {e.question}
                          </dt>
                          <dd className="text-sm mt-0.5 whitespace-pre-wrap break-words">
                            {e.answer}
                          </dd>
                        </div>
                      ))}
                    </dl>
                  )}
                </CardContent>
              </Card>
            );
          })}
          {olderCount > 0 && !showOlder && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowOlder(true)}
              className="w-full"
            >
              ver {olderCount} pesquisa{olderCount > 1 ? "s" : ""} anterior
              {olderCount > 1 ? "es" : ""}
            </Button>
          )}
        </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
