/**
 * Base compartilhada Meta Graph API — Cloud API + Instagram Direct.
 *
 * Cobre:
 *  - hub.verify_token handshake (GET — plain text challenge)
 *  - subscription idempotente em /{node}/subscribed_apps (GET → POST se faltar)
 *  - error code map Meta (131047 = fora da 24h window, etc.)
 *
 * Não cobre HMAC do POST — ver hmac.ts (verifyHmacSha256).
 */

const graphVersion = process.env.META_GRAPH_VERSION || "v25.0";
if (!/^v[0-9]{2}\.0$/.test(graphVersion)) throw new Error("META_GRAPH_VERSION inválida");
export const META_GRAPH_BASE = `https://graph.facebook.com/${graphVersion}`;

export interface MetaSubscribeOpts {
  node: string;
  bearerToken: string;
  /** ?subscribed_fields= — só Instagram usa */
  subscribedFields?: string;
  /** META_APP_ID — pra detectar se o app específico já está subscrito */
  appId?: string;
}

export type MetaErrorCode =
  | 100
  | 131026
  | 131047
  | 131051
  | 200
  | "unknown";

export const META_ERRORS: Record<number, { name: string; action: string }> = {
  100: { name: "InvalidParam", action: "ver logs, corrigir request" },
  131026: { name: "Undeliverable", action: "dropar mensagem" },
  131047: { name: "OutOf24hWindow", action: "responder com template aprovado" },
  131051: { name: "UnsupportedMsgType", action: "dropar ou converter" },
  200: { name: "Permissions", action: "revisar permissões do app Meta" },
};

/** Code de "fora da janela de 24h" da Cloud API. */
export const META_OUT_OF_WINDOW = 131047;

export interface MetaErrorInfo {
  /** code numérico da Meta, ou "unknown" se a resposta não trouxe um. */
  code: number | "unknown";
  name: string;
  action: string;
  message: string;
}

/**
 * Extrai e mapeia o erro de uma resposta de erro da Graph API.
 * Resiliente a body não-JSON (gateway 5xx devolvem HTML).
 */
export function describeMetaError(status: number, body: string): MetaErrorInfo {
  let code: number | "unknown" = "unknown";
  let message = body;
  try {
    const json = JSON.parse(body) as {
      error?: { code?: number; message?: string };
    };
    if (json.error) {
      if (typeof json.error.code === "number") code = json.error.code;
      message = json.error.message ?? body;
    }
  } catch {
    // body não-JSON — mantém o texto cru como message
  }
  const known = typeof code === "number" ? META_ERRORS[code] : undefined;
  return {
    code,
    name: known?.name ?? `HTTP ${status}`,
    action: known?.action ?? "ver logs",
    message,
  };
}

/**
 * Erro de envio de mensagem por um canal. Carrega o `code` da Meta pro caller
 * decidir o que fazer (ex: marcar a conversa como fora da janela em 131047).
 */
export class ChannelSendError extends Error {
  readonly code: number | "unknown";
  readonly metaAction: string;
  constructor(info: MetaErrorInfo, status: number) {
    super(`sendText falhou ${status}: ${info.name} — ${info.message}`);
    this.name = "ChannelSendError";
    this.code = info.code;
    this.metaAction = info.action;
  }
}

interface SubscribedAppsResponse {
  data?: Array<{ id?: string; name?: string }>;
  error?: { code?: number; message?: string };
}

/**
 * Idempotente: GET → POST só se app não estiver na lista.
 * Throws apenas em erro de rede; permissões/erros Meta retornam objeto.
 */
export async function ensureSubscription(
  opts: MetaSubscribeOpts,
): Promise<{ alreadySubscribed: boolean; subscribed: boolean; error?: string }> {
  const url = `${META_GRAPH_BASE}/${opts.node}/subscribed_apps`;
  const headers = { Authorization: `Bearer ${opts.bearerToken}` };

  const listRes = await fetch(url, { headers, cache: "no-store" });
  const list = (await listRes.json()) as SubscribedAppsResponse;
  if (list.error) {
    return { alreadySubscribed: false, subscribed: false, error: `${list.error.code}: ${list.error.message}` };
  }

  const alreadySubscribed = !!list.data?.some(
    (s) => !opts.appId || s.id === opts.appId,
  );

  if (alreadySubscribed) {
    return { alreadySubscribed: true, subscribed: true };
  }

  const postUrl = opts.subscribedFields
    ? `${url}?subscribed_fields=${encodeURIComponent(opts.subscribedFields)}`
    : url;
  const postRes = await fetch(postUrl, { method: "POST", headers });
  const postJson = (await postRes.json()) as { success?: boolean; error?: { code?: number; message?: string } };

  if (postJson.error) {
    return { alreadySubscribed: false, subscribed: false, error: `${postJson.error.code}: ${postJson.error.message}` };
  }
  return { alreadySubscribed: false, subscribed: postJson.success !== false };
}

/**
 * Handshake compartilhado — Meta liga GET no webhook na hora de "Verify and Save".
 * Resposta DEVE ser plain text com o hub.challenge cru.
 */
export async function verifyMetaWebhook(
  req: Request,
  expectedVerifyToken: string | undefined,
): Promise<Response> {
  const url = new URL(req.url);
  const mode = url.searchParams.get("hub.mode");
  const token = url.searchParams.get("hub.verify_token");
  const challenge = url.searchParams.get("hub.challenge") ?? "";

  if (!expectedVerifyToken) {
    return new Response("missing META_WEBHOOK_VERIFY_TOKEN", { status: 500 });
  }
  if (mode === "subscribe" && token === expectedVerifyToken) {
    return new Response(challenge, {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    });
  }
  return new Response("forbidden", { status: 403 });
}

export function publicWebhookUrl(channel: "whatsapp-cloud" | "instagram"): string {
  const base =
    process.env.NEXT_PUBLIC_APP_URL ??
    process.env.RAILWAY_PUBLIC_DOMAIN ??
    "http://localhost:3000";
  const normalized = base.startsWith("http") ? base : `https://${base}`;
  return `${normalized}/api/webhooks/${channel}`;
}
