"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Save, Loader2 } from "lucide-react";
import { saveCadence } from "../actions";

interface TemplateOpt {
  metaName: string;
  language: string;
}
interface StepValue {
  step: number;
  value: string; // "metaName::language" ou ""
}

const NONE = "__none__";

const STEP_LABEL: Record<number, string> = {
  1: "F1 — 1º follow-up (~+1 dia)",
  2: "F2 — 2º follow-up (~+2 dias)",
  3: "F3 — 3º follow-up (~+4 dias)",
};

export function CadenceForm({
  templates,
  initial,
}: {
  templates: TemplateOpt[];
  initial: StepValue[];
}) {
  const [values, setValues] = useState<Record<number, string>>(
    Object.fromEntries(initial.map((s) => [s.step, s.value])),
  );
  const [pending, startTransition] = useTransition();

  function onSubmit() {
    startTransition(async () => {
      const fd = new FormData();
      for (const step of [1, 2, 3]) fd.set(`step_${step}`, values[step] ?? "");
      const res = await saveCadence(fd);
      if (res.error) toast.error(res.error);
      else toast.success(res.message ?? "Salvo");
    });
  }

  return (
    <div className="space-y-4">
      {[1, 2, 3].map((step) => {
        const v = values[step] ?? "";
        return (
          <div key={step} className="space-y-1">
            <Label htmlFor={`step-select-${step}`} className="text-sm font-medium">{STEP_LABEL[step]}</Label>
            <Select
              value={v === "" ? NONE : v}
              onValueChange={(val) => {
                const next: string = !val || val === NONE ? "" : val;
                setValues((p) => ({ ...p, [step]: next }));
              }}
            >
              <SelectTrigger id={`step-select-${step}`}>
                <SelectValue placeholder="Escolher template aprovado..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NONE}>— sem template (pula este step) —</SelectItem>
                {templates.map((t) => (
                  <SelectItem key={`${t.metaName}::${t.language}`} value={`${t.metaName}::${t.language}`}>
                    {t.metaName} ({t.language})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {v === "" && (
              <p className="text-xs text-warning">
                Sem template — este step não envia nada.
              </p>
            )}
          </div>
        );
      })}

      <Button onClick={onSubmit} disabled={pending} size="sm">
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Salvar cadência
      </Button>
    </div>
  );
}
