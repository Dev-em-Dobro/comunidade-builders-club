import { describe, it, expect } from "vitest";
import { normalizePhoneToE164 } from "./phone";

describe("normalizePhoneToE164", () => {
  it("normaliza '+55 (11) 98765-4321' para '5511987654321'", () => {
    expect(normalizePhoneToE164("+55 (11) 98765-4321")).toBe("5511987654321");
  });

  it("preserva número com 10 dígitos sem prefixo 55", () => {
    // 1198765432 (10 dígitos) — válido, normaliza pra "1198765432".
    // Matching layer (Task 4) tenta com 55 prepended como fallback.
    expect(normalizePhoneToE164("(11) 9876-5432")).toBe("1198765432");
  });

  it("retorna null pra entrada com menos de 10 dígitos", () => {
    expect(normalizePhoneToE164("abc")).toBeNull();
    expect(normalizePhoneToE164("123")).toBeNull();
  });

  it("retorna null pra string vazia ou só whitespace", () => {
    expect(normalizePhoneToE164("")).toBeNull();
    expect(normalizePhoneToE164("   ")).toBeNull();
  });
});
