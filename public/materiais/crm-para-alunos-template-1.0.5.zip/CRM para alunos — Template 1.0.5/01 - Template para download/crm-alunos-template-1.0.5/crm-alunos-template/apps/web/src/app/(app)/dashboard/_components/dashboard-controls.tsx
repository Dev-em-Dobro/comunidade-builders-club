"use client";

import { useRouter } from "next/navigation";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export interface LaunchOption {
  id: string;
  name: string;
}

export function DashboardControls({
  launches,
  launch,
  range,
}: {
  launches: LaunchOption[];
  launch: string;
  range: string;
}) {
  const router = useRouter();

  function navigate(next: { launch?: string; range?: string }) {
    const l = next.launch ?? launch;
    const r = next.range ?? range;
    const params = new URLSearchParams();
    if (l !== "all") params.set("launch", l);
    if (r !== "30") params.set("range", r);
    const qs = params.toString();
    router.push(qs ? `/dashboard?${qs}` : "/dashboard");
  }

  return (
    <div className="flex gap-2">
      <Select
        value={launch}
        onValueChange={(v) => navigate({ launch: String(v) })}
      >
        <SelectTrigger size="sm">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">Todos os lançamentos</SelectItem>
          {launches.map((l) => (
            <SelectItem key={l.id} value={l.id}>
              {l.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select
        value={range}
        onValueChange={(v) => navigate({ range: String(v) })}
      >
        <SelectTrigger size="sm">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="7">7 dias</SelectItem>
          <SelectItem value="30">30 dias</SelectItem>
          <SelectItem value="90">90 dias</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}
