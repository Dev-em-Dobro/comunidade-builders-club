/**
 * Serviço do delivery: estabelecimento, orçamento, registro e status dos
 * pedidos. Usado pelos tools do agente e pelas telas. Só servidor.
 */
import { prisma } from "@/lib/db";
import {
  formatBRL,
  normalizeAreas,
  normalizeMenuItems,
  ORDER_STATUSES,
  parseMoneyToCents,
  priceOrder,
  type DeliveryArea,
  type MenuItem,
  type OrderStatus,
  type PaymentMethod,
  type PriceResult,
} from "./menu";

export interface StoreView {
  agentSessionId: string;
  description: string | null;
  hours: string | null;
  pickupEnabled: boolean;
  pickupAddress: string | null;
  areas: DeliveryArea[];
  menu: MenuItem[];
  menuFileName: string | null;
  menuMimeType: string | null;
  menuToken: string | null;
  menuUpdatedAt: Date | null;
}

/** Estabelecimento do agente (sem o arquivo — ele é lido só quando vai ser enviado). */
export async function getStore(agentSessionId: string): Promise<StoreView> {
  const s = await prisma.deliveryStore.findUnique({
    where: { agentSessionId },
    select: {
      description: true,
      hours: true,
      pickupEnabled: true,
      pickupAddress: true,
      areas: true,
      menuItems: true,
      menuFileName: true,
      menuMimeType: true,
      menuToken: true,
      menuUpdatedAt: true,
    },
  });
  return {
    agentSessionId,
    description: s?.description ?? null,
    hours: s?.hours ?? null,
    pickupEnabled: s?.pickupEnabled ?? true,
    pickupAddress: s?.pickupAddress ?? null,
    areas: normalizeAreas(s?.areas),
    menu: normalizeMenuItems(s?.menuItems),
    menuFileName: s?.menuFileName ?? null,
    menuMimeType: s?.menuMimeType ?? null,
    menuToken: s?.menuToken ?? null,
    menuUpdatedAt: s?.menuUpdatedAt ?? null,
  };
}

export async function quoteOrder(agentSessionId: string, input: Record<string, unknown>): Promise<PriceResult> {
  const store = await getStore(agentSessionId);
  return priceOrder(
    { items: input.items, fulfillment: input.fulfillment, neighborhood: input.neighborhood },
    { menu: store.menu, areas: store.areas, pickupEnabled: store.pickupEnabled },
  );
}

export type PlaceResult =
  | {
      ok: true;
      orderNumber: number;
      items: { name: string; quantity: number; unitPrice: string }[];
      subtotal: string;
      deliveryFee: string;
      total: string;
      fulfillment: string;
      payment: string;
    }
  | { ok: false; error: string; message: string; [key: string]: unknown };

const PAYMENTS: PaymentMethod[] = ["pix", "card", "cash"];

export async function placeOrder(args: {
  agentSessionId: string;
  contactId: string;
  conversationId: string | null;
  input: Record<string, unknown>;
}): Promise<PlaceResult> {
  const { input } = args;
  const priced = await quoteOrder(args.agentSessionId, input);
  if (!priced.ok) return priced;

  const payment = PAYMENTS.find((p) => p === input.paymentMethod);
  if (!payment) {
    return { ok: false, error: "missing_payment", message: "Pergunte a forma de pagamento: Pix, cartão ou dinheiro." };
  }
  const address = typeof input.address === "string" ? input.address.trim().slice(0, 300) : "";
  if (input.fulfillment === "delivery" && address.length < 5) {
    return {
      ok: false,
      error: "missing_address",
      message: "Falta o endereço completo de entrega (rua, número, complemento e referência).",
    };
  }
  let changeForCents: number | null = null;
  if (payment === "cash" && input.changeFor !== undefined && input.changeFor !== null && input.changeFor !== "") {
    changeForCents = parseMoneyToCents(input.changeFor);
    if (changeForCents === null || changeForCents < priced.totalCents) {
      return {
        ok: false,
        error: "invalid_change",
        message: `O troco precisa ser para um valor maior ou igual ao total (${formatBRL(priced.totalCents)}).`,
      };
    }
  }
  const contact = await prisma.contact.findUnique({ where: { id: args.contactId }, select: { displayName: true } });
  const customerName =
    (typeof input.customerName === "string" && input.customerName.trim().slice(0, 120)) || contact?.displayName || null;
  const notes = typeof input.notes === "string" && input.notes.trim() ? input.notes.trim().slice(0, 500) : null;

  const order = await prisma.order.create({
    data: {
      agentSessionId: args.agentSessionId,
      contactId: args.contactId,
      conversationId: args.conversationId,
      customerName,
      items: priced.lines as unknown as object,
      subtotalCents: priced.subtotalCents,
      deliveryFeeCents: priced.deliveryFeeCents,
      totalCents: priced.totalCents,
      fulfillment: input.fulfillment === "pickup" ? "pickup" : "delivery",
      neighborhood: priced.neighborhood,
      address: input.fulfillment === "pickup" ? null : address,
      paymentMethod: payment,
      changeForCents,
      notes,
    },
  });

  // Histórico do contato (página do lead).
  const lead = await prisma.lead.findUnique({ where: { contactId: args.contactId }, select: { id: true } });
  if (lead) {
    await prisma.pipelineEvent
      .create({
        data: {
          leadId: lead.id,
          type: "order_placed",
          payload: { orderId: order.id, number: order.number, total: formatBRL(order.totalCents) },
        },
      })
      .catch(() => {});
  }
  console.log(JSON.stringify({ event: "delivery.order_placed", orderId: order.id, number: order.number, at: new Date().toISOString() }));

  return {
    ok: true,
    orderNumber: order.number,
    items: priced.lines.map((l) => ({ name: l.name, quantity: l.quantity, unitPrice: formatBRL(l.unitPriceCents) })),
    subtotal: formatBRL(priced.subtotalCents),
    deliveryFee: formatBRL(priced.deliveryFeeCents),
    total: formatBRL(priced.totalCents),
    fulfillment: order.fulfillment === "pickup" ? "retirada no local" : `entrega em ${order.neighborhood}`,
    payment,
  };
}

export async function updateOrderStatus(agentSessionId: string, orderId: string, status: string): Promise<boolean> {
  if (!ORDER_STATUSES.includes(status as OrderStatus)) return false;
  const res = await prisma.order.updateMany({ where: { id: orderId, agentSessionId }, data: { status } });
  return res.count > 0;
}
