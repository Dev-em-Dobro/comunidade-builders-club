import { defineConfig } from "vitest/config";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [tsconfigPaths()],
  test: {
    environment: "node",
    include: ["src/**/*.test.ts"],
    globals: false,
    // Testes de integração compartilham filas Redis nomeadas (sla, notify) e o
    // Postgres — rodar os arquivos em série evita corrida entre eles.
    fileParallelism: false,
    // Testes de integração apontam pro Redis/Postgres locais do docker-compose.
    // Sobrescreva exportando REDIS_URL/DATABASE_URL antes de rodar, se necessário.
    env: {
      REDIS_URL: process.env.REDIS_URL ?? "redis://127.0.0.1:56381/0",
      DATABASE_URL:
        process.env.DATABASE_URL ??
        "postgresql://crm_test:crm_test@127.0.0.1:55434/crm_template_test?schema=public",
    },
  },
});
