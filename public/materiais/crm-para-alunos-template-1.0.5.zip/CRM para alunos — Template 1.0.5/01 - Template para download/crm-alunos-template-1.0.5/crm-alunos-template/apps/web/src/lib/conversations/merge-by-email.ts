import { prisma } from "@/lib/db";

export type MergeReason =
  | "no_email_in_text"
  | "current_has_email"
  | "no_match"
  | "other_has_identities"
  | "other_has_lead";

export interface MergeResult {
  merged: boolean;
  movedSurveyResponses: number;
  emailUsed: string | null;
  reason?: MergeReason;
}

/**
 * Parte 12-E: extrai emails de um texto livre. Lowercase + dedup, preserva
 * a ordem da 1ª ocorrência. Regex simples — não tenta validar TLD nem
 * suportar emails com unicode.
 */
export function extractEmails(text: string): string[] {
  const re = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g;
  const matches = text.match(re) ?? [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const m of matches) {
    const lower = m.toLowerCase();
    if (seen.has(lower)) continue;
    seen.add(lower);
    out.push(lower);
  }
  return out;
}

/**
 * Parte 12-E: heurística pra fundir um Contact-só-email num Contact atual
 * que ainda não tem email setado. Chamada de `flush.ts` em todo inbound,
 * antes de `ensureLeadForContact`. Best-effort — o caller envolve em
 * try/catch e só loga sucesso/falha.
 *
 * Safety:
 *  - Skipa se `current` já tem email (idempotência).
 *  - Skipa cada candidato `other` que tenha identities (outro WhatsApp
 *    grudado) ou um Lead próprio. Esses guards evitam fundir o WhatsApp
 *    da Maria no Contact do João só porque ela citou o email dele.
 */
export async function mergeByEmailFromInbound(
  currentContactId: string,
  inboundText: string,
): Promise<MergeResult> {
  const emails = extractEmails(inboundText);
  if (emails.length === 0) {
    return {
      merged: false,
      movedSurveyResponses: 0,
      emailUsed: null,
      reason: "no_email_in_text",
    };
  }

  const current = await prisma.contact.findUnique({
    where: { id: currentContactId },
    select: { id: true, email: true },
  });
  if (!current) {
    return {
      merged: false,
      movedSurveyResponses: 0,
      emailUsed: null,
      reason: "no_match",
    };
  }
  if (current.email !== null) {
    return {
      merged: false,
      movedSurveyResponses: 0,
      emailUsed: null,
      reason: "current_has_email",
    };
  }

  let lastSkipReason: MergeReason | undefined;

  for (const email of emails) {
    const other = await prisma.contact.findUnique({
      where: { email },
      select: {
        id: true,
        email: true,
        identities: { select: { id: true }, take: 1 },
        lead: { select: { id: true } },
      },
    });
    if (!other) continue;
    if (other.id === currentContactId) continue; // edge: já é o mesmo Contact

    if (other.identities.length > 0) {
      lastSkipReason = "other_has_identities";
      continue;
    }
    if (other.lead) {
      lastSkipReason = "other_has_lead";
      continue;
    }

    // Safe merge — transação atômica:
    //  1) move SurveyResponses do other pro current
    //  2) zera other.email pra liberar o @unique
    //  3) seta current.email
    //  4) apaga o other (cascade pega o resto — mas guards já garantiram
    //     que não há identities, lead nem conversations a perder)
    const movedSurveyResponses = await prisma.$transaction(async (tx) => {
      const moved = await tx.surveyResponse.updateMany({
        where: { contactId: other.id },
        data: { contactId: currentContactId },
      });
      await tx.contact.update({
        where: { id: other.id },
        data: { email: null },
      });
      await tx.contact.update({
        where: { id: currentContactId },
        data: { email },
      });
      await tx.contact.delete({ where: { id: other.id } });
      return moved.count;
    });

    return {
      merged: true,
      movedSurveyResponses,
      emailUsed: email,
    };
  }

  return {
    merged: false,
    movedSurveyResponses: 0,
    emailUsed: null,
    reason: lastSkipReason ?? "no_match",
  };
}
