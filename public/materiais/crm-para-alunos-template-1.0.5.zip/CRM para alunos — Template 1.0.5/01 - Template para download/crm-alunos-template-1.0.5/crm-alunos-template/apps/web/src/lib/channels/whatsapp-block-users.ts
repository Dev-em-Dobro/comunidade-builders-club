import { resolveMetaSettings } from "@/lib/settings/meta";
/** Bloqueio de usuários na Cloud API da Meta. A resposta pode ser HTTP 200
 * mesmo quando o usuário específico falhou; conferir added/removed_users. */
import { META_GRAPH_BASE as BLOCK_USERS_GRAPH_BASE } from "./meta-graph";

type BlockUserResult = {
  input?: string;
  wa_id?: string;
};

type BlockUsersResponse = {
  data?: Array<{ wa_id?: string }>;
  paging?: { cursors?: { after?: string }; next?: string };
  block_users?: {
    added_users?: BlockUserResult[];
    removed_users?: BlockUserResult[];
    failed_users?: Array<{ input?: string; errors?: Array<{ message?: string; error_data?: { details?: string } }> }>;
  };
  error?: { message?: string; code?: number };
};

async function credentials() {
  const meta = await resolveMetaSettings();
  const phoneNumberId = meta.META_PHONE_NUMBER_ID;
  const token = meta.META_SYSTEM_USER_TOKEN;
  if (!phoneNumberId || !token) throw new Error("Credenciais WhatsApp da Meta não configuradas.");
  return { phoneNumberId, token };
}

function endpoint(phoneNumberId: string) {
  return `${BLOCK_USERS_GRAPH_BASE}/${encodeURIComponent(phoneNumberId)}/block_users`;
}

async function readResponse(res: Response): Promise<BlockUsersResponse> {
  const body = (await res.json().catch(() => ({}))) as BlockUsersResponse;
  if (!res.ok || body.error) {
    throw new Error(body.error?.message ?? `Meta retornou HTTP ${res.status}.`);
  }
  return body;
}

/** Consulta a lista da própria Meta, seguindo a paginação até achar o contato. */
export async function isWhatsAppUserBlocked(waId: string): Promise<boolean> {
  const { phoneNumberId, token } = await credentials();
  let after: string | undefined;
  do {
    const url = new URL(endpoint(phoneNumberId));
    url.searchParams.set("limit", "1000");
    if (after) url.searchParams.set("after", after);
    const body = await readResponse(await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
      cache: "no-store",
    }));
    if (body.data?.some((entry) => entry.wa_id === waId)) return true;
    const next = body.paging?.next ? body.paging.cursors?.after : undefined;
    if (!next || next === after) return false;
    after = next;
  } while (true);
}

export async function setWhatsAppUserBlocked(waId: string, blocked: boolean): Promise<void> {
  const { phoneNumberId, token } = await credentials();
  const body = await readResponse(await fetch(endpoint(phoneNumberId), {
    method: blocked ? "POST" : "DELETE",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      block_users: [{ user: waId }],
    }),
    cache: "no-store",
  }));

  const successes = blocked ? body.block_users?.added_users : body.block_users?.removed_users;
  if (successes?.some((entry) => entry.wa_id === waId || entry.input === waId)) return;
  const failed = body.block_users?.failed_users?.find((entry) => entry.input === waId);
  const reason = failed?.errors?.[0]?.error_data?.details ?? failed?.errors?.[0]?.message;
  throw new Error(reason ?? "A Meta não confirmou a alteração desse número.");
}
