import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  serverExternalPackages: ["@prisma/client", "ioredis", "bullmq"],

  // Next 16 bloqueia requisições cross-origin a recursos de dev (/_next/*, HMR)
  // por padrão. Acessando via túnel (ngrok) o host não é localhost — sem isto
  // o websocket de HMR cai e a página não hidrata (botões client-side mortos).
  // Wildcards cobrem o subdomínio do ngrok-free, que muda a cada restart.
  allowedDevOrigins: [
    "*.ngrok-free.dev",
    "*.ngrok-free.app",
    "*.ngrok.app",
    "*.ngrok.io",
  ],
  experimental: {
    // Upload de PDF pro RAG via Server Action — default é 1MB.
    serverActions: { bodySizeLimit: "10mb" },
  },
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "scontent.fbcdn.net" },
      { protocol: "https", hostname: "scontent.cdninstagram.com" },
      { protocol: "https", hostname: "lookaside.fbsbx.com" },
    ],
  },
};

export default nextConfig;
