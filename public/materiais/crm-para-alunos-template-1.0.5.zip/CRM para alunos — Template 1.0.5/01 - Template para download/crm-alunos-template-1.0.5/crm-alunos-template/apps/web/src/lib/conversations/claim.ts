import { prisma } from "@/lib/db";

export interface ClaimResult {
  /** true = a chamada mudou o assignedUserId. false = no-op idempotente. */
  claimed: boolean;
  /** Dono final da conversa após a chamada (existente ou recém-setado). */
  assignedUserId: string;
  /** Dono anterior, se havia um. Útil pra registrar no PipelineEvent. */
  previousOwnerId: string | null;
}

/**
 * Reivindica a posse de uma conversa pro `userId`. Idempotente:
 *  - sem dono → seta e cria PipelineEvent `handoff_accepted` via=auto_claim
 *  - mesmo dono → no-op (claimed=false)
 *  - outro dono + !force → no-op (claimed=false, mas devolve o dono atual)
 *  - outro dono + force → sobrescreve + PipelineEvent via=manual_claim
 *
 * Não emite `notifyConvEvent` — fica a cargo do caller decidir se vale.
 * O `POST /send` emite quando reclama (header de outras abas precisa atualizar);
 * o `POST /claim` também emite.
 *
 * Não falha se a conversa não tiver lead — pula a criação do PipelineEvent.
 */
export async function claimConversation(
  conversationId: string,
  userId: string,
  opts?: { force?: boolean },
): Promise<ClaimResult> {
  const conv = await prisma.conversation.findUniqueOrThrow({
    where: { id: conversationId },
    select: { assignedUserId: true, leadId: true },
  });

  const previousOwnerId = conv.assignedUserId;

  if (previousOwnerId === userId) {
    return { claimed: false, assignedUserId: userId, previousOwnerId };
  }
  if (previousOwnerId !== null && !opts?.force) {
    return { claimed: false, assignedUserId: previousOwnerId, previousOwnerId };
  }

  await prisma.conversation.update({
    where: { id: conversationId },
    data: { assignedUserId: userId },
  });

  if (conv.leadId) {
    await prisma.pipelineEvent.create({
      data: {
        leadId: conv.leadId,
        type: "handoff_accepted",
        payload: {
          via: previousOwnerId === null ? "auto_claim" : "manual_claim",
          userId,
          previousOwnerId,
        },
      },
    });
  }

  return { claimed: true, assignedUserId: userId, previousOwnerId };
}
