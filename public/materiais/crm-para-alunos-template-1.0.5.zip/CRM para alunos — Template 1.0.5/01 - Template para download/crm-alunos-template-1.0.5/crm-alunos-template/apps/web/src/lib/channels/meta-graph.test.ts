import { describe, it, expect } from "vitest";
import { describeMetaError } from "./meta-graph";

describe("describeMetaError", () => {
  it("mapeia o code 131047 (fora da janela 24h)", () => {
    const r = describeMetaError(
      400,
      JSON.stringify({ error: { code: 131047, message: "Out of window" } }),
    );
    expect(r.code).toBe(131047);
    expect(r.name).toBe("OutOf24hWindow");
    expect(r.action).toMatch(/template/);
    expect(r.message).toBe("Out of window");
  });

  it("code numérico desconhecido cai no fallback de name/action", () => {
    const r = describeMetaError(
      500,
      JSON.stringify({ error: { code: 999999, message: "x" } }),
    );
    expect(r.code).toBe(999999);
    expect(r.name).toMatch(/HTTP 500/);
  });

  it("body não-JSON não quebra — code 'unknown', message crua", () => {
    const r = describeMetaError(502, "<html>Bad Gateway</html>");
    expect(r.code).toBe("unknown");
    expect(r.message).toContain("Bad Gateway");
  });
});
