-- CreateTable
CREATE TABLE "ProfessionalDayOverride" (
    "id" TEXT NOT NULL,
    "professionalId" TEXT NOT NULL,
    "date" TEXT NOT NULL,
    "intervals" JSONB NOT NULL DEFAULT '[]',
    "note" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ProfessionalDayOverride_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ProfessionalDayOverride_professionalId_date_key" ON "ProfessionalDayOverride"("professionalId", "date");

-- AddForeignKey
ALTER TABLE "ProfessionalDayOverride" ADD CONSTRAINT "ProfessionalDayOverride_professionalId_fkey" FOREIGN KEY ("professionalId") REFERENCES "Professional"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Agenda própria do CRM: sai a integração com o Google Agenda.
ALTER TABLE "Professional" DROP COLUMN "calendarId",
DROP COLUMN "calendarName";

ALTER TABLE "Appointment" DROP COLUMN "googleCalendarId",
DROP COLUMN "googleEventId",
DROP COLUMN "googleEventLink";
