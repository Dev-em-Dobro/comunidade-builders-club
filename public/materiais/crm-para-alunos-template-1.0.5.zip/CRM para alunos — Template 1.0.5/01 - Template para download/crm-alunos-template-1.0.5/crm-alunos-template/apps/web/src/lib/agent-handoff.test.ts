import { describe, it, expect } from "vitest";
import { shouldHandoff, resolveTargetSession } from "./agent-handoff";

describe("shouldHandoff", () => {
  const baseCtx = {
    conv: { id: "c1", aiEnabled: true, agentSessionId: "sdr" },
    lead: { id: "l1", stage: "qualified" },
    targetSessionId: "closer",
  };

  it("happy path → true", () => {
    expect(shouldHandoff(baseCtx)).toBe(true);
  });

  it("sem lead → false", () => {
    expect(shouldHandoff({ ...baseCtx, lead: null })).toBe(false);
  });

  it("stage != qualified → false", () => {
    expect(
      shouldHandoff({ ...baseCtx, lead: { id: "l1", stage: "new" } }),
    ).toBe(false);
    expect(
      shouldHandoff({ ...baseCtx, lead: { id: "l1", stage: "contacted" } }),
    ).toBe(false);
  });

  it("aiEnabled=false → false", () => {
    expect(
      shouldHandoff({
        ...baseCtx,
        conv: { ...baseCtx.conv, aiEnabled: false },
      }),
    ).toBe(false);
  });

  it("targetSessionId=null → false", () => {
    expect(shouldHandoff({ ...baseCtx, targetSessionId: null })).toBe(false);
  });

  it("agentSessionId já é o target → false", () => {
    expect(
      shouldHandoff({
        ...baseCtx,
        conv: { ...baseCtx.conv, agentSessionId: "closer" },
      }),
    ).toBe(false);
  });
});

describe("resolveTargetSession", () => {
  const s = (id: string, role: string | null, ts: string) => ({
    id,
    role,
    createdAt: new Date(ts),
  });

  it("lista vazia → null", () => {
    expect(resolveTargetSession([], "closer")).toBeNull();
  });

  it("nenhum match → null", () => {
    expect(
      resolveTargetSession(
        [s("a", "sdr", "2026-01-01T00:00:00Z")],
        "closer",
      ),
    ).toBeNull();
  });

  it("1 match → retorna", () => {
    const sessions = [
      s("a", "sdr", "2026-01-01T00:00:00Z"),
      s("b", "closer", "2026-02-01T00:00:00Z"),
    ];
    expect(resolveTargetSession(sessions, "closer")?.id).toBe("b");
  });

  it("múltiplos matches → retorna o mais antigo por createdAt", () => {
    const sessions = [
      s("novo", "closer", "2026-03-01T00:00:00Z"),
      s("antigo", "closer", "2026-01-01T00:00:00Z"),
      s("medio", "closer", "2026-02-01T00:00:00Z"),
    ];
    expect(resolveTargetSession(sessions, "closer")?.id).toBe("antigo");
  });

  it("ignora sessions com role=null", () => {
    const sessions = [
      s("a", null, "2026-01-01T00:00:00Z"),
      s("b", "closer", "2026-02-01T00:00:00Z"),
    ];
    expect(resolveTargetSession(sessions, "closer")?.id).toBe("b");
  });
});

describe("shouldHandoff — support role", () => {
  const supportCtx = {
    conv: { id: "c1", aiEnabled: true, agentSessionId: "sdr" },
    lead: { id: "l1", stage: "new" },
    targetSessionId: "support",
  };

  it("support ignora o gate de stage=qualified → true mesmo com stage=new", () => {
    expect(shouldHandoff(supportCtx, "support")).toBe(true);
  });

  it("support com stage=won → true", () => {
    expect(
      shouldHandoff(
        { ...supportCtx, lead: { id: "l1", stage: "won" } },
        "support",
      ),
    ).toBe(true);
  });

  it("support ainda exige lead != null", () => {
    expect(shouldHandoff({ ...supportCtx, lead: null }, "support")).toBe(false);
  });

  it("support ainda exige aiEnabled", () => {
    expect(
      shouldHandoff(
        { ...supportCtx, conv: { ...supportCtx.conv, aiEnabled: false } },
        "support",
      ),
    ).toBe(false);
  });

  it("support no-op se já está no target", () => {
    expect(
      shouldHandoff(
        { ...supportCtx, conv: { ...supportCtx.conv, agentSessionId: "support" } },
        "support",
      ),
    ).toBe(false);
  });

  it("closer (default) continua exigindo stage=qualified", () => {
    expect(
      shouldHandoff({ ...supportCtx, targetSessionId: "closer" }, "closer"),
    ).toBe(false); // stage=new
  });
});
