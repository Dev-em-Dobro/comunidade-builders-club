import { beforeEach, afterEach, describe, expect, it, vi } from "vitest";
vi.mock("@/lib/db", () => ({ prisma: { providerCredential: { findMany: vi.fn() } } }));
import { prisma } from "@/lib/db";
import { encryptSecret } from "@/lib/crypto/secrets";
import { resolveMetaSettings, metaSettingsStatus } from "./meta";
beforeEach(() => { vi.stubEnv("SECRETS_KEY", "test-only-encryption-key"); vi.mocked(prisma.providerCredential.findMany).mockResolvedValue([]); });
afterEach(() => { vi.unstubAllEnvs(); vi.clearAllMocks(); });
describe("credenciais Meta isoladas por instalação", () => {
  it("usa ambiente quando não há valor no painel e dá precedência ao valor cifrado", async () => {
    vi.stubEnv("META_APP_SECRET", "environment-secret");
    expect((await resolveMetaSettings()).META_APP_SECRET).toBe("environment-secret");
    vi.mocked(prisma.providerCredential.findMany).mockResolvedValue([{ provider: "meta:META_APP_SECRET", apiKeyEnc: encryptSecret("database-secret") }] as never);
    expect((await resolveMetaSettings()).META_APP_SECRET).toBe("database-secret");
  });
  it("retorna presença e origem ao formulário sem retornar o token", async () => {
    vi.stubEnv("META_APP_SECRET", "environment-secret");
    vi.mocked(prisma.providerCredential.findMany).mockResolvedValue([{ provider: "meta:META_SYSTEM_USER_TOKEN" }] as never);
    const status=await metaSettingsStatus();
    expect(status.META_SYSTEM_USER_TOKEN).toBe("painel"); expect(status.META_APP_SECRET).toBe("ambiente");
    expect(JSON.stringify(status)).not.toContain("environment-secret");
  });
  it("falha se a chave de criptografia mudou, em vez de trocar silenciosamente de conta", async () => {
    const encrypted=encryptSecret("original-account-secret"); vi.stubEnv("SECRETS_KEY", "different-key");
    vi.mocked(prisma.providerCredential.findMany).mockResolvedValue([{ provider:"meta:META_APP_SECRET",apiKeyEnc:encrypted }] as never);
    await expect(resolveMetaSettings()).rejects.toThrow();
  });
});
