import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  findMany: vi.fn(),
  getActiveLaunch: vi.fn(),
}));

vi.mock("@/lib/db", () => ({ prisma: { course: { findMany: mocks.findMany } } }));
vi.mock("@/lib/launches/active", () => ({ getActiveLaunch: mocks.getActiveLaunch }));

import {
  getInstallmentAnswerFacts,
  isInstallmentQuestion,
  selectInstallmentCourse,
} from "./installment-answer";

const courses = [
  { id: "pass", name: "Dobro Pass", paymentMethods: "Pix à vista: R$ 1.997. Cartão parcelado: 12x de R$ 183,08 sem juros (total R$ 2.197). Boleto parcelado: até 24x (total R$ 2.500)." },
  { id: "full", name: "Formação Full Stack JS", paymentMethods: "Cartão em até 12x." },
];

beforeEach(() => {
  vi.clearAllMocks();
  mocks.findMany.mockResolvedValue(courses);
  mocks.getActiveLaunch.mockResolvedValue(null);
});

describe("dúvida de parcelamento", () => {
  it("associa 'esse valor' ao curso recomendado na mensagem anterior", () => {
    const chosen = selectInstallmentCourse(
      [
        { role: "assistant", content: "Eu recomendo o Dobro Pass: inclui a Formação Full Stack JS completa." },
        { role: "user", content: "Esse valor do curso posso parcelar em quantas vezes?" },
      ],
      [],
      courses,
    );
    expect(chosen?.id).toBe("pass");
  });

  it("preserva pedido explícito de atendimento humano", () => {
    expect(isInstallmentQuestion("Quero falar com uma pessoa sobre o parcelamento")).toBe(false);
  });

  it("responde as parcelas do cartão sem antecipar boleto ou afirmar ausência de juros", async () => {
    const facts = await getInstallmentAnswerFacts(
      [
        { role: "assistant", content: "Recomendo o Dobro Pass." },
        { role: "user", content: "Posso parcelar?" },
      ],
      [],
    );
    expect(facts).toEqual({
      courseName: "Dobro Pass",
      answer: "Sim! O Dobro Pass pode ser parcelado no cartão em 12x de R$ 183,08. O total parcelado é aproximadamente R$ 2.197. À vista, o valor cadastrado é R$ 1.997.",
    });
  });

  it("não usa parcelas do preço base quando existe oferta ativa sem condições próprias", async () => {
    mocks.getActiveLaunch.mockResolvedValue({ paymentMethodsOverride: null, plans: [] });
    const facts = await getInstallmentAnswerFacts(
      [
        { role: "assistant", content: "Recomendo o Dobro Pass." },
        { role: "user", content: "Em quantas vezes posso parcelar?" },
      ],
      [],
    );
    expect(facts).toBeNull();
  });

  it("não inventa valor quando o cadastro informa apenas até quantas vezes", async () => {
    const facts = await getInstallmentAnswerFacts(
      [{ role: "user", content: "A Formação Full Stack JS parcela em quantas vezes?" }],
      [],
    );
    expect(facts).toBeNull();
  });
});
