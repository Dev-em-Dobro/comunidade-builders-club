import { describe, it, expect } from "vitest";
import { formatTranscript, formatCriteriaBlock, RECORD_AUDIT_TOOL } from "./prompts";

describe("formatTranscript", () => {
  it("formata mensagens user/assistant com timestamps", () => {
    const msgs = [
      { role: "user", text: "oi", createdAt: new Date("2026-05-24T10:00:00Z") },
      { role: "assistant", text: "olá!", createdAt: new Date("2026-05-24T10:00:05Z") },
    ];
    const out = formatTranscript(msgs);
    expect(out).toContain("[user 2026-05-24T10:00:00.000Z]");
    expect(out).toContain("oi");
    expect(out).toContain("[assistant 2026-05-24T10:00:05.000Z]");
    expect(out).toContain("olá!");
  });

  it("retorna 'Sem mensagens.' quando array vazio", () => {
    expect(formatTranscript([])).toBe("Sem mensagens.");
  });

  it("ignora msg com text null/undefined", () => {
    const out = formatTranscript([
      { role: "user", text: null, createdAt: new Date() },
      { role: "assistant", text: "tem", createdAt: new Date() },
    ]);
    expect(out).toContain("tem");
    expect(out).not.toMatch(/\[user[^\]]*\]\s*$/m); // não tem linha de user vazia
  });
});

describe("formatCriteriaBlock", () => {
  it("numera critérios e inclui id, descrição, exampleFail, weight", () => {
    const block = formatCriteriaBlock([
      {
        id: "c1",
        name: "Não repetiu pergunta",
        description: "Bot não pergunta 2x",
        exampleFail: "perguntou objetivo 2x",
        weight: 4,
      },
      {
        id: "c2",
        name: "Preço correto",
        description: "Bate com catálogo",
        exampleFail: null,
        weight: 5,
      },
    ]);
    expect(block).toContain("# Critérios de auditoria");
    expect(block).toContain("1. **Não repetiu pergunta** (id=c1, peso=4)");
    expect(block).toContain("Bot não pergunta 2x");
    expect(block).toContain("Exemplo de fail: perguntou objetivo 2x");
    expect(block).toContain("2. **Preço correto** (id=c2, peso=5)");
    // Critério sem exampleFail: não imprime a linha "Exemplo de fail:".
    expect(block.match(/Exemplo de fail:/g)?.length).toBe(1);
  });
});

describe("RECORD_AUDIT_TOOL", () => {
  it("tem schema válido com findings array + oneLineVerdict required", () => {
    expect(RECORD_AUDIT_TOOL.name).toBe("record_audit");
    // inputSchema is Record<string,unknown>; cast for property access.
    const required = (RECORD_AUDIT_TOOL.inputSchema as { required?: string[] }).required;
    expect(required).toContain("findings");
    expect(required).toContain("oneLineVerdict");
  });
});
