"use client";

import { useEffect, useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Send, Loader2 } from "lucide-react";

interface Template {
  id: string;
  metaName: string;
  language: string;
  category: string;
  bodyText: string | null;
  variableCount: number;
}

function renderPreview(bodyText: string, variables: string[]): string {
  return bodyText.replace(/\{\{(\d+)\}\}/g, (_, n) => {
    const idx = Number(n) - 1;
    return variables[idx]?.length ? variables[idx] : `{{${n}}}`;
  });
}

export function TemplatePicker({ conversationId }: { conversationId: string }) {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [variables, setVariables] = useState<string[]>([]);
  const [pending, startTransition] = useTransition();

  useEffect(() => {
    let cancelled = false;
    fetch("/api/templates")
      .then((r) => r.json() as Promise<{ templates: Template[] }>)
      .then((body) => {
        if (cancelled) return;
        setTemplates(body.templates ?? []);
      })
      .catch(() => {
        if (cancelled) return;
        toast.error("Falha ao carregar templates");
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, []);

  const selected = templates.find((t) => t.id === selectedId) ?? null;

  function onSelectTemplate(id: string | null) {
    if (!id) return;
    const t = templates.find((tt) => tt.id === id);
    if (!t) return;
    setSelectedId(id);
    setVariables(Array.from({ length: t.variableCount }, () => ""));
  }

  function onVarChange(idx: number, value: string) {
    setVariables((prev) => {
      const next = [...prev];
      next[idx] = value;
      return next;
    });
  }

  const allFilled = selected
    ? variables.every((v) => v.trim().length > 0) ||
      selected.variableCount === 0
    : false;

  function send() {
    if (!selected) return;
    if (!allFilled) {
      toast.error("Preencha todas as variáveis");
      return;
    }
    startTransition(async () => {
      try {
        const r = await fetch(
          `/api/conversations/${conversationId}/send-template`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              templateMetaName: selected.metaName,
              language: selected.language,
              variables,
            }),
          },
        );
        const body = (await r.json().catch(() => ({}))) as {
          ok?: boolean;
          error?: string;
        };
        if (!r.ok) {
          toast.error(body.error ?? `Falha (HTTP ${r.status})`);
          return;
        }
        toast.success("Template enviado");
        setSelectedId(null);
        setVariables([]);
        // SSE traz a msg de volta
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  if (loading) {
    return (
      <div className="border-t bg-background p-3 sticky bottom-0">
        <p className="text-xs text-muted-foreground">Carregando templates…</p>
      </div>
    );
  }

  if (templates.length === 0) {
    return (
      <div className="border-t bg-background p-3 sticky bottom-0">
        <p className="text-xs text-warning">
          Janela 24h fechada e nenhum template aprovado. Cadastre um em
          /settings/templates.
        </p>
      </div>
    );
  }

  return (
    <div className="border-t bg-background p-3 sticky bottom-0 space-y-3">
      <p className="text-xs text-warning">
        Janela 24h fechada — envie um template aprovado:
      </p>

      <Select
        value={selectedId ?? ""}
        onValueChange={onSelectTemplate}
      >
        <SelectTrigger>
          <SelectValue placeholder="Escolher template..." />
        </SelectTrigger>
        <SelectContent>
          {templates.map((t) => (
            <SelectItem key={t.id} value={t.id}>
              {t.metaName} ({t.language})
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {selected && (
        <div className="space-y-2">
          <pre className="text-xs whitespace-pre-wrap font-mono bg-muted p-2 rounded">
            {selected.bodyText
              ? renderPreview(selected.bodyText, variables)
              : `[${selected.metaName} — sem body]`}
          </pre>

          {Array.from({ length: selected.variableCount }, (_, i) => (
            <div key={i} className="space-y-1">
              <Label htmlFor={`var-${i}`} className="text-xs font-mono">
                {`{{${i + 1}}}`}
              </Label>
              <Input
                id={`var-${i}`}
                value={variables[i] ?? ""}
                onChange={(e) => onVarChange(i, e.target.value)}
                placeholder={`Valor da variável ${i + 1}`}
              />
            </div>
          ))}

          <div className="flex justify-end">
            <Button
              size="sm"
              onClick={send}
              disabled={pending || !allFilled}
            >
              {pending ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Send className="size-4" />
              )}
              Enviar template
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
