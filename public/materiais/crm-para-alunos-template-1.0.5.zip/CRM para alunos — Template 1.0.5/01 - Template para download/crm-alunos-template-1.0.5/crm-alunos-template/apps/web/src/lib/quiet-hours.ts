/**
 * Quiet hours — janela do dia em que NÃO se envia follow-up automático.
 *
 * Horários (`"HH:MM"`) são interpretados no fuso de São Paulo. São Paulo não
 * tem horário de verão desde 2019, então usamos um offset fixo UTC−3 — sem
 * lib de timezone. Se o Brasil reinstaurar o horário de verão, este módulo
 * precisa ser revisto.
 */

export interface QuietHours {
  /** Início do bloco silencioso, `"HH:MM"` local SP. Inclusivo. */
  start: string;
  /** Fim do bloco silencioso, `"HH:MM"` local SP. Exclusivo. */
  end: string;
}

/** Offset de São Paulo em minutos (UTC−3). */
const SP_OFFSET_MIN = -180;

/** Minutos desde a meia-noite local SP, em [0, 1440). */
function spMinutesOfDay(d: Date): number {
  const utcMin = d.getUTCHours() * 60 + d.getUTCMinutes();
  return (((utcMin + SP_OFFSET_MIN) % 1440) + 1440) % 1440;
}

/** Converte `"HH:MM"` em minutos desde a meia-noite. */
function parseHHMM(s: string): number {
  const [h, m] = s.split(":").map(Number);
  return h * 60 + m;
}

/** `now` está dentro da janela de quiet hours? `start` inclusivo, `end` exclusivo. */
export function isQuietHours(now: Date, qh: QuietHours | null): boolean {
  if (!qh) return false;
  const cur = spMinutesOfDay(now);
  const start = parseHHMM(qh.start);
  const end = parseHHMM(qh.end);
  if (start === end) return false; // janela vazia
  if (start < end) return cur >= start && cur < end; // mesmo dia
  return cur >= start || cur < end; // cruza meia-noite
}

/**
 * Último instante válido para enviar um follow-up cuja janela de 24h fecha em
 * `windowClosesAt`. Se a janela fecha fora do quiet hours, é a própria data.
 * Se fecha dentro do quiet hours, é o início daquele bloco silencioso — não
 * adianta enviar depois disso.
 */
export function effectiveFollowupDeadline(
  windowClosesAt: Date,
  qh: QuietHours | null,
): Date {
  if (!qh || !isQuietHours(windowClosesAt, qh)) return windowClosesAt;
  const startMin = parseHHMM(qh.start);
  const curMin = spMinutesOfDay(windowClosesAt);
  // Minutos a recuar de windowClosesAt até o início do bloco de quiet hours.
  let back = curMin - startMin;
  if (back < 0) back += 1440; // o bloco começou no dia anterior
  return new Date(windowClosesAt.getTime() - back * 60_000);
}
