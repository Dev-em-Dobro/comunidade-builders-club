import { afterEach, describe, expect, it, vi } from "vitest";
import { resolveMetaSettings } from "@/lib/settings/meta";
import { whatsappCloudAdapter } from "./whatsapp-cloud";

vi.mock("@/lib/settings/meta", () => ({ resolveMetaSettings: vi.fn() }));

const credentials = {
  META_APP_ID: "app-123",
  META_APP_SECRET: "test-secret",
  META_WEBHOOK_VERIFY_TOKEN: "test-verify-token",
  META_PHONE_NUMBER_ID: "phone-123",
  META_BUSINESS_ACCOUNT_ID: "waba-456",
  META_SYSTEM_USER_TOKEN: "test-access-token",
};

afterEach(() => {
  vi.unstubAllGlobals();
  vi.resetAllMocks();
});

describe("assinatura de webhooks WhatsApp", () => {
  it("inscreve o app na WABA e consulta o número apenas para o status", async () => {
    vi.mocked(resolveMetaSettings).mockResolvedValue(credentials);
    const request = vi.fn(async (input: string | URL | Request, init?: RequestInit) => {
      const url = String(input);
      if (url.endsWith("/waba-456/subscribed_apps") && !init?.method) {
        return Response.json({ data: [] });
      }
      if (url.endsWith("/waba-456/subscribed_apps") && init?.method === "POST") {
        return Response.json({ success: true });
      }
      if (url.includes("/phone-123?fields=verified_name,display_phone_number")) {
        return Response.json({ verified_name: "Empresa de teste", display_phone_number: "+5511999999999" });
      }
      throw new Error(`Requisição inesperada: ${url}`);
    });
    vi.stubGlobal("fetch", request);

    const state = await whatsappCloudAdapter.ensureSession();

    expect(state.status).toBe("connected");
    expect(state.message).toContain("app subscrito agora");
    expect(request).toHaveBeenCalledTimes(3);
    expect(request.mock.calls[1]?.[0]).toContain("/waba-456/subscribed_apps");
    expect(request.mock.calls[1]?.[1]?.method).toBe("POST");
    expect(request.mock.calls[2]?.[0]).toContain("/phone-123?fields=");
  });

  it("informa a falta do WABA ID sem tentar assinar o número", async () => {
    vi.mocked(resolveMetaSettings).mockResolvedValue({
      ...credentials,
      META_BUSINESS_ACCOUNT_ID: undefined,
    });
    const request = vi.fn();
    vi.stubGlobal("fetch", request);

    const state = await whatsappCloudAdapter.ensureSession();

    expect(state.status).toBe("missing_credentials");
    expect(state.message).toContain("WABA ID");
    expect(request).not.toHaveBeenCalled();
  });
});
