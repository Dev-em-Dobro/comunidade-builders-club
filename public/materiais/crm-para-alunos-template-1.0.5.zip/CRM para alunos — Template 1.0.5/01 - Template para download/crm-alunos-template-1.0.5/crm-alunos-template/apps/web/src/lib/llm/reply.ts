import { generateReply } from "./index";
import { resolveProviderKey } from "./keys";
import type { LLMRequest, LLMResponse } from "./types";

/**
 * Resolve a chave BYOK do provider (ProviderCredential no banco → env var) e
 * chama generateReply com ela. Use isto — não generateReply direto — em qualquer
 * call site que dependa de um provider dinâmico (ex.: agentSession.provider) ou
 * que deva honrar a chave configurada na tela de Chaves de API.
 */
export async function generateReplyWithKey(
  provider: string,
  req: Omit<LLMRequest, "apiKey">,
): Promise<LLMResponse> {
  const apiKey = await resolveProviderKey(provider);
  return generateReply(provider, { ...req, apiKey });
}
