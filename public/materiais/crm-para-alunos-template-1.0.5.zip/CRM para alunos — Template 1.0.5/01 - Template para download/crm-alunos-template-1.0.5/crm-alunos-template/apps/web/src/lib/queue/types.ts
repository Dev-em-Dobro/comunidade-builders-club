/**
 * Nomes das filas BullMQ do CRM Template.
 *  - sla                  — deadline de resposta (Parte 4) + escalonamento de handoff (Parte 8)
 *  - followup             — geração de follow-up de reengajamento (Partes 7/11)
 *  - window24h            — scan repetível das janelas 24h do WhatsApp (Parte 7)
 *  - notify               — disparo de email + notificação in-app (Partes 4/8)
 *  - ingest-rag           — ingestão de documentos pro RAG
 *  - qualify              — classificação + lead scoring pós-turno (Parte 10)
 *  - reengagement         — scan repetível do reengajamento de leads parados (Parte 11)
 *  - out-window-followup  — scan 30min: cadência de follow-up fora da janela 24h (Parte 13)
 *  - audit                — auditoria on-demand de conversas (Sub-Plan A do auditor)
 *  - launch-transitions   — cron 5min: ativa planned com startsAt<=now, encerra live com endsAt<=now (Oferta por lançamento)
 */
export const QUEUE_NAMES = [
  "sla",
  "followup",
  "window24h",
  "notify",
  "ingest-rag",
  "qualify",
  "reengagement",
  "out-window-followup",
  "window-warning",
  "audit",
  "launch-transitions",
] as const;

export type QueueName = (typeof QUEUE_NAMES)[number];

/**
 * Payload base de TODO job.
 *
 * Padrão de idempotência: o job carrega só referências de domínio
 * (`conversationId` / `leadId`) — NUNCA snapshots de estado. O processador
 * recarrega o estado fresco do DB e revalida antes de agir, porque o estado
 * pode ter mudado entre o enfileiramento e a execução (ex: lead já respondido,
 * stage trocado). Tipos de job específicos estendem esta interface.
 */
export interface BaseJobData {
  conversationId?: string;
  leadId?: string;
}

/** Payload do job `sla.deadline` — checa se a conversa foi respondida a tempo. */
export interface SlaJobData extends BaseJobData {
  conversationId: string;
  inboundMessageId?: string;
}

/** Payload dos jobs da fila `notify`. */
export interface NotifyJobData extends BaseJobData {
  /** tipo da notificação — por ora só breach de SLA. */
  kind: "sla_breach";
}

/** Payload do job `followup.generate` — gera o follow-up de reengajamento. */
export interface FollowupJobData extends BaseJobData {
  conversationId: string;
  /**
   * Motivo do follow-up (Parte 11). Default = "window_closing" (retrocompat
   * com a Parte 7). "reengagement_12h" injeta objeções do lead no prompt.
   */
  reason?: "window_closing" | "reengagement_12h";
}

/** Payload do job `sla.handoff` — escalonamento se ninguém assumir o handoff (Parte 8). */
export interface HandoffJobData extends BaseJobData {
  conversationId: string;
}

/** Payload do job `qualify.lead` — classifica e re-pontua o lead (Parte 10). */
export interface QualifyJobData extends BaseJobData {
  conversationId: string;
}

/** Payload do job `window-warning.fire` — alerta proativo de 1h pra fechamento. */
export interface WindowWarningJobData extends BaseJobData {
  conversationId: string;
}

/** Payload do job `audit.run` — auditoria de um AuditReport. */
export interface AuditJobData extends BaseJobData {
  reportId: string;
}

/** Payload do job `agent.handoff` — troca de AgentSession após lead qualificar (2026-05-25). */
export interface AgentHandoffJobData extends BaseJobData {
  conversationId: string;
  toRole: "closer" | "support";
}

/** Payload do job `out-window-followup.send` — envia 1 template do step. */
export interface OutWindowSendJobData extends BaseJobData {
  conversationId: string;
  step: number;
}
