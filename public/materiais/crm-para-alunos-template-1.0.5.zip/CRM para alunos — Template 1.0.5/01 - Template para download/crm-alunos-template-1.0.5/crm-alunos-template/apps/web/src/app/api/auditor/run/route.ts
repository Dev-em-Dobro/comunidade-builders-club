import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import type { AuditJobData } from "@/lib/queue/types";
import { exceedsDailyBudget } from "@/lib/audit/budget";
import { auditorConfig } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Body {
  reuseFromReportId?: string;
}

/** Janela de debounce contra cliques duplos. */
const DEBOUNCE_MS = 5 * 60 * 1000;

export async function POST(req: Request): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const body = (await req.json().catch(() => ({}))) as Body;

  // Debounce: existe report queued/running criado nos últimos 5min?
  const since = new Date(Date.now() - DEBOUNCE_MS);
  const inflight = await prisma.auditReport.findFirst({
    where: {
      status: { in: ["queued", "running"] },
      runAt: { gte: since },
    },
    select: { id: true },
    orderBy: { runAt: "desc" },
  });
  if (inflight) {
    return NextResponse.json(
      { error: "already_running", existing: inflight.id },
      { status: 409 },
    );
  }

  // Cap diário: bloqueia novos runs quando o gasto do dia excede o limite.
  const cfg = auditorConfig();
  const { exceeded, current } = await exceedsDailyBudget(
    0.05, // estimativa mínima de 1 conversa
    cfg.maxCostPerDayUsd,
  );
  if (exceeded) {
    return NextResponse.json(
      {
        error: "daily_budget_exceeded",
        currentUsd: current,
        capUsd: cfg.maxCostPerDayUsd,
      },
      { status: 429 },
    );
  }

  // Reuso de conversationIds (botão "Reabrir").
  let conversationIds: string[] = [];
  if (body.reuseFromReportId) {
    const prev = await prisma.auditReport.findUnique({
      where: { id: body.reuseFromReportId },
      select: { conversationIds: true },
    });
    if (!prev) {
      return NextResponse.json(
        { error: "reuse_source_not_found" },
        { status: 404 },
      );
    }
    conversationIds = prev.conversationIds;
  }

  const report = await prisma.auditReport.create({
    data: {
      status: "queued",
      trigger: "manual",
      conversationIds,
    },
  });

  await enqueue<AuditJobData>(
    "audit",
    "audit.run",
    { reportId: report.id },
    {
      jobId: `audit-manual-${report.id}`,
      removeOnComplete: true,
      removeOnFail: 50,
      // Sem retry: runAudit não é idempotente — re-execução duplicaria
      // AuditFinding (cada criterion gera findings em insert, sem dedup).
      attempts: 1,
    },
  );

  return NextResponse.json(
    { ok: true, reportId: report.id, redirectTo: `/auditor/${report.id}` },
    { status: 202 },
  );
}
