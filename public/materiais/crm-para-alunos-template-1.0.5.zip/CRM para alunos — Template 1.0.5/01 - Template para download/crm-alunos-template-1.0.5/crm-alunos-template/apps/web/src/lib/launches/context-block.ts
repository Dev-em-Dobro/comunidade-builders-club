import { parseBonuses } from "./types";
import type { ActiveLaunch } from "./active";

const BRL = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

function daysRemaining(endsAt: Date, at: Date): number {
  const ms = endsAt.getTime() - at.getTime();
  return Math.max(0, Math.ceil(ms / 86_400_000));
}

function fmtDateBR(d: Date): string {
  // launch-form envia date-only (YYYY-MM-DD), `new Date(...)` parseia como UTC
  // meia-noite. Renderizar em BRT (-3h) fazia 2026-06-06 virar "05/06 21:00",
  // induzindo o bot a falar "termina dia 5". Render em UTC e só a data preserva
  // a intenção que o admin clicou no picker.
  return d.toLocaleDateString("pt-BR", { timeZone: "UTC" });
}

function fmtBRL(cents: number): string {
  // Intl.NumberFormat may insert U+00A0 (non-breaking space) between "R$" and digits;
  // normalise to regular space so LLM context is plain ASCII-friendly.
  return BRL.format(cents / 100).replace(/ /g, " ");
}

/**
 * Renderiza o bloco "OFERTA ATIVA" que vai pro contexto da LLM.
 *
 * Contrato (do spec):
 *  - Cabeçalho com nome do Launch + janela.
 *  - ÂNGULO opcional.
 *  - PLANOS sempre (ordem de sortOrder, marca tem/sem checkout).
 *  - BÔNUS opcional (lista).
 *  - CONDIÇÕES: usa override se preenchido, senão herda do Course.
 *  - REGRAS DE COMPORTAMENTO: sempre presentes; ganha linha "pergunte qual plano"
 *    quando há 2+ planos.
 */
export function renderOfferBlock(launch: ActiveLaunch, at: Date = new Date()): string {
  const lines: string[] = [];
  lines.push(`## OFERTA ATIVA — ${launch.name}`);
  lines.push(
    `Janela: até ${fmtDateBR(launch.endsAt)} (${daysRemaining(launch.endsAt, at)} dias restantes)`,
  );
  lines.push("");

  if (launch.pitchAngle) {
    lines.push(`ÂNGULO: ${launch.pitchAngle}`);
    lines.push("");
  }

  lines.push("PLANOS:");
  for (const p of launch.plans) {
    const tag = p.checkoutUrl ? "[tem checkout]" : "[sem checkout]";
    lines.push(`- ${p.name} — ${fmtBRL(p.priceCents)} — ${tag}`);
  }
  lines.push("");

  const bonuses = parseBonuses(launch.bonuses);
  if (bonuses.length > 0) {
    lines.push("BÔNUS INCLUÍDOS:");
    for (const b of bonuses) {
      lines.push(`- ${b.title}: ${b.description}`);
    }
    lines.push("");
  }

  const pay = launch.paymentMethodsOverride ?? launch.course.paymentMethods;
  const guar = launch.guaranteePolicyOverride ?? launch.course.guaranteePolicy;
  if (pay || guar) {
    lines.push("CONDIÇÕES (override sobre o curso):");
    if (pay) lines.push(`- Pagamento: ${pay}`);
    if (guar) lines.push(`- Garantia: ${guar}`);
    lines.push("");
  }

  lines.push("REGRAS DE COMPORTAMENTO:");
  lines.push("- Use a janela e o ângulo como gatilho de fechamento.");
  lines.push("- NUNCA invente bônus ou preço fora desta lista.");

  const firstUrl = launch.plans[0]?.checkoutUrl;
  const allPlansSameUrl =
    launch.plans.length >= 2 &&
    firstUrl != null &&
    launch.plans.every((p) => p.checkoutUrl === firstUrl);

  if (launch.plans.length >= 2 && allPlansSameUrl) {
    lines.push(
      "- Os planos compartilham a mesma URL de checkout — a landing page decide a escolha. " +
        "Liste os preços pra o lead saber o que está comprando, mas QUANDO ELE PEDIR O LINK, " +
        "chame get_checkout_link({ courseId }) sem planId e mande a URL retornada direto. " +
        "NÃO pergunte qual plano e NÃO diga 'vou verificar' — manda na hora.",
    );
  } else if (launch.plans.length >= 2) {
    lines.push(
      "- Há 2+ planos com URLs diferentes. Pergunte qual plano o lead quer ANTES da 1ª " +
        "chamada de get_checkout_link.",
    );
    lines.push(
      "- DEPOIS que o lead responder qual plano ('1 ano', 'o mais barato', etc), case o nome " +
        "dito com o `name` da lista de PLANOS acima (case-insensitive, match por substring se " +
        "precisar) e chame get_checkout_link({ courseId, planId }) passando o id correto. " +
        "NÃO diga 'vou verificar com o time' — o link já existe no DB, o tool resolve.",
    );
    lines.push(
      "- Se o tool retornar { needsPlanChoice: true, plans: [...] } DEPOIS do lead ter " +
        "escolhido, é porque você esqueceu o planId. Releia a lista que veio no tool result, " +
        "encontre o id pelo name e chame de novo.",
    );
  }
  lines.push(
    "- Se o lead pedir preço fora da janela ou bônus não listado → use a tool request_human_handoff.",
  );
  lines.push("- Se o lead perguntar sobre oferta anterior/encerrada → handoff.");

  return lines.join("\n");
}
