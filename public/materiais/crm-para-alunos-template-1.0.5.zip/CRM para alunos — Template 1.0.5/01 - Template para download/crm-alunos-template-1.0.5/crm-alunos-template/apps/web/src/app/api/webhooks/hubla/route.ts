import { NextResponse } from "next/server";
import { Prisma } from "@prisma/client";
import crypto from "node:crypto";
import { prisma } from "@/lib/db";
import {
  extractLeadIdFromUtm,
  extractPayerEmail,
  extractPurchaseData,
} from "@/lib/webhooks/hubla/parser";
import { applyPurchase } from "@/lib/webhooks/hubla/apply";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}

/** Constant-time compare; difere em tamanho ⇒ retorna false sem comparar. */
function tokenOk(received: string | null, expected: string): boolean {
  if (!received) return false;
  const a = Buffer.from(received);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export async function POST(req: Request): Promise<Response> {
  const expectedToken = process.env.HUBLA_WEBHOOK_TOKEN;
  if (!expectedToken) {
    log({ event: "hubla.no_token" });
    return NextResponse.json({ error: "not_configured" }, { status: 500 });
  }

  if (!tokenOk(req.headers.get("x-hubla-token"), expectedToken)) {
    log({ event: "hubla.unauthorized" });
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const idempotencyKey = req.headers.get("x-hubla-idempotency");
  if (!idempotencyKey) {
    log({ event: "hubla.no_idempotency" });
    return NextResponse.json({ error: "missing_idempotency" }, { status: 400 });
  }

  let payload: unknown;
  try {
    payload = await req.json();
  } catch {
    log({ event: "hubla.invalid_json", idempotencyKey });
    return NextResponse.json({ error: "invalid_json" }, { status: 400 });
  }

  const eventType =
    typeof (payload as { type?: unknown })?.type === "string"
      ? (payload as { type: string }).type
      : "unknown";

  // Tenta criar o WebhookEvent. Unique (provider, idempotencyKey) cobre dedup
  // — race condition trata o P2002 com lookup do existente:
  //   - existing.result != null → genuinamente processado, dedup.
  //   - existing.result == null → órfão de tentativa anterior que falhou
  //     entre create e update; reprocessa pra não perder a venda.
  let event: { id: string };
  try {
    event = await prisma.webhookEvent.create({
      data: {
        provider: "hubla",
        idempotencyKey,
        eventType,
        payload: payload as Prisma.InputJsonValue,
      },
      select: { id: true },
    });
  } catch (err) {
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      err.code === "P2002"
    ) {
      const existing = await prisma.webhookEvent.findUniqueOrThrow({
        where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey } },
        select: { id: true, result: true },
      });
      if (existing.result !== null) {
        log({ event: "hubla.dedup_race", idempotencyKey, eventType });
        return NextResponse.json({ ok: true, dedup: true }, { status: 200 });
      }
      log({ event: "hubla.reprocess_orphan", idempotencyKey, eventType });
      event = { id: existing.id };
    } else {
      throw err;
    }
  }

  // Dispatch por tipo. invoice.payment_succeeded é tratado na Task 5;
  // tudo o mais grava ignored_type + 200.
  if (eventType !== "invoice.payment_succeeded") {
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { result: "ignored_type", processedAt: new Date() },
    });
    log({ event: "hubla.ignored_type", idempotencyKey, eventType });
    return NextResponse.json({ ok: true }, { status: 200 });
  }

  // ── invoice.payment_succeeded
  const purchase = extractPurchaseData(payload);
  if (!purchase) {
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { result: "invalid_payload", processedAt: new Date() },
    });
    log({ event: "hubla.invalid_payment_payload", idempotencyKey });
    return NextResponse.json({ ok: true }, { status: 200 });
  }

  // 1. Tenta achar lead via UTM.
  let leadId: string | null = extractLeadIdFromUtm(payload);
  if (leadId) {
    const exists = await prisma.lead.findUnique({
      where: { id: leadId },
      select: { id: true },
    });
    if (!exists) leadId = null;
  }

  // 2. Fallback por email.
  if (!leadId) {
    const email = extractPayerEmail(payload);
    if (email) {
      const contact = await prisma.contact.findUnique({
        where: { email },
        select: { lead: { select: { id: true } } },
      });
      leadId = contact?.lead?.id ?? null;
    }
  }

  if (!leadId) {
    await prisma.webhookEvent.update({
      where: { id: event.id },
      data: { result: "lead_not_found", processedAt: new Date() },
    });
    log({ event: "hubla.lead_not_found", idempotencyKey });
    return NextResponse.json({ ok: true }, { status: 200 });
  }

  const applied = await applyPurchase(prisma, leadId, purchase);
  const result = applied.ok ? applied.status : applied.reason;

  await prisma.webhookEvent.update({
    where: { id: event.id },
    data: { result, processedAt: new Date(), leadId: applied.ok ? leadId : null },
  });
  log({ event: "hubla.processed", idempotencyKey, result, leadId });
  return NextResponse.json({ ok: true }, { status: 200 });
}
