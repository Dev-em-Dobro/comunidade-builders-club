import { Queue, type JobsOptions } from "bullmq";
import { getQueueConnection } from "./connection";
import { QUEUE_NAMES, type QueueName, type BaseJobData } from "./types";

const queues = new Map<QueueName, Queue>();

/** Retorna a Queue BullMQ pro nome dado, instanciando lazy + cache em Map. */
export function getQueue(name: QueueName): Queue {
  let q = queues.get(name);
  if (!q) {
    q = new Queue(name, { connection: getQueueConnection() });
    queues.set(name, q);
  }
  return q;
}

/** Enfileira um job tipado na fila dada. */
export function enqueue<T extends BaseJobData>(
  name: QueueName,
  jobName: string,
  data: T,
  opts?: JobsOptions,
) {
  return getQueue(name).add(jobName, data, opts);
}

export type QueueCounts = Awaited<ReturnType<Queue["getJobCounts"]>>;

/** Contadores de jobs (waiting/active/delayed/...) de todas as filas. */
export async function getAllQueueCounts(): Promise<Record<QueueName, QueueCounts>> {
  const result = {} as Record<QueueName, QueueCounts>;
  for (const name of QUEUE_NAMES) {
    result[name] = await getQueue(name).getJobCounts();
  }
  return result;
}

/** Fecha todas as filas abertas. Usado em teardown de teste e shutdown. */
export async function closeAllQueues(): Promise<void> {
  for (const q of queues.values()) await q.close();
  queues.clear();
}
