import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { activateLaunch, closeLaunch } from "./transitions";
import { _resetActiveLaunchCache } from "./active";

const created = { contactIds: [] as string[], courseIds: [] as string[] };
let courseId: string;
let userId: string;

beforeAll(async () => {
  const u = await prisma.user.create({
    data: { email: `transitions-test-${Date.now()}@example.com`, name: "Transitions Test" },
  });
  userId = u.id;

  const c = await prisma.course.create({
    data: { name: "Transitions Course", slug: `trans-${Date.now()}`, priceCents: 1000 },
  });
  courseId = c.id;
  created.courseIds.push(c.id);
});

afterAll(async () => {
  // Limpa launches e changelogs primeiro (FK cascade pode resolver mas explícito é melhor)
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId } } });
  await prisma.launch.deleteMany({ where: { courseId } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.user.delete({ where: { id: userId } }).catch(() => {});
  await prisma.$disconnect();
});

beforeEach(async () => {
  _resetActiveLaunchCache();
  // Limpa launches entre testes pra isolar
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId } } });
  await prisma.launch.deleteMany({ where: { courseId } });
});

async function createPlannedLaunch(opts: {
  startsAt?: Date;
  endsAt?: Date;
  withPlan?: boolean;
  courseIdOverride?: string | null;
} = {}) {
  const launch = await prisma.launch.create({
    data: {
      name: `T-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      slug: `t-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      startsAt: opts.startsAt ?? new Date(Date.now() + 86400000),
      endsAt: opts.endsAt ?? new Date(Date.now() + 7 * 86400000),
      status: "planned",
      courseId: opts.courseIdOverride === null ? null : (opts.courseIdOverride ?? courseId),
    },
  });
  if (opts.withPlan ?? true) {
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "P1", priceCents: 1000, checkoutUrl: "x", sortOrder: 0 },
    });
  }
  return launch;
}

describe("activateLaunch", () => {
  it("erro: launch não existe", async () => {
    const r = await activateLaunch({ launchId: "nonexistent", byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/encontrado/i);
  });

  it("erro: status já é live", async () => {
    const l = await createPlannedLaunch();
    await prisma.launch.update({ where: { id: l.id }, data: { status: "live" } });
    const r = await activateLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/já está live/i);
  });

  it("erro: sem courseId", async () => {
    const l = await createPlannedLaunch({ courseIdOverride: null });
    const r = await activateLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/curso/i);
  });

  it("erro: sem planos", async () => {
    const l = await createPlannedLaunch({ withPlan: false });
    const r = await activateLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/plano/i);
  });

  it("erro: endsAt no passado", async () => {
    const l = await createPlannedLaunch({
      startsAt: new Date(Date.now() - 7 * 86400000),
      endsAt: new Date(Date.now() - 86400000),
    });
    const r = await activateLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/fim no passado/i);
  });

  it("erro: overlap com outro live", async () => {
    // Cria L1 live cobrindo agora
    const l1 = await prisma.launch.create({
      data: {
        name: `L1-${Date.now()}`,
        slug: `l1-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 7 * 86400000),
        status: "live",
        courseId,
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: l1.id, name: "P1", priceCents: 1000, checkoutUrl: "x", sortOrder: 0 },
    });

    // L2 planned com overlap
    const l2 = await createPlannedLaunch({
      startsAt: new Date(Date.now() + 86400000),
      endsAt: new Date(Date.now() + 7 * 86400000),
    });
    const r = await activateLaunch({ launchId: l2.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/conflit/i);
    expect(r.conflict?.id).toBe(l1.id);
  });

  it("sucesso manual: status=live, move startsAt=now se no futuro, grava changelog", async () => {
    const future = new Date(Date.now() + 86400000);
    const l = await createPlannedLaunch({ startsAt: future });
    const r = await activateLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    expect(r.ok).toBe(true);

    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("live");
    expect(after.startsAt.getTime()).toBeLessThan(future.getTime());
    expect(after.startsAt.getTime()).toBeGreaterThan(Date.now() - 5000);

    const changes = await prisma.launchStatusChange.findMany({ where: { launchId: l.id } });
    expect(changes).toHaveLength(1);
    expect(changes[0]!.fromStatus).toBe("planned");
    expect(changes[0]!.toStatus).toBe("live");
    expect(changes[0]!.reason).toBe("manual");
    expect(changes[0]!.byUserId).toBe(userId);
  });

  it("sucesso cron_start: NÃO move startsAt", async () => {
    const past = new Date(Date.now() - 60_000); // já passou
    const l = await createPlannedLaunch({ startsAt: past });
    const r = await activateLaunch({ launchId: l.id, byUserId: null, reason: "cron_start" });
    expect(r.ok).toBe(true);

    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.startsAt.getTime()).toBe(past.getTime());
  });
});

describe("closeLaunch", () => {
  it("erro: launch não existe", async () => {
    const r = await closeLaunch({ launchId: "nonexistent", byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/encontrado/i);
  });

  it("erro: já está closed", async () => {
    const l = await createPlannedLaunch();
    await prisma.launch.update({ where: { id: l.id }, data: { status: "closed" } });
    const r = await closeLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    if (r.ok) throw new Error("expected error result");
    expect(r.error).toMatch(/closed/i);
  });

  it("manual: status=closed, endsAt=now, changelog", async () => {
    const farFuture = new Date(Date.now() + 30 * 86400000);
    const l = await createPlannedLaunch({ endsAt: farFuture });
    await prisma.launch.update({ where: { id: l.id }, data: { status: "live" } });
    const r = await closeLaunch({ launchId: l.id, byUserId: userId, reason: "manual" });
    expect(r.ok).toBe(true);

    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("closed");
    expect(after.endsAt.getTime()).toBeLessThan(farFuture.getTime());
    expect(after.endsAt.getTime()).toBeGreaterThan(Date.now() - 5000);

    const changes = await prisma.launchStatusChange.findMany({ where: { launchId: l.id } });
    expect(changes).toHaveLength(1);
    expect(changes[0]!.toStatus).toBe("closed");
  });

  it("cron_end: NÃO mexe em endsAt", async () => {
    const orig = new Date(Date.now() - 60_000);
    const l = await createPlannedLaunch();
    await prisma.launch.update({
      where: { id: l.id },
      data: { status: "live", endsAt: orig },
    });
    const r = await closeLaunch({ launchId: l.id, byUserId: null, reason: "cron_end" });
    expect(r.ok).toBe(true);

    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.endsAt.getTime()).toBe(orig.getTime());
  });
});
