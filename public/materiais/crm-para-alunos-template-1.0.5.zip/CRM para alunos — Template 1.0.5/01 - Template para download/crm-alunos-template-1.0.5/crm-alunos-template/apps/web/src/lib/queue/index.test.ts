import { describe, it, expect, afterAll } from "vitest";
import { getQueue, getAllQueueCounts, closeAllQueues } from "./index";
import { closeQueueConnection } from "./connection";
import { QUEUE_NAMES } from "./types";

afterAll(async () => {
  await closeAllQueues();
  closeQueueConnection();
});

describe("registry de filas", () => {
  it("getQueue retorna a mesma instância pra um nome (singleton)", () => {
    expect(getQueue("sla")).toBe(getQueue("sla"));
  });

  it("getAllQueueCounts cobre as 5 filas", async () => {
    const counts = await getAllQueueCounts();
    expect(Object.keys(counts).sort()).toEqual([...QUEUE_NAMES].sort());
    for (const name of QUEUE_NAMES) {
      expect(counts[name]).toHaveProperty("waiting");
    }
  });

  it("um job delayed aparece no contador 'delayed'", async () => {
    const q = getQueue("sla");
    await q.obliterate({ force: true });
    await q.add("test-delayed", { leadId: "lead-x" }, { delay: 60_000 });
    const counts = await getAllQueueCounts();
    expect(counts.sla.delayed).toBeGreaterThanOrEqual(1);
    await q.obliterate({ force: true });
  }, 15_000);
});
