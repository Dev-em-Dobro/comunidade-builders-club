import Link from "next/link";
import { prisma } from "@/lib/db";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MessagesSquare, AlertTriangle, Clock, Lock } from "lucide-react";
import { windowBadgeStatus } from "@/lib/window-status";
import { LeadOutcomeBadge } from "@/components/lead-outcome-badge";
import { formatDateTime } from "@/lib/datetime";

export const dynamic = "force-dynamic";

type Filter = "all" | "sla" | "closing" | "handoff";
type Sort = "recent" | "score";

/** Monta a query string preservando filtro e ordenação. */
function buildHref(filter: Filter, sort: Sort): string {
  const params = new URLSearchParams();
  if (filter !== "all") params.set("filter", filter);
  if (sort !== "recent") params.set("sort", sort);
  const qs = params.toString();
  return qs ? `/conversations?${qs}` : "/conversations";
}

/** Classe de cor do badge de score por banda. */
function scoreBadgeClass(score: number): string {
  if (score >= 70) return "border-success/30 text-success";
  if (score >= 40) return "border-warning/30 text-warning";
  return "border-muted-foreground/40 text-muted-foreground";
}

export default async function ConversationsPage({
  searchParams,
}: {
  searchParams: Promise<{ filter?: string; sort?: string }>;
}) {
  const { filter: rawFilter, sort: rawSort } = await searchParams;
  const filter: Filter =
    rawFilter === "sla"
      ? "sla"
      : rawFilter === "closing"
        ? "closing"
        : rawFilter === "handoff"
          ? "handoff"
          : "all";
  const sort: Sort = rawSort === "score" ? "score" : "recent";
  const convs = await safeQuery(filter, sort);

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Conversas
        </h1>
        <p className="text-muted-foreground mt-1">
          {convs.length} conversa{convs.length !== 1 ? "s" : ""} · cross-channel inbox
        </p>
      </header>

      <div className="mb-4 flex flex-wrap items-center gap-2">
        <FilterTab href={buildHref("all", sort)} label="Todas" active={filter === "all"} />
        <FilterTab
          href={buildHref("sla", sort)}
          label="Aguardando humano (SLA)"
          active={filter === "sla"}
        />
        <FilterTab
          href={buildHref("closing", sort)}
          label="Janela fechando"
          active={filter === "closing"}
        />
        <FilterTab
          href={buildHref("handoff", sort)}
          label="Bot solicitou humano"
          active={filter === "handoff"}
        />
        <div className="ml-auto flex items-center gap-1.5 text-sm text-muted-foreground">
          <span>Ordenar:</span>
          <SortTab
            href={buildHref(filter, "recent")}
            label="Recência"
            active={sort === "recent"}
          />
          <SortTab
            href={buildHref(filter, "score")}
            label="Score"
            active={sort === "score"}
            disabled={filter === "closing"}
          />
        </div>
      </div>

      {convs.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <MessagesSquare className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">
            {filter === "sla"
              ? "Nenhum SLA estourado"
              : filter === "closing"
                ? "Nenhuma janela fechando"
                : filter === "handoff"
                  ? "Nenhum pedido de humano aguardando"
                  : "Nenhuma conversa ainda"}
          </p>
          <p className="text-sm text-muted-foreground mt-1">
            {filter === "sla"
              ? "Toda conversa foi respondida dentro do prazo."
              : filter === "closing"
                ? "Nenhuma conversa com a janela de 24h prestes a fechar."
                : filter === "handoff"
                  ? "Toda solicitação já foi assumida por um operador."
                  : "Quando uma mensagem chegar via WhatsApp ou Instagram, aparece aqui."}
          </p>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Contato</TableHead>
                <TableHead>Atendente</TableHead>
                <TableHead>Canal</TableHead>
                <TableHead>IA</TableHead>
                <TableHead className="text-right">Última msg</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {convs.map((c) => (
                <TableRow key={c.id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/conversations/${c.id}`}
                        className={`hover:text-primary ${
                          c.unreadCount > 0 ? "font-semibold" : "font-medium"
                        }`}
                      >
                        {c.contact?.displayName ?? "(sem nome)"}
                      </Link>
                      {c.unreadCount > 0 && (
                        <Badge
                          title="Mensagens não lidas"
                          className="text-[10px] font-mono px-1.5"
                        >
                          {c.unreadCount}
                        </Badge>
                      )}
                      {c.lead && (
                        <Badge
                          variant="outline"
                          title="Lead score"
                          className={`gap-1 text-[10px] font-mono ${scoreBadgeClass(c.lead.score)}`}
                        >
                          {c.lead.score}
                        </Badge>
                      )}
                      {c.lead && (
                        <LeadOutcomeBadge
                          stage={c.lead.stage}
                          lostReason={c.lead.lostReason}
                        />
                      )}
                      {c.lead?.slaBreachedAt && (
                        <Badge variant="destructive" className="gap-1 text-[10px]">
                          <AlertTriangle className="size-3" /> SLA estourado
                        </Badge>
                      )}
                      {(() => {
                        const status = windowBadgeStatus(c, new Date());
                        if (status === "closing") {
                          return (
                            <Badge
                              variant="outline"
                              className="gap-1 text-[10px] border-warning/30 text-warning"
                            >
                              <Clock className="size-3" /> janela fechando
                            </Badge>
                          );
                        }
                        if (status === "closed") {
                          return (
                            <Badge
                              variant="outline"
                              className="gap-1 text-[10px] border-muted-foreground/40 text-muted-foreground"
                            >
                              <Lock className="size-3" /> janela fechada
                            </Badge>
                          );
                        }
                        return null;
                      })()}
                    </div>
                    <div className="text-xs text-muted-foreground font-mono">
                      {c.contact?.identities?.[0]?.externalId}
                    </div>
                  </TableCell>
                  <TableCell>
                    {c.assignedUser ? (
                      <span className="text-sm truncate inline-block max-w-[140px]">
                        {c.assignedUser.name ?? c.assignedUser.email}
                      </span>
                    ) : (
                      <span className="text-muted-foreground/60">—</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className="font-mono text-[10px]">
                      {c.channel}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    {c.handoffRequested ? (
                      <Badge variant="outline" className="font-mono text-[10px] border-warning/30 text-warning">
                        humano
                      </Badge>
                    ) : c.aiEnabled ? (
                      <Badge className="font-mono text-[10px]">on</Badge>
                    ) : (
                      <Badge variant="outline" className="font-mono text-[10px] border-muted-foreground/40">
                        paused
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right text-xs text-muted-foreground font-mono">
                    {c.lastMessageAt ? formatDateTime(c.lastMessageAt) : "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}

function FilterTab({
  href,
  label,
  active,
}: {
  href: string;
  label: string;
  active: boolean;
}) {
  return (
    <Link
      href={href}
      className={`rounded-md px-3 py-1.5 text-sm transition-colors ${
        active
          ? "bg-primary text-primary-foreground"
          : "border border-border text-muted-foreground hover:text-foreground"
      }`}
    >
      {label}
    </Link>
  );
}

function SortTab({
  href,
  label,
  active,
  disabled = false,
}: {
  href: string;
  label: string;
  active: boolean;
  disabled?: boolean;
}) {
  if (disabled) {
    return (
      <span className="rounded-md px-2.5 py-1 text-xs text-muted-foreground/40">
        {label}
      </span>
    );
  }
  return (
    <Link
      href={href}
      className={`rounded-md px-2.5 py-1 text-xs transition-colors ${
        active
          ? "bg-primary text-primary-foreground"
          : "border border-border text-muted-foreground hover:text-foreground"
      }`}
    >
      {label}
    </Link>
  );
}

async function safeQuery(filter: Filter, sort: Sort) {
  try {
    const where =
      filter === "sla"
        ? { lead: { slaBreachedAt: { not: null } } }
        : filter === "closing"
          ? { windowClosingSoon: true, windowClosesAt: { gt: new Date() } }
          : filter === "handoff"
            ? {
                handoffRequested: true,
                lead: {
                  pipelineEvents: { none: { type: "handoff_accepted" } },
                },
              }
            : {};
    return await prisma.conversation.findMany({
      where,
      include: {
        contact: { include: { identities: true } },
        lead: {
          select: {
            slaBreachedAt: true,
            score: true,
            stage: true,
            lostReason: true,
          },
        },
        assignedUser: { select: { id: true, name: true, email: true } },
      },
      orderBy:
        filter === "closing"
          ? { windowClosesAt: "asc" }
          : sort === "score"
            ? [{ lead: { score: "desc" } }, { lastMessageAt: "desc" }]
            : { lastMessageAt: "desc" },
      take: 100,
    });
  } catch {
    return [];
  }
}
