import { auth } from "@/auth";
import Link from "next/link";
import { waqrSettingsStatus } from "@/lib/settings/whatsapp-qr";
import { WaqrForm } from "./waqr-form";
import { clearWaqr } from "./actions";
export const dynamic = "force-dynamic";
export default async function WhatsAppQrSettingsPage() {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const status = await waqrSettingsStatus();
  return <div className="p-6 md:p-8 max-w-3xl space-y-6">
    <header><h1 className="text-3xl font-semibold">WhatsApp via QR (não oficial)</h1><p className="text-muted-foreground mt-2">Conecta um número pelo WhatsApp Web usando um provedor próprio (WAHA). O guia docs/WHATSAPP_QR.md explica a instalação local e no Railway.</p></header>
    <div className="border border-warning/40 bg-warning/10 rounded-md p-4 text-sm space-y-2">
      <p><strong>Conexão não oficial.</strong> A sessão pode cair e o número pode ser bloqueado pelo WhatsApp, principalmente com disparo para quem não escreveu primeiro, volume alto ou número novo. Para atendimento crítico, prefira a API oficial (Conectar Meta).</p>
      <p>Use um número exclusivo deste CRM. Se a mesma sessão também enviar webhook para outro sistema (ex.: n8n), os dois agentes respondem o cliente.</p>
    </div>
    <p className="text-sm text-muted-foreground">Campos vazios preservam os valores atuais. Valores do painel têm precedência sobre as variáveis WAQR_* do servidor e são guardados com criptografia. Chaves salvas não são devolvidas ao navegador. A chave da API deve ser igual a WAHA_API_KEY do container WAHA.</p>
    <WaqrForm status={status} />
    <Link className="underline block" href="/onboarding">Garantir sessão e ler o QR no onboarding</Link><Link className="underline block" href="/settings">Ativar o canal em Geral</Link>
    <details className="border rounded p-4 text-sm"><summary>Remover valores cadastrados no painel</summary><p className="my-3">Remove os valores deste formulário. Se houver variáveis WAQR_* no servidor, elas voltam a ser usadas. Para desconectar o número, desative o canal em Geral e faça logout da sessão no WAHA.</p>
      <form action={clearWaqr}><button type="submit" className="underline text-destructive">Remover valores do painel</button></form>
    </details>
  </div>;
}
