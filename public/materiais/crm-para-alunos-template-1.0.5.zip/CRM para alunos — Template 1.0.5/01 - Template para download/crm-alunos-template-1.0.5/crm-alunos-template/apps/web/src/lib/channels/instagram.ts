import { resolveMetaSettings } from "@/lib/settings/meta";
import { verifyHmacSha256 } from "./hmac";
import {
  META_GRAPH_BASE,
  ensureSubscription,
  publicWebhookUrl,
  verifyMetaWebhook,
} from "./meta-graph";
import { HmacFailure } from "./whatsapp-cloud";
import type {
  ChannelAdapter,
  ChannelMessage,
  ChannelMedia,
  SessionState,
} from "./types";

async function env() {
  const meta = await resolveMetaSettings();
  return {
    appId: meta.META_APP_ID,
    appSecret: meta.META_APP_SECRET,
    pageId: meta.META_IG_PAGE_ID,
    igBusinessAccountId: meta.META_IG_BUSINESS_ACCOUNT_ID,
    pageToken: meta.META_IG_PAGE_ACCESS_TOKEN,
    verifyToken: meta.META_WEBHOOK_VERIFY_TOKEN,
  };
}

function missingCreds(e: Awaited<ReturnType<typeof env>>) {
  return !e.appSecret || !e.pageId || !e.pageToken || !e.verifyToken;
}

async function detectStatus(): Promise<SessionState> {
  const e = await env();
  if (missingCreds(e)) {
    return {
      channel: "instagram",
      status: "missing_credentials",
      webhookUrl: publicWebhookUrl("instagram"),
      message: "Faltam env vars: META_APP_SECRET, META_IG_PAGE_ID, META_IG_PAGE_ACCESS_TOKEN, META_WEBHOOK_VERIFY_TOKEN.",
    };
  }
  const res = await fetch(
    `${META_GRAPH_BASE}/${e.pageId}?fields=name,instagram_business_account`,
    { headers: { Authorization: `Bearer ${e.pageToken}` }, cache: "no-store" },
  );
  const json = (await res.json()) as {
    name?: string;
    instagram_business_account?: { id?: string };
    error?: { code?: number; message?: string };
  };
  if (json.error) {
    return {
      channel: "instagram",
      status: "error",
      webhookUrl: publicWebhookUrl("instagram"),
      message: `${json.error.code}: ${json.error.message}`,
    };
  }
  if (!json.instagram_business_account?.id) {
    return {
      channel: "instagram",
      status: "needs_verification",
      webhookUrl: publicWebhookUrl("instagram"),
      message: "Page não está conectada a um IG Business Account. Conectar via Meta Business Suite.",
    };
  }
  return {
    channel: "instagram",
    status: "connected",
    webhookUrl: publicWebhookUrl("instagram"),
    verifyToken: e.verifyToken,
    message: `${json.name ?? "Page"} ↔ IG ${json.instagram_business_account.id}`,
    details: json as Record<string, unknown>,
  };
}

export const instagramAdapter: ChannelAdapter = {
  id: "instagram",

  async ensureSession() {
    const e = await env();
    if (missingCreds(e)) return detectStatus();
    const result = await ensureSubscription({
      node: e.pageId!,
      bearerToken: e.pageToken!,
      appId: e.appId,
      subscribedFields: "messages,messaging_postbacks",
    });
    const status = await detectStatus();
    return {
      ...status,
      message: result.error
        ? `subscription falhou: ${result.error}`
        : result.alreadySubscribed
          ? `${status.message} · subscription já ativa`
          : `${status.message} · app subscrito agora`,
    };
  },

  async getSessionStatus() {
    return detectStatus();
  },

  async verifyWebhook(req) {
    return verifyMetaWebhook(req, (await env()).verifyToken);
  },

  async parseWebhook(req) {
    const rawBody = await req.text();
    const sig = req.headers.get("x-hub-signature-256");
    const e = await env();
    if (!e.appSecret || !verifyHmacSha256(rawBody, sig, e.appSecret)) {
      throw new HmacFailure("invalid signature");
    }

    const payload = JSON.parse(rawBody) as {
      object?: string;
      entry?: Array<{
        id?: string;
        time?: number;
        messaging?: Array<{
          sender?: { id?: string };
          recipient?: { id?: string };
          timestamp?: number;
          message?: {
            mid?: string;
            text?: string;
            attachments?: Array<{ type?: string; payload?: { url?: string } }>;
            is_echo?: boolean;
          };
          postback?: { mid?: string; title?: string; payload?: string };
        }>;
      }>;
    };

    for (const entry of payload.entry ?? []) {
      for (const m of entry.messaging ?? []) {
        if (m.message?.is_echo) continue; // mensagem outbound emitida pelo próprio Page
        const igsid = m.sender?.id;
        if (!igsid) continue;
        const text =
          m.message?.text ??
          m.postback?.title ??
          (m.message?.attachments?.length ? `[${m.message.attachments[0]!.type ?? "attachment"}]` : "");

        const media: ChannelMedia[] | undefined = m.message?.attachments?.length
          ? m.message.attachments
              .filter((a) => typeof a.type === "string")
              .map((a) => ({
                type: (a.type === "image" || a.type === "audio" || a.type === "video"
                  ? a.type
                  : "document") as ChannelMedia["type"],
                url: a.payload?.url,
              }))
          : undefined;

        return {
          channel: "instagram",
          contactId: igsid,
          text,
          media,
          providerMsgId: m.message?.mid ?? m.postback?.mid,
          receivedAt: m.timestamp
            ? new Date(m.timestamp).toISOString()
            : new Date().toISOString(),
          raw: m,
        } satisfies ChannelMessage;
      }
    }
    return null;
  },

  async sendText(externalId, text) {
    // Gotcha 0.9.27: externalId DEVE ser igsid opaco, nunca Contact.id cuid.
    if (/^c[a-z0-9]{24}$/.test(externalId)) {
      throw new Error(`sendText(instagram) recebeu cuid (${externalId}); use ContactIdentity.externalId.`);
    }
    const e = await env();
    if (missingCreds(e)) {
      throw new Error("Credenciais Instagram ausentes — preencha .env antes do envio.");
    }
    const res = await fetch(`${META_GRAPH_BASE}/${e.pageId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${e.pageToken}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        recipient: { id: externalId },
        message: { text },
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      throw new Error(`Instagram sendText falhou ${res.status}: ${body}`);
    }
  },
};
