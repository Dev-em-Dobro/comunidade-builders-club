/**
 * Ingestão de documento pro RAG: chunk → embed → grava RagDoc + RagChunks.
 *
 * O embedding é gravado via SQL raw — a coluna `vector(768)` é Unsupported no
 * Prisma, então `prisma.ragChunk.create()` não consegue setá-la.
 */
import { createHash, randomUUID } from "node:crypto";
import { prisma } from "@/lib/db";
import { chunkText } from "./chunk";
import { embedBatch, EMBEDDING_MODEL, toVectorLiteral } from "./embeddings";

export interface IngestInput {
  agentSessionId: string;
  title: string;
  sourceType: "text" | "pdf" | "url";
  /** URL original, nome do arquivo, ou "manual" pra texto colado. */
  sourceRef: string;
  /** Texto já extraído (extract.ts roda antes, na server action). */
  text: string;
}

export interface IngestResult {
  docId: string;
  chunks: number;
}

export async function ingestDocument(input: IngestInput): Promise<IngestResult> {
  const text = input.text.trim();
  if (!text) throw new Error("Documento vazio — nada pra indexar.");

  const chunks = chunkText(text);
  if (!chunks.length) throw new Error("Não consegui extrair chunks do documento.");

  // checksum por-agente: o mesmo conteúdo pode ser indexado em agentes diferentes.
  const checksum = createHash("sha256")
    .update(`${input.agentSessionId}\n${text}`)
    .digest("hex");

  const existing = await prisma.ragDoc.findUnique({ where: { checksum } });
  if (existing) {
    throw new Error("Esse conteúdo já foi indexado pra este agente.");
  }

  const doc = await prisma.ragDoc.create({
    data: {
      agentSessionId: input.agentSessionId,
      title: input.title,
      sourceType: input.sourceType,
      sourceRef: input.sourceRef,
      checksum,
    },
  });

  try {
    const vectors = await embedBatch(chunks, "RETRIEVAL_DOCUMENT");
    await prisma.$transaction(
      chunks.map((chunk, ord) => {
        const vec = vectors[ord];
        if (!vec) throw new Error(`Embedding ausente pro chunk ${ord}.`);
        return prisma.$executeRaw`
          INSERT INTO "RagChunk" (id, "docId", ord, text, embedding, "embeddingModel", modality)
          VALUES (
            ${randomUUID()}, ${doc.id}, ${ord}, ${chunk},
            ${toVectorLiteral(vec)}::vector, ${EMBEDDING_MODEL}, ${"text"}
          )
        `;
      }),
    );
  } catch (err) {
    // Rollback do doc — não deixa RagDoc órfão sem chunks.
    await prisma.ragDoc.delete({ where: { id: doc.id } }).catch(() => {});
    throw err;
  }

  return { docId: doc.id, chunks: chunks.length };
}
