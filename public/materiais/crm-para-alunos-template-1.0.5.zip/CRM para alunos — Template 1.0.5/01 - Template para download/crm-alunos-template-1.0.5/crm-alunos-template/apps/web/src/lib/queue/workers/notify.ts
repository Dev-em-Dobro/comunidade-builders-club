import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { notifyAdmins } from "@/lib/notifications";
import { slaConfig } from "@/lib/config";
import type { NotifyJobData } from "@/lib/queue/types";

/** Processa a fila `notify`: email + Notification in-app pros admins. */
export async function notifyProcessor(job: Job): Promise<void> {
  const data = job.data as NotifyJobData;
  if (data.kind !== "sla_breach") return;

  const lead = data.leadId
    ? await prisma.lead.findUnique({
        where: { id: data.leadId },
        include: { contact: { select: { displayName: true } } },
      })
    : null;
  const who = lead?.contact.displayName ?? "Um lead";
  const min = slaConfig().thresholdMin;

  await notifyAdmins({
    type: "sla_breach",
    title: "SLA estourado",
    body: `${who} está sem resposta há mais de ${min} minutos.`,
    payload: { conversationId: data.conversationId, leadId: data.leadId },
  });
}
