"use client";

import { useEffect, useRef } from "react";
import type { ConvEventClientPayload } from "@/lib/realtime/notify";

/**
 * Escuta SSE de /api/conversations/[id]/stream:
 *  - default event (msg_new) → `onMsgNotif(messageId)`
 *  - event: conv_event → `onConvEvent(payload)` (claim/release/window_warning)
 *
 * EventSource reconecta sozinho em desconexão.
 */
export function useConversationStream(
  conversationId: string,
  onMsgNotif: (messageId: string) => void,
  onConvEvent?: (payload: ConvEventClientPayload) => void,
): void {
  // Refs pros callbacks pra não re-criar o EventSource a cada render.
  const msgRef = useRef(onMsgNotif);
  const convRef = useRef(onConvEvent);
  useEffect(() => {
    msgRef.current = onMsgNotif;
  }, [onMsgNotif]);
  useEffect(() => {
    convRef.current = onConvEvent;
  }, [onConvEvent]);

  useEffect(() => {
    const es = new EventSource(`/api/conversations/${conversationId}/stream`);
    es.onmessage = (e) => {
      try {
        const parsed = JSON.parse(e.data) as { messageId?: string };
        if (parsed.messageId) msgRef.current(parsed.messageId);
      } catch {
        // payload malformado — ignora.
      }
    };
    const convHandler = (e: MessageEvent) => {
      try {
        const parsed = JSON.parse(e.data) as ConvEventClientPayload;
        convRef.current?.(parsed);
      } catch {
        // payload malformado — ignora.
      }
    };
    es.addEventListener("conv_event", convHandler);
    es.onerror = () => {
      console.warn("[sse] connection error, will retry");
    };
    return () => {
      es.removeEventListener("conv_event", convHandler);
      es.close();
    };
  }, [conversationId]);
}
