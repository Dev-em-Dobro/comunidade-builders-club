"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { updateOrderStatus } from "@/lib/delivery/service";

/** Muda o status do pedido (qualquer usuário logado — a cozinha não precisa ser admin). */
export async function setOrderStatus(agentId: string, orderId: string, status: string): Promise<void> {
  const session = await auth();
  if (!session?.user) throw new Error("Acesso negado");
  const ok = await updateOrderStatus(agentId, orderId, status);
  if (!ok) throw new Error("Pedido não encontrado ou status inválido.");
  revalidatePath(`/settings/agents/${agentId}/orders`);
}
