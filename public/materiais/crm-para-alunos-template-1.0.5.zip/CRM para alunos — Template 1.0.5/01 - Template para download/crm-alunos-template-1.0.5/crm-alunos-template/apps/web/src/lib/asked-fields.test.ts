import { describe, it, expect } from "vitest";
import { mergeAskedFields, renderQualChecklist, type AskedFieldsMap } from "./asked-fields";

describe("mergeAskedFields", () => {
  it("retorna undefined quando ambos são undefined", () => {
    expect(mergeAskedFields(undefined, undefined)).toBeUndefined();
  });

  it("usa fresh quando old é undefined", () => {
    const fresh: AskedFieldsMap = {
      objetivo: { askedAt: "2026-05-24T10:00:00Z" },
    };
    expect(mergeAskedFields(undefined, fresh)).toEqual(fresh);
  });

  it("preserva askedAt antigo (jamais regride)", () => {
    const old: AskedFieldsMap = {
      objetivo: { askedAt: "2026-05-23T08:00:00Z" },
    };
    const fresh: AskedFieldsMap = {
      objetivo: { askedAt: "2026-05-24T15:00:00Z" },
    };
    const merged = mergeAskedFields(old, fresh);
    expect(merged?.objetivo?.askedAt).toBe("2026-05-23T08:00:00Z");
  });

  it("preenche answeredAt+answer quando old tinha askedAt vazio de resposta", () => {
    const old: AskedFieldsMap = {
      objetivo: { askedAt: "2026-05-23T08:00:00Z" },
    };
    const fresh: AskedFieldsMap = {
      objetivo: {
        askedAt: "2026-05-23T08:00:00Z",
        answeredAt: "2026-05-24T09:00:00Z",
        answer: "quero virar dev fullstack",
      },
    };
    const merged = mergeAskedFields(old, fresh);
    expect(merged?.objetivo?.answeredAt).toBe("2026-05-24T09:00:00Z");
    expect(merged?.objetivo?.answer).toBe("quero virar dev fullstack");
  });

  it("preserva answeredAt antigo quando ambos têm", () => {
    const old: AskedFieldsMap = {
      objetivo: {
        askedAt: "2026-05-23T08:00:00Z",
        answeredAt: "2026-05-23T09:00:00Z",
        answer: "resposta antiga",
      },
    };
    const fresh: AskedFieldsMap = {
      objetivo: {
        askedAt: "2026-05-23T08:00:00Z",
        answeredAt: "2026-05-24T10:00:00Z",
        answer: "resposta nova",
      },
    };
    const merged = mergeAskedFields(old, fresh);
    expect(merged?.objetivo?.answeredAt).toBe("2026-05-23T09:00:00Z");
    expect(merged?.objetivo?.answer).toBe("resposta antiga");
  });

  it("preserva field do old quando fresh omite (fora da window)", () => {
    const old: AskedFieldsMap = {
      objetivo: { askedAt: "2026-05-23T08:00:00Z" },
      nivel: { askedAt: "2026-05-23T09:00:00Z" },
    };
    const fresh: AskedFieldsMap = {
      nivel: {
        askedAt: "2026-05-23T09:00:00Z",
        answeredAt: "2026-05-24T10:00:00Z",
        answer: "iniciante",
      },
    };
    const merged = mergeAskedFields(old, fresh);
    expect(merged?.objetivo?.askedAt).toBe("2026-05-23T08:00:00Z");
    expect(merged?.nivel?.answeredAt).toBe("2026-05-24T10:00:00Z");
  });

  it("retorna undefined quando merged fica vazio", () => {
    expect(mergeAskedFields({}, {})).toBeUndefined();
  });

  it("ignora campos fora da lista QUAL_FIELDS", () => {
    // Caso defensivo: classifier poderia inventar field; merge só itera QUAL_FIELDS
    const fresh = { invento: { askedAt: "2026-05-24T10:00:00Z" } } as unknown as AskedFieldsMap;
    expect(mergeAskedFields(undefined, fresh)).toBeUndefined();
  });
});

describe("renderQualChecklist", () => {
  it("retorna 4 itens não-perguntados quando askedFields é undefined", () => {
    const out = renderQualChecklist(undefined);
    expect(out).toContain("[ ] objetivo — NÃO PERGUNTADA AINDA");
    expect(out).toContain("[ ] nivel — NÃO PERGUNTADA AINDA");
    expect(out).toContain("[ ] urgencia — NÃO PERGUNTADA AINDA");
    expect(out).toContain("[ ] tempo_disponivel — NÃO PERGUNTADA AINDA");
    expect(out).not.toContain("[ ] nome");
    expect(out).not.toContain("[ ] email");
    expect(out).toContain("Próxima a perguntar: objetivo");
  });

  it("mistura [ ] [!] [x] com timestamps corretos", () => {
    const asked: AskedFieldsMap = {
      objetivo: {
        askedAt: "2026-05-23T08:00:00Z",
        answeredAt: "2026-05-23T09:00:00Z",
        answer: "virar dev",
      },
      nivel: { askedAt: "2026-05-24T10:00:00Z" },
    };
    const out = renderQualChecklist(asked);
    expect(out).toContain(`[x] objetivo — respondido: "virar dev"`);
    expect(out).toContain(
      `[!] nivel — PERGUNTADA EM 2026-05-24T10:00:00Z. SEM RESPOSTA ainda. NÃO REPERGUNTAR.`,
    );
    expect(out).toContain("[ ] urgencia — NÃO PERGUNTADA AINDA");
    expect(out).toContain("Próxima a perguntar: urgencia");
  });

  it("trunca answer em 80 chars", () => {
    const longAnswer = "x".repeat(200);
    const asked: AskedFieldsMap = {
      objetivo: {
        askedAt: "2026-05-23T08:00:00Z",
        answeredAt: "2026-05-23T09:00:00Z",
        answer: longAnswer,
      },
    };
    const out = renderQualChecklist(asked);
    const expectedAns = "x".repeat(80);
    expect(out).toContain(`[x] objetivo — respondido: "${expectedAns}"`);
    expect(out).not.toContain("x".repeat(81));
  });

  it("emite 'foque em fechamento' quando todas as 4 estão respondidas", () => {
    const allDone: AskedFieldsMap = Object.fromEntries(
      ["objetivo", "nivel", "urgencia", "tempo_disponivel"].map(
        (f) => [
          f,
          {
            askedAt: "2026-05-23T08:00:00Z",
            answeredAt: "2026-05-23T09:00:00Z",
            answer: "resposta",
          },
        ],
      ),
    ) as AskedFieldsMap;
    const out = renderQualChecklist(allDone);
    expect(out).toContain("Todas as 4 perguntas já foram feitas. Foque em fechamento.");
    expect(out).not.toContain("Próxima a perguntar");
  });
});
