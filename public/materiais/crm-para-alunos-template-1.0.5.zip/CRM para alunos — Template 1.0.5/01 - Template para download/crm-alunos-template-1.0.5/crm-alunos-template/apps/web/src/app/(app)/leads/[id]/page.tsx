import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { ArrowLeft, ChevronLeft, ChevronRight, MessagesSquare } from "lucide-react";
import { STAGE_LABEL, STAGE_VARIANT } from "../stages";
import { lossReasonLabel } from "@/lib/loss-reasons";
import { formatBRL, ORDER_STATUS_LABEL, type OrderStatus } from "@/lib/delivery/menu";

export const dynamic = "force-dynamic";

const FUNNEL_PAGE_SIZE = 20;

export default async function LeadDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ fhPage?: string }>;
}) {
  const { id } = await params;
  const lead = await prisma.lead
    .findUnique({
      where: { id },
      include: {
        contact: true,
        launch: true,
        conversations: { orderBy: { createdAt: "desc" } },
      },
    })
    .catch(() => null);
  if (!lead) notFound();

  const { fhPage } = await searchParams;
  const totalEvents = await prisma.pipelineEvent.count({ where: { leadId: id } });
  const totalPages = Math.max(1, Math.ceil(totalEvents / FUNNEL_PAGE_SIZE));
  const parsedPage = Number.parseInt(fhPage ?? "1", 10);
  const page = Number.isFinite(parsedPage)
    ? Math.min(Math.max(parsedPage, 1), totalPages)
    : 1;
  const pipelineEvents = await prisma.pipelineEvent.findMany({
    where: { leadId: id },
    orderBy: { createdAt: "desc" },
    skip: (page - 1) * FUNNEL_PAGE_SIZE,
    take: FUNNEL_PAGE_SIZE,
  });
  // Pedidos do agente de delivery feitos por este contato (histórico do contato).
  const orders = await prisma.order
    .findMany({ where: { contactId: lead.contactId }, orderBy: { createdAt: "desc" }, take: 20 })
    .catch(() => []);

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <Link
        href="/leads"
        className="text-sm text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-4"
      >
        <ArrowLeft className="size-4" /> Leads
      </Link>

      <header className="mb-6 flex items-center gap-3">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          {lead.contact.displayName ?? "Lead sem nome"}
        </h1>
        <Badge variant={STAGE_VARIANT[lead.stage] ?? "outline"}>
          {STAGE_LABEL[lead.stage] ?? lead.stage}
        </Badge>
      </header>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Funil</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Fact label="Score" value={String(lead.score)} />
            <Fact label="Lançamento" value={lead.launch?.name ?? "—"} />
            <Fact label="Primeira inbound" value={fmt(lead.firstInboundAt)} />
            <Fact label="Primeira resposta" value={fmt(lead.firstResponseAt)} />
            <Fact label="Última atividade" value={fmt(lead.lastActivityAt)} />
            <Fact label="SLA estourado" value={fmt(lead.slaBreachedAt)} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Resultado</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Fact label="Ganho em" value={fmt(lead.wonAt)} />
            <Fact label="Perdido em" value={fmt(lead.lostAt)} />
            <Fact label="Motivo da perda" value={lossReasonLabel(lead.lostReason) ?? "—"} />
            <Fact label="Criado em" value={fmt(lead.createdAt)} />
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">
            Conversas ({lead.conversations.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {lead.conversations.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma conversa.</p>
          ) : (
            lead.conversations.map((c) => (
              <Link
                key={c.id}
                href={`/conversations/${c.id}`}
                className="flex items-center justify-between rounded-md border border-border/60 px-3 py-2 text-sm hover:border-primary/40 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <MessagesSquare className="size-4 text-primary" />
                  <span className="font-mono text-xs">{c.channel}</span>
                </span>
                <span className="text-muted-foreground text-xs">
                  {fmt(c.lastMessageAt)}
                </span>
              </Link>
            ))
          )}
        </CardContent>
      </Card>

      {orders.length > 0 && (
        <Card className="mt-4">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Pedidos ({orders.length})</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {orders.map((o) => {
              const items = (Array.isArray(o.items) ? o.items : []) as { name?: string; quantity?: number }[];
              return (
                <div key={o.id} className="rounded-md border border-border/60 px-3 py-2 text-sm">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium">
                      #{o.number} · {formatBRL(o.totalCents)}
                    </span>
                    <span className="flex items-center gap-2 text-xs text-muted-foreground">
                      {fmt(o.createdAt)}
                      <Badge variant="outline" className="text-[10px]">
                        {ORDER_STATUS_LABEL[o.status as OrderStatus] ?? o.status}
                      </Badge>
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {items.map((i) => `${i.quantity}x ${i.name}`).join(", ")}
                    {o.fulfillment === "pickup" ? " · retirada" : o.neighborhood ? ` · entrega em ${o.neighborhood}` : ""}
                  </p>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}

      <Card className="mt-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">
            Histórico do funil ({totalEvents})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {totalEvents === 0 ? (
            <p className="text-sm text-muted-foreground">Sem eventos.</p>
          ) : (
            <>
              <ul className="space-y-3">
                {pipelineEvents.map((e) => (
                  <li key={e.id} className="flex gap-3 text-sm">
                    <span className="text-muted-foreground text-xs whitespace-nowrap pt-0.5">
                      {fmt(e.createdAt)}
                    </span>
                    <span className="flex-1">
                      <Badge variant="outline" className="font-mono text-[10px]">
                        {e.type}
                      </Badge>
                      {e.payload != null && (
                        <code className="ml-2 text-xs text-muted-foreground">
                          {JSON.stringify(e.payload)}
                        </code>
                      )}
                    </span>
                  </li>
                ))}
              </ul>

              {totalPages > 1 && (
                <div className="mt-4 flex items-center justify-between border-t border-border/50 pt-3">
                  <span className="text-xs text-muted-foreground">
                    Página {page} de {totalPages}
                  </span>
                  <div className="flex items-center gap-2">
                    {page > 1 ? (
                      <Link
                        href={`/leads/${id}?fhPage=${page - 1}`}
                        scroll={false}
                        className={buttonVariants({ variant: "outline", size: "sm" })}
                      >
                        <ChevronLeft className="size-4" /> Anterior
                      </Link>
                    ) : (
                      <span
                        aria-disabled
                        className={`${buttonVariants({ variant: "outline", size: "sm" })} pointer-events-none opacity-40`}
                      >
                        <ChevronLeft className="size-4" /> Anterior
                      </span>
                    )}
                    {page < totalPages ? (
                      <Link
                        href={`/leads/${id}?fhPage=${page + 1}`}
                        scroll={false}
                        className={buttonVariants({ variant: "outline", size: "sm" })}
                      >
                        Próxima <ChevronRight className="size-4" />
                      </Link>
                    ) : (
                      <span
                        aria-disabled
                        className={`${buttonVariants({ variant: "outline", size: "sm" })} pointer-events-none opacity-40`}
                      >
                        Próxima <ChevronRight className="size-4" />
                      </span>
                    )}
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      <div className="mt-6">
        <Link
          href={`/conversations`}
          className={buttonVariants({ variant: "outline", size: "sm" })}
        >
          Ir pro inbox
        </Link>
      </div>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-border/50 pb-1.5 last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-mono text-xs">{value}</span>
    </div>
  );
}

function fmt(d: Date | null): string {
  if (!d) return "—";
  return d.toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}
