"use server";
import { auth } from "@/auth";
import { loadConfig, saveConfig } from "@/lib/config";
import { businessSettingsSchema } from "@/lib/settings/validation";
import { revalidatePath } from "next/cache";
export async function saveBusiness(_previous: { message?: string; error?: string }, form: FormData): Promise<{ error?: string; message?: string }> {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Somente o administrador pode alterar a instância." };
  const parsed = businessSettingsSchema.safeParse({ ...Object.fromEntries(form.entries()), whatsapp: form.get("whatsapp") === "on", instagram: form.get("instagram") === "on", whatsappQr: form.get("whatsappQr") === "on" });
  if (!parsed.success) return { error: parsed.error.issues.map((issue) => `${issue.path.join(".")}: ${issue.message}`).join("; ") };
  const b = parsed.data;
  try {
    const config = loadConfig();
    config.business = { ...config.business, brandName: b.brandName, legalName: b.legalName, supportEmail: b.supportEmail, contactEmail: b.contactEmail, accessUrl: b.accessUrl || null, handoffNotice: b.handoffNotice };
    config.schedule.timezone = b.timezone; config.cache.debounce.windowMs = b.windowMs;
    config.channels.enabled = [ ...(b.whatsapp ? ["whatsapp_cloud" as const] : []), ...(b.instagram ? ["instagram" as const] : []), ...(b.whatsappQr ? ["whatsapp_qr" as const] : []) ];
    config.channels.whatsapp_cloud.enabled = b.whatsapp; config.channels.instagram_direct.enabled = b.instagram;
    config.channels.whatsapp_qr = { ...config.channels.whatsapp_qr, enabled: b.whatsappQr };
    saveConfig(config);
  } catch { return { error: "Não foi possível salvar. Confira a permissão de escrita e o volume de configuração do servidor." }; }
  revalidatePath("/", "layout");
  return { message: "Configuração salva. Alterações de marca e canais aplicadas. Confira as conexões no onboarding." };
}
