/**
 * Parser puro do payload de webhook do Hubla v2.
 *
 * Sem DB, sem env, sem efeitos colaterais — todos os erros viram `null` no
 * retorno. O caller decide o que fazer com `null` (ignored_type,
 * lead_not_found, etc).
 *
 * Estrutura do payload real `invoice.payment_succeeded` (observada em
 * produção 2026-05-28): UTM em `event.invoice.paymentSession.utm.content`;
 * email do comprador em `event.invoice.payer.email`; produtos em
 * `event.products`. Os caminhos com `firstPaymentSession` / `event.payer` /
 * `event.invoice.products` aparecem nos docs como exemplo, então mantemos
 * fallback pra eles caso a Hubla varie estrutura por tipo de venda
 * (assinatura recorrente vs avulsa, etc).
 */

export interface PurchaseData {
  invoiceId: string;
  saleDate: Date;
  productId: string | null;
  offerId: string | null;
  totalCents: number;
  currency: string;
  paymentMethod: string;
  installments: number;
}

/** Acesso seguro a propriedade aninhada — retorna unknown ou undefined. */
function get(obj: unknown, ...keys: string[]): unknown {
  let cur: unknown = obj;
  for (const k of keys) {
    if (cur == null || typeof cur !== "object") return undefined;
    cur = (cur as Record<string, unknown>)[k];
  }
  return cur;
}

function asNonEmptyString(v: unknown): string | null {
  return typeof v === "string" && v.length > 0 ? v : null;
}

/**
 * Extrai o leadId do UTM. Tenta `paymentSession.utm.content` primeiro
 * (estrutura observada em produção), depois `firstPaymentSession.utm.content`
 * (estrutura dos docs).
 */
export function extractLeadIdFromUtm(payload: unknown): string | null {
  return (
    asNonEmptyString(
      get(payload, "event", "invoice", "paymentSession", "utm", "content"),
    ) ??
    asNonEmptyString(
      get(payload, "event", "invoice", "firstPaymentSession", "utm", "content"),
    )
  );
}

/**
 * Extrai email do comprador pro fallback de lookup. Tenta na ordem:
 *  1. `event.invoice.payer.email` (estrutura real v2)
 *  2. `event.payer.email` (estrutura dos docs)
 *  3. `event.user.email` (campo paralelo presente em alguns payloads)
 */
export function extractPayerEmail(payload: unknown): string | null {
  return (
    asNonEmptyString(get(payload, "event", "invoice", "payer", "email")) ??
    asNonEmptyString(get(payload, "event", "payer", "email")) ??
    asNonEmptyString(get(payload, "event", "user", "email"))
  );
}

/**
 * Monta o `PurchaseData` que vai pro `PipelineEvent('purchase')`.
 * Retorna `null` se `invoice.id` estiver ausente/vazio. Demais campos têm
 * fallback (saleDate ausente/inválido vira o instante atual; totalCents
 * ausente vira 0; etc.) — Hubla sempre manda esses no `payment_succeeded`,
 * mas defendemos contra payload truncado pra não jogar exceção tardia.
 */
export function extractPurchaseData(payload: unknown): PurchaseData | null {
  const invoiceId = asNonEmptyString(get(payload, "event", "invoice", "id"));
  if (!invoiceId) return null;

  const saleDateRaw = get(payload, "event", "invoice", "saleDate");
  const parsedSaleDate =
    typeof saleDateRaw === "string" ? new Date(saleDateRaw) : null;
  // Guard contra Invalid Date (string mal-formada): cai pro fallback. Sem
  // isso, .toISOString() explode mais tarde no apply.ts.
  const saleDate =
    parsedSaleDate && !Number.isNaN(parsedSaleDate.getTime())
      ? parsedSaleDate
      : new Date();

  const totalCentsRaw = get(payload, "event", "invoice", "amount", "totalCents");
  const totalCents = typeof totalCentsRaw === "number" ? totalCentsRaw : 0;

  const currency =
    asNonEmptyString(get(payload, "event", "invoice", "currency")) ?? "BRL";
  const paymentMethod =
    asNonEmptyString(get(payload, "event", "invoice", "paymentMethod")) ??
    "unknown";

  const installmentsRaw = get(payload, "event", "invoice", "installments");
  const installments =
    typeof installmentsRaw === "number" ? installmentsRaw : 1;

  // Produtos: real v2 tem em `event.products`; docs mostram em
  // `event.invoice.products`. Aceita ambos.
  const products =
    get(payload, "event", "products") ??
    get(payload, "event", "invoice", "products");
  const firstProduct = Array.isArray(products) ? products[0] : null;
  const productId = asNonEmptyString(get(firstProduct, "id"));
  const offers = get(firstProduct, "offers");
  const firstOffer = Array.isArray(offers) ? offers[0] : null;
  const offerId = asNonEmptyString(get(firstOffer, "id"));

  return {
    invoiceId,
    saleDate,
    productId,
    offerId,
    totalCents,
    currency,
    paymentMethod,
    installments,
  };
}
