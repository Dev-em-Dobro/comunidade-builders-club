import { createHmac, timingSafeEqual } from "node:crypto";

/**
 * Valida X-Hub-Signature-256 (Meta Cloud API + Instagram).
 * Header format: "sha256=<hexdigest>"
 *
 * Gotchas:
 *  - rawBody DEVE ser exatamente os bytes recebidos (req.text(), não req.json()).
 *  - Comparação timing-safe — nunca usar === em strings.
 *  - Falha silenciosa se HMAC inválido — não vazar o motivo pro atacante.
 */
export function verifyHmacSha256(
  rawBody: string,
  signatureHeader: string | null | undefined,
  secret: string,
): boolean {
  if (!signatureHeader) return false;
  const [algo, sigHex] = signatureHeader.split("=");
  if (algo !== "sha256" || !sigHex) return false;

  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const provided = sigHex.toLowerCase();
  if (provided.length !== expected.length) return false;

  try {
    return timingSafeEqual(
      Buffer.from(provided, "hex"),
      Buffer.from(expected, "hex"),
    );
  } catch {
    return false;
  }
}

/**
 * Valida X-Webhook-Hmac do WAHA: HMAC-SHA512 em hex puro (sem prefixo "sha512=")
 * calculado sobre o corpo cru. Mesmas regras: bytes exatos e comparação timing-safe.
 */
export function verifyHmacSha512Hex(
  rawBody: string,
  signatureHeader: string | null | undefined,
  secret: string,
): boolean {
  if (!signatureHeader || !secret) return false;
  const provided = signatureHeader.trim().toLowerCase();
  if (!/^[0-9a-f]+$/.test(provided)) return false;
  const expected = createHmac("sha512", secret).update(rawBody).digest("hex");
  if (provided.length !== expected.length) return false;
  try {
    return timingSafeEqual(Buffer.from(provided, "hex"), Buffer.from(expected, "hex"));
  } catch {
    return false;
  }
}
