import { describe, it, expect, vi, beforeAll, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));

import { PATCH } from "./route";
import { auth } from "@/auth";

const created = {
  leadIds: [] as string[],
  contactIds: [] as string[],
  userIds: [] as string[],
};
let userId: string;

beforeAll(async () => {
  const user = await prisma.user.create({
    data: { email: `stage-${Date.now()}@t.local`, name: "Atendente" },
  });
  userId = user.id;
  created.userIds.push(user.id);
});

afterAll(async () => {
  await prisma.pipelineEvent.deleteMany({
    where: { leadId: { in: created.leadIds } },
  });
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

async function makeLead(stage: string, lastFollowUpStep: number | null = null) {
  const c = await prisma.contact.create({
    data: { displayName: `L-${Date.now()}-${Math.random()}` },
  });
  created.contactIds.push(c.id);
  const l = await prisma.lead.create({
    data: { contactId: c.id, stage, lastFollowUpStep },
  });
  created.leadIds.push(l.id);
  return l;
}

function req(body: unknown): Request {
  return new Request("http://test", {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("PATCH /api/leads/[id]/stage", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const lead = await makeLead("contacted");
    const res = await PATCH(
      req({ stage: "qualified" }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(401);
  });

  it("404 lead inexistente", async () => {
    const res = await PATCH(
      req({ stage: "qualified" }),
      { params: Promise.resolve({ id: "cmnonexistent000000000000" }) },
    );
    expect(res.status).toBe(404);
  });

  it("400 stage inválido", async () => {
    const lead = await makeLead("contacted");
    const res = await PATCH(
      req({ stage: "foobar" }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(400);
  });

  it("400 lastFollowUpStep fora de [1,3]", async () => {
    const lead = await makeLead("contacted");
    const res = await PATCH(
      req({ lastFollowUpStep: 7 }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(400);
  });

  it("400 ao tentar regredir de stage terminal (won → contacted)", async () => {
    const lead = await makeLead("won");
    const res = await PATCH(
      req({ stage: "contacted" }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.error).toMatch(/terminal/i);
  });

  it("200 muda stage + cria PipelineEvent", async () => {
    const lead = await makeLead("contacted");
    const res = await PATCH(
      req({ stage: "qualified" }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("qualified");
    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id, type: "stage_change" },
    });
    expect(events.length).toBeGreaterThanOrEqual(1);
    expect(events[0].payload).toMatchObject({
      from: "contacted",
      to: "qualified",
      via: "manual_drag",
    });
  });

  it("200 muda lastFollowUpStep (null → 2) + cria PipelineEvent", async () => {
    const lead = await makeLead("contacted");
    const res = await PATCH(
      req({ lastFollowUpStep: 2 }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBe(2);
    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id, type: "followup_step_change" },
    });
    expect(events.length).toBeGreaterThanOrEqual(1);
  });

  it("200 reset lastFollowUpStep pra null (F<N> → stage normal)", async () => {
    const lead = await makeLead("contacted", 2);
    const res = await PATCH(
      req({ lastFollowUpStep: null }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBeNull();
  });

  it("200 muda stage + lastFollowUpStep numa única chamada", async () => {
    const lead = await makeLead("contacted", 2);
    const res = await PATCH(
      req({ stage: "qualified", lastFollowUpStep: null }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("qualified");
    expect(after.lastFollowUpStep).toBeNull();
  });
});
