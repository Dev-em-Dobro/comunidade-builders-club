import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { loadConfig } from "@/lib/config";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Database, FileText, Link2, Trash2, Type } from "lucide-react";
import { AgentHeader } from "../_agent";
import { RagForm } from "./rag-form";
import { deleteRagDocument } from "./actions";

export const dynamic = "force-dynamic";

export default async function RagPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const data = await safeQuery(id);
  if (!data) notFound();
  const { agent, docs } = data;

  let ragEnabled = false;
  try {
    ragEnabled = loadConfig().tools.rag === true;
  } catch {
    ragEnabled = false;
  }

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader
        agent={agent}
        active="rag"
        description="Documentos indexados pro RAG. O agente busca os trechos mais relevantes a cada mensagem e usa como contexto."
      />

      {!ragEnabled && (
        <Card className="mb-6 border-amber-500/40">
          <CardContent className="py-4 text-sm text-muted-foreground">
            RAG está <code className="text-xs">off</code> no{" "}
            <code className="text-xs">setup.config.json</code> (
            <code className="text-xs">tools.rag</code>). Você pode indexar
            documentos agora, mas o agente só vai consultá-los depois de ligar o
            flag e reiniciar o app.
          </CardContent>
        </Card>
      )}

      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-base">Adicionar documento</CardTitle>
          <CardDescription>
            Texto colado, PDF ou URL. O conteúdo é quebrado em chunks e embedado
            via Gemini (gemini-embedding-001).
          </CardDescription>
        </CardHeader>
        <CardContent>
          <RagForm agentId={agent.id} />
        </CardContent>
      </Card>

      <h2 className="text-sm font-medium text-muted-foreground mb-3">
        {docs.length} documento{docs.length !== 1 ? "s" : ""} indexado
        {docs.length !== 1 ? "s" : ""}
      </h2>

      {docs.length === 0 ? (
        <Card className="p-10 flex flex-col items-center text-center">
          <Database className="size-8 text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">
            Nenhum documento ainda. Adicione o primeiro acima.
          </p>
        </Card>
      ) : (
        <div className="space-y-2">
          {docs.map((d) => {
            const Icon =
              d.sourceType === "pdf"
                ? FileText
                : d.sourceType === "url"
                  ? Link2
                  : Type;
            return (
              <Card key={d.id}>
                <CardContent className="flex items-center gap-3 py-3">
                  <Icon className="size-4 text-primary shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="font-medium truncate">{d.title}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {d._count.chunks} chunk
                      {d._count.chunks !== 1 ? "s" : ""} · {d.sourceRef}
                    </p>
                  </div>
                  <Badge variant="outline" className="font-mono text-[10px]">
                    {d.sourceType}
                  </Badge>
                  <form action={deleteRagDocument}>
                    <input type="hidden" name="docId" value={d.id} />
                    <input type="hidden" name="agentId" value={agent.id} />
                    <Button
                      type="submit"
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive"
                      aria-label={`Remover ${d.title}`}
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </form>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      <div className="mt-8">
        <Link
          href={`/settings/agents/${agent.id}/rules`}
          className={buttonVariants({ variant: "ghost", size: "sm" })}
        >
          Ver regras de IA deste agente
        </Link>
      </div>
    </div>
  );
}

async function safeQuery(id: string) {
  try {
    const agent = await prisma.agentSession.findUnique({ where: { id } });
    if (!agent) return null;
    const docs = await prisma.ragDoc.findMany({
      where: { agentSessionId: id },
      orderBy: { createdAt: "desc" },
      include: { _count: { select: { chunks: true } } },
    });
    return { agent, docs };
  } catch {
    return null;
  }
}
