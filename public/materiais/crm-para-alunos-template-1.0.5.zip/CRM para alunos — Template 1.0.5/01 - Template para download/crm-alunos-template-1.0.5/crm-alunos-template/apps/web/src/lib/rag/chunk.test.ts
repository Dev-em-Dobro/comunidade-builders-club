import { describe, it, expect } from "vitest";
import { chunkText } from "./chunk";

describe("chunkText", () => {
  it("texto vazio → []", () => {
    expect(chunkText("")).toEqual([]);
    expect(chunkText("   \n  \t ")).toEqual([]);
  });

  it("markdown: uma seção por chunk, sem misturar seções", () => {
    const md = [
      "# FAQ",
      "intro",
      "",
      "---",
      "",
      "## Certificado",
      "Você recebe um certificado reconhecido pelo MEC da faculdade Sirius.",
      "",
      "---",
      "",
      "## Reembolso",
      "Garantia incondicional de 15 dias.",
    ].join("\n");

    const chunks = chunkText(md);

    const cert = chunks.find((c) => c.includes("MEC"));
    expect(cert).toBeDefined();
    // o chunk do certificado não pode arrastar a seção de reembolso junto
    expect(cert!).not.toMatch(/Reembolso|Garantia/);
    // cada seção começa pelo próprio header
    expect(chunks.some((c) => c.startsWith("## Certificado"))).toBe(true);
    expect(chunks.some((c) => c.startsWith("## Reembolso"))).toBe(true);
    // separador '---' isolado não vira chunk
    expect(chunks.some((c) => c.trim() === "---")).toBe(false);
  });

  it("seção maior que MAX_CHARS é fatiada, mas não invade outra seção", () => {
    const big = "palavra ".repeat(400); // ~3200 chars, sem pontuação final forte
    const md = `## Grande\n${big}\n\n## Pequena\nconteúdo da pequena`;
    const chunks = chunkText(md);
    const pequena = chunks.find((c) => c.includes("conteúdo da pequena"));
    expect(pequena).toBeDefined();
    expect(pequena!).not.toMatch(/palavra/);
  });

  it("texto sem headers → empacota por parágrafo (comportamento legado)", () => {
    const txt = "Parágrafo um.\n\nParágrafo dois.";
    expect(chunkText(txt)).toEqual(["Parágrafo um.\n\nParágrafo dois."]);
  });
});
