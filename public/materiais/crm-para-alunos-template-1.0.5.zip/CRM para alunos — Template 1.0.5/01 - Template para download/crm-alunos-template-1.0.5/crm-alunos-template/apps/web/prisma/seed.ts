import * as fs from "node:fs/promises";
import * as path from "node:path";
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function seedAdminUser() {
  const email = process.env.AUTH_INITIAL_EMAIL?.trim().toLowerCase();
  const password = process.env.AUTH_INITIAL_PASSWORD;

  if (!email || !password) {
    const admin = await prisma.user.findFirst({ where: { role: "admin", passwordHash: { not: null } } });
    if (admin) { console.log("[seed] Admin já existe; credenciais iniciais não são necessárias."); return; }
    throw new Error("Preencha AUTH_INITIAL_EMAIL e AUTH_INITIAL_PASSWORD para criar seu primeiro administrador.");
  }
  if (password.length < 8) {
    console.error("[seed] AUTH_INITIAL_PASSWORD precisa ter no mínimo 8 caracteres.");
    process.exit(1);
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing?.passwordHash) {
    console.log(`[seed] Admin já existe: ${email} (id ${existing.id}) — não sobrescrevendo.`);
    return;
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.upsert({
    where: { email },
    update: { passwordHash, role: "admin" },
    create: { email, passwordHash, role: "admin", name: email.split("@")[0] },
  });
  console.log(`[seed] Admin pronto: ${user.email} (id ${user.id}, role ${user.role}).`);
}

async function main() {
  await seedAdminUser();

  const existing = await prisma.agentSession.findFirst({ where: { isDefault: true } });
  if (existing) {
    console.log(`[seed] AgentSession default já existe: ${existing.id} (${existing.name})`);
    return;
  }

  const agent = await prisma.agentSession.create({
    data: {
      name: "Agente SDR (exemplo)",
      systemPrompt: await fs.readFile(
        path.resolve(process.cwd(), "prisma", "agent-prompts/example-sdr.md"),
        "utf8",
      ),
      model: "claude-sonnet-4-6",
      provider: "anthropic",
      temperature: 0.7,
      maxTokens: 1024,
      memoryMode: "window_20",
      role: "sdr",
      isDefault: true,
    },
  });

  await prisma.aIRule.create({
    data: {
      agentSessionId: agent.id,
      priority: 10,
      mode: "keyword_pause",
      params: { keywords: ["pausar ia", "stop ai", "para ia"] },
      action: "drop",
    },
  });
  await prisma.aIRule.create({
    data: {
      agentSessionId: agent.id,
      priority: 20,
      mode: "keyword_trigger",
      params: {
        keywords: ["falar com atendente", "falar com humano", "atendente", "operador"],
        matchMode: "any",
      },
      action: "handoff",
    },
  });

  console.log(`[seed] AgentSession criada: ${agent.id} (${agent.name})`);
  console.log(`[seed] 2 AIRules criadas (keyword_pause priority=10, keyword_trigger handoff priority=20)`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
