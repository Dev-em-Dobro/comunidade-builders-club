/**
 * Campos do canal "WhatsApp via QR" (provedor não oficial: WAHA hoje, Uazapi depois).
 * Mesmo padrão de META_FIELDS: valor do painel (cifrado) tem precedência sobre o .env.
 */
export const WAQR_FIELDS = [
  { key: "WAQR_PROVIDER", label: "Provedor (waha)", secret: false, kind: "provider" },
  { key: "WAQR_BASE_URL", label: "URL da API do provedor (ex.: http://127.0.0.1:3000)", secret: false, kind: "url" },
  { key: "WAQR_SESSION", label: "Nome da sessão (padrão: default)", secret: false, kind: "session" },
  { key: "WAQR_API_KEY", label: "Chave da API do provedor (X-Api-Key)", secret: true, kind: "secret" },
  { key: "WAQR_WEBHOOK_SECRET", label: "Segredo HMAC do webhook", secret: true, kind: "secret" },
  { key: "WAQR_WEBHOOK_BASE_URL", label: "URL do CRM vista pelo provedor (opcional)", secret: false, kind: "url" },
] as const;

export type WaqrKey = typeof WAQR_FIELDS[number]["key"];
export type WaqrFieldKind = typeof WAQR_FIELDS[number]["kind"];

export const WAQR_PROVIDERS = ["waha"] as const;
export type WaqrProviderId = typeof WAQR_PROVIDERS[number];

/** Valida um valor do formulário conforme o tipo do campo. */
export function validateWaqrValue(value: string, kind: WaqrFieldKind): boolean {
  if (value.length > 8192) return false;
  switch (kind) {
    case "provider":
      return (WAQR_PROVIDERS as readonly string[]).includes(value);
    case "session":
      return /^[A-Za-z0-9_-]{1,64}$/.test(value);
    case "url":
      try {
        const url = new URL(value);
        return (url.protocol === "http:" || url.protocol === "https:") && !url.username && !url.password;
      } catch {
        return false;
      }
    case "secret":
      return /^[\x21-\x7e]+$/.test(value);
  }
}
