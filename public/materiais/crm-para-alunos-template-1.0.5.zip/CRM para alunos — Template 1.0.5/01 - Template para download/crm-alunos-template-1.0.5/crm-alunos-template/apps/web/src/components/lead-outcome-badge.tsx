import { Badge } from "@/components/ui/badge";
import { CircleCheck, CircleX } from "lucide-react";
import { lossReasonShort } from "@/lib/loss-reasons";

/**
 * Selo de resultado do lead (ganho / perdido). Presentacional e sem estado —
 * usado tanto na listagem de conversas (server) quanto no header da conversa
 * (dentro de um client component). Estágios não-terminais → não renderiza nada.
 *
 * Rótulos em minúsculo pra casar com os outros selos (`ganho`/`perdido`);
 * no perdido mostra o motivo curto inline + completo no tooltip.
 */
export function LeadOutcomeBadge({
  stage,
  lostReason,
  className,
}: {
  stage: string;
  lostReason?: string | null;
  className?: string;
}) {
  if (stage === "won") {
    return (
      <Badge
        variant="outline"
        title="Lead ganho"
        className={`gap-1 text-[10px] border-success/40 text-success ${className ?? ""}`}
      >
        <CircleCheck className="size-3" /> ganho
      </Badge>
    );
  }
  if (stage === "lost") {
    const reason = lossReasonShort(lostReason);
    return (
      <Badge
        variant="outline"
        title={reason ? `Motivo da perda: ${reason}` : "Lead perdido"}
        className={`gap-1 text-[10px] border-destructive/40 text-destructive ${className ?? ""}`}
      >
        <CircleX className="size-3" /> perdido{reason ? ` · ${reason}` : ""}
      </Badge>
    );
  }
  return null;
}
