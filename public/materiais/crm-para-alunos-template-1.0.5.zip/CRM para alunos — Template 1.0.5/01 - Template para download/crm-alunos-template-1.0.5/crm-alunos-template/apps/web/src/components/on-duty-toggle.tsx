"use client";

import { useState, useTransition } from "react";
import { Power, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { setOnDuty } from "@/app/(app)/duty-actions";

/**
 * Toggle icon-only de plantão, no header da sidebar (ao lado do sino).
 * Otimista: atualiza o estado na hora e reverte se a action falhar.
 */
export function OnDutyToggle({ initial }: { initial: boolean }) {
  const [on, setOn] = useState(initial);
  const [pending, startTransition] = useTransition();

  function toggle() {
    const next = !on;
    setOn(next);
    startTransition(async () => {
      try {
        await setOnDuty(next);
        toast.success(next ? "Você está de plantão" : "Você saiu do plantão");
      } catch {
        setOn(!next);
        toast.error("Falha ao atualizar o plantão");
      }
    });
  }

  return (
    <button
      type="button"
      onClick={toggle}
      disabled={pending}
      aria-pressed={on}
      aria-label={
        on ? "De plantão (clique para sair)" : "Fora de plantão (clique para entrar)"
      }
      title={on ? "De plantão" : "Fora de plantão"}
      className={`relative inline-flex size-7 items-center justify-center rounded-md transition-colors ${
        on
          ? "bg-primary/15 text-primary"
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
      }`}
    >
      {pending ? (
        <Loader2 className="size-4 animate-spin" />
      ) : (
        <Power className="size-4" />
      )}
    </button>
  );
}
