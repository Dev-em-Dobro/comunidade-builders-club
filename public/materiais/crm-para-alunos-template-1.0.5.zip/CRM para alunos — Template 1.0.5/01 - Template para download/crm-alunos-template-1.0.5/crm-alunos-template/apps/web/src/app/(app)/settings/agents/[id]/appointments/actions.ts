"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { cancelAppointment } from "@/lib/scheduling/service";

export async function cancelAppointmentAction(agentId: string, id: string): Promise<void> {
  const session = await auth();
  if (!session?.user) throw new Error("Acesso negado");
  const owned = await prisma.appointment.count({ where: { id, agentSessionId: agentId } });
  if (!owned) throw new Error("Consulta não encontrada neste agente.");
  const res = await cancelAppointment(id);
  if (!res.ok) throw new Error(res.error ?? "Não foi possível cancelar.");
  revalidatePath(`/settings/agents/${agentId}/appointments`);
}
