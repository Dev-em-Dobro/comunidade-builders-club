import { prisma } from "@/lib/db";
import { decryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";
import { META_FIELDS, type MetaKey } from "./meta-fields";

/** DB values override env, without a process cache. Secrets stay on the server. */
export async function resolveMetaSettings(): Promise<Partial<Record<MetaKey, string>>> {
  const values: Partial<Record<MetaKey, string>> = {};
  for (const { key } of META_FIELDS) if (process.env[key]) values[key] = process.env[key];
  if (secretsKeyConfigured()) {
    const rows = await prisma.providerCredential.findMany({
      where: { provider: { in: META_FIELDS.map(({ key }) => `meta:${key}`) } },
      select: { provider: true, apiKeyEnc: true },
    });
    for (const row of rows) values[row.provider.slice(5) as MetaKey] = decryptSecret(row.apiKeyEnc);
  }
  return values;
}

/** Only presence and source may cross the server/client boundary. */
export async function metaSettingsStatus() {
  const rows = await prisma.providerCredential.findMany({
    where: { provider: { in: META_FIELDS.map(({ key }) => `meta:${key}`) } }, select: { provider: true },
  });
  return Object.fromEntries(META_FIELDS.map(({ key }) => [key,
    rows.some((row) => row.provider === `meta:${key}`) ? "painel" : process.env[key] ? "ambiente" : "ausente",
  ]));
}
