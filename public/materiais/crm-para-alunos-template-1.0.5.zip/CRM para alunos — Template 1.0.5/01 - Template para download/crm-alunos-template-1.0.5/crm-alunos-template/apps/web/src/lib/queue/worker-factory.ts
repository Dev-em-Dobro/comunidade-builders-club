import { Worker, type Processor } from "bullmq";
import { queueConnectionOptions } from "./connection";
import type { QueueName } from "./types";

/**
 * Cria um Worker BullMQ pra fila dada.
 *
 * Passa `RedisOptions` (não uma instância): o BullMQ cria e é dono da conexão,
 * fechando-a por completo no `worker.close()`. Cada worker tem a sua — não
 * compartilham, pra evitar corrida no shutdown.
 */
export function createWorker<T = unknown>(
  name: QueueName,
  processor: Processor<T>,
): Worker<T> {
  return new Worker<T>(name, processor, {
    connection: queueConnectionOptions(),
  });
}
