/**
 * POST /api/agents/<id>/menu — recebe o arquivo do cardápio (PDF/foto), a IA lê
 * os itens com preço e o CRM guarda arquivo + itens no estabelecimento do agente.
 *
 * Rota de API (e não server action) pra ter controle do upload e do erro: cada
 * etapa vai pro log e qualquer falha volta como JSON pra tela mostrar.
 */
import { randomBytes } from "node:crypto";
import { NextResponse } from "next/server";
import type { Prisma } from "@prisma/client";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { DELIVERY_ROLE } from "@/lib/delivery/agent";
import { extractMenuItems, MENU_MAX_BYTES, MENU_MIME_TYPES } from "@/lib/delivery/menu-extract";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
// A IA pode levar até ~1 min pra ler um cardápio grande.
export const maxDuration = 120;

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}

const fail = (status: number, error: string) => NextResponse.json({ ok: false, error }, { status });

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  if (gate.user.role !== "admin") return fail(403, "Acesso exclusivo do administrador.");
  const { id: agentId } = await params;

  const agent = await prisma.agentSession.findFirst({
    where: { id: agentId, role: DELIVERY_ROLE },
    select: { id: true, provider: true, model: true },
  });
  if (!agent) return fail(404, "Agente de delivery não encontrado.");

  let form: FormData;
  try {
    form = await req.formData();
  } catch (err) {
    log({ event: "delivery.menu_upload_bad_body", agentId, error: String((err as Error)?.message ?? err) });
    return fail(400, "Não consegui ler o arquivo enviado. Tente de novo.");
  }
  const file = form.get("file");
  if (!file || typeof file === "string") return fail(400, "Escolha o arquivo do cardápio (PDF ou foto).");
  log({ event: "delivery.menu_upload_received", agentId, name: file.name, size: file.size, type: file.type });

  if (file.size === 0) return fail(400, "O arquivo está vazio.");
  if (file.size > MENU_MAX_BYTES) return fail(413, "Arquivo grande demais (máx. 8 MB).");
  if (!(MENU_MIME_TYPES as readonly string[]).includes(file.type)) {
    return fail(415, `Formato não suportado (${file.type || "desconhecido"}). Use PDF, PNG, JPG ou WEBP.`);
  }

  const bytes = new Uint8Array(await file.arrayBuffer());
  const started = Date.now();
  let items;
  try {
    items = await extractMenuItems({ provider: agent.provider, model: agent.model, file: bytes, mimeType: file.type });
  } catch (err) {
    const error = String((err as Error)?.message ?? err);
    log({ event: "delivery.menu_extract_failed", agentId, provider: agent.provider, model: agent.model, ms: Date.now() - started, error });
    return fail(422, `A IA não conseguiu ler o cardápio: ${error}`);
  }

  const data = {
    menuFile: bytes,
    menuMimeType: file.type,
    menuFileName: file.name.slice(0, 120),
    // Token novo a cada upload: o link antigo para de funcionar.
    menuToken: randomBytes(18).toString("base64url"),
    menuItems: items as unknown as Prisma.InputJsonValue,
    menuUpdatedAt: new Date(),
  };
  await prisma.deliveryStore.upsert({
    where: { agentSessionId: agentId },
    create: { agentSessionId: agentId, ...data },
    update: data,
  });
  log({ event: "delivery.menu_saved", agentId, items: items.length, ms: Date.now() - started });
  return NextResponse.json({ ok: true, count: items.length });
}
