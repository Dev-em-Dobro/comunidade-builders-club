/**
 * Conexão OAuth 2.0 com o Google (Sheets) — uma conta por instalação.
 *
 * Fluxo:
 *   1. Admin cola Client ID/Secret do Google Cloud (ou usa GOOGLE_OAUTH_CLIENT_ID/SECRET).
 *   2. /api/integrations/google/connect redireciona pro consentimento do Google.
 *   3. /api/integrations/google/callback troca o code por refresh_token e grava
 *      criptografado em GoogleConnection.
 *   4. getAccessToken() renova o access_token sob demanda (cache no banco —
 *      web e worker são processos diferentes).
 *
 * Sem SDK do Google: só fetch nas APIs REST.
 */
import { prisma } from "@/lib/db";
import { decryptSecret, encryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";

export const GOOGLE_SCOPES = [
  "openid",
  "email",
  // Exportar consultas pra planilha.
  "https://www.googleapis.com/auth/spreadsheets",
];

const AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN_URL = "https://oauth2.googleapis.com/token";
const REVOKE_URL = "https://oauth2.googleapis.com/revoke";
const SINGLETON = "singleton";

export class GoogleNotConnectedError extends Error {
  constructor(message = "Google não conectado. Conecte em Integrações → Google Sheets.") {
    super(message);
    this.name = "GoogleNotConnectedError";
  }
}

export class GoogleApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
    this.name = "GoogleApiError";
  }
}

/** Origem pública deduzida dos headers (respeita proxy: x-forwarded-*). */
export function originFromHeaders(h: Headers): string {
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3100";
  const proto =
    h.get("x-forwarded-proto")?.split(",")[0]?.trim() ??
    (/^(localhost|127\.0\.0\.1)(:|$)/.test(host) ? "http" : "https");
  return `${proto}://${host}`;
}

/** URL pública do CRM — base do redirect URI. */
export function publicBaseUrl(fallbackOrigin?: string): string {
  const base = process.env.PUBLIC_BASE_URL || fallbackOrigin || "";
  return base.replace(/\/+$/, "");
}

export function googleRedirectUri(fallbackOrigin?: string): string {
  return `${publicBaseUrl(fallbackOrigin)}/api/integrations/google/callback`;
}

async function loadRow() {
  return prisma.googleConnection.findUnique({ where: { id: SINGLETON } });
}

/** Client ID/Secret: painel tem precedência sobre as variáveis de ambiente. */
export async function resolveClientCredentials(): Promise<{
  clientId: string;
  clientSecret: string;
  source: "painel" | "ambiente";
} | null> {
  const row = await loadRow().catch(() => null);
  if (row?.clientId && row.clientSecretEnc && secretsKeyConfigured()) {
    return { clientId: row.clientId, clientSecret: decryptSecret(row.clientSecretEnc), source: "painel" };
  }
  const id = process.env.GOOGLE_OAUTH_CLIENT_ID;
  const secret = process.env.GOOGLE_OAUTH_CLIENT_SECRET;
  if (id && secret) return { clientId: id, clientSecret: secret, source: "ambiente" };
  return null;
}

export interface GoogleConnectionStatus {
  credentials: "painel" | "ambiente" | "ausente";
  clientIdHint: string | null;
  connected: boolean;
  accountEmail: string | null;
  connectedAt: Date | null;
  sheetsSpreadsheetId: string | null;
  sheetsSpreadsheetUrl: string | null;
  sheetsTabName: string | null;
}

/** Só metadados seguros — nada de segredo atravessa pro cliente. */
export async function googleConnectionStatus(): Promise<GoogleConnectionStatus> {
  const row = await loadRow().catch(() => null);
  const creds = await resolveClientCredentials().catch(() => null);
  return {
    credentials: creds?.source ?? "ausente",
    clientIdHint: creds ? creds.clientId.slice(0, 12) + "…" : null,
    connected: Boolean(row?.refreshTokenEnc),
    accountEmail: row?.accountEmail ?? null,
    connectedAt: row?.connectedAt ?? null,
    sheetsSpreadsheetId: row?.sheetsSpreadsheetId ?? null,
    sheetsSpreadsheetUrl: row?.sheetsSpreadsheetUrl ?? null,
    sheetsTabName: row?.sheetsTabName ?? null,
  };
}

export async function saveClientCredentials(clientId: string, clientSecret: string | null) {
  const data: { clientId: string; clientSecretEnc?: string } = { clientId };
  if (clientSecret) data.clientSecretEnc = encryptSecret(clientSecret);
  const existing = await loadRow();
  if (!existing && !clientSecret) throw new Error("Informe o Client Secret.");
  // Trocar o client invalida os tokens emitidos pelo anterior.
  const changedClient = existing?.clientId && existing.clientId !== clientId;
  await prisma.googleConnection.upsert({
    where: { id: SINGLETON },
    create: { id: SINGLETON, ...data },
    update: {
      ...data,
      ...(changedClient
        ? { refreshTokenEnc: null, accessTokenEnc: null, accessTokenExpiresAt: null, accountEmail: null, connectedAt: null }
        : {}),
    },
  });
}

export function buildAuthUrl(args: { clientId: string; redirectUri: string; state: string }): string {
  const url = new URL(AUTH_URL);
  url.searchParams.set("client_id", args.clientId);
  url.searchParams.set("redirect_uri", args.redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", GOOGLE_SCOPES.join(" "));
  // offline + consent: garante refresh_token mesmo em reconexões.
  url.searchParams.set("access_type", "offline");
  url.searchParams.set("prompt", "consent");
  url.searchParams.set("include_granted_scopes", "true");
  url.searchParams.set("state", args.state);
  return url.toString();
}

interface TokenResponse {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
  scope?: string;
  id_token?: string;
  error?: string;
  error_description?: string;
}

async function postToken(body: Record<string, string>): Promise<TokenResponse> {
  const res = await fetch(TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(body),
  });
  const json = (await res.json().catch(() => ({}))) as TokenResponse;
  if (!res.ok || json.error) {
    throw new GoogleApiError(json.error_description || json.error || `token HTTP ${res.status}`, res.status);
  }
  return json;
}

/** E-mail da conta a partir do id_token (veio direto do endpoint de token via TLS). */
function emailFromIdToken(idToken?: string): string | null {
  if (!idToken) return null;
  try {
    const payload = JSON.parse(Buffer.from(idToken.split(".")[1]!, "base64url").toString("utf8"));
    return typeof payload.email === "string" ? payload.email : null;
  } catch {
    return null;
  }
}

/** Troca o authorization code e grava a conexão. */
export async function completeOAuth(code: string, redirectUri: string): Promise<{ email: string | null }> {
  const creds = await resolveClientCredentials();
  if (!creds) throw new Error("Client ID/Secret do Google não configurados.");
  const tok = await postToken({
    code,
    client_id: creds.clientId,
    client_secret: creds.clientSecret,
    redirect_uri: redirectUri,
    grant_type: "authorization_code",
  });
  if (!tok.refresh_token) {
    throw new Error(
      "O Google não devolveu refresh_token. Remova o acesso do app em myaccount.google.com/permissions e conecte de novo.",
    );
  }
  const email = emailFromIdToken(tok.id_token);
  const data = {
    refreshTokenEnc: encryptSecret(tok.refresh_token),
    accessTokenEnc: encryptSecret(tok.access_token),
    accessTokenExpiresAt: new Date(Date.now() + tok.expires_in * 1000),
    accountEmail: email,
    scopes: tok.scope ?? null,
    connectedAt: new Date(),
  };
  await prisma.googleConnection.upsert({
    where: { id: SINGLETON },
    create: { id: SINGLETON, ...data },
    update: data,
  });
  return { email };
}

/** Access token válido (renova quando faltam < 60 s). */
export async function getAccessToken(): Promise<string> {
  const row = await loadRow();
  if (!row?.refreshTokenEnc) throw new GoogleNotConnectedError();
  if (
    row.accessTokenEnc &&
    row.accessTokenExpiresAt &&
    row.accessTokenExpiresAt.getTime() - Date.now() > 60_000
  ) {
    return decryptSecret(row.accessTokenEnc);
  }
  const creds = await resolveClientCredentials();
  if (!creds) throw new GoogleNotConnectedError("Client ID/Secret do Google ausentes.");
  let tok: TokenResponse;
  try {
    tok = await postToken({
      refresh_token: decryptSecret(row.refreshTokenEnc),
      client_id: creds.clientId,
      client_secret: creds.clientSecret,
      grant_type: "refresh_token",
    });
  } catch (err) {
    if (err instanceof GoogleApiError && err.status === 400) {
      // invalid_grant: acesso revogado ou token expirado (app em modo "Teste" expira em 7 dias).
      throw new GoogleNotConnectedError(
        "A autorização do Google expirou ou foi revogada. Conecte novamente em Integrações → Google Sheets.",
      );
    }
    throw err;
  }
  await prisma.googleConnection.update({
    where: { id: SINGLETON },
    data: {
      accessTokenEnc: encryptSecret(tok.access_token),
      accessTokenExpiresAt: new Date(Date.now() + tok.expires_in * 1000),
    },
  });
  return tok.access_token;
}

/** fetch autenticado numa API do Google; devolve o JSON (ou null em 204). */
export async function googleFetch<T = unknown>(url: string, init: RequestInit = {}): Promise<T> {
  const token = await getAccessToken();
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...(init.headers ?? {}),
    },
  });
  if (res.status === 204) return null as T;
  const json = (await res.json().catch(() => ({}))) as { error?: { message?: string } };
  if (!res.ok) {
    throw new GoogleApiError(json.error?.message || `Google HTTP ${res.status}`, res.status);
  }
  return json as T;
}

/** Revoga o token no Google (best-effort) e apaga a conexão local. Mantém Client ID/Secret. */
export async function disconnectGoogle(): Promise<void> {
  const row = await loadRow();
  if (row?.refreshTokenEnc) {
    try {
      await fetch(`${REVOKE_URL}?token=${encodeURIComponent(decryptSecret(row.refreshTokenEnc))}`, {
        method: "POST",
      });
    } catch {
      // revogação é best-effort
    }
  }
  if (row) {
    await prisma.googleConnection.update({
      where: { id: SINGLETON },
      data: {
        refreshTokenEnc: null,
        accessTokenEnc: null,
        accessTokenExpiresAt: null,
        accountEmail: null,
        scopes: null,
        connectedAt: null,
      },
    });
  }
}

export async function isGoogleConnected(): Promise<boolean> {
  const row = await loadRow().catch(() => null);
  return Boolean(row?.refreshTokenEnc);
}
