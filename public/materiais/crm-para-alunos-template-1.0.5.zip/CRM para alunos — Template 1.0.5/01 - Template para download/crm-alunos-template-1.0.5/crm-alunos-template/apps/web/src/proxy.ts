/**
 * Next.js 16 — proxy.ts (era middleware.ts até Next 15).
 *
 * Função: bloquear acesso ao painel sem sessão. Rotas públicas:
 *   - /login
 *   - /privacy, /data-deletion (páginas legais exigidas pela Meta — o
 *     revisor abre essas URLs sem login)
 *   - /api/auth/* (Auth.js handlers)
 *   - /api/webhooks/* (Meta liga aqui sem cookie nosso — HMAC é validado no handler)
 *   - /api/health (healthcheck Railway)
 *   - /l/* (link curto de CTA, Parte 12-A — lead clica do WhatsApp sem sessão)
 *   - /cardapio/* (cardápio do agente de delivery — cliente abre do WhatsApp)
 *
 * Tudo o resto exige sessão JWT válida (cookie next-auth.session-token).
 *
 * Importante: a documentação do Next 16 alerta que proxy NÃO substitui
 * autorização server-side. Aqui só fazemos o "optimistic redirect" — cada
 * rota protegida ainda valida via auth() server-side se for sensível.
 */

import { NextResponse, type NextRequest } from "next/server";
import { auth } from "@/auth";

const PUBLIC_PATHS = [
  "/login",
  "/privacy",
  "/data-deletion",
  "/api/auth",
  "/api/webhooks",
  "/api/health",
  "/l",
  "/cardapio",
] as const;

function isPublic(pathname: string): boolean {
  return PUBLIC_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`));
}

export default auth((req: NextRequest & { auth: unknown }) => {
  const { pathname } = req.nextUrl;

  if (isPublic(pathname)) return NextResponse.next();

  // Sem sessão → redireciona pra /login com ?callbackUrl=… pra voltar depois.
  if (!req.auth) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("callbackUrl", pathname);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
});

export const config = {
  // Skip arquivos estáticos do Next + ícones públicos.
  // Match tudo o mais (HTML pages + API routes — o handler filtra públicas dentro).
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:png|jpg|jpeg|gif|svg|webp|ico)$).*)"],
};
