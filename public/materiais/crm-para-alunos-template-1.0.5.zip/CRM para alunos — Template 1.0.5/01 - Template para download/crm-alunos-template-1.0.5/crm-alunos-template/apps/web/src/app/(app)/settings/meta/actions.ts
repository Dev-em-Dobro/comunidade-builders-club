"use server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { encryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";
import { META_FIELDS } from "@/lib/settings/meta-fields";
import { validateMetaValue } from "@/lib/settings/validation";
import { revalidatePath } from "next/cache";
export async function saveMeta(_previous: { error?: string; message?: string }, form: FormData): Promise<{ error?: string; message?: string }> {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Somente o administrador pode alterar as credenciais." };
  if (!secretsKeyConfigured()) return { error: "Configure SECRETS_KEY no servidor antes de salvar." };
  const entries = META_FIELDS.map((field) => ({ ...field, value: String(form.get(field.key) || "").trim() })).filter((field) => field.value);
  for (const field of entries) if (!validateMetaValue(field.value, field.secret)) return { error: `Valor inválido: ${field.label}. IDs contêm somente números; tokens não podem conter espaços.` };
  if (!entries.length) return { message: "Nenhum valor alterado. Campos vazios preservam a configuração atual." };
  try {
    await prisma.$transaction(entries.map(({ key, value }) => prisma.providerCredential.upsert({
      where: { provider: `meta:${key}` }, create: { provider: `meta:${key}`, apiKeyEnc: encryptSecret(value) }, update: { apiKeyEnc: encryptSecret(value), hint: null },
    })));
  } catch { return { error: "Não foi possível salvar as credenciais. Verifique o banco de dados." }; }
  revalidatePath("/settings/meta");
  return { message: "Credenciais salvas e criptografadas. Confira a conexão no onboarding e ative o canal em Geral." };
}
export async function clearMeta() {
  const session = await auth();
  if (session?.user?.role !== "admin") throw new Error("Acesso negado");
  await prisma.providerCredential.deleteMany({ where: { provider: { in: META_FIELDS.map(({ key }) => `meta:${key}`) } } });
  revalidatePath("/settings/meta");
}
