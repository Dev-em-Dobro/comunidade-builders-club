const MAX_VALUE_LEN = 200;
const MAX_TOTAL_LEN = 1200;

/** Coerce qualquer valor pra string trimada; valores vazios viram null. */
function toStringValue(v: unknown): string | null {
  if (v == null) return null;
  let s: string;
  if (typeof v === "string") s = v;
  else if (typeof v === "number" || typeof v === "boolean") s = String(v);
  else s = JSON.stringify(v);
  s = s.trim();
  return s.length > 0 ? s : null;
}

function truncate(value: string, max: number): string {
  if (value.length <= max) return value;
  return value.slice(0, max) + "…";
}

export interface DisplayEntry {
  question: string;
  answer: string;
}

/**
 * Formata `answers` como markdown pra injeção no system prompt do bot.
 * Trunca cada valor em 200 chars; trunca bloco total em 1200 chars no
 * boundary de uma resposta. Retorna string vazia se não houver respostas.
 */
export function formatAnswersForPrompt(
  surveyName: string,
  answers: Record<string, unknown>,
  submittedAt?: Date | null,
): string {
  const entries = Object.entries(answers)
    .map(([k, v]) => [k, toStringValue(v)] as const)
    .filter((p): p is [string, string] => p[1] !== null);

  if (entries.length === 0) return "";

  const headerLines: string[] = [`## Resposta da pesquisa "${surveyName}"`];
  if (submittedAt) {
    headerLines.push(`(respondida em ${submittedAt.toISOString().slice(0, 10)})`);
  }
  const header = headerLines.join("\n");

  const lines: string[] = [];
  let used = header.length + 1; // +\n
  let omitted = 0;

  for (const [k, v] of entries) {
    const line = `- ${k}: ${truncate(v, MAX_VALUE_LEN)}`;
    if (used + line.length + 1 > MAX_TOTAL_LEN) {
      omitted = entries.length - lines.length;
      break;
    }
    lines.push(line);
    used += line.length + 1;
  }

  let out = `${header}\n${lines.join("\n")}`;
  if (omitted > 0) out += `\n…[mais ${omitted} respostas omitidas]`;
  return out;
}

/** Para renderizar no drawer do atendente: sem truncar, mantém ordem. */
export function formatAnswersForDisplay(
  answers: Record<string, unknown>,
): DisplayEntry[] {
  return Object.entries(answers)
    .map(([k, v]) => ({ question: k, answer: toStringValue(v) }))
    .filter((e): e is DisplayEntry => e.answer !== null);
}
