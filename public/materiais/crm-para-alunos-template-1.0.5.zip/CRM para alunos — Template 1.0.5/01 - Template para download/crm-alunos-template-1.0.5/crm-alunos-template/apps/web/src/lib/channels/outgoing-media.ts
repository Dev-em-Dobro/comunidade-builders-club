export type OutgoingMediaKind = "image" | "audio";

export interface OutgoingMediaInfo {
  kind: OutgoingMediaKind;
  mimeType: string;
  maxBytes: number;
}

const SUPPORTED: Record<string, OutgoingMediaInfo> = {
  ".jpg": { kind: "image", mimeType: "image/jpeg", maxBytes: 5_000_000 },
  ".jpeg": { kind: "image", mimeType: "image/jpeg", maxBytes: 5_000_000 },
  ".png": { kind: "image", mimeType: "image/png", maxBytes: 5_000_000 },
  ".mp3": { kind: "audio", mimeType: "audio/mpeg", maxBytes: 16_000_000 },
  ".m4a": { kind: "audio", mimeType: "audio/mp4", maxBytes: 16_000_000 },
  ".mp4": { kind: "audio", mimeType: "audio/mp4", maxBytes: 16_000_000 },
  ".aac": { kind: "audio", mimeType: "audio/aac", maxBytes: 16_000_000 },
  ".ogg": { kind: "audio", mimeType: "audio/ogg", maxBytes: 16_000_000 },
  ".amr": { kind: "audio", mimeType: "audio/amr", maxBytes: 16_000_000 },
};

/** Valida antes do upload. A Meta faz a validação final do conteúdo binário. */
export function inspectOutgoingMedia(file: Pick<File, "name" | "size" | "type">): OutgoingMediaInfo {
  const extension = file.name.toLowerCase().match(/\.[^.]+$/)?.[0];
  const info = extension ? SUPPORTED[extension] : undefined;
  if (!info) throw new Error("Formato não aceito. Use JPG, PNG, MP3, M4A, AAC, OGG ou AMR.");
  if (file.size === 0) throw new Error("O arquivo está vazio.");
  if (file.size > info.maxBytes) {
    throw new Error(`Arquivo acima do limite de ${info.maxBytes / 1_000_000} MB.`);
  }
  const declaredType = file.type.toLowerCase().split(";")[0];
  if (declaredType && declaredType !== "application/octet-stream") {
    const family = declaredType.split("/")[0];
    if (family !== info.kind) throw new Error("O tipo do arquivo não combina com a extensão.");
  }
  return info;
}
