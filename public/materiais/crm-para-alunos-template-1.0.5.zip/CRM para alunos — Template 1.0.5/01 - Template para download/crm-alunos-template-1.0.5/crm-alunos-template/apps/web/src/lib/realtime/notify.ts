import { prisma } from "@/lib/db";

/**
 * Notifica listeners SSE sobre uma msg nova numa conversa.
 * Payload mínimo (<8KB limite do pg_notify): só ids; o cliente faz fetch
 * pra trazer a Message completa com sentBy populado.
 *
 * Chamado em:
 *  - flush.ts após persistir outbound do bot
 *  - /api/conversations/[id]/send após persistir msg do operador
 */
export async function notifyMessage(
  conversationId: string,
  messageId: string,
): Promise<void> {
  const payload = JSON.stringify({ conversationId, messageId });
  await prisma.$executeRawUnsafe(`SELECT pg_notify('msg_new', $1)`, payload);
}

/**
 * Discriminador de eventos não-mensagem da conversa.
 * Server-side. O canal SSE serializa via JSON (datas viram strings — ver
 * `ConvEventClientPayload` pra forma após o JSON.parse no cliente).
 */
export type ConvEventPayload =
  | {
      type: "claim";
      userId: string;
      userName: string | null;
      previousOwnerId: string | null;
      /** True quando o claim também pausou a IA (composer abre sem refresh). */
      aiPausedByClaim?: boolean;
    }
  | {
      type: "release";
      previousOwnerId: string;
    }
  | {
      type: "window_warning";
      minutesLeft: number;
      windowClosesAt: string; // ISO
    };

/** Forma do payload após desserialização pelo cliente. Mesmas chaves, datas como string. */
export type ConvEventClientPayload = ConvEventPayload & {
  conversationId: string;
};

/**
 * Notifica eventos não-mensagem da conversa (claim/release/window_warning).
 * Canal pg_notify separado de `msg_new` pra cliente discriminar via SSE event name.
 * Payload limite 8KB do pg_notify; todos os payloads aqui são pequenos.
 */
export async function notifyConvEvent(
  conversationId: string,
  payload: ConvEventPayload,
): Promise<void> {
  const body = JSON.stringify({ conversationId, ...payload });
  await prisma.$executeRawUnsafe(`SELECT pg_notify('conv_event', $1)`, body);
}
