-- AlterTable: add role field to AgentSession
ALTER TABLE "AgentSession" ADD COLUMN "role" TEXT;

-- CreateIndex
CREATE INDEX "AgentSession_role_idx" ON "AgentSession"("role");

-- Backfill: marca a session default existente como SDR.
UPDATE "AgentSession" SET "role" = 'sdr' WHERE "isDefault" = true AND "role" IS NULL;
