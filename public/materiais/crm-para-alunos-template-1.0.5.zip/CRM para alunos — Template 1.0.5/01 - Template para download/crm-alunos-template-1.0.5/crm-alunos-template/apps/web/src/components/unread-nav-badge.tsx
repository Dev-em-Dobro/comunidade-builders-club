"use client";

import { useEffect, useState } from "react";

const POLL_MS = 30_000;

/**
 * Badge de conversas não lidas no item "Conversas" da nav.
 * Polling leve (30s) — a sidebar é server-rendered, então o contador
 * vive neste client component. Falha de rede é silenciosa.
 */
export function UnreadNavBadge() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let alive = true;
    async function load() {
      try {
        const r = await fetch("/api/conversations/unread-count");
        if (!r.ok) return;
        const body = (await r.json()) as { count?: number };
        if (alive && typeof body.count === "number") setCount(body.count);
      } catch {
        // silencioso — próximo tick tenta de novo.
      }
    }
    void load();
    const t = setInterval(load, POLL_MS);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  if (count <= 0) return null;
  return (
    <span className="ml-auto rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-mono leading-none text-primary-foreground">
      {count}
    </span>
  );
}
