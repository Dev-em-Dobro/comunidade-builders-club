import { prisma } from "@/lib/db";
import { appendUtm } from "@/lib/cta/utm";

export const dynamic = "force-dynamic";

const NOT_FOUND_HTML =
  "<!doctype html><html><body><h1>Link não encontrado</h1></body></html>";
const GONE_HTML =
  "<!doctype html><html><body><h1>Link expirado</h1>" +
  "<p>Fale com a gente pra receber um link atualizado.</p></body></html>";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ code: string }> },
): Promise<Response> {
  const { code } = await params;

  const link = await prisma.shortLink.findUnique({
    where: { code },
    include: { course: true, launchPlan: true },
  });

  if (!link) {
    return new Response(NOT_FOUND_HTML, {
      status: 404,
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  }

  // Se o ShortLink foi criado durante uma oferta (launchPlan != null),
  // usamos a URL daquele plano — o lead recebeu aquele preço, é o que ele
  // deve ver mesmo se o plano perder a URL depois (cai 410, força handoff).
  // Sem launchPlan → comportamento antigo (Course.checkoutUrl).
  const targetCheckoutUrl = link.launchPlan
    ? link.launchPlan.checkoutUrl
    : link.course.checkoutUrl;

  if (targetCheckoutUrl == null) {
    return new Response(GONE_HTML, {
      status: 410,
      headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
    });
  }

  const finalUrl = appendUtm(targetCheckoutUrl, {
    utm_source: "wa",
    utm_content: link.leadId,
    utm_campaign: link.course.slug,
  });

  const userAgent = req.headers.get("user-agent") ?? null;
  const referer = req.headers.get("referer") ?? null;

  // Fire-and-forget — perder 1 evento é aceitável (log analítico).
  void Promise.all([
    prisma.shortLink.update({
      where: { code },
      data: { clickCount: { increment: 1 }, lastClickAt: new Date() },
    }),
    prisma.pipelineEvent.create({
      data: {
        leadId: link.leadId,
        type: "cta_click",
        payload: { code, courseId: link.courseId, launchPlanId: link.launchPlanId ?? null, userAgent, referer },
      },
    }),
  ]).catch((err) => {
    console.error("[l/code] background write failed", err);
  });

  return new Response(null, {
    status: 302,
    headers: { location: finalUrl, "cache-control": "no-store" },
  });
}
