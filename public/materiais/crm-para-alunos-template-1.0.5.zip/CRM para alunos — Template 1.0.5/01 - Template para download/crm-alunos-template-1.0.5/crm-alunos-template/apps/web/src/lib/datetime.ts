/**
 * Formatação de data/hora pra EXIBIÇÃO.
 *
 * Timestamps são gravados em UTC. Renderizar `toISOString().slice(...)` mostra a
 * hora UTC crua (bug real: aparecia 13:40 em vez de 10:40 BRT). Aqui convertemos
 * pro fuso do negócio.
 *
 * O fuso é FIXO (America/Sao_Paulo), não o do navegador: é determinístico entre
 * SSR e cliente (evita hydration mismatch — lição de hidratação do projeto) e
 * bate com o `TZ` do servidor. Se um dia houver operador fora do Brasil, revisar.
 */
export const DISPLAY_TZ = "America/Sao_Paulo";

/** "HH:mm:ss" no fuso de exibição. */
export function formatTime(d: string | Date): string {
  return new Date(d).toLocaleTimeString("pt-BR", {
    timeZone: DISPLAY_TZ,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}

/** "dd/MM/yyyy HH:mm:ss" no fuso de exibição. */
export function formatDateTime(d: string | Date): string {
  return new Date(d).toLocaleString("pt-BR", {
    timeZone: DISPLAY_TZ,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
}
