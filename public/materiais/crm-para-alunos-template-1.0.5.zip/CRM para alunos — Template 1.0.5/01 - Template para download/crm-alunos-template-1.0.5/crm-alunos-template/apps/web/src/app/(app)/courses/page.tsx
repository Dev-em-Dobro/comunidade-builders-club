import Link from "next/link";
import { prisma } from "@/lib/db";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, GraduationCap } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function CoursesPage() {
  const courses = await safeQuery();

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Cursos
          </h1>
          <p className="text-muted-foreground mt-1">
            Catálogo de cursos vendáveis — referenciados pelo interesse do lead.
          </p>
        </div>
        <Link href="/courses/new" className={buttonVariants()}>
          <Plus className="size-4" /> Novo curso
        </Link>
      </header>

      {courses.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <GraduationCap className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhum curso cadastrado</p>
          <p className="text-sm text-muted-foreground mt-1">
            Cadastre os cursos que a IA pode oferecer nos lançamentos.
          </p>
          <Link
            href="/courses/new"
            className={buttonVariants({ className: "mt-4" })}
          >
            <Plus className="size-4" /> Criar curso
          </Link>
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Slug</TableHead>
                <TableHead>Preço</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {courses.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-medium">{c.name}</TableCell>
                  <TableCell className="font-mono text-xs text-muted-foreground">
                    {c.slug}
                  </TableCell>
                  <TableCell className="font-mono">
                    {fmtPrice(c.priceCents)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={c.active ? "default" : "outline"}>
                      {c.active ? "ativo" : "inativo"}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Link
                      href={`/courses/${c.id}`}
                      className={buttonVariants({ size: "sm", variant: "outline" })}
                    >
                      Editar
                    </Link>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}

function fmtPrice(cents: number): string {
  return (cents / 100).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

async function safeQuery() {
  try {
    return await prisma.course.findMany({ orderBy: { createdAt: "desc" } });
  } catch {
    return [];
  }
}
