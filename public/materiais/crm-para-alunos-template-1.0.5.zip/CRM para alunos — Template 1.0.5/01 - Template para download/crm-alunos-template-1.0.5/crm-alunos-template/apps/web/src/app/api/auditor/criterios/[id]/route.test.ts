import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));

import { PATCH } from "./route";
import { auth } from "@/auth";

const created: string[] = [];

async function makeCriterion() {
  const c = await prisma.auditCriterion.create({
    data: {
      name: `Teste PATCH ${Date.now()}-${Math.random()}`,
      description: "Descrição inicial",
      weight: 3,
      active: true,
    },
  });
  created.push(c.id);
  return c;
}

afterAll(async () => {
  if (created.length > 0) {
    await prisma.auditCriterion.deleteMany({ where: { id: { in: created } } });
  }
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "test-user" } } as never);
});

function call(id: string, body: object) {
  const req = new Request("http://test", {
    method: "PATCH",
    body: JSON.stringify(body),
  });
  return PATCH(req, { params: Promise.resolve({ id }) });
}

describe("PATCH /api/auditor/criterios/[id]", () => {
  it("rejeita sem auth", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const c = await makeCriterion();
    const res = await call(c.id, { name: "novo" });
    expect(res.status).toBe(401);
  });

  it("retorna 404 quando id não existe", async () => {
    const res = await call("cmnonexistent000000000000", { name: "x" });
    expect(res.status).toBe(404);
  });

  it("rejeita payload vazio", async () => {
    const c = await makeCriterion();
    const res = await call(c.id, {});
    expect(res.status).toBe(400);
  });

  it("rejeita weight fora de 1-5", async () => {
    const c = await makeCriterion();
    const res = await call(c.id, { weight: 0 });
    expect(res.status).toBe(400);
  });

  it("atualiza name + weight", async () => {
    const c = await makeCriterion();
    const res = await call(c.id, { name: "Renomeado", weight: 5 });
    expect(res.status).toBe(200);
    const after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after?.name).toBe("Renomeado");
    expect(after?.weight).toBe(5);
  });

  it("desativa via active=false (não deleta)", async () => {
    const c = await makeCriterion();
    const res = await call(c.id, { active: false });
    expect(res.status).toBe(200);
    const after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after).not.toBeNull(); // continua existindo
    expect(after?.active).toBe(false);
  });

  it("aceita exampleFail = null (limpa o campo)", async () => {
    const c = await prisma.auditCriterion.create({
      data: {
        name: `Com exampleFail ${Date.now()}`,
        description: "d",
        exampleFail: "antes",
      },
    });
    created.push(c.id);
    const res = await call(c.id, { exampleFail: null });
    expect(res.status).toBe(200);
    const after = await prisma.auditCriterion.findUnique({ where: { id: c.id } });
    expect(after?.exampleFail).toBeNull();
  });
});
