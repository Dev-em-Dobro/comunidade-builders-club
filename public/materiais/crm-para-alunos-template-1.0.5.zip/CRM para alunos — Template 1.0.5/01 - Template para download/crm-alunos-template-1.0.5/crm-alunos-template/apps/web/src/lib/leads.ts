import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";
import type { Lead } from "@prisma/client";
import { getActiveLaunch } from "@/lib/launches/active";

/**
 * Garante um Lead pro Contact dado.
 *
 * `Lead.contactId` é @unique → no máximo 1 Lead por Contact. Idempotente e
 * P2002-safe (mesmo padrão de ensureContactIdentity): duas inbounds concorrentes
 * podem correr no create — a segunda colide no @unique e cai no findUnique.
 *
 * Na criação registra o PipelineEvent inicial (`stage_change` → new).
 * Retorna `created=true` só na primeira vez.
 */
export async function ensureLeadForContact(
  contactId: string,
): Promise<{ lead: Lead; created: boolean }> {
  const existing = await prisma.lead.findUnique({ where: { contactId } });
  if (existing) return { lead: existing, created: false };

  try {
    const now = new Date();
    const lead = await prisma.lead.create({
      data: {
        contactId,
        stage: "new",
        firstInboundAt: now,
        lastActivityAt: now,
      },
    });
    await prisma.pipelineEvent.create({
      data: { leadId: lead.id, type: "stage_change", payload: { to: "new" } },
    });
    return { lead, created: true };
  } catch (err) {
    // Corrida: outra inbound criou o Lead entre o findUnique e o create.
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      err.code === "P2002"
    ) {
      const lead = await prisma.lead.findUnique({ where: { contactId } });
      if (lead) return { lead, created: false };
    }
    throw err;
  }
}

/**
 * Atribui Lead.launchId baseado nos courses de interesse:
 *  - se launchId já está setado, no-op
 *  - busca getActiveLaunch pra cada course em interestCourseIds
 *  - se EXATAMENTE 1 launch ativo → seta launchId
 *  - se 0 ou 2+ → mantém null (ambiguidade ou nenhuma oferta)
 *
 * Idempotente e fire-and-forget — pode ser chamado de qualquer lugar que
 * modifique interestCourseIds. Não throwa: erros são swallowed pra não
 * derrubar o fluxo principal.
 */
export async function tryAttributeLaunchId(leadId: string): Promise<void> {
  try {
    const lead = await prisma.lead.findUnique({
      where: { id: leadId },
      select: { launchId: true, interestCourseIds: true },
    });
    if (!lead) return;
    if (lead.launchId) return; // já atribuído
    if (lead.interestCourseIds.length === 0) return;

    const matches = await Promise.all(
      lead.interestCourseIds.map((cid) => getActiveLaunch(cid)),
    );
    const active = matches.filter((l): l is NonNullable<typeof l> => l !== null);

    if (active.length !== 1) return; // 0 = sem oferta; 2+ = ambíguo

    await prisma.lead.update({
      where: { id: leadId },
      data: { launchId: active[0]!.id },
    });
  } catch (err) {
    console.warn(
      `[tryAttributeLaunchId] erro silencioso pra leadId=${leadId}: ${(err as Error)?.message ?? err}`,
    );
  }
}

/** Marca atividade no Lead — chamado a cada inbound. */
export async function touchLeadActivity(leadId: string): Promise<void> {
  await prisma.lead.update({
    where: { id: leadId },
    data: { lastActivityAt: new Date() },
  });
}
