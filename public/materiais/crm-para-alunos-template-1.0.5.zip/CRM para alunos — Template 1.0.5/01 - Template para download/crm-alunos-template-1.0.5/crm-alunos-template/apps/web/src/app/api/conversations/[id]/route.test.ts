import { describe, it, expect, vi, beforeAll, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));

import { PATCH } from "./route";
import { auth } from "@/auth";

const created = {
  conversationIds: [] as string[],
  contactIds: [] as string[],
  userIds: [] as string[],
};
let userId: string;
let convId: string;

beforeAll(async () => {
  const user = await prisma.user.create({
    data: { email: `convpatch-${Date.now()}@t.local`, name: "Atendente" },
  });
  userId = user.id;
  created.userIds.push(user.id);

  const contact = await prisma.contact.create({ data: { displayName: "L" } });
  created.contactIds.push(contact.id);

  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud", aiEnabled: true },
  });
  convId = conv.id;
  created.conversationIds.push(conv.id);
});

afterAll(async () => {
  await prisma.conversation.deleteMany({
    where: { id: { in: created.conversationIds } },
  });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

function req(body: unknown): Request {
  return new Request("http://test", {
    method: "PATCH",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("PATCH /api/conversations/[id]", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await PATCH(req({ aiEnabled: false }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(401);
  });

  it("200 alterna aiEnabled com sessão", async () => {
    const res = await PATCH(req({ aiEnabled: false }), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const after = await prisma.conversation.findUniqueOrThrow({
      where: { id: convId },
    });
    expect(after.aiEnabled).toBe(false);
  });
});
