import { describe, it, expect } from "vitest";
import { generateBase62Code, BASE62_ALPHABET } from "./short-code";

describe("generateBase62Code", () => {
  it("retorna string com tamanho exato", () => {
    expect(generateBase62Code(6)).toHaveLength(6);
    expect(generateBase62Code(10)).toHaveLength(10);
  });

  it("usa só caracteres do alfabeto base62", () => {
    const code = generateBase62Code(100);
    for (const ch of code) {
      expect(BASE62_ALPHABET).toContain(ch);
    }
  });

  it("gera valores distintos em chamadas seguidas", () => {
    const samples = new Set<string>();
    for (let i = 0; i < 50; i++) samples.add(generateBase62Code(6));
    expect(samples.size).toBe(50);
  });

  it("rejeita length <= 0", () => {
    expect(() => generateBase62Code(0)).toThrow();
    expect(() => generateBase62Code(-1)).toThrow();
  });
});
