/**
 * Normaliza telefone pra forma E.164 sem o '+' (estilo `5511987654321`).
 * Remove tudo que não é dígito; rejeita strings cujo resultado tem <10 ou >15 dígitos.
 *
 * IMPORTANTE: ContactIdentity.externalId guarda o número SEM '+' (gotcha 0.9.27
 * do wizard); por isso retornamos sem '+' também — bate direto no DB.
 *
 * NÃO prepende DDI brasileiro automaticamente — quem normaliza e quem chama
 * tem responsabilidades diferentes. O matcher (Task 4) faz tentativa-fallback
 * com `55` prepended quando o número tem 10-11 dígitos sem DDI.
 */
export function normalizePhoneToE164(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 10 || digits.length > 15) return null;
  return digits;
}
