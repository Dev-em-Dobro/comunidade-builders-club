/**
 * System prompt, tool def e formatters do auditor (Sub-Plan A).
 * Sem I/O — funções puras + constantes.
 */
import type { LLMToolDef } from "@/lib/llm";

export const AUDITOR_SYSTEM_PROMPT =
  "Você é um gerente sênior de vendas e atendimento. Sua função é auditar " +
  "conversas entre o nosso bot e leads, identificando o que o bot fez bem e " +
  "o que precisa melhorar.\n\n" +
  "Para cada critério da checklist fornecida, dê um veredito: `pass` (bot " +
  "atendeu o critério), `fail` (bot pisou na bola), ou `na` (critério não se " +
  "aplica nesta conversa). Para fails, dê uma evidência curta extraída da " +
  "conversa (1-2 linhas) e uma recomendação concreta de como evitar isso no " +
  "futuro. Atribua severity 1-5: 5 só para erros que custariam o lead; 1 " +
  "para chatices menores.\n\n" +
  "Você também pode anotar observações livres fora da checklist — coisas " +
  "que chamaram sua atenção e que valem ser sinalizadas ao time mesmo sem " +
  "critério formal.\n\n" +
  "Regras estritas:\n" +
  "- Não invente fatos. Se a conversa não tem evidência, marque `na` em vez de `fail`.\n" +
  "- Não recomende o que o bot já fez bem.\n" +
  "- Seja específico: \"use a regra X depois da pergunta Y\" vale mais que \"melhorar tom\".\n" +
  "- Use português brasileiro.";

export const RECORD_AUDIT_TOOL: LLMToolDef = {
  name: "record_audit",
  description:
    "Registra a auditoria desta conversa. Chame uma única vez, com sua " +
    "melhor leitura, cobrindo todos os critérios listados.",
  inputSchema: {
    type: "object",
    properties: {
      findings: {
        type: "array",
        items: {
          type: "object",
          properties: {
            criterionId: {
              type: "string",
              description: "ID exato do critério da lista fornecida.",
            },
            verdict: { type: "string", enum: ["pass", "fail", "na"] },
            severity: { type: "integer", minimum: 1, maximum: 5 },
            evidence: {
              type: "string",
              description: "Trecho curto da conversa que evidencia o verdict.",
            },
            recommendation: {
              type: "string",
              description: "Sugestão concreta de melhoria (só pra fail).",
            },
          },
          required: ["criterionId", "verdict"],
        },
      },
      freeNotes: {
        type: "string",
        description:
          "Observações livres sobre esta conversa fora da checklist. " +
          "String vazia se nada a anotar.",
      },
      oneLineVerdict: {
        type: "string",
        description:
          "Uma frase curta resumindo a conversa pra agregação. " +
          "Ex: 'bot fechou bem mas repetiu 2x a pergunta de orçamento'.",
      },
    },
    required: ["findings", "oneLineVerdict"],
  },
};

export interface TranscriptMsg {
  role: string;
  text: string | null | undefined;
  createdAt: Date;
}

/** Formata uma lista de mensagens pra texto compacto pro prompt do auditor. */
export function formatTranscript(msgs: TranscriptMsg[]): string {
  const valid = msgs.filter((m): m is TranscriptMsg & { text: string } => Boolean(m.text));
  if (valid.length === 0) return "Sem mensagens.";
  return valid
    .map((m) => `[${m.role} ${m.createdAt.toISOString()}]\n${m.text}`)
    .join("\n\n");
}

export interface CriterionForPrompt {
  id: string;
  name: string;
  description: string;
  exampleFail: string | null;
  weight: number;
}

/** Formata os critérios ativos como bloco markdown pro system prompt dinâmico. */
export function formatCriteriaBlock(criteria: CriterionForPrompt[]): string {
  const lines = [
    "# Critérios de auditoria",
    "Avalie cada um. Use o `id` EXATO ao preencher o tool record_audit.",
    "",
  ];
  criteria.forEach((c, i) => {
    lines.push(`${i + 1}. **${c.name}** (id=${c.id}, peso=${c.weight})`);
    lines.push(`   ${c.description}`);
    if (c.exampleFail) {
      lines.push(`   Exemplo de fail: ${c.exampleFail}`);
    }
    lines.push("");
  });
  return lines.join("\n");
}
