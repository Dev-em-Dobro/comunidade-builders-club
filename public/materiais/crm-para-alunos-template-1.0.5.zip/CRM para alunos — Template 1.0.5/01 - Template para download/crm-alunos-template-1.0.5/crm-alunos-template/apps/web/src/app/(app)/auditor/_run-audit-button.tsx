"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";

interface Props {
  disabled: boolean;
  inflightId: string | null;
}

export function RunAuditButton({ disabled, inflightId }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function handleClick() {
    if (disabled) {
      if (inflightId) router.push(`/auditor/${inflightId}`);
      return;
    }
    setLoading(true);
    try {
      const res = await fetch("/api/auditor/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: "{}",
      });
      const data = (await res.json()) as { reportId?: string; existing?: string };
      const target = data.reportId ?? data.existing;
      if (target) router.push(`/auditor/${target}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Button onClick={handleClick} disabled={loading}>
      {disabled
        ? "Auditoria em andamento — abrir"
        : loading
          ? "Iniciando..."
          : "Rodar agora"}
    </Button>
  );
}
