import { getAllQueueCounts } from "@/lib/queue";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Lê o Redis a cada request — nunca pré-renderizar no build.
export const dynamic = "force-dynamic";

export default async function QueuesPage() {
  let counts: Awaited<ReturnType<typeof getAllQueueCounts>> | null = null;
  let error: string | null = null;
  try {
    counts = await getAllQueueCounts();
  } catch (err) {
    error = String((err as Error)?.message ?? err);
  }

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Filas de jobs
        </h1>
        <p className="text-muted-foreground mt-1">
          Contadores BullMQ por fila. Atualiza a cada carga da página.
        </p>
      </header>

      {error && (
        <p className="text-destructive text-sm mb-4">
          Redis indisponível — {error}
        </p>
      )}

      <div className="grid gap-4 md:grid-cols-2">
        {counts &&
          Object.entries(counts).map(([name, c]) => (
            <Card key={name}>
              <CardHeader className="pb-2">
                <CardTitle className="text-base font-mono">{name}</CardTitle>
                <CardDescription>
                  {c.waiting + c.active + c.delayed} pendentes
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-1.5 text-xs">
                <Badge variant="outline">waiting {c.waiting}</Badge>
                <Badge variant="outline">active {c.active}</Badge>
                <Badge variant="outline">delayed {c.delayed}</Badge>
                <Badge variant="outline">completed {c.completed}</Badge>
                <Badge variant="outline">failed {c.failed}</Badge>
              </CardContent>
            </Card>
          ))}
      </div>
    </div>
  );
}
