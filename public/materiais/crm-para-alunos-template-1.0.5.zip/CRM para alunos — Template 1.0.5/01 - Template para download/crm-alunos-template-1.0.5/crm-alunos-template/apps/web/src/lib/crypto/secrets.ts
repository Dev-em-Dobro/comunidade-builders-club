import { createCipheriv, createDecipheriv, randomBytes, createHash } from "crypto";

const ALGO = "aes-256-gcm";

/**
 * Deriva uma chave de 32 bytes de qualquer string via SHA-256. Aceita
 * SECRETS_KEY de comprimento arbitrário (não exige exatamente 32 bytes).
 */
function getKey(): Buffer {
  const raw = process.env.SECRETS_KEY;
  if (!raw) {
    throw new Error("SECRETS_KEY ausente — necessário para criptografar credenciais.");
  }
  return createHash("sha256").update(raw).digest();
}

export function secretsKeyConfigured(): boolean {
  return Boolean(process.env.SECRETS_KEY);
}

/** Formato retornado: `ivBase64:tagBase64:ciphertextBase64`. */
export function encryptSecret(plain: string): string {
  const key = getKey();
  const iv = randomBytes(12);
  const cipher = createCipheriv(ALGO, key, iv);
  const ct = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString("base64"), tag.toString("base64"), ct.toString("base64")].join(":");
}

export function decryptSecret(enc: string): string {
  const key = getKey();
  const parts = enc.split(":");
  if (parts.length !== 3 || parts.some((p) => !p)) {
    throw new Error("Formato de secret inválido — esperado iv:tag:ciphertext.");
  }
  const [ivB64, tagB64, ctB64] = parts;
  const decipher = createDecipheriv(ALGO, key, Buffer.from(ivB64, "base64"));
  decipher.setAuthTag(Buffer.from(tagB64, "base64"));
  return Buffer.concat([
    decipher.update(Buffer.from(ctB64, "base64")),
    decipher.final(),
  ]).toString("utf8");
}
