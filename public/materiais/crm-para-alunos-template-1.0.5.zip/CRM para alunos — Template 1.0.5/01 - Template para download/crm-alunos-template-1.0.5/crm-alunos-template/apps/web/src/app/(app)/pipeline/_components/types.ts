export type Assignee =
  | { type: "human"; name: string }
  | { type: "bot"; name: string; role: string | null };

export interface LeadView {
  id: string;
  contactDisplayName: string | null;
  score: number;
  stage: string;
  lastFollowUpStep: number | null;
  lastFollowUpAt: string | null;
  lastActivityAt: string | null;
  conversationId: string | null;
  channel: string | null;
  courseName: string | null;
  assignee: Assignee | null;
  windowClosesAt: string | null;
  windowExpired: boolean;
}
