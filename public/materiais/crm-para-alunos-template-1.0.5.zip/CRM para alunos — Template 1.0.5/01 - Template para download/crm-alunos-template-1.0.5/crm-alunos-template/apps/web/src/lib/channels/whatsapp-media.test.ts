import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { fetchWhatsAppMedia } from "./whatsapp-media";

describe("fetchWhatsAppMedia", () => {
  const originalToken = process.env.META_SYSTEM_USER_TOKEN;
  const originalPhoneId = process.env.META_PHONE_NUMBER_ID;

  beforeEach(() => {
    process.env.META_SYSTEM_USER_TOKEN = "test-token";
    process.env.META_PHONE_NUMBER_ID = "123456";
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    if (originalToken === undefined) delete process.env.META_SYSTEM_USER_TOKEN;
    else process.env.META_SYSTEM_USER_TOKEN = originalToken;
    if (originalPhoneId === undefined) delete process.env.META_PHONE_NUMBER_ID;
    else process.env.META_PHONE_NUMBER_ID = originalPhoneId;
  });

  it("obtém URL temporário e baixa o áudio com token e Range", async () => {
    const mock = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({
        url: "https://lookaside.fbsbx.com/whatsapp_business/attachments/?mid=77",
        mime_type: "audio/ogg",
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response("audio-bytes", { status: 206 }));
    vi.stubGlobal("fetch", mock);

    const result = await fetchWhatsAppMedia("77", "audio", "bytes=0-99");

    expect(result.mimeType).toBe("audio/ogg");
    expect(result.upstream.status).toBe(206);
    expect(String(mock.mock.calls[0]![0])).toBe("https://graph.facebook.com/v25.0/77?phone_number_id=123456");
    expect(mock.mock.calls[1]![1]).toEqual(expect.objectContaining({
      headers: { Authorization: "Bearer test-token", Range: "bytes=0-99" },
    }));
  });

  it("aceita o MIME real de um documento recebido", async () => {
    const mock = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify({
        url: "https://lookaside.fbsbx.com/whatsapp_business/attachments/?mid=88",
        mime_type: "application/pdf",
      }), { status: 200 }))
      .mockResolvedValueOnce(new Response("pdf-bytes", { status: 200 }));
    vi.stubGlobal("fetch", mock);

    const result = await fetchWhatsAppMedia("88", "document");

    expect(result.mimeType).toBe("application/pdf");
    expect(result.upstream.status).toBe(200);
    expect(mock).toHaveBeenCalledTimes(2);
  });

  it("rejeita URL fora dos domínios de mídia da Meta", async () => {
    const mock = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({
      url: "https://example.com/private",
      mime_type: "image/jpeg",
    }), { status: 200 }));
    vi.stubGlobal("fetch", mock);

    await expect(fetchWhatsAppMedia("77", "image")).rejects.toThrow("URL de mídia da Meta inválido");
    expect(mock).toHaveBeenCalledTimes(1);
  });
});
