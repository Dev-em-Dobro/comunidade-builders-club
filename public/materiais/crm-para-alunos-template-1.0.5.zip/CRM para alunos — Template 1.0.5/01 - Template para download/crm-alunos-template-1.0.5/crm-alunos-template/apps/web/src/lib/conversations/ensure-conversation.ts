import { prisma } from "@/lib/db";
import type { Conversation } from "@prisma/client";
import type { ChannelId } from "@/lib/channels/types";

/**
 * Find-or-create da conversa do contato no canal.
 *
 * `firstEver` = true quando NENHUMA conversa do contato existia em QUALQUER
 * canal antes desta — sinal de "primeira vez que a pessoa fala com a gente",
 * usado pelo `flush.ts` pra disparar a notificação de nova conversa.
 */
export async function ensureConversation(
  contactId: string,
  channel: ChannelId,
): Promise<{ conv: Conversation; firstEver: boolean }> {
  const existing = await prisma.conversation.findFirst({
    where: { contactId, channel },
    orderBy: { createdAt: "desc" },
  });
  if (existing) return { conv: existing, firstEver: false };

  const anyPrior = await prisma.conversation.findFirst({
    where: { contactId },
    select: { id: true },
  });
  const firstEver = anyPrior === null;

  const defaultAgent = await prisma.agentSession.findFirst({
    where: { isDefault: true },
  });
  const conv = await prisma.conversation.create({
    data: {
      contactId,
      channel,
      agentSessionId: defaultAgent?.id ?? null,
    },
  });
  return { conv, firstEver };
}
