import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/lib/channels/meta-templates", () => ({
  listMetaTemplates: vi.fn(),
}));

import { listMetaTemplates } from "@/lib/channels/meta-templates";
import { syncTemplatesFromMeta } from "./sync";

const createdIds: string[] = [];

afterAll(async () => {
  if (createdIds.length > 0) {
    await prisma.messageTemplate.deleteMany({ where: { id: { in: createdIds } } });
  }
  await prisma.messageTemplate.deleteMany({
    where: { metaName: { startsWith: "synctest_" } },
  });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(listMetaTemplates).mockReset();
});

describe("syncTemplatesFromMeta", () => {
  it("ADD: cria templates novos vindos da Meta", async () => {
    vi.mocked(listMetaTemplates).mockResolvedValueOnce([
      {
        name: `synctest_new_${Date.now()}`,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [{ type: "BODY", text: "Oi {{1}}" }],
      },
    ]);
    const r = await syncTemplatesFromMeta();
    expect(r.added).toBe(1);
    expect(r.updated).toBe(0);
    const row = await prisma.messageTemplate.findFirst({
      where: { metaName: { startsWith: "synctest_new_" } },
    });
    expect(row).not.toBeNull();
    createdIds.push(row!.id);
    expect(row?.bodyText).toBe("Oi {{1}}");
    expect(row?.variableCount).toBe(1);
  });

  it("UPDATE: atualiza template existente quando status muda", async () => {
    const name = `synctest_upd_${Date.now()}`;
    const existing = await prisma.messageTemplate.create({
      data: {
        metaName: name,
        language: "pt_BR",
        category: "UTILITY",
        status: "PENDING",
        components: [{ type: "BODY", text: "antes" }],
        bodyText: "antes",
        variableCount: 0,
      },
    });
    createdIds.push(existing.id);
    vi.mocked(listMetaTemplates).mockResolvedValueOnce([
      {
        name,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [{ type: "BODY", text: "depois {{1}}" }],
      },
    ]);
    const r = await syncTemplatesFromMeta();
    expect(r.updated).toBe(1);
    const after = await prisma.messageTemplate.findUnique({ where: { id: existing.id } });
    expect(after?.status).toBe("APPROVED");
    expect(after?.bodyText).toBe("depois {{1}}");
    expect(after?.variableCount).toBe(1);
  });

  it("REMOVE: deleta templates locais ausentes da Meta", async () => {
    const name = `synctest_rm_${Date.now()}`;
    const orphan = await prisma.messageTemplate.create({
      data: {
        metaName: name,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [],
        bodyText: null,
        variableCount: 0,
      },
    });
    vi.mocked(listMetaTemplates).mockResolvedValueOnce([]);
    const r = await syncTemplatesFromMeta();
    expect(r.removed).toBeGreaterThanOrEqual(1);
    const after = await prisma.messageTemplate.findUnique({ where: { id: orphan.id } });
    expect(after).toBeNull();
  });

  it("IDEMPOTENT: rodar 2x sem mudança → 0/0/0", async () => {
    const name = `synctest_idem_${Date.now()}`;
    vi.mocked(listMetaTemplates).mockResolvedValue([
      {
        name,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [{ type: "BODY", text: "estável" }],
      },
    ]);
    await syncTemplatesFromMeta();
    const row = await prisma.messageTemplate.findFirst({ where: { metaName: name } });
    createdIds.push(row!.id);
    const r = await syncTemplatesFromMeta();
    expect(r.added).toBe(0);
    expect(r.updated).toBe(0);
    expect(r.removed).toBe(0);
  });
});
