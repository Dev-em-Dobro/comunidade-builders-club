/** URL da aba Consultas do agente, só com os parâmetros preenchidos. */
export function appointmentsHref(agentId: string, params: Record<string, string | null | undefined>): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v) q.set(k, v);
  const s = q.toString();
  const base = `/settings/agents/${agentId}/appointments`;
  return s ? `${base}?${s}` : base;
}
