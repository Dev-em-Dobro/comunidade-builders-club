"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import type { Prisma } from "@prisma/client";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { isValidDate, zonedParts } from "@/lib/scheduling/time";
import { schedulingTimezone } from "@/lib/scheduling/timezone";
import { parseDayIntervals, WEEKDAYS, type TimeInterval, type WorkingHours } from "@/lib/scheduling/working-hours";

export interface ProfessionalFormState {
  error?: string;
  /** Muda a cada gravação bem-sucedida (o form limpa a seleção). */
  savedAt?: number;
}

async function ensureAdmin(): Promise<string | null> {
  const session = await auth();
  return session?.user?.role === "admin" ? null : "Sem permissão. Apenas admins podem gerenciar profissionais.";
}

const base = (agentId: string) => `/settings/agents/${agentId}/professionals`;

/** O agente existe e é de agendamento? */
async function isSchedulingAgent(agentId: string): Promise<boolean> {
  const n = await prisma.agentSession.count({ where: { id: agentId, role: "scheduling" } });
  return n > 0;
}

/** O profissional pertence a este agente? */
async function ownsProfessional(agentId: string, professionalId: string): Promise<boolean> {
  const n = await prisma.professional.count({ where: { id: professionalId, agentSessionId: agentId } });
  return n > 0;
}

export async function saveProfessional(agentId: string, form: FormData): Promise<ProfessionalFormState> {
  const denied = await ensureAdmin();
  if (denied) return { error: denied };
  if (!(await isSchedulingAgent(agentId))) return { error: "Agente de agendamento não encontrado." };

  const id = (form.get("id") as string | null) || null;
  const name = String(form.get("name") ?? "").trim();
  const specialty = String(form.get("specialty") ?? "").trim() || null;
  const description = String(form.get("description") ?? "").trim() || null;
  const durationMin = Number(form.get("durationMin") ?? 30);
  const active = form.get("active") === "on";

  if (!name) return { error: "Nome obrigatório" };
  if (name.length > 120) return { error: "Nome muito longo" };
  if (description && description.length > 1000) return { error: "Descrição muito longa (máx. 1000 caracteres)" };
  if (!Number.isInteger(durationMin) || durationMin < 5 || durationMin > 480) {
    return { error: "Duração da consulta deve ficar entre 5 e 480 minutos" };
  }

  const workingHours: WorkingHours = {};
  for (const { day, label } of WEEKDAYS) {
    try {
      const intervals = parseDayIntervals(String(form.get(`wh_${day}`) ?? ""));
      if (intervals.length) workingHours[String(day)] = intervals;
    } catch (err) {
      return { error: `${label}: ${(err as Error).message}` };
    }
  }

  const data = {
    name,
    specialty,
    description,
    durationMin,
    active,
    workingHours: workingHours as Prisma.InputJsonValue,
  };
  let createdId: string | null = null;
  try {
    if (id) {
      if (!(await ownsProfessional(agentId, id))) return { error: "Profissional não encontrado neste agente." };
      await prisma.professional.update({ where: { id }, data });
    } else {
      createdId = (
        await prisma.professional.create({ data: { ...data, agentSessionId: agentId }, select: { id: true } })
      ).id;
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
  revalidatePath(base(agentId));
  // Profissional novo cai na edição, onde ficam as exceções (folgas, feriados).
  redirect(createdId ? `${base(agentId)}/${createdId}` : base(agentId));
}

/** "2026-12-25" válido e não no passado (fuso do negócio). */
function overrideDateError(date: string): string | null {
  if (!isValidDate(date)) return "Escolha uma data válida.";
  if (date < zonedParts(new Date(), schedulingTimezone()).date) return "Não dá para criar exceção em data passada.";
  return null;
}

/**
 * Cria/atualiza a exceção de um dia. mode=closed → não atende;
 * mode=custom → atende só nos intervalos informados (substitui a semana padrão).
 */
export async function saveDayOverride(
  agentId: string,
  professionalId: string,
  form: FormData,
): Promise<ProfessionalFormState> {
  const denied = await ensureAdmin();
  if (denied) return { error: denied };
  const dates = form
    .getAll("date")
    .map((d) => String(d).trim())
    .filter(Boolean);
  if (!dates.length) return { error: "Escolha pelo menos um dia no calendário." };
  if (dates.length > 62) return { error: "Selecione no máximo 62 dias por vez." };
  for (const d of dates) {
    const err = overrideDateError(d);
    if (err) return { error: `${d.split("-").reverse().join("/")}: ${err}` };
  }
  const mode = String(form.get("mode") ?? "closed");
  const note = String(form.get("note") ?? "").trim().slice(0, 120) || null;
  let intervals: TimeInterval[] = [];
  if (mode === "custom") {
    try {
      intervals = parseDayIntervals(String(form.get("intervals") ?? ""));
    } catch (err) {
      return { error: (err as Error).message };
    }
    if (!intervals.length) return { error: "Informe o horário de atendimento desse dia (ex.: 09:00-12:00)." };
  }
  if (!(await ownsProfessional(agentId, professionalId))) return { error: "Profissional não encontrado neste agente." };

  const json = intervals as unknown as Prisma.InputJsonValue;
  await prisma.$transaction(
    dates.map((date) =>
      prisma.professionalDayOverride.upsert({
        where: { professionalId_date: { professionalId, date } },
        create: { professionalId, date, intervals: json, note },
        update: { intervals: json, note },
      }),
    ),
  );
  revalidatePath(`${base(agentId)}/${professionalId}`);
  return { savedAt: Date.now() };
}

export async function deleteDayOverride(agentId: string, professionalId: string, overrideId: string): Promise<void> {
  const denied = await ensureAdmin();
  if (denied) throw new Error(denied);
  await prisma.professionalDayOverride.deleteMany({
    where: { id: overrideId, professionalId, professional: { agentSessionId: agentId } },
  });
  revalidatePath(`${base(agentId)}/${professionalId}`);
}

export async function deleteProfessional(agentId: string, id: string): Promise<void> {
  const denied = await ensureAdmin();
  if (denied) throw new Error(denied);
  // Consultas mantêm o histórico (professionalId vira null; o nome fica no snapshot).
  await prisma.professional.deleteMany({ where: { id, agentSessionId: agentId } });
  revalidatePath(base(agentId));
  redirect(base(agentId));
}
