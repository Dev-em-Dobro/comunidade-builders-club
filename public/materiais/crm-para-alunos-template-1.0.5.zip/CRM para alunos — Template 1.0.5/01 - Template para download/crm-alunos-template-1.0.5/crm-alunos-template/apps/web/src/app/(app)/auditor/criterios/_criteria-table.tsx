"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Pause, Play, Pencil, Plus } from "lucide-react";
import { CriterionForm } from "./_criterion-form";
import { toggleCriterionActive } from "./actions";

interface Criterion {
  id: string;
  name: string;
  description: string;
  exampleFail: string | null;
  weight: number;
  active: boolean;
}

export function CriteriaTable({ criteria }: { criteria: Criterion[] }) {
  const [editing, setEditing] = useState<Criterion | "new" | null>(null);
  const [pendingId, setPendingId] = useState<string | null>(null);
  const [, startTransition] = useTransition();

  const initialForForm =
    editing === "new"
      ? undefined
      : editing
        ? {
            id: editing.id,
            name: editing.name,
            description: editing.description,
            exampleFail: editing.exampleFail,
            weight: editing.weight,
            active: editing.active,
          }
        : undefined;

  function handleToggle(c: Criterion) {
    setPendingId(c.id);
    startTransition(async () => {
      const res = await toggleCriterionActive(c.id);
      setPendingId(null);
      if (!res.ok) {
        toast.error(res.error ?? "Falha ao alternar critério");
      }
    });
  }

  return (
    <>
      <div className="flex justify-end">
        <Button onClick={() => setEditing("new")} aria-label="Novo critério">
          <Plus className="size-4" /> Novo critério
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12"></TableHead>
            <TableHead>Nome</TableHead>
            <TableHead className="text-right w-20">Peso</TableHead>
            <TableHead className="w-32 text-right">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {criteria.length === 0 && (
            <TableRow>
              <TableCell colSpan={4} className="text-center text-muted-foreground">
                Nenhum critério cadastrado. Crie o primeiro com &quot;Novo critério&quot;.
              </TableCell>
            </TableRow>
          )}
          {criteria.map((c) => (
            <TableRow key={c.id} className={c.active ? "" : "opacity-60"}>
              <TableCell aria-label={c.active ? "Ativo" : "Pausado"}>
                {c.active ? "✅" : "⏸️"}
              </TableCell>
              <TableCell>
                <div className="font-medium">{c.name}</div>
                <div className="text-xs text-muted-foreground line-clamp-1">
                  {c.description}
                </div>
              </TableCell>
              <TableCell className="text-right">{c.weight}</TableCell>
              <TableCell className="text-right">
                <div className="flex gap-1 justify-end">
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    onClick={() => setEditing(c)}
                    aria-label={`Editar critério ${c.name}`}
                  >
                    <Pencil className="size-4" />
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="ghost"
                    disabled={pendingId === c.id}
                    onClick={() => handleToggle(c)}
                    aria-label={`${c.active ? "Pausar" : "Ativar"} critério ${c.name}`}
                  >
                    {c.active ? <Pause className="size-4" /> : <Play className="size-4" />}
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={editing !== null} onOpenChange={(open) => !open && setEditing(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>
              {editing === "new" ? "Novo critério" : "Editar critério"}
            </DialogTitle>
          </DialogHeader>
          <CriterionForm
            key={editing === "new" ? "new" : editing?.id ?? "closed"}
            initial={initialForForm}
            onSaved={() => setEditing(null)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
}
