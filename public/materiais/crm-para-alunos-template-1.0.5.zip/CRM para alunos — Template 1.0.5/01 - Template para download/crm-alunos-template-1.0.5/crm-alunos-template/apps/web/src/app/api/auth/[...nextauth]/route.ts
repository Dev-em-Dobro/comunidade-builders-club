/**
 * Auth.js v5 catch-all route — expõe /api/auth/signin, /api/auth/signout,
 * /api/auth/callback/credentials, /api/auth/session, /api/auth/csrf.
 *
 * O config real (providers, callbacks, session strategy) vive em @/auth.
 */

import { handlers } from "@/auth";

export const { GET, POST } = handlers;
