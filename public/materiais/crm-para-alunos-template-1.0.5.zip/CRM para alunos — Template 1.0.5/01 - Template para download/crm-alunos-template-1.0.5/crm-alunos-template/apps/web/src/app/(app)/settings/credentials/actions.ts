"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { encryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";

export interface CredentialFormState {
  ok?: boolean;
  error?: string;
  message?: string;
}

const KNOWN_PROVIDERS = ["anthropic", "openai"];

export async function saveCredential(formData: FormData): Promise<CredentialFormState> {
  const session = await auth();
  if (session?.user?.role !== "admin") {
    return { error: "Sessão expirada. Faça login novamente." };
  }
  if (!secretsKeyConfigured()) {
    return { error: "SECRETS_KEY não configurada no servidor — não é possível salvar chaves com segurança." };
  }

  const provider = String(formData.get("provider") ?? "").trim();
  const apiKey = String(formData.get("apiKey") ?? "").trim();

  if (!KNOWN_PROVIDERS.includes(provider)) {
    return { error: "Provider inválido." };
  }
  if (!apiKey) {
    return { error: "Cole uma chave de API." };
  }

  try {
    const apiKeyEnc = encryptSecret(apiKey);
    const hint = apiKey.slice(-4);
    await prisma.providerCredential.upsert({
      where: { provider },
      update: { apiKeyEnc, hint },
      create: { provider, apiKeyEnc, hint },
    });
    revalidatePath("/settings/credentials");
    return { ok: true, message: "Chave salva." };
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
}
