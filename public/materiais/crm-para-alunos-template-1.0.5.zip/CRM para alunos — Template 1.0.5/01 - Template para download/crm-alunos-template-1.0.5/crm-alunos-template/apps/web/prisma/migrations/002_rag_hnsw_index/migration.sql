-- Índice HNSW pra busca vetorial por cosine distance no RAG.
-- OPCIONAL no MVP: o retrieval funciona sem ele (seq scan). Recomendado quando
-- a base passar de algumas centenas de chunks — aí o seq scan fica lento.
CREATE INDEX IF NOT EXISTS "RagChunk_embedding_hnsw"
  ON "RagChunk" USING hnsw (embedding vector_cosine_ops);
