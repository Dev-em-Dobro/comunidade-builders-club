import { getQueue } from "@/lib/queue";
import type { WindowWarningJobData } from "@/lib/queue/types";

const JOB_NAME = "fire";
const WARN_MS_BEFORE_CLOSE = 60 * 60_000; // 1h antes do fechamento

/** jobId determinístico: 1 job pendente por conversa, idempotente. */
function jobIdFor(convId: string): string {
  return `window-warning__${convId}`;
}

/**
 * Agenda o alerta proativo de 1h pra fechamento da janela 24h.
 * Chamado pelo `flush.ts` quando inbound chega (reset a cada inbound).
 *
 * Se faltar menos de 1h pro fechamento, o alerta perdeu sentido — não agenda.
 * Caso contrário, remove o job anterior (mesmo jobId) e enfileira novo com
 * `delay = closesAt - 60min - now`.
 */
export async function scheduleWindowWarning(
  conversationId: string,
  windowClosesAt: Date,
): Promise<void> {
  const now = Date.now();
  const fireAt = windowClosesAt.getTime() - WARN_MS_BEFORE_CLOSE;
  const delay = fireAt - now;
  if (delay <= 0) return; // janela já está em <1h ou passou

  const queue = getQueue("window-warning");
  const id = jobIdFor(conversationId);
  await queue.remove(id).catch(() => {});
  const data: WindowWarningJobData = { conversationId };
  await queue.add(JOB_NAME, data, {
    jobId: id,
    delay,
    removeOnComplete: true,
    removeOnFail: 50,
  });
}

/** Cancela o alerta pendente — usado se a conversa for arquivada. */
export async function cancelWindowWarning(conversationId: string): Promise<void> {
  const queue = getQueue("window-warning");
  await queue.remove(jobIdFor(conversationId)).catch(() => {});
}
