import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { messageMediaUrl } from "@/lib/conversations/message-media-url";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TAKE = 50;

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { id: conversationId } = await params;
  const url = new URL(req.url);
  const since = url.searchParams.get("since");

  // Resolve cutoff por id (preciso, idempotente entre clientes em diferentes
  // horários de relógio).
  let after: Date | null = null;
  if (since) {
    const sinceMsg = await prisma.message.findUnique({
      where: { id: since },
      select: { createdAt: true, conversationId: true },
    });
    if (sinceMsg && sinceMsg.conversationId === conversationId) {
      after = sinceMsg.createdAt;
    }
  }

  const messages = await prisma.message.findMany({
    where: {
      conversationId,
      ...(after ? { createdAt: { gt: after } } : {}),
    },
    include: { sentBy: { select: { id: true, name: true } } },
    orderBy: { createdAt: "asc" },
    take: TAKE,
  });

  return NextResponse.json({
    messages: messages.map((message) => ({
      id: message.id,
      direction: message.direction,
      role: message.role,
      text: message.text,
      mediaType: message.mediaType,
      mediaUrl: messageMediaUrl(message),
      modelUsed: message.modelUsed,
      sentByUserId: message.sentByUserId,
      sentBy: message.sentBy,
      createdAt: message.createdAt,
      templateMetaName: message.templateMetaName,
    })),
  });
}
