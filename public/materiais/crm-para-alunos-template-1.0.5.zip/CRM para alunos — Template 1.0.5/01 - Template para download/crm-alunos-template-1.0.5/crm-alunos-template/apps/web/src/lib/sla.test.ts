import { describe, it, expect, afterAll } from "vitest";
import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { scheduleSlaCheck, cancelSlaCheck } from "./sla";
import { slaProcessor } from "./queue/workers/sla";
import { getQueue, closeAllQueues } from "./queue";
import { closeQueueConnection } from "./queue/connection";

const contactIds: string[] = [];

async function makeConversation() {
  const contact = await prisma.contact.create({
    data: { displayName: "SLA test" },
  });
  contactIds.push(contact.id);
  const lead = await prisma.lead.create({ data: { contactId: contact.id } });
  const conv = await prisma.conversation.create({
    data: {
      contactId: contact.id,
      channel: "whatsapp_cloud",
      leadId: lead.id,
    },
  });
  return { contact, lead, conv };
}

/** Job BullMQ falso — slaProcessor só usa `id` e `data`. */
function fakeJob(id: string, conversationId: string): Job {
  return { id, data: { conversationId } } as unknown as Job;
}

afterAll(async () => {
  await getQueue("sla").obliterate({ force: true }).catch(() => {});
  await getQueue("notify").obliterate({ force: true }).catch(() => {});
  await closeAllQueues();
  closeQueueConnection();
  await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
  await prisma.$disconnect();
});

describe("scheduleSlaCheck / cancelSlaCheck", () => {
  it("scheduleSlaCheck salva o slaJobId na conversa", async () => {
    const { conv } = await makeConversation();
    await scheduleSlaCheck(conv.id);

    const updated = await prisma.conversation.findUnique({
      where: { id: conv.id },
    });
    expect(updated!.slaJobId).toBeTruthy();
  });

  it("cancelSlaCheck limpa o slaJobId e (markResponded) seta firstResponseAt", async () => {
    const { conv, lead } = await makeConversation();
    await scheduleSlaCheck(conv.id);
    await cancelSlaCheck(conv.id, { markResponded: true });

    const updatedConv = await prisma.conversation.findUnique({
      where: { id: conv.id },
    });
    expect(updatedConv!.slaJobId).toBeNull();

    const updatedLead = await prisma.lead.findUnique({ where: { id: lead.id } });
    expect(updatedLead!.firstResponseAt).not.toBeNull();
  });
});

describe("slaProcessor", () => {
  it("marca breach quando a conversa não foi respondida no prazo", async () => {
    const { conv, lead } = await makeConversation();
    const jobId = "sla-job-test-breach";
    await prisma.conversation.update({
      where: { id: conv.id },
      data: { slaJobId: jobId },
    });

    await slaProcessor(fakeJob(jobId, conv.id));

    const updatedLead = await prisma.lead.findUnique({ where: { id: lead.id } });
    expect(updatedLead!.slaBreachedAt).not.toBeNull();

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id, type: "sla_breach" },
    });
    expect(events).toHaveLength(1);
  });

  it("não marca breach quando a verificação já foi resolvida (slaJobId nulo)", async () => {
    const { conv, lead } = await makeConversation();
    // slaJobId fica nulo — simula resposta enviada a tempo.
    await slaProcessor(fakeJob("stale-job", conv.id));

    const updatedLead = await prisma.lead.findUnique({ where: { id: lead.id } });
    expect(updatedLead!.slaBreachedAt).toBeNull();
  });
});
