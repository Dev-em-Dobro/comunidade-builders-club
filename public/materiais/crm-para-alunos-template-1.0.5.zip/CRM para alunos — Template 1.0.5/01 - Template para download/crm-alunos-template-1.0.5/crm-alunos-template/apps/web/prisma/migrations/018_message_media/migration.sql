ALTER TABLE "Message" ADD COLUMN "mediaType" TEXT;
ALTER TABLE "Message" ADD COLUMN "mediaId" TEXT;
ALTER TABLE "Message" ADD COLUMN "mediaMimeType" TEXT;

-- Instagram já guardava URLs de anexos. Recupera o tipo quando o texto é o
-- marcador gerado pelo parser antigo; IDs antigos do WhatsApp não foram salvos.
UPDATE "Message"
SET "mediaType" = CASE "text"
    WHEN '[image]' THEN 'image'
    WHEN '[audio]' THEN 'audio'
END
WHERE "mediaUrl" IS NOT NULL AND "text" IN ('[image]', '[audio]');
