import type { PrismaClient } from "@prisma/client";
import { Prisma } from "@prisma/client";
import type { PurchaseData } from "./parser";

export type ApplyResult =
  | { ok: true; status: "applied" | "already_won" }
  | { ok: false; reason: "lead_not_found" };

/**
 * Aplica uma compra confirmada a um Lead. Idempotente por *estado*: se já
 * é 'won' não muda stage/wonAt, só registra o PipelineEvent('purchase').
 *
 * A leitura de `lead.stage` e o write rodam dentro da mesma transação
 * pra evitar TOCTOU — sem isso, outra rota (qualification worker, etc)
 * poderia mudar o stage entre o read e a decisão.
 *
 * Dedup de reentrega do mesmo invoice é responsabilidade do dedup em
 * WebhookEvent (unique constraint), não daqui.
 */
export async function applyPurchase(
  prisma: PrismaClient | Prisma.TransactionClient,
  leadId: string,
  data: PurchaseData,
): Promise<ApplyResult> {
  const purchasePayload = {
    invoiceId: data.invoiceId,
    productId: data.productId,
    offerId: data.offerId,
    totalCents: data.totalCents,
    currency: data.currency,
    paymentMethod: data.paymentMethod,
    installments: data.installments,
    saleDate: data.saleDate.toISOString(),
    via: "hubla_webhook" as const,
  };

  const run = async (tx: Prisma.TransactionClient): Promise<ApplyResult> => {
    const lead = await tx.lead.findUnique({
      where: { id: leadId },
      select: { id: true, stage: true },
    });
    if (!lead) return { ok: false, reason: "lead_not_found" };

    if (lead.stage === "won") {
      await tx.pipelineEvent.create({
        data: { leadId, type: "purchase", payload: purchasePayload },
      });
      return { ok: true, status: "already_won" };
    }

    const updateData: Prisma.LeadUpdateInput = {
      stage: "won",
      wonAt: data.saleDate,
    };
    if (lead.stage === "lost") {
      updateData.lostAt = null;
      updateData.lostReason = null;
    }
    await tx.lead.update({ where: { id: leadId }, data: updateData });

    await tx.pipelineEvent.create({
      data: {
        leadId,
        type: "stage_change",
        payload: { from: lead.stage, to: "won", via: "hubla_webhook" },
      },
    });
    await tx.pipelineEvent.create({
      data: { leadId, type: "purchase", payload: purchasePayload },
    });
    return { ok: true, status: "applied" };
  };

  // Aceita PrismaClient ou Prisma.TransactionClient (padrão de getCheckoutLink).
  if ("$transaction" in prisma) {
    return (prisma as PrismaClient).$transaction(run);
  }
  return run(prisma as Prisma.TransactionClient);
}
