import { Resend } from "resend";

export interface EmailParams {
  to: string[];
  subject: string;
  text: string;
}

/**
 * Wrapper do Resend.
 *
 * No-op (só loga) se `RESEND_API_KEY` não estiver setada — dev/local não quebra
 * por falta de credencial de email. Em produção, setar a key + `RESEND_FROM`.
 */
export async function sendEmail(params: EmailParams): Promise<void> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    console.log(
      JSON.stringify({
        event: "email.skipped_no_key",
        to: params.to,
        subject: params.subject,
        at: new Date().toISOString(),
      }),
    );
    return;
  }
  if (!params.to.length) return;

  const from = process.env.RESEND_FROM ?? "CRM Template <onboarding@resend.dev>";
  const resend = new Resend(apiKey);
  const { error } = await resend.emails.send({
    from,
    to: params.to,
    subject: params.subject,
    text: params.text,
  });
  if (error) {
    throw new Error(`Resend: ${error.message}`);
  }
}
