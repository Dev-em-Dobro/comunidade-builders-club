import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { syncTemplatesFromMeta } from "@/lib/templates/sync";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  try {
    const result = await syncTemplatesFromMeta();
    return NextResponse.json(result);
  } catch (err) {
    const msg = (err as Error)?.message ?? "sync failed";
    console.error(
      JSON.stringify({
        event: "templates.sync_failed",
        error: msg,
        at: new Date().toISOString(),
      }),
    );
    return NextResponse.json(
      { error: `Falha ao sincronizar com a Meta: ${msg}` },
      { status: 502 },
    );
  }
}
