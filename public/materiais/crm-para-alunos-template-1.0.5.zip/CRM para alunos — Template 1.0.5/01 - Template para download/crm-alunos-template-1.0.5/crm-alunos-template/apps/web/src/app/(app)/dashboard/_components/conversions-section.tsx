import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { bucketConversionsByDay, conversionRate } from "../metrics";
import { ConversionsChart } from "./charts";

const DAY_MS = 24 * 60 * 60 * 1000;

interface ConversionsData {
  won: Date[];
  lost: Date[];
  error: boolean;
}

async function getConversions(rangeDays: number): Promise<ConversionsData> {
  try {
    const since = new Date(Date.now() - rangeDays * DAY_MS);
    const [wonRows, lostRows] = await Promise.all([
      prisma.lead.findMany({
        where: { wonAt: { gte: since } },
        select: { wonAt: true },
      }),
      prisma.lead.findMany({
        where: { lostAt: { gte: since } },
        select: { lostAt: true },
      }),
    ]);
    return {
      won: wonRows
        .map((r) => r.wonAt)
        .filter((d): d is Date => d !== null),
      lost: lostRows
        .map((r) => r.lostAt)
        .filter((d): d is Date => d !== null),
      error: false,
    };
  } catch {
    return { won: [], lost: [], error: true };
  }
}

export async function ConversionsSection({
  rangeDays,
}: {
  rangeDays: number;
}) {
  const { won, lost, error } = await getConversions(rangeDays);
  const buckets = bucketConversionsByDay(won, lost, rangeDays, new Date());
  const rate = conversionRate(won.length, lost.length);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Conversões</CardTitle>
        <CardDescription>
          {error ? (
            "Ganhos e perdas por dia"
          ) : (
            <>
              {won.length} ganho{won.length !== 1 ? "s" : ""} · {lost.length}{" "}
              perdido{lost.length !== 1 ? "s" : ""} · taxa{" "}
              {rate === null ? "—" : `${rate.toFixed(0)}%`}
            </>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : (
          <ConversionsChart buckets={buckets} />
        )}
      </CardContent>
    </Card>
  );
}
