import { describe, it, expect } from "vitest";
import { windowBadgeStatus, type WindowBadgeInput } from "./window-status";

const NOW = new Date("2026-06-15T12:00:00.000Z");

/** Conversa reivindicada com janela ainda aberta (fecha em 2h) por padrão. */
function conv(over: Partial<WindowBadgeInput> = {}): WindowBadgeInput {
  return {
    windowClosingSoon: true,
    windowExpired: false,
    windowClosesAt: new Date("2026-06-15T14:00:00.000Z"),
    ...over,
  };
}

describe("windowBadgeStatus", () => {
  it("closing: reivindicada e janela ainda no futuro", () => {
    expect(windowBadgeStatus(conv(), NOW)).toBe("closing");
  });

  it("closed: reivindicada mas windowClosesAt já passou (o bug)", () => {
    expect(
      windowBadgeStatus(
        conv({ windowClosesAt: new Date("2026-06-15T10:00:00.000Z") }),
        NOW,
      ),
    ).toBe("closed");
  });

  it("closed: windowExpired true mesmo sem claim", () => {
    expect(
      windowBadgeStatus(
        conv({ windowClosingSoon: false, windowExpired: true }),
        NOW,
      ),
    ).toBe("closed");
  });

  it("null: janela fechada mas nunca reivindicada nem expirada (conversa antiga)", () => {
    expect(
      windowBadgeStatus(
        conv({
          windowClosingSoon: false,
          windowClosesAt: new Date("2026-06-14T10:00:00.000Z"),
        }),
        NOW,
      ),
    ).toBeNull();
  });

  it("null: janela aberta e não reivindicada", () => {
    expect(windowBadgeStatus(conv({ windowClosingSoon: false }), NOW)).toBeNull();
  });

  it("null: conversa sem janela (windowClosesAt null, sem claim)", () => {
    expect(
      windowBadgeStatus(
        conv({ windowClosingSoon: false, windowClosesAt: null }),
        NOW,
      ),
    ).toBeNull();
  });

  it("closing tratado como aberto na borda exata (now === windowClosesAt vira closed)", () => {
    expect(windowBadgeStatus(conv({ windowClosesAt: NOW }), NOW)).toBe("closed");
  });
});
