/**
 * Embeddings via Gemini (gemini-embedding-001).
 *
 * A Anthropic não tem API de embeddings — o RAG usa o Gemini. Saída truncada
 * a 768 dims (MRL) pra bater com a coluna `vector(768)` do schema, sem migration.
 * Chave grátis em https://aistudio.google.com/apikey → GEMINI_API_KEY.
 */

const MODEL = "gemini-embedding-001";
const DIMS = 768;
const API_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
// batchEmbedContents aceita até 100 requests por chamada.
const BATCH_LIMIT = 100;

export const EMBEDDING_MODEL = MODEL;
export const EMBEDDING_DIMS = DIMS;

export type EmbedTaskType = "RETRIEVAL_DOCUMENT" | "RETRIEVAL_QUERY";

function getApiKey(): string {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error(
      "GEMINI_API_KEY ausente — necessária pro RAG. Gerar em https://aistudio.google.com/apikey",
    );
  }
  return key;
}

/** L2-normaliza — gemini-embedding-001 não normaliza quando outputDimensionality < 3072. */
function normalize(v: number[]): number[] {
  let sum = 0;
  for (const x of v) sum += x * x;
  const norm = Math.sqrt(sum);
  if (norm === 0) return v;
  return v.map((x) => x / norm);
}

/** Embeda um único texto. taskType QUERY pra busca, DOCUMENT pra indexação. */
export async function embedText(
  text: string,
  taskType: EmbedTaskType,
): Promise<number[]> {
  const [vec] = await embedBatch([text], taskType);
  if (!vec) throw new Error("Gemini embeddings: vetor vazio");
  return vec;
}

/** Embeda vários textos. Quebra automaticamente em lotes de BATCH_LIMIT. */
export async function embedBatch(
  texts: string[],
  taskType: EmbedTaskType,
): Promise<number[][]> {
  if (!texts.length) return [];
  const key = getApiKey();
  const out: number[][] = [];

  for (let i = 0; i < texts.length; i += BATCH_LIMIT) {
    const slice = texts.slice(i, i + BATCH_LIMIT);
    const res = await fetch(`${API_BASE}/${MODEL}:batchEmbedContents`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        requests: slice.map((text) => ({
          model: `models/${MODEL}`,
          content: { parts: [{ text }] },
          taskType,
          outputDimensionality: DIMS,
        })),
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(
        `Gemini embeddings falhou (${res.status}): ${body.slice(0, 300)}`,
      );
    }

    const json = (await res.json()) as { embeddings?: { values: number[] }[] };
    if (!json.embeddings || json.embeddings.length !== slice.length) {
      throw new Error(
        "Gemini embeddings: resposta com contagem inesperada de vetores",
      );
    }
    for (const e of json.embeddings) out.push(normalize(e.values));
  }

  return out;
}

/** Formata um vetor pro literal textual do pgvector: '[0.1,0.2,...]'. */
export function toVectorLiteral(vec: number[]): string {
  return `[${vec.join(",")}]`;
}
