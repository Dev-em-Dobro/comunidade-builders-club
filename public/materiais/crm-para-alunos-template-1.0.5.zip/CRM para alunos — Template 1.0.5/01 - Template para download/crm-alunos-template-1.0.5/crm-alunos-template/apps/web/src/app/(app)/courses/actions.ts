"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import { auth } from "@/auth";

export interface CourseFormState {
  ok?: boolean;
  error?: string;
}

/**
 * Gate de autorização das mutações de curso. Server actions são POST e NÃO são
 * barradas pelo redirect otimista do proxy.ts — sem esta checagem, qualquer
 * usuário autenticado (inclusive role operator) criava/editava/apagava cursos.
 * Mesmo padrão do ensureAdmin() de launches/actions.ts (defense-in-depth por
 * função, não confiar só no middleware).
 */
async function ensureAdmin(): Promise<{ ok: true } | { ok: false; error: string }> {
  const session = await auth();
  const role = (session?.user as { role?: string } | undefined)?.role;
  if (role !== "admin") {
    return { ok: false, error: "Sem permissão. Apenas admins podem gerenciar cursos." };
  }
  return { ok: true };
}

const SLUG_RE = /^[a-z0-9-]+$/;

/** Cria ou atualiza um Curso. Preço entra em reais e é guardado em centavos. */
export async function saveCourse(formData: FormData): Promise<CourseFormState> {
  const gate = await ensureAdmin();
  if (!gate.ok) return { error: gate.error };
  const id = formData.get("id") as string | null;
  const name = String(formData.get("name") ?? "").trim();
  const slug = String(formData.get("slug") ?? "").trim().toLowerCase();
  const priceReais = Number(formData.get("price") ?? NaN);
  const active = formData.get("active") === "on";
  const checkoutUrlRaw = String(formData.get("checkoutUrl") ?? "").trim();
  const descriptionRaw = String(formData.get("description") ?? "").trim();
  const guaranteeRaw = String(formData.get("guaranteePolicy") ?? "").trim();
  const paymentRaw = String(formData.get("paymentMethods") ?? "").trim();

  if (!name) return { error: "Nome obrigatório" };
  if (!SLUG_RE.test(slug)) {
    return { error: "Slug inválido — só letras minúsculas, números e hífen" };
  }
  if (!Number.isFinite(priceReais) || priceReais < 0) {
    return { error: "Preço inválido" };
  }
  let checkoutUrl: string | null = null;
  if (checkoutUrlRaw.length > 0) {
    try {
      const u = new URL(checkoutUrlRaw);
      if (u.protocol !== "http:" && u.protocol !== "https:") {
        return { error: "Checkout URL inválido — use http(s)" };
      }
      checkoutUrl = checkoutUrlRaw;
    } catch {
      return { error: "Checkout URL inválido" };
    }
  }
  if (descriptionRaw.length > 5000) {
    return { error: "Descrição muito longa (máximo 5000 caracteres)" };
  }
  if (guaranteeRaw.length > 500) {
    return { error: "Política de garantia muito longa (máximo 500 caracteres)" };
  }
  if (paymentRaw.length > 500) {
    return { error: "Formas de pagamento muito longas (máximo 500 caracteres)" };
  }
  const description = descriptionRaw.length > 0 ? descriptionRaw : null;
  const guaranteePolicy = guaranteeRaw.length > 0 ? guaranteeRaw : null;
  const paymentMethods = paymentRaw.length > 0 ? paymentRaw : null;
  const priceCents = Math.round(priceReais * 100);

  // Guard de integridade: desativar um curso que tem lançamento live esvazia
  // o catálogo do bot (buildCatalogBlock retorna null em 0 cursos ativos) e
  // deixa a oferta órfã — o bot perde TODO o contexto de produto e passa a
  // alucinar preço/produtos (incidente 2026-05-29). Encerre o lançamento antes.
  if (id && !active) {
    const liveLaunch = await prisma.launch.findFirst({
      where: { courseId: id, status: "live" },
      select: { name: true },
    });
    if (liveLaunch) {
      return {
        error: `Não dá pra desativar: o lançamento "${liveLaunch.name}" está live nesse curso. Encerre o lançamento primeiro.`,
      };
    }
  }

  try {
    if (id) {
      await prisma.course.update({
        where: { id },
        data: {
          name,
          slug,
          priceCents,
          active,
          checkoutUrl,
          description,
          guaranteePolicy,
          paymentMethods,
        },
      });
    } else {
      await prisma.course.create({
        data: {
          name,
          slug,
          priceCents,
          active,
          checkoutUrl,
          description,
          guaranteePolicy,
          paymentMethods,
        },
      });
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }

  revalidatePath("/courses");
  redirect("/courses");
}

/** Remove um Curso. Bloqueia se houver lançamento live (mesma integridade do
 *  guard de desativação — deletar zera o courseId do launch e o deixa órfão). */
export async function deleteCourse(id: string): Promise<void> {
  const gate = await ensureAdmin();
  if (!gate.ok) {
    redirect("/courses");
  }
  const liveLaunch = await prisma.launch.findFirst({
    where: { courseId: id, status: "live" },
    select: { id: true },
  });
  if (!liveLaunch) {
    await prisma.course.delete({ where: { id } }).catch(() => {});
  }
  revalidatePath("/courses");
  redirect("/courses");
}
