import { describe, it, expect, vi, beforeEach, afterEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/lib/llm", async () => {
  const actual = await vi.importActual<typeof import("@/lib/llm")>("@/lib/llm");
  return {
    ...actual,
    generateReply: vi.fn(),
  };
});

vi.mock("@/lib/channels/registry", () => ({
  getAdapter: vi.fn(() => ({
    sendText: vi.fn().mockResolvedValue(undefined),
  })),
}));

vi.mock("@/lib/realtime/notify", () => ({
  notifyMessage: vi.fn().mockResolvedValue(undefined),
}));

import { generateReply } from "@/lib/llm";
import { getAdapter } from "@/lib/channels/registry";
import { runAgentHandoff } from "./agent-handoff";

const createdIds = {
  agentSessionIds: [] as string[],
  conversationIds: [] as string[],
  leadIds: [] as string[],
  contactIds: [] as string[],
};

async function createFixture(opts?: {
  leadStage?: string;
  aiEnabled?: boolean;
  initialAgentSessionId?: string;
  withCloser?: boolean;
  closerPersona?: string | null;
  closerName?: string;
  withSupport?: boolean;
  supportPersona?: string | null;
}) {
  const leadStage = opts?.leadStage ?? "qualified";
  const aiEnabled = opts?.aiEnabled ?? true;
  const withCloser = opts?.withCloser ?? true;

  const sdr = await prisma.agentSession.create({
    data: {
      name: `SDR Test ${Date.now()}-${Math.random()}`,
      systemPrompt: "Você é o SDR.",
      role: "sdr",
      isDefault: false,
    },
  });
  createdIds.agentSessionIds.push(sdr.id);

  let closerId: string | null = null;
  if (withCloser) {
    const closer = await prisma.agentSession.create({
      data: {
        name: opts?.closerName ?? `Closer Test ${Date.now()}-${Math.random()}`,
        persona: opts?.closerPersona ?? null,
        systemPrompt: "Você é o closer.",
        role: "closer",
        isDefault: false,
      },
    });
    createdIds.agentSessionIds.push(closer.id);
    closerId = closer.id;
  }

  const withSupport = opts?.withSupport ?? false;
  let supportId: string | null = null;
  if (withSupport) {
    const support = await prisma.agentSession.create({
      data: {
        name: `Support Test ${Date.now()}-${Math.random()}`,
        persona: opts?.supportPersona ?? null,
        systemPrompt: "Você é o suporte.",
        role: "support",
        isDefault: false,
      },
    });
    createdIds.agentSessionIds.push(support.id);
    supportId = support.id;
  }

  const contact = await prisma.contact.create({
    data: { displayName: "AgentHandoff Test" },
  });
  createdIds.contactIds.push(contact.id);

  // ContactIdentity é a 1-por-canal — agente-handoff resolve externalId via ela.
  await prisma.contactIdentity.create({
    data: {
      contactId: contact.id,
      channel: "test",
      externalId: `ext-${Date.now()}-${Math.random()}`,
    },
  });

  const lead = await prisma.lead.create({
    data: { contactId: contact.id, stage: leadStage, score: 80 },
  });
  createdIds.leadIds.push(lead.id);

  const conv = await prisma.conversation.create({
    data: {
      channel: "test",
      contactId: contact.id,
      leadId: lead.id,
      agentSessionId: opts?.initialAgentSessionId ?? sdr.id,
      aiEnabled,
    },
  });
  createdIds.conversationIds.push(conv.id);

  await prisma.message.create({
    data: {
      conversationId: conv.id,
      direction: "inbound",
      role: "user",
      text: "quero comprar",
    },
  });

  return { sdr, closerId, supportId, contact, lead, conv };
}

function mockReply(text: string) {
  (generateReply as unknown as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
    text,
    modelUsed: "test",
    tokensIn: 10,
    tokensOut: 5,
    toolUses: [],
  });
}

// afterEach cleans up each test's data immediately so subsequent tests don't
// see leftover AgentSession rows (especially "closer" sessions) from prior tests.
// Without this, the global session query in runAgentHandoff would find closers
// created by earlier tests, breaking the "withCloser: false" skip assertion.
afterEach(async () => {
  if (createdIds.agentSessionIds.length === 0) return;
  await prisma.pipelineEvent.deleteMany({
    where: { leadId: { in: createdIds.leadIds } },
  });
  await prisma.message.deleteMany({
    where: { conversationId: { in: createdIds.conversationIds } },
  });
  await prisma.conversation.deleteMany({
    where: { id: { in: createdIds.conversationIds } },
  });
  await prisma.lead.deleteMany({ where: { id: { in: createdIds.leadIds } } });
  await prisma.contact.deleteMany({
    where: { id: { in: createdIds.contactIds } },
  });
  await prisma.agentSession.deleteMany({
    where: { id: { in: createdIds.agentSessionIds } },
  });
  // Reset tracking arrays so afterAll finds nothing to re-delete.
  createdIds.agentSessionIds.length = 0;
  createdIds.conversationIds.length = 0;
  createdIds.leadIds.length = 0;
  createdIds.contactIds.length = 0;
});

afterAll(async () => {
  // Safety net: clean up anything missed by afterEach (e.g., if a test threw
  // before afterEach ran — though vitest still calls afterEach on failure).
  if (createdIds.agentSessionIds.length > 0) {
    await prisma.pipelineEvent.deleteMany({
      where: { leadId: { in: createdIds.leadIds } },
    });
    await prisma.message.deleteMany({
      where: { conversationId: { in: createdIds.conversationIds } },
    });
    await prisma.conversation.deleteMany({
      where: { id: { in: createdIds.conversationIds } },
    });
    await prisma.lead.deleteMany({ where: { id: { in: createdIds.leadIds } } });
    // ContactIdentity tem FK em Contact com onDelete:Cascade — sai junto.
    await prisma.contact.deleteMany({
      where: { id: { in: createdIds.contactIds } },
    });
    await prisma.agentSession.deleteMany({
      where: { id: { in: createdIds.agentSessionIds } },
    });
  }
  await prisma.$disconnect();
});

describe("runAgentHandoff — happy path", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
  });

  it("envia despedida, flipa agentSessionId e cria PipelineEvent agent_handoff", async () => {
    const fx = await createFixture();
    mockReply("obrigada! vou te passar pro João que continua daqui.");

    await runAgentHandoff(fx.conv.id);

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.closerId);

    const msgs = await prisma.message.findMany({
      where: { conversationId: fx.conv.id, direction: "outbound" },
    });
    expect(msgs).toHaveLength(1);
    expect(msgs[0].text).toContain("obrigada");

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: fx.lead.id, type: "agent_handoff" },
    });
    expect(events).toHaveLength(1);
    expect(events[0].payload).toMatchObject({
      from: fx.sdr.id,
      to: fx.closerId,
      leadId: fx.lead.id,
      via: "auto_qualified",
    });
  });

  it("usa closer.persona na despedida quando setado (e não closer.name)", async () => {
    const fx = await createFixture({
      closerPersona: "Lucas",
      closerName: `Vendas Produto Exemplo ${Date.now()}-${Math.random()}`,
    });
    mockReply("vou te passar pro Lucas");

    await runAgentHandoff(fx.conv.id);

    const gen = generateReply as unknown as ReturnType<typeof vi.fn>;
    expect(gen).toHaveBeenCalledTimes(1);
    const callArg = gen.mock.calls[0][1];
    const lastUserMsg = callArg.messages[callArg.messages.length - 1];
    expect(lastUserMsg.role).toBe("user");
    expect(lastUserMsg.content).toContain("Lucas");
    expect(lastUserMsg.content).not.toContain("Vendas Produto Exemplo");

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: fx.lead.id, type: "agent_handoff" },
    });
    expect(events[0].payload).toMatchObject({ toPersona: "Lucas" });
  });

  it("cai no closer.name quando persona for null", async () => {
    const fx = await createFixture({
      closerPersona: null,
      closerName: `FallbackName-${Date.now()}-${Math.random()}`,
    });
    mockReply("ok");

    await runAgentHandoff(fx.conv.id);

    const gen = generateReply as unknown as ReturnType<typeof vi.fn>;
    const callArg = gen.mock.calls[0][1];
    const lastUserMsg = callArg.messages[callArg.messages.length - 1];
    expect(lastUserMsg.content).toContain("FallbackName-");
  });

  it("é idempotente: 2ª chamada não envia mensagem nem cria evento novo", async () => {
    const fx = await createFixture();
    mockReply("primeira despedida");
    await runAgentHandoff(fx.conv.id);

    // 2ª chamada — conv.agentSessionId já é o closer
    await runAgentHandoff(fx.conv.id);

    const msgs = await prisma.message.findMany({
      where: { conversationId: fx.conv.id, direction: "outbound" },
    });
    expect(msgs).toHaveLength(1);

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: fx.lead.id, type: "agent_handoff" },
    });
    expect(events).toHaveLength(1);
  });
});

describe("runAgentHandoff — skips", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
  });

  it("não faz nada se closer não está cadastrado", async () => {
    const fx = await createFixture({ withCloser: false });
    await runAgentHandoff(fx.conv.id);

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.sdr.id);

    const msgs = await prisma.message.findMany({
      where: { conversationId: fx.conv.id, direction: "outbound" },
    });
    expect(msgs).toHaveLength(0);

    expect(generateReply).not.toHaveBeenCalled();
  });

  it("não faz nada se aiEnabled=false", async () => {
    const fx = await createFixture({ aiEnabled: false });
    await runAgentHandoff(fx.conv.id);

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.sdr.id);
    expect(generateReply).not.toHaveBeenCalled();
  });

  it("não faz nada se lead não está em qualified", async () => {
    const fx = await createFixture({ leadStage: "new" });
    await runAgentHandoff(fx.conv.id);

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.sdr.id);
    expect(generateReply).not.toHaveBeenCalled();
  });
});

describe("runAgentHandoff — support role", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
  });

  it("flipa pro suporte mesmo com stage != qualified (aluno, não lead)", async () => {
    const fx = await createFixture({
      leadStage: "new",
      withCloser: false,
      withSupport: true,
      supportPersona: "Bia",
    });
    mockReply("Ah, entendi! Já te passo pra Bia do suporte.");

    await runAgentHandoff(fx.conv.id, "support");

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.supportId);

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: fx.lead.id, type: "agent_handoff" },
    });
    expect(events).toHaveLength(1);
    expect(events[0].payload).toMatchObject({
      to: fx.supportId,
      via: "student_triage",
      toPersona: "Bia",
    });

    const gen = generateReply as unknown as ReturnType<typeof vi.fn>;
    const callArg = gen.mock.calls[0][1];
    const lastUserMsg = callArg.messages[callArg.messages.length - 1];
    expect(lastUserMsg.content).toContain("Bia");
  });

  it("no-op se não há session de suporte cadastrada", async () => {
    const fx = await createFixture({
      leadStage: "new",
      withCloser: false,
      withSupport: false,
    });

    await runAgentHandoff(fx.conv.id, "support");

    const conv = await prisma.conversation.findUnique({
      where: { id: fx.conv.id },
      select: { agentSessionId: true },
    });
    expect(conv?.agentSessionId).toBe(fx.sdr.id);
    expect(generateReply).not.toHaveBeenCalled();
  });
});
