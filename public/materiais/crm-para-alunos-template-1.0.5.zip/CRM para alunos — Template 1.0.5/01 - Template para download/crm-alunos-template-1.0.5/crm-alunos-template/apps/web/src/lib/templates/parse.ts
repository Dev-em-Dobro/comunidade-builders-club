/**
 * Helpers puros pra extrair info de templates da Meta. Sem I/O — DB e
 * Meta API ficam noutros arquivos.
 */

export interface MetaComponent {
  type: string;
  text?: string;
  format?: string;
  buttons?: unknown[];
  parameters?: unknown[];
  [k: string]: unknown;
}

/**
 * Extrai o maior N em {{N}} do texto. Templates Meta usam essa notação
 * pra placeholders posicionais ({{1}} = primeira variável, etc).
 */
export function extractVariableCount(text: string): number {
  const matches = text.matchAll(/\{\{(\d+)\}\}/g);
  let max = 0;
  for (const m of matches) {
    const n = Number(m[1]);
    if (n > max) max = n;
  }
  return max;
}

/**
 * Acha o component type=BODY no array de components e retorna o `text`.
 * Null se não houver BODY (ex: template só com header de mídia).
 *
 * Assume: BODY de templates text-based sempre traz `text`. Se a Meta um dia
 * mandar BODY sem `text`, o null retornado fica indistinguível de "sem BODY"
 * — aceitável pro picker (variableCount=0, preview vazio).
 */
export function extractBodyText(components: MetaComponent[]): string | null {
  const body = components.find((c) => c.type?.toUpperCase() === "BODY");
  return body?.text ?? null;
}
