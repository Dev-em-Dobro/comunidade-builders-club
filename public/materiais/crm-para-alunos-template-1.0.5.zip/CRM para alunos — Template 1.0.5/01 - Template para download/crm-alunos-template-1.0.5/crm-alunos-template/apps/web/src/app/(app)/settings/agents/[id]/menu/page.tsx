import { auth } from "@/auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { formatAreasText, formatBRL, formatMenuLines, type MenuItem } from "@/lib/delivery/menu";
import { getStore } from "@/lib/delivery/service";
import { DELIVERY_ROLE } from "@/lib/delivery/agent";
import { ExternalLink } from "lucide-react";
import { AgentHeader, requireAgentOfRole } from "../_agent";
import { MenuItemsForm, MenuUploadForm, StoreSettingsForm } from "./menu-forms";

export const dynamic = "force-dynamic";

export default async function AgentMenuPage({ params }: { params: Promise<{ id: string }> }) {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const { id } = await params;
  const agent = await requireAgentOfRole(id, DELIVERY_ROLE);
  const store = await getStore(agent.id);

  const groups = new Map<string, MenuItem[]>();
  for (const item of store.menu) {
    const key = item.category ?? "Itens";
    groups.set(key, [...(groups.get(key) ?? []), item]);
  }
  const publicBase = process.env.PUBLIC_BASE_URL?.replace(/\/+$/, "");

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <AgentHeader
        agent={agent}
        active="menu"
        description="O que o agente sabe sobre o estabelecimento, onde entrega e o que vende."
      />
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Cardápio</CardTitle>
            <CardDescription>
              {store.menuFileName ? (
                <>
                  Atual: <strong>{store.menuFileName}</strong> · {store.menu.length} itens
                  {publicBase && store.menuToken && (
                    <>
                      {" · "}
                      <a
                        href={`${publicBase}/cardapio/${store.menuToken}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 underline"
                      >
                        ver como o cliente recebe <ExternalLink className="size-3" />
                      </a>
                    </>
                  )}
                </>
              ) : (
                "Nenhum cardápio ainda — sem ele o agente não consegue registrar pedidos."
              )}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <MenuUploadForm agentId={agent.id} hasMenu={Boolean(store.menuFileName)} />

            {store.menu.length > 0 && (
              <div className="space-y-4 border-t border-border pt-6">
                <p className="text-sm font-medium">O que a IA entendeu do cardápio</p>
                <div className="grid gap-4 md:grid-cols-2">
                  {[...groups.entries()].map(([category, items]) => (
                    <div key={category} className="space-y-1">
                      <p className="text-xs uppercase tracking-wide text-muted-foreground">{category}</p>
                      <ul className="divide-y divide-border rounded-md border border-border text-sm">
                        {items.map((i) => (
                          <li key={i.name} className="flex items-start justify-between gap-3 px-3 py-1.5">
                            <span className="min-w-0">
                              {i.name}
                              {i.description && <span className="block text-xs text-muted-foreground">{i.description}</span>}
                            </span>
                            <span className="whitespace-nowrap font-medium">{formatBRL(i.priceCents)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
                <details className="rounded-md border border-border p-3">
                  <summary className="cursor-pointer text-sm">Corrigir itens ou preços</summary>
                  <div className="mt-3">
                    <MenuItemsForm agentId={agent.id} initialText={formatMenuLines(store.menu)} />
                  </div>
                </details>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Estabelecimento e entrega</CardTitle>
            <CardDescription>Apresentação, horário, retirada e bairros atendidos com a taxa de cada um.</CardDescription>
          </CardHeader>
          <CardContent>
            <StoreSettingsForm
              agentId={agent.id}
              initial={{
                description: store.description ?? "",
                hours: store.hours ?? "",
                pickupEnabled: store.pickupEnabled,
                pickupAddress: store.pickupAddress ?? "",
                areasText: formatAreasText(store.areas),
              }}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
