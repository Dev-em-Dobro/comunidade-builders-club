/**
 * Orchestrator do auditor (Sub-Plan A). Chamado pelo worker `audit`.
 *
 * 1. Seleciona conversas (ou reusa as do report se já populadas).
 * 2. Carrega critérios ativos.
 * 3. Pra cada conversa: monta contexto → LLM call com tool forçada → persist findings.
 * 4. Summary agregado via 2ª LLM call.
 * 5. Atualiza report → status='done' (ou 'error' se tudo falhou).
 */
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { buildCatalogBlock, buildLeadContextBlock } from "@/lib/llm/context-blocks";
import { selectConversations } from "./select-conversations";
import { AuditOutputSchema, type ConversationAuditResult, type Verdict } from "./types";
import {
  AUDITOR_SYSTEM_PROMPT,
  RECORD_AUDIT_TOOL,
  formatCriteriaBlock,
  formatTranscript,
  type CriterionForPrompt,
} from "./prompts";
import { exceedsRunBudget } from "./budget";
import { auditorConfig } from "@/lib/config";

/** Modelo via env (sobrescrível); fallback Sonnet 4.6. */
const MODEL = process.env.AUDITOR_MODEL ?? "claude-sonnet-4-6";

const MAX_MESSAGES = 80;

/** Estimativa de custo por conversa (smoke real: ~$0.05). */
const COST_ESTIMATE_PER_CONV_USD = 0.05;

export async function runAudit(reportId: string): Promise<void> {
  log({ event: "audit.run.start", reportId });
  const existing = await prisma.auditReport.update({
    where: { id: reportId },
    data: { status: "running" },
    select: { conversationIds: true },
  });

  // 1. Conversas: reusa se report já trouxe (caso "reabrir"), senão seleciona.
  let candidates: Array<{
    conversationId: string;
    contactId: string;
    displayName: string | null;
    botTurnCount: number;
  }>;
  if (existing.conversationIds.length > 0) {
    const convs = await prisma.conversation.findMany({
      where: { id: { in: existing.conversationIds } },
      select: {
        id: true,
        contactId: true,
        contact: { select: { displayName: true } },
      },
    });
    candidates = convs.map((c) => ({
      conversationId: c.id,
      contactId: c.contactId,
      displayName: c.contact?.displayName ?? null,
      botTurnCount: 0,
    }));
  } else {
    candidates = await selectConversations(24, 5, 2);
    await prisma.auditReport.update({
      where: { id: reportId },
      data: { conversationIds: candidates.map((c) => c.conversationId) },
    });
  }

  if (candidates.length === 0) {
    await finishReport(reportId, {
      summary: "Nenhuma conversa elegível nas últimas 24h.",
      costUsd: 0,
    });
    log({ event: "audit.run.done", reportId, reason: "no_conversations" });
    return;
  }

  // 2. Critérios.
  const criteria = await prisma.auditCriterion.findMany({
    where: { active: true },
    orderBy: [{ weight: "desc" }, { createdAt: "asc" }],
  });

  if (criteria.length === 0) {
    await finishReport(reportId, {
      summary: "Nenhum critério ativo. Cadastre em /auditor/criterios.",
      costUsd: 0,
    });
    log({ event: "audit.run.done", reportId, reason: "no_criteria" });
    return;
  }

  const criteriaForPrompt: CriterionForPrompt[] = criteria.map((c) => ({
    id: c.id,
    name: c.name,
    description: c.description,
    exampleFail: c.exampleFail,
    weight: c.weight,
  }));

  // 3. Contexto compartilhado (catálogo).
  const catalogBlock = await buildCatalogBlock();

  // 4. Pra cada conversa.
  const cfg = auditorConfig();
  let totalCost = 0;
  let budgetTruncated = false;
  const perConvResults: ConversationAuditResult[] = [];
  for (const cand of candidates) {
    // Cap de custo por execução: antes de cada LLM call, checar se a estimativa
    // de próxima conversa ultrapassaria o cap.
    if (exceedsRunBudget(totalCost + COST_ESTIMATE_PER_CONV_USD, cfg.maxCostPerRunUsd)) {
      log({
        event: "audit.budget.run_exceeded",
        reportId,
        totalCostSoFar: totalCost,
        maxCostPerRunUsd: cfg.maxCostPerRunUsd,
      });
      budgetTruncated = true;
      break;
    }

    try {
      log({
        event: "audit.conversation.start",
        reportId,
        conversationId: cand.conversationId,
        botTurnCount: cand.botTurnCount,
      });
      const result = await runAuditorOnConversation(
        cand,
        criteriaForPrompt,
        catalogBlock,
      );
      totalCost += result.costUsd;
      perConvResults.push(result);
      await persistFindings(reportId, result);
      log({
        event: "audit.conversation.done",
        reportId,
        conversationId: cand.conversationId,
        findingCount: result.findings.length,
        costUsd: result.costUsd,
      });
    } catch (err) {
      log({
        event: "audit.conversation.failed",
        reportId,
        conversationId: cand.conversationId,
        error: String((err as Error)?.message ?? err),
      });
      await prisma.auditFinding.create({
        data: {
          reportId,
          conversationId: cand.conversationId,
          contactDisplaySnapshot: cand.displayName,
          criterionId: null,
          criterionNameSnapshot: "Erro de auditoria",
          verdict: "error",
          freeNotes: `LLM error: ${String((err as Error)?.message ?? err)}`,
        },
      });
      perConvResults.push({
        conversationId: cand.conversationId,
        contactDisplay: cand.displayName,
        findings: [],
        oneLineVerdict: `[ERRO] ${String((err as Error)?.message ?? err)}`,
        costUsd: 0,
      });
    }
  }

  // 5. Summary agregado.
  let summary = "Summary indisponível — veja achados por conversa.";
  if (budgetTruncated && perConvResults.length === 0) {
    summary = `Auditoria interrompida: cap de custo por execução ($${cfg.maxCostPerRunUsd}) atingido antes da primeira conversa.`;
  } else {
    try {
      const sumResult = await summarizeReport(perConvResults);
      summary = sumResult.summary;
      if (budgetTruncated) {
        summary += `\n\n> **Aviso:** auditoria truncada por cap de custo por execução ($${cfg.maxCostPerRunUsd}). Nem todas as conversas foram avaliadas.`;
      }
      totalCost += sumResult.costUsd;
      log({ event: "audit.summary.done", reportId, costUsd: sumResult.costUsd });
    } catch (err) {
      log({
        event: "audit.summary.failed",
        reportId,
        error: String((err as Error)?.message ?? err),
      });
    }
  }

  await finishReport(reportId, { summary, costUsd: totalCost });
  log({ event: "audit.run.done", reportId, totalCostUsd: totalCost });
}

/** Roda o auditor numa única conversa. Pode lançar — caller pega. */
async function runAuditorOnConversation(
  cand: {
    conversationId: string;
    contactId: string;
    displayName: string | null;
  },
  criteria: CriterionForPrompt[],
  catalogBlock: string | null,
): Promise<ConversationAuditResult> {
  const [messages, conv] = await Promise.all([
    prisma.message.findMany({
      where: {
        conversationId: cand.conversationId,
        role: { in: ["user", "assistant"] },
      },
      orderBy: { createdAt: "asc" },
      take: MAX_MESSAGES,
      select: { role: true, text: true, createdAt: true },
    }),
    prisma.conversation.findUniqueOrThrow({
      where: { id: cand.conversationId },
      select: { leadId: true },
    }),
  ]);
  let leadBlock: string | null = null;
  if (conv.leadId) {
    leadBlock = await buildLeadContextBlock(conv.leadId, cand.contactId);
  }

  const transcript = formatTranscript(messages);
  const criteriaBlock = formatCriteriaBlock(criteria);
  const dynBlocks = [catalogBlock, leadBlock, criteriaBlock].filter(
    (s): s is string => Boolean(s),
  );

  const resp = await generateReplyWithKey("anthropic", {
    model: MODEL,
    temperature: 0.2,
    maxTokens: 4000,
    systemStatic: AUDITOR_SYSTEM_PROMPT,
    systemDynamic: dynBlocks.join("\n\n"),
    messages: [
      {
        role: "user",
        content:
          `Conversa #${cand.conversationId} (${cand.displayName ?? "sem nome"}).\n\n` +
          `Histórico:\n\n${transcript}\n\n` +
          `Agora avalie cada critério usando o tool record_audit.`,
      },
    ],
    tools: [RECORD_AUDIT_TOOL],
    toolChoice: { type: "tool", name: "record_audit" },
  });

  const toolUse = resp.toolUses?.find((t) => t.name === "record_audit");
  if (!toolUse) {
    throw new Error("LLM não chamou record_audit");
  }
  const parsed = AuditOutputSchema.parse(toolUse.input);

  const validCriterionIds = new Set(criteria.map((c) => c.id));
  const finalFindings: ConversationAuditResult["findings"] = [];
  for (const f of parsed.findings) {
    if (!validCriterionIds.has(f.criterionId)) {
      log({
        event: "audit.invalid_criterion_id",
        conversationId: cand.conversationId,
        criterionId: f.criterionId,
      });
      continue;
    }
    const crit = criteria.find((c) => c.id === f.criterionId)!;
    finalFindings.push({
      criterionId: f.criterionId,
      criterionNameSnapshot: crit.name,
      verdict: f.verdict as Verdict,
      severity: f.severity,
      evidence: f.evidence,
      recommendation: f.recommendation,
    });
  }

  if (parsed.freeNotes.trim().length > 0) {
    finalFindings.push({
      criterionId: null,
      criterionNameSnapshot: "Observações livres",
      verdict: "na",
      freeNotes: parsed.freeNotes,
    });
  }

  return {
    conversationId: cand.conversationId,
    contactDisplay: cand.displayName,
    findings: finalFindings,
    oneLineVerdict: parsed.oneLineVerdict,
    costUsd: resp.costUsd ?? 0,
  };
}

async function persistFindings(
  reportId: string,
  result: ConversationAuditResult,
): Promise<void> {
  if (result.findings.length === 0) return;
  await prisma.auditFinding.createMany({
    data: result.findings.map((f) => ({
      reportId,
      conversationId: result.conversationId,
      contactDisplaySnapshot: result.contactDisplay,
      criterionId: f.criterionId,
      criterionNameSnapshot: f.criterionNameSnapshot,
      verdict: f.verdict,
      severity: f.severity ?? null,
      evidence: f.evidence ?? null,
      recommendation: f.recommendation ?? null,
      freeNotes: f.freeNotes ?? null,
    })),
  });
}

async function summarizeReport(
  perConv: ConversationAuditResult[],
): Promise<{ summary: string; costUsd: number }> {
  const lines: string[] = [];
  for (const r of perConv) {
    lines.push(`- Conversa #${r.conversationId}: ${r.oneLineVerdict}`);
  }
  const criticalFails = perConv.flatMap((r) =>
    r.findings
      .filter((f) => f.verdict === "fail" && (f.severity ?? 0) >= 4)
      .map((f) => `- [${r.conversationId}] ${f.criterionNameSnapshot}: ${f.evidence ?? ""}`),
  );

  const userMsg =
    `Resumos por conversa:\n${lines.join("\n")}\n\n` +
    (criticalFails.length > 0
      ? `Achados críticos (severity ≥ 4):\n${criticalFails.join("\n")}\n\n`
      : "Sem achados críticos.\n\n") +
    `Escreva um resumo executivo em markdown com:\n` +
    `## Visão geral (2-3 frases)\n## Prioridade 1 (críticos, se houver)\n## Padrões observados`;

  const resp = await generateReplyWithKey("anthropic", {
    model: MODEL,
    temperature: 0.3,
    maxTokens: 1500,
    systemStatic:
      "Você é um gerente sênior consolidando achados de auditoria. Seja conciso e acionável.",
    messages: [{ role: "user", content: userMsg }],
  });

  return { summary: resp.text || "Summary vazio.", costUsd: resp.costUsd ?? 0 };
}

async function finishReport(
  reportId: string,
  data: { summary: string; costUsd: number },
): Promise<void> {
  await prisma.auditReport.update({
    where: { id: reportId },
    data: {
      status: "done",
      finishedAt: new Date(),
      summary: data.summary,
      costUsd: new Prisma.Decimal(data.costUsd.toFixed(6)),
      modelUsed: MODEL,
    },
  });
}

function log(payload: Record<string, unknown>): void {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
