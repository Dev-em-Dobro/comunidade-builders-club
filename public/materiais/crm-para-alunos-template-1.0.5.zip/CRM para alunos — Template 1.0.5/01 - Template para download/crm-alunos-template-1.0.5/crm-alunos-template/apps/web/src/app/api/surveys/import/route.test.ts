import { describe, it, expect, beforeAll, afterAll, vi, beforeEach } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "u-test" } })),
}));

import { POST } from "./route";
import { auth } from "@/auth";

const created = { contactIds: [] as string[] };
let contactPhoneId: string;
let contactEmail: string;
let contactEmailId: string;

beforeAll(async () => {
  const c1 = await prisma.contact.create({
    data: {
      displayName: "Phone match",
      identities: {
        create: { channel: "whatsapp_cloud", externalId: "5511966665555" },
      },
    },
  });
  contactPhoneId = c1.id;
  created.contactIds.push(c1.id);

  contactEmail = `import-${Date.now()}@t.local`;
  const c2 = await prisma.contact.create({
    data: { displayName: "Email match", email: contactEmail },
  });
  contactEmailId = c2.id;
  created.contactIds.push(c2.id);
});

afterAll(async () => {
  await prisma.surveyResponse.deleteMany({ where: { contactId: { in: created.contactIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "u-test" } } as never);
});

function multipart(opts: { csv: string | null; surveyName: string | null }): Request {
  const fd = new FormData();
  if (opts.csv !== null) {
    fd.append("file", new Blob([opts.csv], { type: "text/csv" }), "survey.csv");
  }
  if (opts.surveyName !== null) {
    fd.append("surveyName", opts.surveyName);
  }
  return new Request("http://localhost/api/surveys/import", {
    method: "POST",
    body: fd,
  });
}

describe("POST /api/surveys/import", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(multipart({ csv: "phone\n+5511966665555\n", surveyName: "X" }));
    expect(res.status).toBe(401);
  });

  it("400 sem surveyName", async () => {
    const res = await POST(multipart({ csv: "phone\n+5511966665555\n", surveyName: null }));
    expect(res.status).toBe(400);
  });

  it("400 sem file", async () => {
    const res = await POST(multipart({ csv: null, surveyName: "X" }));
    expect(res.status).toBe(400);
  });

  it("200 com CSV válido: 2 matched + 1 created (decisão #4 revisada)", async () => {
    const phantomEmail = `phantom-${Date.now()}@x.com`;
    const csv = [
      "phone,email,Objetivo,Renda",
      `+5511966665555,,dobrar a renda,5-10k`,
      `,${contactEmail},faturar muito,10-20k`,
      `+5519999999999,${phantomEmail},?,?`,
    ].join("\n");
    const res = await POST(
      multipart({ csv, surveyName: "Lançamento teste" }),
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.totalRows).toBe(3);
    expect(body.matched).toBe(2);
    expect(body.created).toBe(1);
    expect(body.skipped).toBe(0);

    // O contact "fantasma" foi criado com o email + identity do phone.
    const phantom = await prisma.contact.findUnique({
      where: { email: phantomEmail },
      include: { identities: true, surveyResponses: true },
    });
    expect(phantom).not.toBeNull();
    expect(phantom!.identities[0]!.externalId).toBe("5519999999999");
    expect(phantom!.surveyResponses).toHaveLength(1);
    created.contactIds.push(phantom!.id);

    const saved = await prisma.surveyResponse.findMany({
      where: { contactId: { in: [contactPhoneId, contactEmailId] }, surveyName: "Lançamento teste" },
    });
    expect(saved).toHaveLength(2);
    expect(
      saved.find((s) => s.contactId === contactPhoneId)!.answers as Record<string, string>,
    ).toEqual({ Objetivo: "dobrar a renda", Renda: "5-10k" });
  });

  it("skippa linha sem email/phone válidos", async () => {
    const csv = [
      "phone,email,Objetivo",
      `abc,sem-arroba,nada`,
    ].join("\n");
    const res = await POST(multipart({ csv, surveyName: "X" }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.matched).toBe(0);
    expect(body.created).toBe(0);
    expect(body.skipped).toBe(1);
    expect(body.skippedDetails[0].reason).toBe(
      "linha sem email nem telefone válidos",
    );
  });

  it("200 com CSV só header → totalRows=0, matched=0, created=0, skipped=0", async () => {
    const csv = "phone,Objetivo\n";
    const res = await POST(multipart({ csv, surveyName: "Vazio" }));
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.totalRows).toBe(0);
    expect(body.matched).toBe(0);
    expect(body.created).toBe(0);
  });
});
