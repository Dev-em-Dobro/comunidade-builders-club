import type { ChannelId } from "@/lib/config";

export type { ChannelId };

export type MediaType = "image" | "audio" | "video" | "document" | "sticker";

export interface ChannelMedia {
  type: MediaType;
  /** ID devolvido no webhook WhatsApp; URL temporária é buscada sob demanda. */
  id?: string;
  url?: string;
  base64?: string;
  mimeType?: string;
  caption?: string;
  /** Nome do arquivo no envio (documento). */
  fileName?: string;
}

/**
 * Mensagem normalizada cross-canal.
 *
 * IMPORTANTE (gotchas 0.9.21 + 0.9.27):
 *   contactId aqui = externalId do canal — wa_id E.164 sem sufixo (Cloud API)
 *   ou igsid opaco (Instagram). NUNCA é o Contact.id cuid do DB.
 *   Mantenha-o intacto no pipeline de debounce — Redis serializa o objeto inteiro.
 */
export interface ChannelMessage {
  channel: ChannelId;
  contactId: string;
  contactName?: string;
  text: string;
  media?: ChannelMedia[];
  /**
   * Turno deve ser registrado na inbox mas NÃO gerar auto-resposta do bot.
   * Hoje: reação (emoji numa msg). O `decideAction` dropa o turno quando TODO
   * o lote é suprimível. Normalizado pelo adapter de cada canal.
   */
  suppressAutoReply?: boolean;
  /** ID da msg no provedor — usado pra dedup (gotcha 0.9.4). */
  providerMsgId?: string;
  receivedAt: string;
  /** payload original — útil pra debug, NUNCA escrever direto no DB. */
  raw: unknown;
}

export type SessionStatus = "connected" | "needs_verification" | "missing_credentials" | "error";

export interface SessionState {
  channel: ChannelId;
  status: SessionStatus;
  /** webhook URL público que o operador cola no Meta App Dashboard */
  webhookUrl?: string;
  /** token que o operador cola no campo "Verify Token" do dashboard */
  verifyToken?: string;
  /** mensagem human-readable pro painel */
  message?: string;
  details?: Record<string, unknown>;
}

export interface ChannelAdapter {
  id: ChannelId;
  /**
   * Idempotente — chamada no instrumentation.ts a cada boot.
   * Faz GET subscribed_apps + POST se faltar. Nunca lança em produção
   * (instrumentation só loga; operador conserta via /onboarding).
   */
  ensureSession(opts?: Record<string, unknown>): Promise<SessionState>;
  /** Status raw pra UI/healthcheck */
  getSessionStatus(): Promise<SessionState>;
  /** GET /api/webhooks/<id> — Meta hub.challenge handshake (plain text) */
  verifyWebhook(req: Request): Promise<Response>;
  /** POST /api/webhooks/<id> — retorna ChannelMessage ou null (evento que não é msg inbound) */
  parseWebhook(req: Request): Promise<ChannelMessage | null>;
  /**
   * Envia texto pelo canal.
   * @param externalId — wa_id (Cloud API) ou igsid (Instagram). NÃO passar Contact.id (gotcha 0.9.27).
   */
  sendText(externalId: string, text: string): Promise<void>;
  sendMedia?(externalId: string, media: ChannelMedia): Promise<void>;
  /** Liga/desliga o "digitando…" na conversa. Opcional — canal sem suporte ignora. */
  setTyping?(externalId: string, on: boolean): Promise<void>;
}
