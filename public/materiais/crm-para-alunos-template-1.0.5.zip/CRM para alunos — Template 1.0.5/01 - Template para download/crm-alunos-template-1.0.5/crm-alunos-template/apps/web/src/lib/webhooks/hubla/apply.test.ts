import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { applyPurchase, type ApplyResult } from "./apply";
import type { PurchaseData } from "./parser";

const created = { contactIds: [] as string[], leadIds: [] as string[] };

const PURCHASE: PurchaseData = {
  invoiceId: "inv_test_1",
  saleDate: new Date("2026-05-28T14:00:00.000Z"),
  productId: "prod_1",
  offerId: "offer_1",
  totalCents: 100000,
  currency: "BRL",
  paymentMethod: "credit_card",
  installments: 12,
};

async function makeLead(stage: string, opts: { lostAt?: Date; lostReason?: string } = {}) {
  const contact = await prisma.contact.create({
    data: { displayName: `Apply test ${Date.now()}-${Math.random()}` },
  });
  created.contactIds.push(contact.id);
  const lead = await prisma.lead.create({
    data: {
      contactId: contact.id,
      stage,
      interestCourseIds: [],
      lostAt: opts.lostAt ?? null,
      lostReason: opts.lostReason ?? null,
    },
  });
  created.leadIds.push(lead.id);
  return lead;
}

afterAll(async () => {
  await prisma.pipelineEvent.deleteMany({ where: { leadId: { in: created.leadIds } } });
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

describe("applyPurchase", () => {
  it("retorna lead_not_found quando leadId inexistente", async () => {
    const r: ApplyResult = await applyPurchase(prisma, "id_que_nao_existe", PURCHASE);
    expect(r).toEqual({ ok: false, reason: "lead_not_found" });
  });

  it("aplica em lead 'qualified' → vira won, cria 2 PipelineEvents", async () => {
    const lead = await makeLead("qualified");
    const r = await applyPurchase(prisma, lead.id, PURCHASE);
    expect(r).toEqual({ ok: true, status: "applied" });

    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    expect(after.wonAt?.toISOString()).toBe(PURCHASE.saleDate.toISOString());

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id },
      orderBy: { createdAt: "asc" },
    });
    expect(events.map((e) => e.type)).toEqual(["stage_change", "purchase"]);
    const stageChange = events[0]!.payload as { from: string; to: string; via: string };
    expect(stageChange).toMatchObject({ from: "qualified", to: "won", via: "hubla_webhook" });
    const purchase = events[1]!.payload as { invoiceId: string; totalCents: number; via: string };
    expect(purchase).toMatchObject({
      invoiceId: "inv_test_1",
      totalCents: 100000,
      via: "hubla_webhook",
    });
  });

  it("idempotência: lead já 'won' não altera stage/wonAt, mas cria PipelineEvent('purchase')", async () => {
    const lead = await makeLead("qualified");
    await applyPurchase(prisma, lead.id, PURCHASE);
    const firstWonAt = (await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } })).wonAt!;

    // Segunda compra (upsell)
    const upsell: PurchaseData = {
      ...PURCHASE,
      invoiceId: "inv_test_2",
      saleDate: new Date("2026-06-01T10:00:00.000Z"),
    };
    const r = await applyPurchase(prisma, lead.id, upsell);
    expect(r).toEqual({ ok: true, status: "already_won" });

    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.wonAt?.toISOString()).toBe(firstWonAt.toISOString()); // não muda

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id, type: "purchase" },
      orderBy: { createdAt: "asc" },
    });
    expect(events.length).toBe(2);
    expect((events[1]!.payload as { invoiceId: string }).invoiceId).toBe("inv_test_2");

    // already_won não duplica stage_change — só 1 (da primeira chamada).
    const stageChanges = await prisma.pipelineEvent.count({
      where: { leadId: lead.id, type: "stage_change" },
    });
    expect(stageChanges).toBe(1);
  });

  it("lead em 'lost' → vira won, limpa lostAt/lostReason", async () => {
    const lead = await makeLead("lost", {
      lostAt: new Date("2026-05-20T10:00:00.000Z"),
      lostReason: "no_response",
    });
    const r = await applyPurchase(prisma, lead.id, PURCHASE);
    expect(r).toEqual({ ok: true, status: "applied" });

    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    expect(after.lostAt).toBeNull();
    expect(after.lostReason).toBeNull();

    const stageChange = await prisma.pipelineEvent.findFirstOrThrow({
      where: { leadId: lead.id, type: "stage_change" },
    });
    expect((stageChange.payload as { from: string }).from).toBe("lost");
  });
});
