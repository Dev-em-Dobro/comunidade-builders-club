import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import {
  CRITERION_PUBLIC_SELECT,
  CriterionPatchSchema,
  firstZodError,
} from "@/lib/audit/criterion-schema";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { id } = await params;
  const raw = await req.json().catch(() => null);
  const parsed = CriterionPatchSchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: firstZodError(parsed.error) },
      { status: 400 },
    );
  }
  const existing = await prisma.auditCriterion.findUnique({
    where: { id },
    select: { id: true },
  });
  if (!existing) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  const updated = await prisma.auditCriterion.update({
    where: { id },
    data: parsed.data,
    select: CRITERION_PUBLIC_SELECT,
  });
  return NextResponse.json({ criterion: updated });
}
