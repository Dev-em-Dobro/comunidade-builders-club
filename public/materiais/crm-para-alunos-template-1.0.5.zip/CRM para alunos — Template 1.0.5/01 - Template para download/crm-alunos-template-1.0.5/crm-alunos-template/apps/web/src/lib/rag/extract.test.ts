import { afterEach, describe, expect, it, vi } from "vitest";
import { extractUrl, googleDocsExportUrl } from "./extract";

describe("googleDocsExportUrl", () => {
  it("converte link de edição em URL de exportação TXT", () => {
    expect(
      googleDocsExportUrl(
        "https://docs.google.com/document/d/abc_123/edit?usp=sharing",
      ),
    ).toBe("https://docs.google.com/document/d/abc_123/export?format=txt");
  });

  it("aceita links com seletor de usuário e rejeita outras URLs", () => {
    expect(
      googleDocsExportUrl("https://docs.google.com/document/u/0/d/abc-123/edit"),
    ).toBe("https://docs.google.com/document/d/abc-123/export?format=txt");
    expect(googleDocsExportUrl("https://drive.google.com/file/d/abc-123/view")).toBeNull();
    expect(googleDocsExportUrl("https://docs.google.com/spreadsheets/d/abc-123/edit")).toBeNull();
  });
});

describe("extractUrl para Google Docs", () => {
  afterEach(() => vi.unstubAllGlobals());

  it("usa export TXT e preserva o conteúdo de todas as abas", async () => {
    const fetchMock = vi.fn().mockResolvedValue(
      new Response("\uFEFFAba Renovação\r\nPlano anual\r\n\r\nAba Pagamento\r\nBoleto parcelado", {
        headers: { "content-type": "text/plain; charset=utf-8" },
      }),
    );
    vi.stubGlobal("fetch", fetchMock);

    const result = await extractUrl(
      "https://docs.google.com/document/d/doc-123/edit?usp=sharing",
    );

    expect(fetchMock).toHaveBeenCalledWith(
      "https://docs.google.com/document/d/doc-123/export?format=txt",
      expect.objectContaining({ redirect: "follow" }),
    );
    expect(result.text).toContain("Aba Renovação\nPlano anual");
    expect(result.text).toContain("Aba Pagamento\nBoleto parcelado");
  });

  it("retorna erro útil quando o documento exige login", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue(
        new Response("<html><body>Faça login</body></html>", {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
      ),
    );

    await expect(
      extractUrl("https://docs.google.com/document/d/doc-123/edit"),
    ).rejects.toThrow(/compartilhamento permite acesso pelo link/i);
  });
});
