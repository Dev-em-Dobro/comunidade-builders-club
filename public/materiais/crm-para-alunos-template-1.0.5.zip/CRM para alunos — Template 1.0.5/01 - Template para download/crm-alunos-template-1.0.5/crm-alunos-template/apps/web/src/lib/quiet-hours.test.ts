import { describe, it, expect } from "vitest";
import { isQuietHours, effectiveFollowupDeadline } from "./quiet-hours";

// América/São_Paulo = UTC−3. Datas abaixo anotadas com o horário local SP.
const QH = { start: "21:00", end: "08:00" }; // cruza meia-noite

describe("isQuietHours", () => {
  it("false quando quietHours é null", () => {
    expect(isQuietHours(new Date("2026-05-21T05:00:00.000Z"), null)).toBe(false);
  });

  it("janela cruzando meia-noite: madrugada e noite são quiet", () => {
    // 05:00Z = 02:00 SP → dentro
    expect(isQuietHours(new Date("2026-05-21T05:00:00.000Z"), QH)).toBe(true);
    // 02:00Z = 23:00 SP → dentro
    expect(isQuietHours(new Date("2026-05-21T02:00:00.000Z"), QH)).toBe(true);
  });

  it("janela cruzando meia-noite: meio-dia não é quiet", () => {
    // 15:00Z = 12:00 SP → fora
    expect(isQuietHours(new Date("2026-05-21T15:00:00.000Z"), QH)).toBe(false);
  });

  it("start é inclusivo, end é exclusivo", () => {
    // 00:00Z dia 22 = 21:00 SP dia 21 → start, dentro
    expect(isQuietHours(new Date("2026-05-22T00:00:00.000Z"), QH)).toBe(true);
    // 11:00Z = 08:00 SP → end, fora
    expect(isQuietHours(new Date("2026-05-21T11:00:00.000Z"), QH)).toBe(false);
  });

  it("janela no mesmo dia (start < end)", () => {
    const day = { start: "12:00", end: "14:00" };
    expect(isQuietHours(new Date("2026-05-21T16:00:00.000Z"), day)).toBe(true);  // 13:00 SP
    expect(isQuietHours(new Date("2026-05-21T18:00:00.000Z"), day)).toBe(false); // 15:00 SP
  });
});

describe("effectiveFollowupDeadline", () => {
  it("retorna a própria data quando fecha fora do quiet hours", () => {
    const closes = new Date("2026-05-21T18:00:00.000Z"); // 15:00 SP
    expect(effectiveFollowupDeadline(closes, QH).toISOString()).toBe(
      "2026-05-21T18:00:00.000Z",
    );
  });

  it("retorna a própria data quando quietHours é null", () => {
    const closes = new Date("2026-05-22T05:00:00.000Z");
    expect(effectiveFollowupDeadline(closes, null).toISOString()).toBe(
      "2026-05-22T05:00:00.000Z",
    );
  });

  it("antecipa para o início do bloco quando fecha dentro do quiet hours", () => {
    // fecha 05:00Z dia 22 = 02:00 SP dia 22 → bloco começou 21:00 SP dia 21 = 00:00Z dia 22
    const closes = new Date("2026-05-22T05:00:00.000Z");
    expect(effectiveFollowupDeadline(closes, QH).toISOString()).toBe(
      "2026-05-22T00:00:00.000Z",
    );
  });
});
