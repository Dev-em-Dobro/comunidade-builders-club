"use server";
import { auth } from "@/auth";
import { loadConfig, saveConfig, withChannelEnabled } from "@/lib/config";
import { revalidatePath } from "next/cache";

/** Liga/desliga o recebimento do WhatsApp via QR direto do onboarding (o mesmo que a caixa em Geral). */
export async function setWhatsappQrEnabled(enabled: boolean): Promise<{ ok: boolean; error?: string }> {
  const session = await auth();
  if (session?.user?.role !== "admin") return { ok: false, error: "Somente o administrador pode alterar os canais." };
  try {
    saveConfig(withChannelEnabled(loadConfig(), "whatsapp_qr", enabled));
  } catch {
    return { ok: false, error: "Não foi possível salvar. Confira a permissão de escrita e o volume de configuração do servidor." };
  }
  revalidatePath("/", "layout");
  return { ok: true };
}
