-- AlterTable
ALTER TABLE "Lead" ADD COLUMN "lastFollowUpStep" INTEGER;
ALTER TABLE "Lead" ADD COLUMN "lastFollowUpAt" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX "Lead_lastFollowUpStep_idx" ON "Lead"("lastFollowUpStep");
