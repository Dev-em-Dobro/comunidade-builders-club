import { describe, it, expect } from "vitest";
import { resolveRoundTripText, buildDirectiveBlocks, contactInfoBlock, paymentAnswerBlock } from "./flush";

const URL = "https://crmdev.example.com/l/uQuahV";

describe("buildDirectiveBlocks — diretrizes sempre injetadas no prompt", () => {
  it("SEMPRE inclui a diretriz de contato (vale pra todos os agentes)", () => {
    const hasContato = (blocks: string[]) =>
      blocks.some((b) => b.startsWith("# Dados de contato"));
    expect(hasContato(buildDirectiveBlocks({ hasCta: false }))).toBe(true);
    expect(hasContato(buildDirectiveBlocks({ hasCta: true }))).toBe(true);
  });

  it("a diretriz de contato usa o email dado e proíbe inventar", () => {
    const block = contactInfoBlock("suporteproduto-exemplo@gmail.com");
    expect(block).toContain("suporteproduto-exemplo@gmail.com");
    expect(block.toLowerCase()).toContain("nunca");
    // nunca deve sugerir um endereço alucinado como válido
    expect(block).not.toContain("contato@empresa-exemplo");
  });

  it("sem email configurado, cai no guardrail genérico (não inventa)", () => {
    const block = contactInfoBlock("");
    expect(block).not.toContain("@");
    expect(block.toLowerCase()).toContain("invente");
  });

  it("mantém a diretriz de fraseado de handoff", () => {
    expect(
      buildDirectiveBlocks({ hasCta: false }).some((b) =>
        b.includes("um dos nossos especialistas"),
      ),
    ).toBe(true);
  });

  it("orienta responder parcelas e valores do catálogo antes do handoff", () => {
    const block = paymentAnswerBlock();
    expect(block).toContain("quantidade de parcelas e valor por parcela");
    expect(block).toContain("Não transfira a conversa");
    expect(buildDirectiveBlocks({ hasCta: false })).toContain(block);
  });

  it("inclui o bloco de CTA apenas quando hasCta é true", () => {
    const hasGetCheckout = (blocks: string[]) =>
      blocks.some((b) => b.includes("get_checkout_link"));
    expect(hasGetCheckout(buildDirectiveBlocks({ hasCta: true }))).toBe(true);
    expect(hasGetCheckout(buildDirectiveBlocks({ hasCta: false }))).toBe(false);
  });
});

describe("resolveRoundTripText", () => {
  it("usa o texto do round-trip quando ele vem preenchido", () => {
    const r = resolveRoundTripText({
      roundTripText: "Aqui está o link: " + URL,
      firstText: "Os bônus são X e Y.",
      checkoutUrl: URL,
    });
    expect(r.usedFallback).toBe(false);
    expect(r.text).toContain(URL);
  });

  it("round-trip VAZIO → cai no texto da 1ª chamada (bot não fica mudo)", () => {
    const r = resolveRoundTripText({
      roundTripText: "",
      firstText: "Os bônus são mentoria 4x e kit físico.",
      checkoutUrl: null,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe("Os bônus são mentoria 4x e kit físico.");
  });

  it("round-trip vazio só com whitespace também dispara o fallback", () => {
    const r = resolveRoundTripText({
      roundTripText: "   \n  ",
      firstText: "Resposta da 1ª chamada.",
      checkoutUrl: null,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe("Resposta da 1ª chamada.");
  });

  it("fallback anexa a URL do tool quando ela não está no texto da 1ª chamada", () => {
    const r = resolveRoundTripText({
      roundTripText: "",
      firstText: "Os bônus são mentoria 4x e kit físico.",
      checkoutUrl: URL,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe("Os bônus são mentoria 4x e kit físico.\n\n" + URL);
  });

  it("fallback NÃO duplica a URL se a 1ª chamada já a citou", () => {
    const r = resolveRoundTripText({
      roundTripText: "",
      firstText: "Segue o link: " + URL,
      checkoutUrl: URL,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe("Segue o link: " + URL);
    expect(r.text.match(new RegExp(URL.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))?.length).toBe(1);
  });

  it("fallback só com URL quando a 1ª chamada veio vazia (tool_use puro)", () => {
    const r = resolveRoundTripText({
      roundTripText: "",
      firstText: "",
      checkoutUrl: URL,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe(URL);
  });

  it("tudo vazio → texto vazio (caso degenerado: só aí o empty_reply guard age)", () => {
    const r = resolveRoundTripText({
      roundTripText: "",
      firstText: "",
      checkoutUrl: null,
    });
    expect(r.usedFallback).toBe(true);
    expect(r.text).toBe("");
  });
});
