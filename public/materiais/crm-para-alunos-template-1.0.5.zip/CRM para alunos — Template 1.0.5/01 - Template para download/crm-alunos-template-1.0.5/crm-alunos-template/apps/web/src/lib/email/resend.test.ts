import { describe, it, expect, afterEach, vi } from "vitest";
import { sendEmail } from "./resend";

afterEach(() => {
  vi.unstubAllEnvs();
});

describe("sendEmail", () => {
  it("não lança e vira no-op quando RESEND_API_KEY está ausente", async () => {
    vi.stubEnv("RESEND_API_KEY", "");
    await expect(
      sendEmail({ to: ["a@b.com"], subject: "x", text: "y" }),
    ).resolves.toBeUndefined();
  });
});
