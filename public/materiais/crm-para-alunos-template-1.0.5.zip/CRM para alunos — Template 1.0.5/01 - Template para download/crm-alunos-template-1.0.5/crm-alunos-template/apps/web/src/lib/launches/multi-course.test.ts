import { describe, it, expect } from "vitest";
import { pickPrimaryCourseId } from "./multi-course";

const courses = [
  { id: "c1", name: "Produto Exemplo", slug: "produto-exemplo" },
  { id: "c2", name: "MasterClass", slug: "masterclass" },
];

describe("pickPrimaryCourseId", () => {
  it("retorna interestCourseIds[0] se nenhum foi mencionado", () => {
    expect(
      pickPrimaryCourseId({
        interestCourseIds: ["c1", "c2"],
        messages: [],
        courses,
      }),
    ).toBe("c1");
  });

  it("retorna o curso mencionado mais recentemente na conversa", () => {
    const msgs = [
      { text: "oi, queria saber do Produto Exemplo", createdAt: new Date("2026-06-15T10:00:00Z") },
      { text: "e do MasterClass também", createdAt: new Date("2026-06-15T11:00:00Z") },
    ];
    expect(
      pickPrimaryCourseId({
        interestCourseIds: ["c1", "c2"],
        messages: msgs,
        courses,
      }),
    ).toBe("c2");
  });

  it("é case-insensitive", () => {
    const msgs = [
      { text: "produto-exemplo por favor", createdAt: new Date() },
    ];
    expect(
      pickPrimaryCourseId({
        interestCourseIds: ["c1", "c2"],
        messages: msgs,
        courses,
      }),
    ).toBe("c1");
  });

  it("usa slug como fallback se name não bater", () => {
    const msgs = [
      { text: "no masterclass tem desconto?", createdAt: new Date() },
    ];
    expect(
      pickPrimaryCourseId({
        interestCourseIds: ["c1", "c2"],
        messages: msgs,
        courses,
      }),
    ).toBe("c2");
  });

  it("ignora cursos fora do interestCourseIds", () => {
    const msgs = [
      { text: "queria saber do MasterClass", createdAt: new Date() },
    ];
    expect(
      pickPrimaryCourseId({
        interestCourseIds: ["c1"], // c2 mencionado mas não tá no interesse
        messages: msgs,
        courses,
      }),
    ).toBe("c1");
  });

  it("retorna null se interestCourseIds vazio", () => {
    expect(
      pickPrimaryCourseId({
        interestCourseIds: [],
        messages: [],
        courses,
      }),
    ).toBeNull();
  });
});
