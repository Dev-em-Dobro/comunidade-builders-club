-- Agente de delivery: estabelecimento/cardápio e pedidos.
-- CreateTable
CREATE TABLE "DeliveryStore" (
    "id" TEXT NOT NULL,
    "agentSessionId" TEXT NOT NULL,
    "description" TEXT,
    "hours" TEXT,
    "pickupEnabled" BOOLEAN NOT NULL DEFAULT true,
    "pickupAddress" TEXT,
    "areas" JSONB NOT NULL DEFAULT '[]',
    "menuFileName" TEXT,
    "menuMimeType" TEXT,
    "menuFile" BYTEA,
    "menuToken" TEXT,
    "menuItems" JSONB NOT NULL DEFAULT '[]',
    "menuUpdatedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DeliveryStore_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Order" (
    "id" TEXT NOT NULL,
    "number" SERIAL NOT NULL,
    "agentSessionId" TEXT,
    "contactId" TEXT NOT NULL,
    "conversationId" TEXT,
    "customerName" TEXT,
    "items" JSONB NOT NULL,
    "subtotalCents" INTEGER NOT NULL,
    "deliveryFeeCents" INTEGER NOT NULL DEFAULT 0,
    "totalCents" INTEGER NOT NULL,
    "fulfillment" TEXT NOT NULL,
    "neighborhood" TEXT,
    "address" TEXT,
    "paymentMethod" TEXT NOT NULL,
    "changeForCents" INTEGER,
    "notes" TEXT,
    "status" TEXT NOT NULL DEFAULT 'new',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Order_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "DeliveryStore_agentSessionId_key" ON "DeliveryStore"("agentSessionId");

-- CreateIndex
CREATE UNIQUE INDEX "DeliveryStore_menuToken_key" ON "DeliveryStore"("menuToken");

-- CreateIndex
CREATE INDEX "Order_agentSessionId_createdAt_idx" ON "Order"("agentSessionId", "createdAt");

-- CreateIndex
CREATE INDEX "Order_contactId_createdAt_idx" ON "Order"("contactId", "createdAt");

-- CreateIndex
CREATE INDEX "Order_status_idx" ON "Order"("status");

-- AddForeignKey
ALTER TABLE "DeliveryStore" ADD CONSTRAINT "DeliveryStore_agentSessionId_fkey" FOREIGN KEY ("agentSessionId") REFERENCES "AgentSession"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Order" ADD CONSTRAINT "Order_agentSessionId_fkey" FOREIGN KEY ("agentSessionId") REFERENCES "AgentSession"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Order" ADD CONSTRAINT "Order_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES "Contact"("id") ON DELETE CASCADE ON UPDATE CASCADE;
