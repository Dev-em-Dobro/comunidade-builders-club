/**
 * Core de envio de template aprovado numa conversa — compartilhado pela rota
 * manual (/send-template) e pelo worker de follow-up fora da janela.
 *
 * Recebe o template JÁ validado (APPROVED, variableCount conferido) e a
 * identidade resolvida pelo caller — aqui só faz o envio Meta + persistência +
 * cadência + notificação. Lança ChannelSendError (de sendTemplateMessage) pro
 * caller mapear.
 */
import { prisma } from "@/lib/db";
import { sendTemplateMessage } from "@/lib/channels/meta-templates";
import { notifyMessage } from "@/lib/realtime/notify";

export interface SendApprovedTemplateInput {
  conversationId: string;
  leadId: string | null;
  externalId: string;
  template: { metaName: string; language: string; bodyText: string | null };
  variables: string[];
  /** Grava Lead.lastFollowUpStep = step. */
  step: number;
  /** null = enviado pelo bot (sem dono humano). */
  sentByUserId: string | null;
}

export interface SendApprovedTemplateResult {
  messageId: string;
}

/** Renderiza {{N}} → variables[N-1] pro Message.text (histórico legível). */
function renderBody(bodyText: string, variables: string[]): string {
  return bodyText.replace(/\{\{(\d+)\}\}/g, (_, n) => {
    const idx = Number(n) - 1;
    return variables[idx] ?? `{{${n}}}`;
  });
}

export async function sendApprovedTemplate(
  input: SendApprovedTemplateInput,
): Promise<SendApprovedTemplateResult> {
  const sent = await sendTemplateMessage({
    externalId: input.externalId,
    templateName: input.template.metaName,
    language: input.template.language,
    variables: input.variables,
  });

  const renderedText = input.template.bodyText
    ? renderBody(input.template.bodyText, input.variables)
    : `[template:${input.template.metaName}]`;

  const message = await prisma.message.create({
    data: {
      conversationId: input.conversationId,
      direction: "outbound",
      role: "assistant",
      text: renderedText,
      providerMsgId: sent.providerMsgId,
      sentByUserId: input.sentByUserId,
      templateMetaName: input.template.metaName,
    },
  });

  const now = new Date();
  // NOTA: windowClosesAt e windowExpired NÃO são atualizados aqui. Templates
  // podem ser enviados fora da janela — só inbound do lead redefine a janela
  // 24h (ver lib/window24h.ts + lib/flush.ts).
  await prisma.conversation.update({
    where: { id: input.conversationId },
    data: { lastMessageAt: now, lastOutboundAt: now },
  });

  if (input.leadId) {
    await prisma.lead.update({
      where: { id: input.leadId },
      data: { lastFollowUpStep: input.step, lastFollowUpAt: now },
    });
    await prisma.pipelineEvent.create({
      data: {
        leadId: input.leadId,
        type: "followup_sent",
        payload: { step: input.step, auto: input.sentByUserId === null },
      },
    });
  }

  await notifyMessage(input.conversationId, message.id);
  return { messageId: message.id };
}
