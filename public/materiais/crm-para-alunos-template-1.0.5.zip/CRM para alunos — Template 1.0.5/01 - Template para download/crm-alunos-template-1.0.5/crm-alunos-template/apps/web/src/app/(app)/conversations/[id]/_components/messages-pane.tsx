"use client";

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowDown, FileText } from "lucide-react";
import Image from "next/image";
import { formatTime } from "@/lib/datetime";

export interface MessageView {
  id: string;
  direction: "inbound" | "outbound";
  role: string;
  text: string;
  mediaType: string | null;
  mediaUrl: string | null;
  modelUsed: string | null;
  sentByUserId: string | null;
  sentBy: { id: string; name: string | null } | null;
  createdAt: string | Date;
  templateMetaName?: string | null;
}

interface Props {
  messages: MessageView[];
}

function isHuman(m: MessageView): boolean {
  return m.direction === "outbound" && m.sentByUserId != null;
}

function MessageMedia({ message }: { message: MessageView }) {
  const [failed, setFailed] = useState(false);
  if (!message.mediaUrl || !message.mediaType) return null;
  if (failed) {
    return (
      <a href={message.mediaUrl} target="_blank" rel="noopener noreferrer" className="text-xs underline">
        Mídia não pôde ser exibida. Abrir arquivo
      </a>
    );
  }

  if (message.mediaType === "image") {
    return (
      <a href={message.mediaUrl} target="_blank" rel="noopener noreferrer" aria-label="Abrir imagem em nova aba">
        <Image
          src={message.mediaUrl}
          alt="Imagem recebida na conversa"
          width={512}
          height={384}
          unoptimized
          onError={() => setFailed(true)}
          className="max-h-80 w-auto max-w-full rounded object-contain"
        />
      </a>
    );
  }
  if (message.mediaType === "audio") {
    return (
      <audio
        controls
        preload="none"
        src={message.mediaUrl}
        onError={() => setFailed(true)}
        className="w-full max-w-72"
        aria-label="Áudio recebido na conversa"
      >
        Seu navegador não reproduz este áudio.
      </audio>
    );
  }
  if (message.mediaType === "document") {
    return (
      <a
        href={message.mediaUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 rounded border border-current/20 px-3 py-2 underline"
      >
        <FileText className="size-5 shrink-0" aria-hidden="true" />
        Abrir documento
      </a>
    );
  }
  return null;
}

/** Threshold (px) do "está no fim". <=THRESHOLD = sticky-to-bottom + zera contador. */
const STICKY_THRESHOLD = 100;

export function MessagesPane({ messages }: Props) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const lastCountRef = useRef(messages.length);
  const initializedRef = useRef(false);
  const [userScrolledUp, setUserScrolledUp] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  // Auto-scroll inicial: 1× quando a lista hidrata com mensagens.
  // useLayoutEffect roda antes do paint — sem flicker.
  useLayoutEffect(() => {
    if (initializedRef.current) return;
    const el = scrollRef.current;
    if (!el || messages.length === 0) return;
    el.scrollTop = el.scrollHeight;
    initializedRef.current = true;
  }, [messages.length]);

  // Sticky / unread counter — dispara só nas adições subsequentes.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (messages.length > lastCountRef.current) {
      const newCount = messages.length - lastCountRef.current;
      const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
      const wasAtBottom = distFromBottom <= STICKY_THRESHOLD;
      if (wasAtBottom) {
        el.scrollTop = el.scrollHeight;
      } else {
        setUserScrolledUp(true);
        setUnreadCount((c) => c + newCount);
      }
    }
    lastCountRef.current = messages.length;
  }, [messages.length]);

  function onScroll() {
    const el = scrollRef.current;
    if (!el) return;
    const distFromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    if (distFromBottom <= STICKY_THRESHOLD) {
      if (userScrolledUp) setUserScrolledUp(false);
      if (unreadCount > 0) setUnreadCount(0);
    } else if (!userScrolledUp) {
      setUserScrolledUp(true);
    }
  }

  function scrollToBottom() {
    const el = scrollRef.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
    setUnreadCount(0);
    setUserScrolledUp(false);
  }

  return (
    <Card className="relative">
      <CardHeader className="py-3">
        <CardTitle className="text-sm font-mono text-muted-foreground">
          {messages.length} mensagens
        </CardTitle>
      </CardHeader>
      <Separator />
      <CardContent
        ref={scrollRef}
        onScroll={onScroll}
        className="pt-4 space-y-3 max-h-[60vh] overflow-y-auto relative"
      >
        {messages.length === 0 ? (
          <p className="text-sm text-muted-foreground italic">
            Sem mensagens ainda.
          </p>
        ) : (
          messages.map((m) => {
            const human = isHuman(m);
            const mediaOnly = Boolean(m.mediaUrl && m.text.trim() === `[${m.mediaType}]`);
            return (
              <div
                key={m.id}
                className={`flex flex-col max-w-[80%] ${
                  m.direction === "outbound" ? "ml-auto items-end" : "items-start"
                }`}
              >
                <div
                  className={`rounded-md px-3 py-2 text-sm ${
                    m.direction === "outbound"
                      ? human
                        ? "bg-purple-600 text-white"
                        : "bg-primary text-primary-foreground"
                      : "bg-secondary"
                  }`}
                >
                  <MessageMedia message={m} />
                  {!mediaOnly && <div className={m.mediaUrl ? "mt-2 whitespace-pre-wrap" : "whitespace-pre-wrap"}>{m.text}</div>}
                </div>
                <div className="text-[10px] text-muted-foreground mt-1 font-mono flex items-center gap-1">
                  <span>{formatTime(m.createdAt)}</span>
                  {m.modelUsed && (
                    <Badge
                      variant="outline"
                      className="font-mono text-[9px] py-0"
                    >
                      {m.modelUsed}
                    </Badge>
                  )}
                  {human && (
                    <Badge
                      variant="outline"
                      className="font-mono text-[9px] py-0 border-purple-600/40 text-purple-700 dark:text-purple-400"
                    >
                      {m.sentBy?.name ?? "atendente"}
                    </Badge>
                  )}
                  {m.templateMetaName && (
                    <span className="font-mono text-[10px] text-muted-foreground ml-2">
                      [template: {m.templateMetaName}]
                    </span>
                  )}
                </div>
              </div>
            );
          })
        )}
        {userScrolledUp && unreadCount > 0 && (
          <button
            type="button"
            onClick={scrollToBottom}
            className="sticky bottom-2 mx-auto flex items-center gap-1.5 rounded-full bg-primary text-primary-foreground px-3 py-1.5 text-xs shadow-lg hover:opacity-90 transition-opacity"
          >
            <ArrowDown className="size-3" />
            {unreadCount} nova{unreadCount > 1 ? "s" : ""}
          </button>
        )}
      </CardContent>
    </Card>
  );
}
