import { auth } from "@/auth";
import { NextResponse } from "next/server";
import { fetchWaqrQr } from "@/lib/channels/whatsapp-qr";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET /api/sessions/whatsapp-qr/qr — imagem do QR code para parear o número.
 * Só administrador. O QR muda a cada ~20s; a tela recarrega quando pedido.
 */
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ channel: string }> },
) {
  const session = await auth();
  if (session?.user?.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { channel } = await params;
  if (channel !== "whatsapp-qr") return NextResponse.json({ error: "QR disponível apenas para WhatsApp via QR" }, { status: 404 });
  try {
    const upstream = await fetchWaqrQr();
    const type = upstream.headers.get("content-type") ?? "";
    if (!upstream.ok || !type.startsWith("image/")) {
      const detail = type.includes("json")
        ? ((await upstream.json().catch(() => ({}))) as { error?: string }).error
        : undefined;
      return NextResponse.json(
        { error: detail ?? `QR indisponível (HTTP ${upstream.status}). Clique em "Garantir sessão" e tente de novo.` },
        { status: 409 },
      );
    }
    return new Response(upstream.body, {
      status: 200,
      headers: { "Content-Type": type, "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" },
    });
  } catch (err) {
    return NextResponse.json({ error: String((err as Error)?.message ?? err) }, { status: 502 });
  }
}
