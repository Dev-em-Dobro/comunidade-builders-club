import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { OBJECTION_LABEL, type ObjectionTag } from "@/lib/objections";

const DAY_MS = 24 * 60 * 60 * 1000;

interface Bucket {
  tag: ObjectionTag;
  count: number;
}

/**
 * Query bruta — Prisma 6 não filtra `groupBy` por campo de relação. O ranges
 * do dashboard são pequenos, então um findMany + group no app dá conta.
 */
async function getTopObjections(
  rangeDays: number,
  launch: string,
): Promise<{ buckets: Bucket[]; total: number; error: boolean }> {
  try {
    const since = new Date(Date.now() - rangeDays * DAY_MS);
    const rows = await prisma.objectionTag.findMany({
      where: {
        createdAt: { gte: since },
        ...(launch !== "all" ? { lead: { launchId: launch } } : {}),
      },
      select: { tag: true },
    });
    const counts = new Map<string, number>();
    for (const r of rows) counts.set(r.tag, (counts.get(r.tag) ?? 0) + 1);
    const buckets: Bucket[] = [...counts.entries()]
      .map(([tag, count]) => ({ tag: tag as ObjectionTag, count }))
      .filter((b) => b.tag in OBJECTION_LABEL)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
    return { buckets, total: rows.length, error: false };
  } catch {
    return { buckets: [], total: 0, error: true };
  }
}

export async function ObjectionsSection({
  rangeDays,
  launch,
}: {
  rangeDays: number;
  launch: string;
}) {
  const { buckets, total, error } = await getTopObjections(rangeDays, launch);
  const maxCount = buckets[0]?.count ?? 0;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Top objeções</CardTitle>
        <CardDescription>
          {error
            ? "Banco indisponível."
            : total === 0
              ? "Nenhuma objeção registrada nesse período."
              : `${total} tag${total !== 1 ? "s" : ""} no período`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error || buckets.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            {error ? "—" : "Sem dados ainda."}
          </p>
        ) : (
          <div className="space-y-2">
            {buckets.map((b) => {
              const pct = total > 0 ? Math.round((b.count / total) * 100) : 0;
              const widthPct = maxCount > 0 ? Math.round((b.count / maxCount) * 100) : 0;
              return (
                <div key={b.tag} className="flex items-center gap-2 text-sm">
                  <div className="w-24 shrink-0 truncate text-muted-foreground">
                    {OBJECTION_LABEL[b.tag]}
                  </div>
                  <div className="flex-1 h-2 rounded-sm bg-muted overflow-hidden">
                    <div
                      className="h-full bg-warning/60"
                      style={{ width: `${widthPct}%` }}
                    />
                  </div>
                  <div className="w-16 shrink-0 text-right font-mono text-xs text-muted-foreground">
                    {b.count} · {pct}%
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
