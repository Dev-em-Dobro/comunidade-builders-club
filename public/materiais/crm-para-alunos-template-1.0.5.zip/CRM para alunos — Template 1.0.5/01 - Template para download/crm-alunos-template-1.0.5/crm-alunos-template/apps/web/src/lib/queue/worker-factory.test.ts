import { describe, it, expect, afterAll } from "vitest";
import { Queue } from "bullmq";
import { createWorker } from "./worker-factory";
import { getQueueConnection, closeQueueConnection } from "./connection";
import type { QueueName } from "./types";

// Fila única por execução — não colide com os workers do app (que escutam só
// as filas nomeadas em QUEUE_NAMES) se o dev server estiver rodando em paralelo.
const TEST_QUEUE = `test-worker-factory-${Date.now()}` as QueueName;

afterAll(() => {
  closeQueueConnection();
});

describe("createWorker", () => {
  it("processa um job enfileirado", async () => {
    const queue = new Queue(TEST_QUEUE, { connection: getQueueConnection() });
    await queue.obliterate({ force: true });

    let received: string | undefined;
    const worker = createWorker<{ ping: string }>(TEST_QUEUE, async (job) => {
      received = job.data.ping;
    });
    await worker.waitUntilReady();

    // Listener ANTES do add — senão um job rápido completa antes de escutarmos.
    const completed = new Promise<void>((resolve) => {
      worker.once("completed", () => resolve());
    });

    await queue.add("test-job", { ping: "pong" });
    await completed;

    expect(received).toBe("pong");

    await worker.close();
    await queue.obliterate({ force: true });
    await queue.close();
  }, 15_000);
});
