import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { isOrphan, reapOrphans, ORPHAN_THRESHOLD_MS } from "./reaper";

// IDs criados neste arquivo — limpos no afterAll.
const createdReportIds: string[] = [];

afterAll(async () => {
  if (createdReportIds.length > 0) {
    await prisma.auditReport.deleteMany({ where: { id: { in: createdReportIds } } });
  }
  await prisma.$disconnect();
});

/** Cria um AuditReport com status e runAt controlados. */
async function mkReport(status: string, runAt: Date): Promise<string> {
  const r = await prisma.auditReport.create({
    data: { status, trigger: "manual", runAt },
  });
  createdReportIds.push(r.id);
  return r.id;
}

// ── isOrphan ──────────────────────────────────────────────────────────────────

describe("isOrphan", () => {
  it("retorna false para status != running (done)", () => {
    expect(isOrphan({ status: "done", runAt: new Date(0) })).toBe(false);
  });

  it("retorna false para status != running (queued)", () => {
    expect(isOrphan({ status: "queued", runAt: new Date(0) })).toBe(false);
  });

  it("retorna false para running recente (< threshold)", () => {
    const now = Date.now();
    const recentRunAt = new Date(now - ORPHAN_THRESHOLD_MS + 60_000); // 1min antes do threshold
    expect(isOrphan({ status: "running", runAt: recentRunAt }, now)).toBe(false);
  });

  it("retorna true para running > threshold", () => {
    const now = Date.now();
    const oldRunAt = new Date(now - ORPHAN_THRESHOLD_MS - 1); // 1ms além do threshold
    expect(isOrphan({ status: "running", runAt: oldRunAt }, now)).toBe(true);
  });

  it("retorna false para running exatamente no threshold (não excede, apenas iguala)", () => {
    const now = Date.now();
    const exactRunAt = new Date(now - ORPHAN_THRESHOLD_MS);
    // Exatamente no threshold NÃO é órfão (seria > e não >=).
    expect(isOrphan({ status: "running", runAt: exactRunAt }, now)).toBe(false);
  });
});

// ── reapOrphans ───────────────────────────────────────────────────────────────

describe("reapOrphans", () => {
  it("marca como error só o report running antigo, não o recente", async () => {
    const now = new Date();

    // Report running antigo (20 min atrás — além dos 15 min de threshold).
    const oldRunAt = new Date(now.getTime() - 20 * 60 * 1000);
    const oldId = await mkReport("running", oldRunAt);

    // Report running recente (2 min atrás — dentro dos 15 min).
    const recentRunAt = new Date(now.getTime() - 2 * 60 * 1000);
    const recentId = await mkReport("running", recentRunAt);

    const result = await reapOrphans(now);

    // Pelo menos 1 reaped (o antigo).
    expect(result.reaped).toBeGreaterThanOrEqual(1);

    const oldReport = await prisma.auditReport.findUniqueOrThrow({ where: { id: oldId } });
    expect(oldReport.status).toBe("error");
    expect(oldReport.errorMessage).toContain("reaper");
    expect(oldReport.finishedAt).not.toBeNull();

    const recentReport = await prisma.auditReport.findUniqueOrThrow({ where: { id: recentId } });
    expect(recentReport.status).toBe("running"); // não tocado
  });

  it("não toca reports done ou error", async () => {
    const oldDate = new Date(Date.now() - 60 * 60 * 1000); // 1h atrás

    const doneId = await mkReport("done", oldDate);
    const errorId = await mkReport("error", oldDate);

    await reapOrphans(new Date());

    const done = await prisma.auditReport.findUniqueOrThrow({ where: { id: doneId } });
    const error = await prisma.auditReport.findUniqueOrThrow({ where: { id: errorId } });
    expect(done.status).toBe("done");
    expect(error.status).toBe("error");
  });
});
