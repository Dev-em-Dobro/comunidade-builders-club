import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { parseSurveyCsv } from "@/lib/surveys/csv-parse";
import { findOrCreateContact } from "@/lib/surveys/find-or-create-contact";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_FILE_BYTES = 10 * 1024 * 1024; // 10MB

interface SkippedDetail {
  rowNumber: number;
  reason: string;
}

export async function POST(req: Request): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const form = await req.formData().catch(() => null);
  if (!form) {
    return NextResponse.json({ error: "invalid_form" }, { status: 400 });
  }

  const surveyName = (form.get("surveyName") as string | null)?.trim() ?? "";
  if (!surveyName || surveyName.length > 200) {
    return NextResponse.json({ error: "invalid_surveyName" }, { status: 400 });
  }

  const file = form.get("file");
  if (!(file instanceof Blob)) {
    return NextResponse.json({ error: "file_missing" }, { status: 400 });
  }
  if (file.size > MAX_FILE_BYTES) {
    return NextResponse.json({ error: "file_too_large" }, { status: 413 });
  }

  // Decode tentando UTF-8 primeiro; se vier replacement char (�), refaz como
  // windows-1252 (Latin-1) — CSVs do Excel brasileiro vêm nessa codificação.
  const buf = await file.arrayBuffer();
  let csv = new TextDecoder("utf-8", { fatal: false }).decode(buf);
  if (csv.includes("�")) {
    csv = new TextDecoder("windows-1252").decode(buf);
  }
  const { rows, errors } = parseSurveyCsv(csv);

  const skippedDetails: SkippedDetail[] = errors.map((e) => ({
    rowNumber: e.rowNumber,
    reason: e.reason,
  }));

  interface ToCreate {
    contactId: string;
    surveyName: string;
    answers: Record<string, string>;
    submittedAt: Date | null;
  }
  const toCreate: ToCreate[] = [];
  let matchedCount = 0;
  let createdCount = 0;

  for (const row of rows) {
    const r = await findOrCreateContact({
      phoneRaw: row.phoneRaw,
      emailRaw: row.emailRaw,
    });
    if (!r.contactId) {
      skippedDetails.push({
        rowNumber: row.rowNumber,
        reason: "linha sem email nem telefone válidos",
      });
      continue;
    }
    if (r.created) createdCount++;
    else matchedCount++;
    toCreate.push({
      contactId: r.contactId,
      surveyName,
      answers: row.answers,
      submittedAt: row.submittedAt,
    });
  }

  if (toCreate.length > 0) {
    // createMany em batches de 100 pra não estourar tamanho do statement.
    const BATCH = 100;
    for (let i = 0; i < toCreate.length; i += BATCH) {
      const chunk = toCreate.slice(i, i + BATCH);
      await prisma.surveyResponse.createMany({ data: chunk });
    }
  }

  const totalRows = rows.length + errors.length;
  return NextResponse.json({
    totalRows,
    matched: matchedCount,
    created: createdCount,
    skipped: skippedDetails.length,
    skippedDetails,
  });
}
