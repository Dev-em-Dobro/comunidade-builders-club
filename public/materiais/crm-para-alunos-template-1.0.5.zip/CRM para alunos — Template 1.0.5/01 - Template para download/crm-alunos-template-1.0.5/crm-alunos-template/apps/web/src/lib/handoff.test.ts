import { describe, it, expect } from "vitest";
import { rankAssignees, shouldEscalate } from "./handoff";

describe("rankAssignees", () => {
  const u = (id: string) => ({ id });

  it("operador nunca atribuído vem antes de quem já foi atribuído", () => {
    const users = [u("a"), u("b")];
    const events = [{ userId: "a", createdAt: new Date("2026-05-22T10:00:00Z") }];
    expect(rankAssignees(users, events).map((x) => x.id)).toEqual(["b", "a"]);
  });

  it("entre atribuídos, o mais antigo vem primeiro", () => {
    const users = [u("a"), u("b")];
    const events = [
      { userId: "a", createdAt: new Date("2026-05-22T12:00:00Z") },
      { userId: "b", createdAt: new Date("2026-05-22T09:00:00Z") },
    ];
    expect(rankAssignees(users, events).map((x) => x.id)).toEqual(["b", "a"]);
  });

  it("usa o evento mais recente de cada usuário", () => {
    const users = [u("a"), u("b")];
    const events = [
      { userId: "a", createdAt: new Date("2026-05-22T08:00:00Z") },
      { userId: "a", createdAt: new Date("2026-05-22T14:00:00Z") },
      { userId: "b", createdAt: new Date("2026-05-22T10:00:00Z") },
    ];
    // último de a = 14h, de b = 10h → b vem primeiro
    expect(rankAssignees(users, events).map((x) => x.id)).toEqual(["b", "a"]);
  });

  it("ignora eventos de usuários fora da lista", () => {
    const users = [u("a"), u("b")];
    const events = [
      { userId: "ghost", createdAt: new Date("2026-05-22T23:00:00Z") },
      { userId: "a", createdAt: new Date("2026-05-22T10:00:00Z") },
    ];
    // 'ghost' não está em users → ignorado; a foi atribuído, b não → b primeiro
    expect(rankAssignees(users, events).map((x) => x.id)).toEqual(["b", "a"]);
  });

  it("dois nunca atribuídos mantêm a ordem de entrada", () => {
    const users = [u("a"), u("b")];
    expect(rankAssignees(users, []).map((x) => x.id)).toEqual(["a", "b"]);
  });

  it("lista de usuários vazia → resultado vazio", () => {
    expect(rankAssignees([], [])).toEqual([]);
  });
});

describe("shouldEscalate", () => {
  const HANDOFF = new Date("2026-05-22T10:00:00Z");

  it("escala: handoff aberto e nunca aceito", () => {
    expect(
      shouldEscalate({ handoffRequested: true, handoffAt: HANDOFF, acceptedAt: null }),
    ).toBe(true);
  });

  it("não escala: handoff já resolvido (handoffRequested false)", () => {
    expect(
      shouldEscalate({ handoffRequested: false, handoffAt: HANDOFF, acceptedAt: null }),
    ).toBe(false);
  });

  it("não escala: aceito depois do handoff", () => {
    expect(
      shouldEscalate({
        handoffRequested: true,
        handoffAt: HANDOFF,
        acceptedAt: new Date("2026-05-22T10:05:00Z"),
      }),
    ).toBe(false);
  });

  it("escala: aceite anterior ao handoff (de um handoff antigo)", () => {
    expect(
      shouldEscalate({
        handoffRequested: true,
        handoffAt: HANDOFF,
        acceptedAt: new Date("2026-05-22T09:00:00Z"),
      }),
    ).toBe(true);
  });

  it("escala: handoff aberto sem registro de evento de handoff nem aceite", () => {
    expect(
      shouldEscalate({ handoffRequested: true, handoffAt: null, acceptedAt: null }),
    ).toBe(true);
  });

  it("não escala: aceito e sem registro de handoff", () => {
    expect(
      shouldEscalate({
        handoffRequested: true,
        handoffAt: null,
        acceptedAt: new Date("2026-05-22T10:05:00Z"),
      }),
    ).toBe(false);
  });
});
