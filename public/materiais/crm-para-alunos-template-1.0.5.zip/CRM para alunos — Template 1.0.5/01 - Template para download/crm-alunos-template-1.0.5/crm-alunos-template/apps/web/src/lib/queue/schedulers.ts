import { getQueue } from "./index";
import { REAP_INTERVAL_MS } from "@/lib/audit/reaper";

/** Intervalo do scan de janelas 24h. */
const SCAN_INTERVAL_MS = 15 * 60 * 1000;
/** Intervalo do scan de reengajamento (Parte 11). */
const REENGAGEMENT_INTERVAL_MS = 30 * 60 * 1000;
/** Intervalo do scan de follow-up fora da janela. */
const OUT_WINDOW_INTERVAL_MS = 30 * 60 * 1000;
/** Intervalo do cron de transições de lançamento (Oferta por lançamento). */
const LAUNCH_TRANSITION_INTERVAL_MS = 5 * 60 * 1000;

/**
 * Registra os job schedulers repetíveis do BullMQ.
 *
 * `upsertJobScheduler` é idempotente — atualiza o scheduler existente em vez
 * de duplicar, então é seguro chamar a cada boot do app.
 */
export async function registerSchedulers(): Promise<void> {
  await getQueue("window24h").upsertJobScheduler(
    "window24h-scan",
    { every: SCAN_INTERVAL_MS },
    {
      name: "scan",
      opts: { removeOnComplete: true, removeOnFail: 20 },
    },
  );
  await getQueue("reengagement").upsertJobScheduler(
    "reengagement-scan",
    { every: REENGAGEMENT_INTERVAL_MS },
    {
      name: "scan",
      opts: { removeOnComplete: true, removeOnFail: 20 },
    },
  );
  await getQueue("out-window-followup").upsertJobScheduler(
    "out-window-followup-scan",
    { every: OUT_WINDOW_INTERVAL_MS },
    { name: "scan", opts: { removeOnComplete: true, removeOnFail: 20 } },
  );
  // Reaper de AuditReports running órfãos — roda a cada REAP_INTERVAL_MS.
  await getQueue("audit").upsertJobScheduler(
    "audit-reap-cron",
    { every: REAP_INTERVAL_MS },
    {
      name: "audit.reap",
      opts: { removeOnComplete: true, removeOnFail: 20 },
    },
  );
  // Cron de transições de lançamento — ativa planned + encerra live por data.
  await getQueue("launch-transitions").upsertJobScheduler(
    "launch-transitions-scan",
    { every: LAUNCH_TRANSITION_INTERVAL_MS },
    { name: "scan", opts: { removeOnComplete: true, removeOnFail: 20 } },
  );
}
