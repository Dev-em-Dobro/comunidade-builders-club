import { prisma } from "@/lib/db";
import type { AIRule, AgentSession, Conversation } from "@prisma/client";
import type { ChannelMessage } from "@/lib/channels/types";

export type RuleMode =
  | "always_on"
  | "contact_whitelist"
  | "contact_blacklist"
  | "keyword_trigger"
  | "keyword_pause"
  | "schedule"
  | "manual_approval"
  | "human_takeover";

export type RuleAction = "respond" | "drop" | "handoff" | "static_reply";

export type Decision =
  | { action: "respond"; agentSession: AgentSession; reason?: string; ruleId?: string }
  | { action: "drop"; reason: string; ruleId?: string }
  | { action: "handoff"; reason: string; ruleId?: string; notice?: string }
  | { action: "static_reply"; text: string; ruleId?: string };

/**
 * Pipeline de decisão — chamado APÓS debounce flush e ANTES do LLM.
 *
 * Ordem de avaliação:
 *  1. Override manual: conversation.aiEnabled == false → drop
 *  2. AgentSession resolution (default fallback)
 *  3. Rules por priority (asc), short-circuit no primeiro match
 *  4. Default: respond com agentSession resolvida
 *
 * Loga `{ ruleId, decision, reason }` pra auditoria.
 */
/**
 * Lote inteiro é "suprimível" — registrar mas não auto-responder (ex.: reação
 * com emoji). Se vier QUALQUER texto real junto no mesmo lote, não suprime.
 */
export function isSuppressedBatch(msgs: ChannelMessage[]): boolean {
  return msgs.length > 0 && msgs.every((m) => m.suppressAutoReply === true);
}

export async function decideAction(
  msgs: ChannelMessage[],
  conv: Conversation,
): Promise<Decision> {
  // Reação (emoji) e afins: já persistidos na inbox; aqui só evitamos o
  // auto-reply (não puxar conversa por causa de um 👍). Drop, igual aos
  // outros guards silenciosos.
  if (isSuppressedBatch(msgs)) {
    log({ event: "rules.suppress_auto_reply", conversationId: conv.id });
    return { action: "drop", reason: "suppress_auto_reply" };
  }

  if (!conv.aiEnabled) {
    log({ event: "rules.short_circuit", conversationId: conv.id, reason: "aiEnabled=false" });
    return { action: "drop", reason: "conversation.aiEnabled=false" };
  }

  const agentSession = conv.agentSessionId
    ? await prisma.agentSession.findUnique({ where: { id: conv.agentSessionId } })
    : await prisma.agentSession.findFirst({ where: { isDefault: true } });
  if (!agentSession) {
    log({ event: "rules.no_agent", conversationId: conv.id });
    return { action: "drop", reason: "no_default_agent_session" };
  }

  const rules = await prisma.aIRule.findMany({
    where: { agentSessionId: agentSession.id, enabled: true },
    orderBy: { priority: "asc" },
  });

  for (const r of rules) {
    if (!evaluateRule(r, msgs, conv)) continue;
    log({
      event: "rules.match",
      conversationId: conv.id,
      ruleId: r.id,
      mode: r.mode,
      action: r.action,
    });
    if (r.action === "respond") return { action: "respond", agentSession, ruleId: r.id };
    if (r.action === "drop")    return { action: "drop", reason: `rule:${r.id}`, ruleId: r.id };
    if (r.action === "handoff") {
      return {
        action: "handoff",
        reason: `rule:${r.id}`,
        ruleId: r.id,
        // Aviso opcional enviado ao cliente antes de pausar a IA.
        notice: r.staticReply?.trim() || undefined,
      };
    }
    if (r.action === "static_reply") {
      return { action: "static_reply", text: r.staticReply ?? "", ruleId: r.id };
    }
  }

  // Trivial-loop guard: depois de uma conversa de fato (CTA já enviado ou
  // handoff já ocorrido), se as últimas trocas viraram só despedida/emoji,
  // drop silencioso pra não puxar conversa morta de novo. Prompt do closer
  // tem instrução parecida ("encerramento natural") mas o modelo escapa —
  // este guard é determinístico.
  if (await isTrivialChitchatLoop(conv.id, msgs)) {
    log({ event: "rules.trivial_loop_drop", conversationId: conv.id });
    return { action: "drop", reason: "trivial_chitchat_loop" };
  }

  log({ event: "rules.default_respond", conversationId: conv.id, agentSessionId: agentSession.id });
  return { action: "respond", agentSession };
}

// ───────────────────────── Trivial-loop detection ─────────────────────────

const TRIVIAL_WORDS = new Set([
  "ok", "okay", "blz", "beleza", "vlw", "valeu", "flw", "tmj",
  "abraço", "abraco", "abracos", "abraços", "abs",
  "tchau", "ate", "até", "ate mais", "até mais", "atemais",
  "tá", "ta", "tá bom", "ta bom", "tabom",
  "sim", "nao", "não",
  "obrigado", "obrigada", "obg",
  "bjs", "bj", "bjss",
]);

/** Texto vazio/emoji-only/palavra trivial/despedida curta. */
function isTrivialText(raw: string | null | undefined): boolean {
  if (!raw) return true;
  const t = raw.trim();
  if (t.length === 0) return true;
  // Só pictográficos + espaços/pontuação (emoji, símbolos como 👍 😄 🙏).
  if (/^[\s\p{Extended_Pictographic}\p{Emoji_Component}\p{Symbol}\p{Punctuation}]+$/u.test(t)) {
    return true;
  }
  if (t.length <= 5) return true;
  const lower = t.toLowerCase().replace(/[!.?,]/g, "").trim();
  if (TRIVIAL_WORDS.has(lower)) return true;
  // "ok valeu", "tá obrigado" — 2 palavras triviais coladas.
  const parts = lower.split(/\s+/);
  if (parts.length <= 3 && parts.every((p) => TRIVIAL_WORDS.has(p))) return true;
  return false;
}

/**
 * Detecta loop de chitchat trivial: a conversa já passou do fechamento
 * (handoff ocorreu OU link/promo já enviada) e as últimas 4 mensagens
 * (2 outbound + 2 inbound) são todas triviais. Inclui a nova msg atual.
 */
async function isTrivialChitchatLoop(
  conversationId: string,
  newMsgs: ChannelMessage[],
): Promise<boolean> {
  // Nova msg do lead precisa ser trivial pra começar a analisar.
  const newText = newMsgs.map((m) => m.text).join(" ").trim();
  if (!isTrivialText(newText)) return false;

  // Histórico recente, ordem desc pra pegar os últimos rapidinho.
  const history = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: "desc" },
    take: 6,
    select: { direction: true, text: true },
  });
  // Conversa muito curta — não é loop de fechamento, é só começo.
  if (history.length < 4) return false;

  // Sinal de "já fechou": tem ao menos uma outbound do passado que NÃO é trivial
  // (significa que o bot já fez trabalho real — pitch, link, agendamento, etc).
  const hadRealOutbound = history.some(
    (m) => m.direction === "outbound" && !isTrivialText(m.text),
  );
  if (!hadRealOutbound) return false;

  // Últimas 2 outbound + 2 inbound (já existentes) todas triviais.
  const lastOutbounds = history.filter((m) => m.direction === "outbound").slice(0, 2);
  const lastInbounds = history.filter((m) => m.direction === "inbound").slice(0, 2);
  if (lastOutbounds.length < 2 || lastInbounds.length < 2) return false;

  return (
    lastOutbounds.every((m) => isTrivialText(m.text)) &&
    lastInbounds.every((m) => isTrivialText(m.text))
  );
}

function evaluateRule(rule: AIRule, msgs: ChannelMessage[], conv: Conversation): boolean {
  const p = (rule.params ?? {}) as Record<string, unknown>;
  switch (rule.mode as RuleMode) {
    case "always_on":
      return true;
    case "contact_whitelist": {
      const ids = (p.contactIds as string[] | undefined) ?? [];
      return ids.includes(conv.contactId);
    }
    case "contact_blacklist": {
      const ids = (p.contactIds as string[] | undefined) ?? [];
      return ids.includes(conv.contactId);
    }
    case "keyword_trigger":
    case "keyword_pause":
      return matchesKeywords(p, msgs);
    case "schedule":
      return insideSchedule(p, new Date());
    case "human_takeover":
      // Sem acesso a histórico aqui — flush.ts checa antes; placeholder.
      return false;
    case "manual_approval":
      // Sempre aplica — flush.ts não vai chamar LLM, vai abrir ticket.
      return true;
    default:
      return false;
  }
}

function matchesKeywords(
  p: Record<string, unknown>,
  msgs: ChannelMessage[],
): boolean {
  const keywords = (p.keywords as string[] | undefined) ?? [];
  if (!keywords.length) return false;
  const matchMode = (p.matchMode as "any" | "all" | undefined) ?? "any";
  const caseSensitive = !!p.caseSensitive;
  const haystack = msgs
    .map((m) => (caseSensitive ? m.text : m.text.toLowerCase()))
    .join("\n");
  const needles = keywords.map((k) => (caseSensitive ? k : k.toLowerCase()));
  return matchMode === "all"
    ? needles.every((n) => haystack.includes(n))
    : needles.some((n) => haystack.includes(n));
}

function insideSchedule(p: Record<string, unknown>, now: Date): boolean {
  const tz = (p.timezone as string | undefined) ?? "America/Sao_Paulo";
  const days = (p.days as number[] | undefined) ?? [0, 1, 2, 3, 4, 5, 6];
  const start = (p.start as string | undefined) ?? "00:00";
  const end = (p.end as string | undefined) ?? "23:59";

  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: tz,
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(now);
  const wd = parts.find((p) => p.type === "weekday")?.value;
  const hh = parts.find((p) => p.type === "hour")?.value ?? "00";
  const mm = parts.find((p) => p.type === "minute")?.value ?? "00";
  const minutesNow = Number(hh) * 60 + Number(mm);
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  const minutesStart = sh * 60 + sm;
  const minutesEnd = eh * 60 + em;

  const WD = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 } as const;
  const dayIdx = wd ? (WD as Record<string, number>)[wd] ?? -1 : -1;
  if (!days.includes(dayIdx)) return false;
  return minutesNow >= minutesStart && minutesNow <= minutesEnd;
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
