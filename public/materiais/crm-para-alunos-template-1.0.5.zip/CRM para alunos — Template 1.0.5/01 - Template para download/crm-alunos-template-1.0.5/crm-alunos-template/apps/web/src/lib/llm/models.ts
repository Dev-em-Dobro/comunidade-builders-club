/**
 * Modelos disponíveis por provedor, pro seletor do agente. Só servidor.
 *
 * A lista vem da conta do provedor (models.list() dos SDKs) com a chave salva
 * em Chaves de API — assim só aparecem modelos que existem e que a chave pode
 * usar. Sem chave ou com erro, cai numa lista de reserva curta.
 */
import Anthropic from "@anthropic-ai/sdk";
import OpenAI from "openai";
import { resolveProviderKey } from "./keys";

export interface ModelOption {
  id: string;
  label: string;
}

export interface ProviderModels {
  provider: string;
  /** "api" = lista da conta; "fallback" = lista de reserva (sem chave ou erro). */
  source: "api" | "fallback";
  models: ModelOption[];
}

/**
 * Recomendados primeiro, na ordem e com o rótulo daqui. O PRIMEIRO de cada
 * provedor é o padrão de um agente novo: o de melhor custo-benefício. É só
 * sugestão — quem configura o agente escolhe qualquer modelo da lista, e
 * agentes existentes nunca têm o modelo trocado.
 */
const RECOMMENDED: Record<string, ModelOption[]> = {
  anthropic: [
    { id: "claude-haiku-5-5", label: "Claude Haiku 5.5 — melhor custo-benefício (padrão)" },
    { id: "claude-sonnet-5-5", label: "Claude Sonnet 5.5 — equilibrado" },
    { id: "claude-opus-5-5", label: "Claude Opus 5.5 — mais capaz, mais caro" },
  ],
  openai: [
    { id: "gpt-4.1-mini", label: "GPT-4.1 mini — melhor custo-benefício (padrão)" },
    { id: "gpt-5-mini", label: "GPT-5 mini" },
    { id: "gpt-5", label: "GPT-5 — mais capaz, mais caro" },
  ],
};

export const PROVIDERS = Object.keys(RECOMMENDED);

/** Só modelos de chat — a conta da OpenAI também lista áudio, imagem, embeddings… */
export function isOpenAIChatModel(id: string): boolean {
  if (!/^(gpt-|o\d|chatgpt-)/i.test(id)) return false;
  return !/(audio|realtime|transcribe|tts|image|embed|moderation|search|instruct|whisper|dall-e|computer-use)/i.test(id);
}

/** Recomendados (os que existirem na conta) primeiro, depois o resto. */
export function orderModels(provider: string, available: ModelOption[]): ModelOption[] {
  const byId = new Map(available.map((m) => [m.id, m]));
  const top = (RECOMMENDED[provider] ?? []).filter((r) => byId.has(r.id));
  const topIds = new Set(top.map((m) => m.id));
  return [...top, ...available.filter((m) => !topIds.has(m.id))];
}

async function listAnthropic(apiKey: string): Promise<ModelOption[]> {
  const client = new Anthropic({ apiKey, timeout: 8_000, maxRetries: 0 });
  const out: { id: string; label: string; created: number }[] = [];
  for await (const m of client.models.list()) {
    out.push({ id: m.id, label: `${m.display_name} (${m.id})`, created: Date.parse(m.created_at) || 0 });
  }
  out.sort((a, b) => b.created - a.created);
  return out.map(({ id, label }) => ({ id, label }));
}

async function listOpenAI(apiKey: string): Promise<ModelOption[]> {
  const client = new OpenAI({ apiKey, timeout: 8_000, maxRetries: 0 });
  const out: { id: string; created: number }[] = [];
  for await (const m of client.models.list()) {
    if (isOpenAIChatModel(m.id)) out.push({ id: m.id, created: m.created ?? 0 });
  }
  out.sort((a, b) => b.created - a.created);
  return out.map(({ id }) => ({ id, label: id }));
}

const TTL_MS = 10 * 60_000;
const cache = new Map<string, { at: number; value: ProviderModels }>();

function fallback(provider: string): ProviderModels {
  return { provider, source: "fallback", models: RECOMMENDED[provider] ?? [] };
}

export async function providerModels(provider: string): Promise<ProviderModels> {
  const hit = cache.get(provider);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;

  const apiKey = await resolveProviderKey(provider).catch(() => undefined);
  if (!apiKey) return fallback(provider);
  try {
    const list = provider === "anthropic" ? await listAnthropic(apiKey) : await listOpenAI(apiKey);
    if (!list.length) return fallback(provider);
    const labels = new Map((RECOMMENDED[provider] ?? []).map((m) => [m.id, m.label]));
    const value: ProviderModels = {
      provider,
      source: "api",
      models: orderModels(
        provider,
        list.map((m) => ({ id: m.id, label: labels.get(m.id) ?? m.label })),
      ),
    };
    cache.set(provider, { at: Date.now(), value });
    return value;
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "llm.models_list_failed",
        provider,
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
    return fallback(provider);
  }
}

/** Modelos de todos os provedores (em paralelo), pro formulário do agente. */
export async function allProviderModels(): Promise<Record<string, ProviderModels>> {
  const lists = await Promise.all(PROVIDERS.map((p) => providerModels(p)));
  return Object.fromEntries(lists.map((l) => [l.provider, l]));
}
