import { prisma } from "@/lib/db";
import { findOverlappingLive } from "./validation";
import { invalidateActiveLaunch } from "./active";

export type TransitionReason = "manual" | "cron_start" | "cron_end";

export interface ActivateInput {
  launchId: string;
  byUserId: string | null;
  reason: TransitionReason;
}

export type TransitionResult =
  | { ok: true }
  | { ok: false; error: string; conflict?: { id: string; name: string } };

/** planned → live. Aplica validações do spec. */
export async function activateLaunch(input: ActivateInput): Promise<TransitionResult> {
  const launch = await prisma.launch.findUnique({ where: { id: input.launchId } });
  if (!launch) return { ok: false, error: "Lançamento não encontrado" };
  if (launch.status === "live") return { ok: false, error: "Lançamento já está live" };
  if (!launch.courseId) return { ok: false, error: "Lançamento sem curso atribuído" };

  const planCount = await prisma.launchPlan.count({ where: { launchId: launch.id } });
  if (planCount < 1) return { ok: false, error: "Lançamento sem nenhum plano cadastrado" };

  const now = new Date();
  if (launch.endsAt <= now) return { ok: false, error: "Lançamento com fim no passado" };

  const conflict = await findOverlappingLive({
    courseId: launch.courseId,
    startsAt: launch.startsAt,
    endsAt: launch.endsAt,
    excludeLaunchId: launch.id,
  });
  if (conflict) {
    return { ok: false, error: `Conflito com lançamento live: ${conflict.name}`, conflict };
  }

  const data: { status: string; startsAt?: Date } = { status: "live" };
  if (input.reason === "manual" && launch.startsAt > now) {
    data.startsAt = now;
  }

  await prisma.$transaction(async (tx) => {
    await tx.launch.update({ where: { id: launch.id }, data });
    await tx.launchStatusChange.create({
      data: {
        launchId: launch.id,
        fromStatus: launch.status,
        toStatus: "live",
        byUserId: input.byUserId ?? undefined,
        reason: input.reason,
      },
    });
  });

  invalidateActiveLaunch(launch.courseId);
  return { ok: true };
}

export interface CloseInput {
  launchId: string;
  byUserId: string | null;
  reason: TransitionReason;
}

/** live → closed. Cron seta automático quando endsAt passa; manual move endsAt=now. */
export async function closeLaunch(input: CloseInput): Promise<TransitionResult> {
  const launch = await prisma.launch.findUnique({ where: { id: input.launchId } });
  if (!launch) return { ok: false, error: "Lançamento não encontrado" };
  if (launch.status === "closed") return { ok: false, error: "Lançamento já está closed" };

  const data: { status: string; endsAt?: Date } = { status: "closed" };
  if (input.reason === "manual") {
    data.endsAt = new Date();
  }

  await prisma.$transaction(async (tx) => {
    await tx.launch.update({ where: { id: launch.id }, data });
    await tx.launchStatusChange.create({
      data: {
        launchId: launch.id,
        fromStatus: launch.status,
        toStatus: "closed",
        byUserId: input.byUserId ?? undefined,
        reason: input.reason,
      },
    });
  });

  if (launch.courseId) invalidateActiveLaunch(launch.courseId);
  return { ok: true };
}
