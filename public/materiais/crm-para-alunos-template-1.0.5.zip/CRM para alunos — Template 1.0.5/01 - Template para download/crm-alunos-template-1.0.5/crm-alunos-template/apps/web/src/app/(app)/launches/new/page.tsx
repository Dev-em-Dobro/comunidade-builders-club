import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { auth } from "@/auth";
import { LaunchForm } from "../launch-form";

export default async function NewLaunchPage() {
  const session = await auth();
  if ((session?.user as { role?: string } | undefined)?.role !== "admin") {
    redirect("/launches");
  }

  const courses = await prisma.course.findMany({
    where: { active: true },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Novo lançamento
        </h1>
        <p className="text-muted-foreground mt-1">
          Janela comercial de um curso — início, fim e status.
        </p>
      </header>
      <LaunchForm courses={courses} />
    </div>
  );
}
