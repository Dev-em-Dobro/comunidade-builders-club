import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ reportId: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { reportId } = await params;
  const r = await prisma.auditReport.findUnique({
    where: { id: reportId },
    select: { status: true, finishedAt: true },
  });
  if (!r) return NextResponse.json({ error: "not_found" }, { status: 404 });
  return NextResponse.json({
    status: r.status,
    finishedAt: r.finishedAt?.toISOString() ?? null,
  });
}
