import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@/lib/db", () => ({
  prisma: {
    conversation: { findFirst: vi.fn(), create: vi.fn() },
    agentSession: { findFirst: vi.fn() },
  },
}));

import { prisma } from "@/lib/db";
import { ensureConversation } from "./ensure-conversation";

const mockPrisma = prisma as unknown as {
  conversation: { findFirst: ReturnType<typeof vi.fn>; create: ReturnType<typeof vi.fn> };
  agentSession: { findFirst: ReturnType<typeof vi.fn> };
};

beforeEach(() => {
  vi.clearAllMocks();
  mockPrisma.agentSession.findFirst.mockResolvedValue({ id: "agent_default" });
  mockPrisma.conversation.create.mockImplementation((args: { data: Record<string, unknown> }) =>
    Promise.resolve({ id: "conv_new", ...args.data }),
  );
});

describe("ensureConversation", () => {
  it("firstEver=false e não cria quando já existe conversa no canal", async () => {
    mockPrisma.conversation.findFirst.mockResolvedValueOnce({
      id: "conv_existing",
      contactId: "c1",
      channel: "whatsapp_cloud",
    });

    const { conv, firstEver } = await ensureConversation("c1", "whatsapp_cloud");

    expect(firstEver).toBe(false);
    expect(conv.id).toBe("conv_existing");
    expect(mockPrisma.conversation.create).not.toHaveBeenCalled();
  });

  it("firstEver=true quando o contato não tem NENHUMA conversa", async () => {
    // 1ª chamada (canal atual) → null; 2ª chamada (qualquer canal) → null
    mockPrisma.conversation.findFirst
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce(null);

    const { conv, firstEver } = await ensureConversation("c1", "whatsapp_cloud");

    expect(firstEver).toBe(true);
    expect(conv.channel).toBe("whatsapp_cloud");
    expect(mockPrisma.conversation.create).toHaveBeenCalledTimes(1);
  });

  it("firstEver=false quando há conversa em OUTRO canal", async () => {
    // 1ª chamada (canal atual) → null; 2ª chamada (qualquer canal) → existe
    mockPrisma.conversation.findFirst
      .mockResolvedValueOnce(null)
      .mockResolvedValueOnce({ id: "conv_other" });

    const { firstEver } = await ensureConversation("c1", "instagram");

    expect(firstEver).toBe(false);
    expect(mockPrisma.conversation.create).toHaveBeenCalledTimes(1);
  });
});
