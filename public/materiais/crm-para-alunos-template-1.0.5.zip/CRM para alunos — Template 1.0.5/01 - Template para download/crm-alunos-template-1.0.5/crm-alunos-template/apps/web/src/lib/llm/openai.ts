import OpenAI from "openai";
import type { LLMProvider, LLMRequest, LLMResponse } from "./types";

function getClient(overrideKey?: string): OpenAI {
  const apiKey = overrideKey ?? process.env.OPENAI_API_KEY;
  if (!apiKey) {
    throw new Error("OPENAI_API_KEY ausente ou chave não configurada em Chaves de API.");
  }
  return new OpenAI({ apiKey });
}

// gpt-5* só aceita a temperature padrão; enviar 0.7 dá 400. Omitir nesses casos.
function supportsCustomTemperature(model: string): boolean {
  return !/^gpt-5/i.test(model);
}

type ReasoningEffort = "none" | "minimal" | "low" | "medium" | "high";

// gpt-5* são modelos de reasoning, e o menor esforço aceito depende da geração:
//  - gpt-5.x (gpt-5.1, gpt-5.6-luna…): em /v1/chat/completions, reasoning +
//    function tools dá 400 ("set reasoning_effort to 'none'"). As tools são
//    essenciais (request_handoff, checkout, agendamento), então mandamos "none"
//    (incidente 2026-08-20).
//  - gpt-5 / gpt-5-mini / gpt-5-nano (1ª geração, com ou sem data): NÃO aceitam
//    "none" ("Supported values are: 'minimal', 'low', 'medium', and 'high'") —
//    o menor é "minimal", que funciona com tools (incidente 2026-11-14).
export function reasoningEffortFor(model: string): ReasoningEffort | undefined {
  if (!/^gpt-5/i.test(model)) return undefined;
  if (/^gpt-5(-mini|-nano)?(-\d{4}-\d{2}-\d{2})?$/i.test(model)) return "minimal";
  return "none";
}

/**
 * Se a OpenAI recusou o reasoning_effort com 400, devolve o valor pra tentar de
 * novo (lido da própria mensagem de erro): `null` = mandar sem o parâmetro,
 * `undefined` = não é esse erro, não tenta de novo.
 */
export function reasoningEffortRetry(err: unknown, sent: ReasoningEffort): ReasoningEffort | null | undefined {
  const status = (err as { status?: number })?.status;
  const message = String((err as Error)?.message ?? "");
  if (status !== 400 || !/reasoning_effort/i.test(message)) return undefined;
  const supported = /Supported values are:([^.]*)/i.exec(message)?.[1] ?? "";
  for (const candidate of ["minimal", "none", "low"] as const) {
    if (candidate !== sent && supported.includes(`'${candidate}'`)) return candidate;
  }
  if (sent !== "none" && /reasoning_effort to 'none'/i.test(message)) return "none";
  return null;
}

function safeJsonParse(s: string): Record<string, unknown> {
  try {
    const v = JSON.parse(s);
    return v && typeof v === "object" ? (v as Record<string, unknown>) : {};
  } catch {
    return {};
  }
}

export const openaiProvider: LLMProvider = {
  id: "openai",

  async generateReply(req: LLMRequest): Promise<LLMResponse> {
    const client = getClient(req.apiKey);

    const systemContent = req.systemDynamic
      ? `${req.systemStatic}\n\n${req.systemDynamic}`
      : req.systemStatic;

    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: "system", content: systemContent },
    ];

    for (const m of req.messages) {
      if (m.role === "assistant" && m.toolUse) {
        messages.push({
          role: "assistant",
          content: m.content && m.content.length > 0 ? m.content : null,
          tool_calls: [
            {
              id: m.toolUse.id,
              type: "function",
              function: { name: m.toolUse.name, arguments: JSON.stringify(m.toolUse.input) },
            },
          ],
        });
        continue;
      }
      if (m.role === "tool") {
        if (!m.toolResult) {
          throw new Error("openai adapter: tool turn missing toolResult");
        }
        messages.push({
          role: "tool",
          tool_call_id: m.toolResult.toolUseId,
          content: m.toolResult.content,
        });
        continue;
      }
      messages.push({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      });
    }

    const tools: OpenAI.Chat.Completions.ChatCompletionTool[] | undefined = req.tools?.map(
      (t) => ({
        type: "function",
        function: { name: t.name, description: t.description, parameters: t.inputSchema },
      }),
    );

    const toolChoice: OpenAI.Chat.Completions.ChatCompletionToolChoiceOption | undefined =
      req.toolChoice?.type === "tool"
        ? { type: "function", function: { name: req.toolChoice.name } }
        : req.toolChoice?.type === "auto"
          ? "auto"
          : undefined;

    const create = (effort: ReasoningEffort | undefined) =>
      client.chat.completions.create({
        model: req.model,
        ...(supportsCustomTemperature(req.model)
          ? { temperature: req.temperature ?? 0.7 }
          : {}),
        ...(effort ? { reasoning_effort: effort } : {}),
        max_completion_tokens: req.maxTokens ?? 1024,
        messages,
        ...(tools ? { tools } : {}),
        ...(toolChoice ? { tool_choice: toolChoice } : {}),
      });

    const effort = reasoningEffortFor(req.model);
    let resp: OpenAI.Chat.Completions.ChatCompletion;
    try {
      resp = await create(effort);
    } catch (err) {
      // Modelo novo com regra diferente de reasoning_effort: tenta 1x com o
      // valor que a própria API diz aceitar, em vez de deixar o lead sem resposta.
      const retry = effort ? reasoningEffortRetry(err, effort) : undefined;
      if (retry === undefined) throw err;
      console.log(
        JSON.stringify({
          event: "llm.openai.reasoning_effort_retry",
          model: req.model,
          sent: effort,
          retry: retry ?? "omitted",
          at: new Date().toISOString(),
        }),
      );
      resp = await create(retry ?? undefined);
    }

    const message = resp.choices[0]?.message;
    const text = (message?.content ?? "").trim();

    const toolUses = (message?.tool_calls ?? [])
      .filter(
        (tc): tc is OpenAI.Chat.Completions.ChatCompletionMessageToolCall & { type: "function" } =>
          tc.type === "function",
      )
      .map((tc) => ({
        id: tc.id,
        name: tc.function.name,
        input: safeJsonParse(tc.function.arguments),
      }));

    return {
      text,
      modelUsed: resp.model,
      tokensIn: resp.usage?.prompt_tokens ?? 0,
      tokensOut: resp.usage?.completion_tokens ?? 0,
      toolUses: toolUses.length ? toolUses : undefined,
      raw: resp,
    };
  },
};
