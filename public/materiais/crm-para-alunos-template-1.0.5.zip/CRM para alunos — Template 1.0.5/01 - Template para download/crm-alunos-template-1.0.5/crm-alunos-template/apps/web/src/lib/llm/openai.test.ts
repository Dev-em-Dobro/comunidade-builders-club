import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock do SDK openai: captura o payload enviado e devolve uma resposta controlada.
const createMock = vi.fn();
vi.mock("openai", () => ({
  default: class {
    chat = { completions: { create: createMock } };
    constructor(_opts: unknown) {}
  },
}));

import { openaiProvider, reasoningEffortFor } from "./openai";
import type { LLMRequest } from "./types";

beforeEach(() => createMock.mockReset());

function baseReq(overrides: Partial<LLMRequest> = {}): LLMRequest {
  return {
    model: "gpt-5-mini",
    systemStatic: "Você é um SDR.",
    systemDynamic: "Contexto: lead novo.",
    messages: [{ role: "user", content: "oi" }],
    apiKey: "sk-test",
    ...overrides,
  };
}

describe("openaiProvider.generateReply", () => {
  it("junta systemStatic+systemDynamic numa mensagem system e mapeia o histórico", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "olá!", tool_calls: undefined } }],
      usage: { prompt_tokens: 10, completion_tokens: 5 },
    });

    const resp = await openaiProvider.generateReply(baseReq());

    const payload = createMock.mock.calls[0][0];
    expect(payload.messages[0]).toEqual({
      role: "system",
      content: "Você é um SDR.\n\nContexto: lead novo.",
    });
    expect(payload.messages[1]).toEqual({ role: "user", content: "oi" });
    expect(resp.text).toBe("olá!");
    expect(resp.tokensIn).toBe(10);
    expect(resp.tokensOut).toBe(5);
  });

  it("traduz LLMToolDef → function tool e toolChoice forçado", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });

    await openaiProvider.generateReply(
      baseReq({
        tools: [{ name: "request_handoff", description: "escala p/ humano", inputSchema: { type: "object", properties: {} } }],
        toolChoice: { type: "tool", name: "request_handoff" },
      }),
    );

    const payload = createMock.mock.calls[0][0];
    expect(payload.tools[0]).toEqual({
      type: "function",
      function: { name: "request_handoff", description: "escala p/ humano", parameters: { type: "object", properties: {} } },
    });
    expect(payload.tool_choice).toEqual({ type: "function", function: { name: "request_handoff" } });
  });

  it("mapeia turns toolUse/toolResult para o formato OpenAI", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "pronto", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });

    await openaiProvider.generateReply(
      baseReq({
        messages: [
          { role: "user", content: "quero o link" },
          {
            role: "assistant",
            content: "",
            toolUse: { id: "call_1", name: "get_checkout_link", input: { courseId: "c1" } },
          },
          {
            role: "tool",
            content: "",
            toolResult: { toolUseId: "call_1", content: '{"url":"http://x"}' },
          },
        ],
      }),
    );

    const msgs = createMock.mock.calls[0][0].messages;
    // [0] system, [1] user, [2] assistant com tool_calls, [3] tool
    expect(msgs[2]).toEqual({
      role: "assistant",
      content: null,
      tool_calls: [
        { id: "call_1", type: "function", function: { name: "get_checkout_link", arguments: '{"courseId":"c1"}' } },
      ],
    });
    expect(msgs[3]).toEqual({ role: "tool", tool_call_id: "call_1", content: '{"url":"http://x"}' });
  });

  it("parseia tool_calls da resposta em toolUses (arguments malformado → {})", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [
        {
          message: {
            content: null,
            tool_calls: [
              { id: "call_9", type: "function", function: { name: "flagReadyToBuy", arguments: "not-json" } },
            ],
          },
        },
      ],
      usage: { prompt_tokens: 2, completion_tokens: 3 },
    });

    const resp = await openaiProvider.generateReply(baseReq());
    expect(resp.toolUses).toEqual([{ id: "call_9", name: "flagReadyToBuy", input: {} }]);
    expect(resp.text).toBe("");
  });

  it("usa max_completion_tokens (não max_tokens) no payload", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });

    await openaiProvider.generateReply(baseReq({ maxTokens: 512 }));

    const payload = createMock.mock.calls[0][0];
    expect(payload.max_completion_tokens).toBe(512);
    expect(payload.max_tokens).toBeUndefined();
  });

  it("turn tool sem toolResult lança (bug do caller)", async () => {
    await expect(
      openaiProvider.generateReply(
        baseReq({ messages: [{ role: "tool", content: "" }] }),
      ),
    ).rejects.toThrow(/toolResult/);
  });

  it("envia temperature para modelos que aceitam (gpt-4o-mini)", async () => {
    createMock.mockResolvedValue({
      model: "gpt-4o-mini",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    await openaiProvider.generateReply(baseReq({ model: "gpt-4o-mini" }));
    expect(createMock.mock.calls[0][0].temperature).toBe(0.7);
  });

  it("omite temperature para gpt-5*", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5-mini",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    await openaiProvider.generateReply(baseReq({ model: "gpt-5-mini" }));
    expect(createMock.mock.calls[0][0].temperature).toBeUndefined();
  });

  // Regressão do incidente 2026-08-20: gpt-5.6-luna (reasoning) + function tools
  // em /v1/chat/completions retorna 400 ("Function tools with reasoning_effort
  // are not supported ... set reasoning_effort to 'none'"). Sem tolerância: como
  // as tools são essenciais (handoff/checkout), desligamos o reasoning nesses
  // modelos — senão TODA resposta do bot com tools engasga e o lead fica sem
  // resposta.
  it("desliga reasoning_effort para gpt-5* (senão tools dão 400)", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5.6-luna",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    await openaiProvider.generateReply(
      baseReq({
        model: "gpt-5.6-luna",
        tools: [{ name: "request_handoff", description: "escala", inputSchema: { type: "object", properties: {} } }],
      }),
    );
    expect(createMock.mock.calls[0][0].reasoning_effort).toBe("none");
  });

  // Incidente 2026-11-14: gpt-5 (1ª geração) não aceita "none" — o agente de
  // agendamento ficou sem responder. O menor esforço dele é "minimal".
  it("usa reasoning_effort 'minimal' no gpt-5 de 1ª geração (com tools)", async () => {
    createMock.mockResolvedValue({
      model: "gpt-5",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    await openaiProvider.generateReply(
      baseReq({
        model: "gpt-5",
        tools: [{ name: "check_availability", description: "horários", inputSchema: { type: "object", properties: {} } }],
      }),
    );
    expect(createMock.mock.calls[0][0].reasoning_effort).toBe("minimal");
  });

  it("escolhe o reasoning_effort pela geração do gpt-5", () => {
    expect(reasoningEffortFor("gpt-5")).toBe("minimal");
    expect(reasoningEffortFor("gpt-5-mini")).toBe("minimal");
    expect(reasoningEffortFor("gpt-5-nano-2025-08-07")).toBe("minimal");
    expect(reasoningEffortFor("gpt-5.1")).toBe("none");
    expect(reasoningEffortFor("gpt-5.6-luna")).toBe("none");
    expect(reasoningEffortFor("gpt-4.1-mini")).toBeUndefined();
  });

  it("se a API recusar o reasoning_effort, tenta 1x com o valor que ela aceita", async () => {
    const rejected = Object.assign(
      new Error(
        "400 Unsupported value: 'reasoning_effort' does not support 'none' with this model. Supported values are: 'minimal', 'low', 'medium', and 'high'.",
      ),
      { status: 400 },
    );
    createMock.mockRejectedValueOnce(rejected).mockResolvedValueOnce({
      model: "gpt-5.9-novo",
      choices: [{ message: { content: "Olá! Posso ajudar.", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    const resp = await openaiProvider.generateReply(baseReq({ model: "gpt-5.9-novo" }));
    expect(createMock).toHaveBeenCalledTimes(2);
    expect(createMock.mock.calls[0][0].reasoning_effort).toBe("none");
    expect(createMock.mock.calls[1][0].reasoning_effort).toBe("minimal");
    expect(resp.text).toBe("Olá! Posso ajudar.");
  });

  it("não tenta de novo em erros que não são de reasoning_effort", async () => {
    createMock.mockRejectedValueOnce(Object.assign(new Error("401 Incorrect API key"), { status: 401 }));
    await expect(openaiProvider.generateReply(baseReq({ model: "gpt-5" }))).rejects.toThrow(/401/);
    expect(createMock).toHaveBeenCalledTimes(1);
  });

  it("não seta reasoning_effort para modelos não-reasoning (gpt-4o-mini)", async () => {
    createMock.mockResolvedValue({
      model: "gpt-4o-mini",
      choices: [{ message: { content: "ok", tool_calls: undefined } }],
      usage: { prompt_tokens: 1, completion_tokens: 1 },
    });
    await openaiProvider.generateReply(baseReq({ model: "gpt-4o-mini" }));
    expect(createMock.mock.calls[0][0].reasoning_effort).toBeUndefined();
  });
});
