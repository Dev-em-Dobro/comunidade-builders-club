import { describe, it, expect, beforeAll, afterAll, vi, beforeEach } from "vitest";
import type { Job } from "bullmq";
import { prisma } from "@/lib/db";

vi.mock("@/lib/realtime/notify", () => ({
  notifyConvEvent: vi.fn().mockResolvedValue(undefined),
}));

import { windowWarningProcessor } from "./window-warning";
import { notifyConvEvent } from "@/lib/realtime/notify";

const created = { contactIds: [] as string[], userIds: [] as string[] };
let onDutyA: string;
let onDutyB: string;
let offDuty: string;
let convFar: string;
let convClosed: string;

beforeAll(async () => {
  const a = await prisma.user.create({
    data: {
      email: `ww-a-${Date.now()}@t.local`,
      name: "On Duty A",
      isOnDuty: true,
    },
  });
  const b = await prisma.user.create({
    data: {
      email: `ww-b-${Date.now()}@t.local`,
      name: "On Duty B",
      isOnDuty: true,
    },
  });
  const c = await prisma.user.create({
    data: {
      email: `ww-c-${Date.now()}@t.local`,
      name: "Off Duty",
      isOnDuty: false,
    },
  });
  onDutyA = a.id;
  onDutyB = b.id;
  offDuty = c.id;
  created.userIds.push(a.id, b.id, c.id);

  const contact1 = await prisma.contact.create({ data: { displayName: "Far" } });
  const contact2 = await prisma.contact.create({ data: { displayName: "Closed" } });
  created.contactIds.push(contact1.id, contact2.id);

  // conversa com janela fechando em ~30min (dentro do range 0–65min)
  const c1 = await prisma.conversation.create({
    data: {
      contactId: contact1.id,
      channel: "whatsapp_cloud",
      windowClosesAt: new Date(Date.now() + 30 * 60_000),
    },
  });
  convFar = c1.id;
  // conversa com janela já fechada
  const c2 = await prisma.conversation.create({
    data: {
      contactId: contact2.id,
      channel: "whatsapp_cloud",
      windowClosesAt: new Date(Date.now() - 5 * 60_000),
    },
  });
  convClosed = c2.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(notifyConvEvent).mockClear();
});

function jobOf(conversationId: string): Job {
  return { data: { conversationId } } as unknown as Job;
}

describe("windowWarningProcessor", () => {
  it("aborta se windowClosesAt <= now (janela já fechou)", async () => {
    await windowWarningProcessor(jobOf(convClosed));
    expect(notifyConvEvent).not.toHaveBeenCalled();
    const notifs = await prisma.notification.findMany({
      where: { type: "window_warning", payload: { path: ["conversationId"], equals: convClosed } },
    });
    expect(notifs.length).toBe(0);
  });

  it("aborta se minutesLeft > 65 (job atrasado ou duplicado)", async () => {
    const conv = await prisma.conversation.update({
      where: { id: convFar },
      data: { windowClosesAt: new Date(Date.now() + 90 * 60_000) }, // 90min
    });
    await windowWarningProcessor(jobOf(conv.id));
    expect(notifyConvEvent).not.toHaveBeenCalled();
    // restaura
    await prisma.conversation.update({
      where: { id: convFar },
      data: { windowClosesAt: new Date(Date.now() + 30 * 60_000) },
    });
  });

  it("cria Notification pra cada User isOnDuty=true e dispara notifyConvEvent", async () => {
    await windowWarningProcessor(jobOf(convFar));

    const notifs = await prisma.notification.findMany({
      where: {
        type: "window_warning",
        userId: { in: [onDutyA, onDutyB, offDuty] },
      },
    });
    // Só os on-duty.
    expect(notifs.length).toBe(2);
    expect(notifs.map((n) => n.userId).sort()).toEqual([onDutyA, onDutyB].sort());
    for (const n of notifs) {
      const p = n.payload as {
        conversationId?: string;
        minutesLeft?: number;
        title?: string;
        body?: string;
      };
      expect(p.conversationId).toBe(convFar);
      expect(p.minutesLeft).toBeGreaterThan(0);
      expect(p.title).toBe("Janela do WhatsApp fechando");
      expect(p.body).toContain("Far");
      expect(p.body).toMatch(/\d+min/);
    }

    expect(notifyConvEvent).toHaveBeenCalledTimes(1);
    const [convArg, payloadArg] = vi.mocked(notifyConvEvent).mock.calls[0]!;
    expect(convArg).toBe(convFar);
    expect(payloadArg.type).toBe("window_warning");
  });

  it("dispara notifyConvEvent mesmo se ninguém estiver on-duty", async () => {
    await prisma.user.updateMany({
      where: { id: { in: [onDutyA, onDutyB] } },
      data: { isOnDuty: false },
    });
    await windowWarningProcessor(jobOf(convFar));
    const notifs = await prisma.notification.findMany({
      where: { type: "window_warning", userId: { in: [onDutyA, onDutyB, offDuty] } },
    });
    // só os do teste anterior
    expect(notifs.length).toBe(2);
    expect(notifyConvEvent).toHaveBeenCalledTimes(1);
    // restaura
    await prisma.user.updateMany({
      where: { id: { in: [onDutyA, onDutyB] } },
      data: { isOnDuty: true },
    });
  });
});
