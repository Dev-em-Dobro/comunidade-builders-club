import { isChannelEnabled } from "@/lib/config";
import { NextResponse } from "next/server";
import { whatsappCloudAdapter, HmacFailure } from "@/lib/channels/whatsapp-cloud";
import { enqueueForDebounce } from "@/lib/debounce";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return whatsappCloudAdapter.verifyWebhook(req);
}

export async function POST(req: Request) {
  if (!isChannelEnabled("whatsapp_cloud")) return NextResponse.json({ ok: false, error: "channel_disabled" }, { status: 403 });
  // Gotcha 0.9.4: responder 200 RÁPIDO — Meta reentrega se demorar.
  // Processo pesado (debounce + LLM) vai assíncrono.
  try {
    const msg = await whatsappCloudAdapter.parseWebhook(req);
    if (!msg) {
      // status updates, reactions, etc. — não entram no pipeline de IA.
      return NextResponse.json({ ok: true, skipped: true });
    }
    log({ event: "webhook.whatsapp_cloud.recv", providerMsgId: msg.providerMsgId, contactId: msg.contactId });
    // Fire-and-forget — Railway worker é long-lived, setTimeout dentro do debounce sobrevive.
    void enqueueForDebounce(msg);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof HmacFailure) {
      log({ event: "webhook.whatsapp_cloud.invalid_signature" });
      return NextResponse.json({ ok: false }, { status: 401 });
    }
    log({
      event: "webhook.whatsapp_cloud.error",
      error: String((err as Error)?.message ?? err),
    });
    // Mesmo em erro retornamos 200 pra evitar replay infinito da Meta.
    return NextResponse.json({ ok: true, error: "internal" });
  }
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
