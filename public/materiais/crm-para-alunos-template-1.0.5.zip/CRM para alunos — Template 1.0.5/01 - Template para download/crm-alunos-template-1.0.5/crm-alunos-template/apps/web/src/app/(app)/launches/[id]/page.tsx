import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { auth } from "@/auth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Trash2 } from "lucide-react";
import { LaunchForm } from "../launch-form";
import { deleteLaunch } from "../actions";
import { PlansEditor } from "@/components/launches/plans-editor";
import { StatusToggle } from "@/components/launches/status-toggle";
import { OfferPreviewModal } from "@/components/launches/offer-preview-modal";
import { renderOfferBlock } from "@/lib/launches/context-block";
import type { ActiveLaunch } from "@/lib/launches/active";
import { parseBonuses } from "@/lib/launches/types";

export const dynamic = "force-dynamic";

const STATUS_VARIANT: Record<string, "default" | "secondary" | "outline"> = {
  live: "default",
  planned: "secondary",
  closed: "outline",
};

export default async function EditLaunchPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const session = await auth();
  const isAdmin = (session?.user as { role?: string } | undefined)?.role === "admin";

  const launch = await prisma.launch
    .findUnique({
      where: { id },
      include: {
        course: {
          select: {
            id: true,
            name: true,
            paymentMethods: true,
            guaranteePolicy: true,
            priceCents: true,
            checkoutUrl: true,
            description: true,
            slug: true,
            active: true,
            createdAt: true,
            updatedAt: true,
          },
        },
        plans: { orderBy: { sortOrder: "asc" } },
      },
    })
    .catch(() => null);
  if (!launch) notFound();

  const courses = await prisma.course.findMany({
    where: { active: true },
    select: { id: true, name: true },
    orderBy: { name: "asc" },
  });

  // Preview só faz sentido se há curso + planos
  const previewMarkdown =
    launch.course && launch.plans.length > 0
      ? renderOfferBlock({
          ...launch,
          course: launch.course,
        } as ActiveLaunch)
      : null;

  return (
    <div className="p-6 md:p-8 max-w-4xl space-y-8">
      <header className="flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            {launch.name}
          </h1>
          <p className="text-muted-foreground mt-1 flex items-center gap-2">
            <Badge variant={STATUS_VARIANT[launch.status] ?? "outline"}>
              {launch.status}
            </Badge>
            <span>
              {launch.startsAt.toLocaleDateString("pt-BR")} →{" "}
              {launch.endsAt.toLocaleDateString("pt-BR")}
            </span>
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          {previewMarkdown && <OfferPreviewModal markdown={previewMarkdown} />}
          {isAdmin && <StatusToggle launchId={launch.id} status={launch.status} />}
        </div>
      </header>

      {isAdmin && (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold">Dados do lançamento</h2>
          <LaunchForm
            courses={courses}
            initial={{
              id: launch.id,
              name: launch.name,
              slug: launch.slug,
              startsAt: launch.startsAt.toISOString().slice(0, 10),
              endsAt: launch.endsAt.toISOString().slice(0, 10),
              status: launch.status,
              courseId: launch.courseId,
              pitchAngle: launch.pitchAngle,
              bonuses: parseBonuses(launch.bonuses),
              paymentMethodsOverride: launch.paymentMethodsOverride,
              guaranteePolicyOverride: launch.guaranteePolicyOverride,
              coursePaymentMethods: launch.course?.paymentMethods ?? null,
              courseGuaranteePolicy: launch.course?.guaranteePolicy ?? null,
            }}
          />
        </section>
      )}

      <section className="space-y-3">
        <h2 className="text-lg font-semibold">Planos</h2>
        {isAdmin ? (
          <>
            <p className="text-sm text-muted-foreground">
              Sem planos, o lançamento não pode ser ativado. Adicione pelo menos um
              pra liberar a oferta.
            </p>
            <PlansEditor
              launchId={launch.id}
              initial={launch.plans.map((p) => ({
                id: p.id,
                name: p.name,
                priceCents: p.priceCents,
                checkoutUrl: p.checkoutUrl,
                description: p.description,
                sortOrder: p.sortOrder,
              }))}
            />
          </>
        ) : (
          <ul className="space-y-2">
            {launch.plans.map((p) => (
              <li key={p.id} className="rounded border p-3">
                <div className="font-medium">{p.name}</div>
                <div className="text-sm text-muted-foreground">
                  R$ {(p.priceCents / 100).toFixed(2).replace(".", ",")}
                  {p.checkoutUrl ? "" : " · sem checkout"}
                </div>
                {p.description && <div className="text-sm mt-1">{p.description}</div>}
              </li>
            ))}
          </ul>
        )}
      </section>

      {isAdmin && (
        <form
          action={deleteLaunch.bind(null, launch.id)}
          className="border-t border-border pt-6"
        >
          <Button type="submit" variant="destructive" size="sm">
            <Trash2 className="size-4" /> Excluir lançamento
          </Button>
        </form>
      )}
    </div>
  );
}
