import { prisma } from "@/lib/db";
import { Prisma } from "@prisma/client";
import { decideAction } from "@/lib/ai-rules";
import { loadMemory } from "@/lib/memory";
import { generateReply, type LLMToolDef } from "@/lib/llm";
import { resolveProviderKey } from "@/lib/llm/keys";
import type { LLMTurn } from "@/lib/llm/types";
import { loadConfig, qualificationConfig, businessConfig } from "@/lib/config";
import { retrieveContext } from "@/lib/rag/retrieve";
import {
  buildRenewalAnswerDirective,
  hasHublaRenewalDetails,
  hasNoCardOrLimitSignal,
  hasTmbRenewalDetails,
  isRenewalFollowup,
} from "@/lib/rag/renewal";
import { ensureLeadForContact, touchLeadActivity } from "@/lib/leads";
import { scheduleSlaCheck, cancelSlaCheck } from "@/lib/sla";
import { channelHasMessagingWindow, computeWindowClose } from "@/lib/window24h";
import { runHandoff } from "@/lib/handoff";
import { enqueue } from "@/lib/queue";
import { classifyLead, isSupportAudience } from "@/lib/qualification";
import { looksLikeReturningStudent } from "@/lib/student-signals";
import { getCheckoutLink } from "@/lib/cta/get-checkout-link";
import { runAgentHandoffWithCheckout } from "@/lib/cta/closer-handoff";
import { scheduleWindowWarning } from "@/lib/window-warning";
import { buildCatalogBlock, buildLeadContextBlock } from "@/lib/llm/context-blocks";
import type { ChannelMessage, ChannelId } from "@/lib/channels/types";
import { sendOutboundReply } from "@/lib/outbound";
import { DEFAULT_HUMANIZE, humanizeDirective, normalizeHumanize } from "@/lib/humanize";
import { mergeByEmailFromInbound } from "@/lib/conversations/merge-by-email";
import { ensureConversation } from "@/lib/conversations/ensure-conversation";
import { bumpUnreadAndNotify } from "@/lib/conversations/unread";
import { notifyMessage } from "@/lib/realtime/notify";
import { notifyNewConversation } from "@/lib/integrations/n8n";
import { detectClosedOfferReference } from "@/lib/objections";
import { unsupportedMediaReply } from "@/lib/media-fallback";
import { getInstallmentAnswerFacts } from "@/lib/installment-answer";
import { runToolLoop } from "@/lib/llm/tool-loop";
import { isModuleRole, prepareRoleModule, type RoleModule } from "@/lib/agent-modules";

/** Tool que deixa o LLM pedir handoff por intenção — não só por palavra-chave. */
const HANDOFF_TOOL: LLMToolDef = {
  name: "request_handoff",
  description:
    "Transfere a conversa para um atendente humano e pausa a IA. Use quando: " +
    "(a) o LEAD explicitamente pedir falar com pessoa/humano/atendente/suporte; " +
    "(b) o lead demonstrar frustração clara com o atendimento; OU " +
    "(c) o lead fizer uma pergunta factual sobre o produto (preço, condição de " +
    "pagamento, conteúdo, prazo, garantia) que você NÃO tem como responder " +
    "porque a informação não está no catálogo nem na base de conhecimento — " +
    "nesse caso escale para um humano EM VEZ de prometer que 'vai verificar e " +
    "volta' (promessa vazia que ninguém cumpre). Perguntas comuns sobre " +
    "parcelamento, quantidade de parcelas e valor de cada parcela devem ser " +
    "respondidas diretamente quando a condição estiver no catálogo ou na " +
    "oferta ativa; NÃO use esta tool nesses casos. Fora esses casos, NÃO chame " +
    "esta tool por iniciativa própria: não use ao terminar uma qualificação, " +
    "não use só porque acha que o próximo passo é falar com alguém. A transição " +
    "entre etapas do funil (ex.: SDR→Closer) é orquestrada pelo sistema, não por você.",
  inputSchema: {
    type: "object",
    properties: {
      reason: {
        type: "string",
        description: "Motivo curto do handoff, ex: 'lead pediu atendente'.",
      },
    },
    required: [],
  },
};

/** Tool que deixa o LLM sinalizar intenção clara de compra do lead (Parte 10). */
const READY_TO_BUY_TOOL: LLMToolDef = {
  name: "flagReadyToBuy",
  description:
    "Sinaliza que o lead demonstrou intenção CLARA de comprar agora — pediu " +
    "o link de pagamento, perguntou como fechar/contratar, ou disse " +
    "explicitamente que quer comprar. NÃO use para interesse vago ou dúvidas " +
    "comuns. Após chamar esta tool, continue respondendo o lead normalmente " +
    "no mesmo turno.",
  inputSchema: {
    type: "object",
    properties: {
      reason: {
        type: "string",
        description: "Motivo curto, ex: 'lead pediu o link de pagamento'.",
      },
    },
    required: [],
  },
};

/** Tool que devolve link de checkout pra IA costurar na resposta (Parte 12-A). */
const GET_CHECKOUT_LINK_TOOL: LLMToolDef = {
  name: "get_checkout_link",
  description:
    "Devolve a URL de checkout do curso pra você mandar ao lead na resposta. " +
    "Use quando o lead estiver `qualified` no funil OU quando ele pedir " +
    "explicitamente preço, link de pagamento ou como comprar. Se houver " +
    "objeção ativa não tratada no contexto, responda a objeção primeiro. " +
    "Se houver OFERTA ATIVA com 2+ planos, NÃO chame este tool sem `planId`. " +
    "Pergunte ao lead qual plano ele quer primeiro, depois chame com planId. " +
    "Se chamar sem planId numa oferta com 2+ planos, vai voltar a lista de planos. " +
    "Se o tool retornar handoff:true, pare e diga 'Vou chamar nosso time " +
    "comercial pra te ajudar com os próximos passos.'",
  inputSchema: {
    type: "object",
    properties: {
      courseId: { type: "string", description: "Course.id do curso a oferecer." },
      planId: {
        type: "string",
        description: "LaunchPlan.id quando houver oferta ativa com 2+ planos. Omita pra obter a lista de planos disponíveis.",
      },
    },
    required: ["courseId"],
  },
};

/**
 * Mapa de tools disponíveis. AgentSession.tools (JSON array de strings) escolhe
 * o subset por sessão. Lista vazia = "todos disponíveis" (back-compat).
 *
 * Convenção:
 *   - SDR.tools = ["request_handoff", "flagReadyToBuy"]        # escala + sinaliza compra
 *   - Closer.tools = ["request_handoff", "flagReadyToBuy", "get_checkout_link"]
 *   - Agentes legados sem tools setadas: recebem todos (back-compat)
 */
const TOOLS_BY_NAME = {
  request_handoff: () => HANDOFF_TOOL,
  flagReadyToBuy: () => READY_TO_BUY_TOOL,
  get_checkout_link: () => GET_CHECKOUT_LINK_TOOL,
} as const;

type ToolName = keyof typeof TOOLS_BY_NAME;

function resolveToolsFromSession(sessionTools: unknown): {
  tools: LLMToolDef[];
  enabled: Set<ToolName>;
} {
  let names: ToolName[];
  if (Array.isArray(sessionTools) && sessionTools.length > 0) {
    names = sessionTools.filter(
      (t): t is ToolName => typeof t === "string" && t in TOOLS_BY_NAME,
    );
  } else {
    names = Object.keys(TOOLS_BY_NAME) as ToolName[];
  }
  const tools = names.map((n) => TOOLS_BY_NAME[n]());
  return { tools, enabled: new Set(names) };
}

function ctaSystemBlock(phrasing: string): string {
  return (
    "# CTA — link de checkout (REGRA PRIORITÁRIA)\n" +
    "Você tem acesso ao tool get_checkout_link({ courseId }). É OBRIGATÓRIO\n" +
    "chamar este tool quando QUALQUER uma destas condições for verdade:\n" +
    "- o lead pediu explicitamente link, matrícula, inscrição, checkout ou\n" +
    "  como comprar um curso específico — mesmo que ainda não esteja totalmente\n" +
    "  qualificado. Entregar o link É o que ele pediu; perguntar mais antes é\n" +
    "  fricção.\n" +
    "- o lead está em stage qualified no funil e o assunto é compra.\n" +
    "Use o id exato do curso a partir da seção `# Catálogo de cursos`.\n" +
    "Exceções (ÚNICAS):\n" +
    "- se houver objeção ativa não tratada no contexto, responda a objeção\n" +
    "  PRIMEIRO e mande o link logo em seguida no mesmo turno.\n" +
    "- se o tool retornar handoff:true, pare e diga exatamente: 'Vou chamar\n" +
    `  ${phrasing} pra te ajudar com os próximos passos.'\n` +
    "NÃO faça mais perguntas de qualificação quando o lead pede o link de um\n" +
    "curso identificado no catálogo. Apenas chame o tool."
  );
}

/**
 * Diretriz de fraseado sempre injetada. Garante que, ao encaminhar o lead pra
 * um humano, o bot use o fraseado configurado (business.handoffPhrasing) em vez
 * de "atendente humano"/"atendente"/"operador" — mesmo que o systemPrompt da
 * session (dado em prod) ainda diga o contrário. Vale pra QUALQUER agente, por
 * isso mora no código e não no DB.
 */
function handoffPhrasingBlock(phrasing: string): string {
  return (
    "# Como se referir à passagem pra atendimento humano\n" +
    "Quando você for transferir, encaminhar ou escalar a conversa pra uma\n" +
    `pessoa, refira-se sempre a ela como "${phrasing}".\n` +
    "NUNCA use os termos \"atendente humano\", \"atendente\", \"operador\",\n" +
    "\"vendedor humano\" ou equivalentes ao falar com o lead."
  );
}

/** Dá prioridade às condições comerciais já cadastradas antes de escalar. */
export function paymentAnswerBlock(): string {
  return (
    "# Dúvidas sobre preço e parcelamento (REGRA PRIORITÁRIA)\n" +
    "Quando perguntarem em quantas vezes um curso pode ser parcelado, " +
    "consulte primeiro a OFERTA ATIVA e o Catálogo de cursos desta conversa. " +
    "Identifique o curso pelo contexto recente; uma pergunta como 'esse valor " +
    "posso parcelar?' se refere ao curso que você acabou de oferecer.\n" +
    "Se houver quantidade de parcelas e valor por parcela cadastrados para " +
    "esse curso/plano, responda diretamente com ambos, mencione o valor à " +
    "vista e o total parcelado somente se estiverem explícitos nos dados. " +
    "Não transfira a conversa, não chame request_handoff e não peça para a " +
    "pessoa falar com um especialista apenas por essa dúvida.\n" +
    "Se o catálogo informar só a quantidade de parcelas, diga apenas essa " +
    "quantidade e, se houver checkout, que o valor exato aparece nele; não " +
    "invente o valor. " +
    "Se houver mais de um plano, apresente as condições de cada plano que " +
    "estiverem cadastradas ou pergunte qual plano a pessoa quer. " +
    "Para uma pergunta genérica, apresente primeiro as parcelas no cartão; " +
    "boleto parcelado segue o fluxo próprio quando a pessoa disser que não " +
    "tem cartão. " +
    "Só peça handoff se faltar a condição necessária nos dados ou se a " +
    "pessoa pedir atendimento humano explicitamente. Não use valores de " +
    "uma oferta antiga para responder sobre uma oferta ativa. Se o total " +
    "parcelado for maior que o preço à vista, não chame a parcela de 'sem juros'."
  );
}

/**
 * Diretriz de contato sempre injetada. Impede que o bot ALUCINE dados de
 * contato (caso real: inventou um e-mail plausível numa proposta de parceria).
 * O único e-mail válido vem de business.supportEmail; qualquer assunto fora do
 * fluxo do agente (parceria, imprensa, setor específico) é roteado pra lá. Vale
 * pra QUALQUER agente, por isso mora no código. Sem e-mail configurado, cai num
 * guardrail genérico (nunca inventa; escala pra humano).
 */
export function contactInfoBlock(supportEmail: string): string {
  const head =
    "# Dados de contato (CRÍTICO)\n" +
    "Você NUNCA inventa dados de contato: email, telefone, WhatsApp, setor\n" +
    "ou domínio. Não puxe da memória geral nem chute endereços plausíveis.\n";
  if (!supportEmail) {
    return (
      head +
      "Se pedirem um e-mail ou canal de contato que você não tem certeza, NÃO\n" +
      "invente: encaminhe a pessoa pra um humano."
    );
  }
  return (
    head +
    `O ÚNICO email de contato que você pode passar é ${supportEmail}.\n` +
    "Para qualquer assunto fora do seu fluxo — parceria, proposta comercial,\n" +
    "imprensa, trabalhe conosco ou falar com um setor específico — e sempre que\n" +
    "pedirem \"o email/canal de contato de vocês\", oriente a pessoa a escrever\n" +
    `pra ${supportEmail}, que a equipe direciona pro setor certo.`
  );
}

/**
 * Blocos de diretriz sempre presentes no prompt (independentes do DB), na
 * ordem em que são injetados. Valores específicos do negócio (fraseado, e-mail)
 * vêm de businessConfig() — não mais hardcoded. O bloco de CTA só entra quando a
 * session tem `get_checkout_link` habilitado — instruir a chamar um tool
 * inexistente confunde o modelo.
 */
export function buildDirectiveBlocks(opts: { hasCta: boolean; salesContext?: boolean }): string[] {
  const biz = businessConfig();
  // salesContext=false (agente de consulta): sem regras de preço/parcelamento de curso.
  const sales = opts.salesContext ?? true;
  return [
    opts.hasCta ? ctaSystemBlock(biz.handoffPhrasing) : null,
    sales ? paymentAnswerBlock() : null,
    handoffPhrasingBlock(biz.handoffPhrasing),
    contactInfoBlock(biz.supportEmail),
  ].filter((s): s is string => Boolean(s));
}

/**
 * Resolve o texto final do round-trip do tool `get_checkout_link`.
 *
 * A 2ª chamada do round-trip vai SEM tools (loop guard) e às vezes volta
 * VAZIA: quando o link já foi enviado num turno anterior e a 1ª chamada já
 * respondeu a pergunta do lead, o modelo "não tem nada a acrescentar" e
 * devolve `end_turn` sem bloco de texto. Antes, `flush.ts` usava só o texto da
 * 2ª chamada e, vazio, caía no guard de `empty_reply` — engolindo o turno
 * inteiro (bot "mudo"), mesmo a 1ª chamada tendo produzido uma resposta válida.
 *
 * Regra: nunca engula o turno. Se o round-trip volta vazio, cai no texto da 1ª
 * chamada e — se o tool produziu uma URL ainda não citada nesse texto — anexa o
 * link, garantindo que o lead receba tanto a resposta quanto o checkout.
 */
export function resolveRoundTripText(args: {
  roundTripText: string;
  firstText: string;
  checkoutUrl?: string | null;
}): { text: string; usedFallback: boolean } {
  const rt = args.roundTripText.trim();
  if (rt) return { text: rt, usedFallback: false };

  const parts: string[] = [];
  const first = args.firstText.trim();
  if (first) parts.push(first);
  if (args.checkoutUrl && !parts.join(" ").includes(args.checkoutUrl)) {
    parts.push(args.checkoutUrl);
  }
  return { text: parts.join("\n\n"), usedFallback: true };
}

/**
 * Orchestrator chamado quando o debounce expira (ou síncrono se Redis cair).
 * Responsabilidades:
 *  1. Ensure Contact + ContactIdentity (idempotente, P2002-safe — gotcha 0.9.5)
 *  2. Ensure Conversation
 *  3. Persiste msgs inbound (dedup por providerMsgId — gotcha 0.9.4)
 *  4. Decide via AI rules
 *  5. Se respond → LLM → sendText via adapter (gotcha 0.9.27 — usa externalId, não Contact.id)
 *  6. Persiste msg outbound + usage
 *  7. Logs estruturados por fase (gotcha 0.9.18)
 */
export async function flushConversation(msgs: ChannelMessage[]): Promise<void> {
  if (!msgs.length) return;

  const channel = msgs[0]!.channel;
  const externalId = msgs[0]!.contactId;
  const startedAt = Date.now();
  log({ event: "flush.start", channel, externalId, count: msgs.length });

  try {
    // ── 1. Contact + ContactIdentity (idempotente)
    const ident = await ensureContactIdentity(channel, externalId, msgs[0]?.contactName);

    // ── 1b. Parte 12-E: se o lead colou email no texto e existe um Contact
    // só-email (típico de pesquisa CSV importada) sem identities/lead, funde
    // a SurveyResponse no Contact atual ANTES do `buildLeadContextBlock` ler
    // o contexto. Best-effort: erro só vira log.
    try {
      const inboundText = msgs
        .map((m) => m.text)
        .filter((s): s is string => Boolean(s))
        .join("\n");
      if (inboundText) {
        const r = await mergeByEmailFromInbound(ident.contactId, inboundText);
        if (r.merged) {
          log({
            event: "flush.email_merge_applied",
            contactId: ident.contactId,
            email: r.emailUsed,
            movedSurveyResponses: r.movedSurveyResponses,
          });
        }
      }
    } catch (err) {
      log({
        event: "flush.email_merge_failed",
        contactId: ident.contactId,
        error: String((err as Error)?.message ?? err),
      });
    }

    // ── 2. Conversation
    const { conv, firstEver } = await ensureConversation(ident.contactId, channel);

    // ── 2b. Lead — toda conversa rastreável no funil (Parte 3).
    const { lead, created: leadCreated } = await ensureLeadForContact(ident.contactId);
    if (conv.leadId !== lead.id) {
      await prisma.conversation.update({
        where: { id: conv.id },
        data: { leadId: lead.id },
      });
    }
    // ensureLeadForContact já seta lastActivityAt na criação; senão, atualiza.
    if (!leadCreated) await touchLeadActivity(lead.id);
    log({
      event: "flush.lead",
      conversationId: conv.id,
      leadId: lead.id,
      created: leadCreated,
    });

    // ── 2c. Primeira conversa do contato → avisa por email via n8n.
    // Best-effort: roda solto e erro só vira log — nunca bloqueia o inbound.
    if (firstEver) {
      void (async () => {
        const contact = await prisma.contact.findUnique({
          where: { id: ident.contactId },
          select: { displayName: true },
        });
        await notifyNewConversation({
          conversationId: conv.id,
          contactName: contact?.displayName ?? null,
          channel,
          externalId,
          leadId: lead.id,
          firstMessage: msgs[0]?.text ?? null,
          conversationUrl: `${process.env.PUBLIC_BASE_URL ?? ""}/conversations/${conv.id}`,
          at: new Date().toISOString(),
        });
      })().catch((err) =>
        log({
          event: "flush.new_conversation_notice_failed",
          conversationId: conv.id,
          error: String((err as Error)?.message ?? err),
        }),
      );
    }

    // ── 3. Persistir inbound (dedup por providerMsgId)
    const persisted: string[] = [];
    for (const m of msgs) {
      if (m.providerMsgId) {
        const dup = await prisma.message.findUnique({
          where: { providerMsgId: m.providerMsgId },
        });
        if (dup) {
          log({ event: `webhook.${channel}.duplicate`, providerMsgId: m.providerMsgId });
          continue;
        }
      }
      const saved = await prisma.message.create({
        data: {
          conversationId: conv.id,
          direction: "inbound",
          role: "user",
          text: m.text,
          mediaUrl: m.media?.[0]?.url,
          mediaType: m.media?.[0]?.type,
          mediaId: m.media?.[0]?.id,
          mediaMimeType: m.media?.[0]?.mimeType,
          providerMsgId: m.providerMsgId,
        },
      });
      persisted.push(saved.id);
    }
    // Inbound recebida — atualiza atividade e (re)abre a janela 24h (Parte 6).
    const inboundAt = new Date();
    const hasWindow = channelHasMessagingWindow(channel);
    const newWindowClose = hasWindow ? computeWindowClose(inboundAt) : null;
    await prisma.conversation.update({
      where: { id: conv.id },
      data: {
        lastMessageAt: inboundAt,
        lastInboundAt: inboundAt,
        windowClosesAt: newWindowClose,
        windowExpired: false,
      },
    });

    // Não-lidas: incrementa pelo nº de msgs persistidas; na transição 0→N
    // avisa por email (NOTIFY_EMAIL). Best-effort — nunca bloqueia o inbound.
    if (persisted.length > 0) {
      const preview = msgs
        .map((m) => m.text)
        .filter((s): s is string => Boolean(s))
        .join("\n");
      bumpUnreadAndNotify({
        conversationId: conv.id,
        count: persisted.length,
        preview,
      })
        .catch((err) =>
          log({
            event: "flush.unread_bump_failed",
            conversationId: conv.id,
            error: String((err as Error)?.message ?? err),
          }),
        )
        // SSE: acorda os clientes com a conversa aberta — inbound não passava
        // por notifyMessage (só outbound via sendOutboundMessage), então msg de
        // lead não aparecia ao vivo com a IA pausada nem re-zerava o contador.
        // 1 notify por rajada basta: o cliente busca ?since=<lastId> e traz
        // todas. Encadeado APÓS o bump assentar: o POST /read disparado pelo
        // notify não pode correr na frente do incremento.
        .finally(() => {
          notifyMessage(conv.id, persisted[persisted.length - 1]!).catch((err) =>
            log({
              event: "flush.msg_notify_failed",
              conversationId: conv.id,
              error: String((err as Error)?.message ?? err),
            }),
          );
        });
    }

    // Reset cadência de follow-up se lead respondeu. Lead volta pra coluna
    // de stage natural no /pipeline. updateMany sem fetch — só atualiza se
    // havia step setado (no-op silencioso senão).
    if (conv.leadId) {
      const reset = await prisma.lead.updateMany({
        where: { id: conv.leadId, lastFollowUpStep: { not: null } },
        data: { lastFollowUpStep: null, lastFollowUpAt: null },
      });
      if (reset.count > 0) {
        log({
          event: "flush.followup_reset",
          conversationId: conv.id,
          leadId: conv.leadId,
        });
      }
    }

    // Agenda o alerta proativo de 1h antes do fechamento (Parte 12-C).
    // Reset a cada inbound: scheduler remove o job antigo antes de criar novo.
    // Falha não bloqueia o flush.
    if (newWindowClose) {
      scheduleWindowWarning(conv.id, newWindowClose).catch((err) => {
        log({
          event: "flush.window_warning_schedule_failed",
          conversationId: conv.id,
          error: String((err as Error)?.message ?? err),
        });
      });
    }

    // ── 3b. SLA — agenda a verificação de 5 min se não há uma pendente (Parte 4).
    // O job revalida ao disparar; é cancelado abaixo quando a resposta sai.
    if (!conv.slaJobId) {
      await scheduleSlaCheck(conv.id, persisted.at(-1));
    }

    // ── 4. Decide
    const decision = await decideAction(msgs, conv);
    log({
      event: "flush.decided",
      conversationId: conv.id,
      action: decision.action,
      ruleId: "ruleId" in decision ? decision.ruleId : undefined,
    });

    if (decision.action === "drop") {
      await cancelSlaCheck(conv.id);
      return;
    }

    if (decision.action === "handoff") {
      await runHandoff(conv, decision.notice ?? businessConfig().handoffNotice);
      return;
    }

    let outboundText: string;
    let usage = { tokensIn: 0, tokensOut: 0, costUsd: undefined as number | undefined, modelUsed: undefined as string | undefined };
    // Marca se a classificação já rodou inline (triagem de audience) — nesse caso
    // NÃO reenfileiramos o qualify.lead no fim (seria classificação duplicada).
    let classifiedInline = false;
    let skipQualificationEnqueue = false;

    // Turno puramente mídia (áudio/imagem/figurinha/vídeo/documento): o LLM não
    // "vê" nem "ouve" mídia, então avisamos e pedimos texto — sem gastar tokens.
    // Só chega aqui se a IA está ativa (aiEnabled=false já caiu em drop acima).
    const mediaNotice =
      decision.action === "respond" ? unsupportedMediaReply(msgs) : null;

    if (decision.action === "static_reply") {
      outboundText = decision.text;
    } else if (mediaNotice) {
      log({ event: "flush.media_fallback", conversationId: conv.id });
      outboundText = mediaNotice;
    } else {
      let memory = await loadMemory(conv.id, decision.agentSession.memoryMode);
      const lastUser = memory[memory.length - 1];
      if (!lastUser || lastUser.role !== "user") {
        memory.push({ role: "user", content: msgs.map((m) => m.text).join("\n") });
      }
      let renewalTurns = memory.map((turn) => ({
        role: turn.role,
        content: typeof turn.content === "string" ? turn.content : "",
      }));
      const renewalInteraction = isRenewalFollowup(renewalTurns);
      let renewalSearchSession = decision.agentSession;
      if (renewalInteraction && decision.agentSession.role === "support") {
        const salesSession = await prisma.agentSession.findFirst({
          where: { role: "sdr" },
          orderBy: { createdAt: "asc" },
        });
        if (salesSession) renewalSearchSession = salesSession;
      }

      let preloadedRenewalHits: Awaited<ReturnType<typeof retrieveContext>> | null = null;
      let renewalFaqHasAnswer = false;
      if (renewalInteraction && ragEnabled()) {
        try {
          const renewalQuery = memory
            .slice(-8)
            .map((turn) => turn.content)
            .join("\n");
          const hits = await retrieveContext(renewalSearchSession.id, renewalQuery, 5);
          if (hasHublaRenewalDetails(hits)) {
            preloadedRenewalHits = hits;
            renewalFaqHasAnswer = true;
            skipQualificationEnqueue = true;
            if (renewalSearchSession.id !== decision.agentSession.id) {
              await prisma.conversation.update({
                where: { id: conv.id },
                data: { agentSessionId: renewalSearchSession.id },
              });
              conv.agentSessionId = renewalSearchSession.id;
              decision.agentSession = renewalSearchSession;
              memory = await loadMemory(conv.id, renewalSearchSession.memoryMode);
              renewalTurns = memory.map((turn) => ({
                role: turn.role,
                content: typeof turn.content === "string" ? turn.content : "",
              }));
              log({
                event: "flush.renewal_returned_to_sales",
                conversationId: conv.id,
                agentSessionId: renewalSearchSession.id,
              });
            }
            log({
              event: "flush.rag_renewal_answer_available",
              conversationId: conv.id,
              chunks: hits.length,
            });
          } else if (renewalSearchSession.id === decision.agentSession.id) {
            preloadedRenewalHits = hits;
          }
        } catch (err) {
          log({
            event: "flush.rag_error",
            conversationId: conv.id,
            error: String((err as Error)?.message ?? err),
            phase: "renewal_preload",
          });
        }
      }
      const tmbEligible =
        renewalFaqHasAnswer &&
        hasNoCardOrLimitSignal(renewalTurns) &&
        Boolean(preloadedRenewalHits && hasTmbRenewalDetails(preloadedRenewalHits));
      const hublaAlreadyOffered = memory.some(
        (turn) => turn.role === "assistant" && /pay\.hub\.la\//i.test(turn.content),
      );

      // ── Triagem inline de audience (2026-07-02): quando o agente atual é o SDR,
      // decide ANTES de responder se a conversa deve ir pro agente de suporte
      // (Bia) — trocando no MESMO turno, pra a resposta já sair no tom dela.
      //
      // Dois sinais, nessa ordem:
      //  1. DETERMINÍSTICO (2026-08-20): frases claras de aluno/acesso/login. Não
      //     depende do classificador LLM, que é frágil — deixou "comprei o curso,
      //     quero voltar a acessar, qual site de login" cair no SDR, que escalou
      //     pra humano em vez de a Bia mandar o link.
      //  2. Fallback: classificador Haiku (audience=student/support/refund). Só
      //     roda quando não houve sinal determinístico — SUBSTITUI a classificação
      //     async pra turnos do SDR (mesma qtd de chamadas, só síncrona).
      if (decision.agentSession.role === "sdr" && !renewalFaqHasAnswer) {
        const inboundText = msgs
          .map((m) => m.text)
          .filter((s): s is string => Boolean(s))
          .join("\n");
        let routeToSupport = looksLikeReturningStudent(inboundText);
        let routeVia = "deterministic_student_signal";

        if (!routeToSupport && qualificationConfig().enabled) {
          try {
            await classifyLead(conv.id);
            classifiedInline = true;
          } catch (err) {
            log({
              event: "flush.inline_classify_error",
              conversationId: conv.id,
              error: String((err as Error)?.message ?? err),
            });
          }
          const freshLead = await prisma.lead.findUnique({
            where: { id: lead.id },
            select: { qualification: true },
          });
          const audience = (freshLead?.qualification as { audience?: string } | null)?.audience;
          if (isSupportAudience(audience)) {
            routeToSupport = true;
            routeVia = "classifier_audience";
          }
        }

        if (routeToSupport) {
          const supportSession = await prisma.agentSession.findFirst({
            where: { role: "support" },
            orderBy: { createdAt: "asc" },
          });
          if (supportSession && supportSession.id !== conv.agentSessionId) {
            await prisma.$transaction([
              prisma.conversation.update({
                where: { id: conv.id },
                data: { agentSessionId: supportSession.id },
              }),
              prisma.pipelineEvent.create({
                data: {
                  leadId: lead.id,
                  type: "agent_handoff",
                  payload: {
                    from: decision.agentSession.id,
                    to: supportSession.id,
                    fromName: decision.agentSession.name,
                    toName: supportSession.name,
                    fromPersona: decision.agentSession.persona ?? null,
                    toPersona: supportSession.persona ?? null,
                    leadId: lead.id,
                    via: "student_triage_inline",
                    routeVia,
                  },
                },
              }),
            ]);
            log({
              event: "flush.inline_support_route",
              conversationId: conv.id,
              leadId: lead.id,
              via: routeVia,
            });
            // A partir daqui o "agente da vez" é a Bia — a resposta sai no tom dela.
            decision.agentSession = supportSession;
          }
        }
      }

      // === Detector de menção a oferta encerrada (Task 12) ===
      const inboundTextForDetector = msgs
        .map((m) => m.text)
        .filter((s): s is string => Boolean(s))
        .join("\n");
      if (inboundTextForDetector && lead.interestCourseIds.length > 0) {
        const closedLaunches = await prisma.launch.findMany({
          where: {
            status: "closed",
            courseId: { in: lead.interestCourseIds },
          },
          select: { name: true, status: true },
        });
        if (
          detectClosedOfferReference(inboundTextForDetector, closedLaunches) &&
          !renewalFaqHasAnswer
        ) {
          log({
            event: "flush.closed_offer_reference_handoff",
            conversationId: conv.id,
            leadId: lead.id,
          });
          await prisma.objectionTag.create({
            data: {
              leadId: lead.id,
              tag: "preco",
              rationale: "referência a oferta encerrada",
              conversationId: conv.id,
            },
          });
          await runHandoff(conv, businessConfig().handoffNotice);
          return; // não chama LLM
        }
        if (renewalFaqHasAnswer) {
          log({
            event: "flush.closed_offer_handoff_skipped_for_renewal_faq",
            conversationId: conv.id,
            leadId: lead.id,
          });
        }
      }

      // ── 5. LLM
      // ── RAG: recupera contexto da base de conhecimento do agente.
      // Gated por tools.rag; falha de RAG nunca derruba a resposta (só loga).
      let systemDynamic: string | undefined;
      let renewalAnswerDirective: string | undefined;
      if (ragEnabled()) {
        try {
          const query = memory
            .slice(-8)
            .map((turn) => turn.content)
            .join("\n");
          const hits = preloadedRenewalHits ?? (await retrieveContext(decision.agentSession.id, query, 5));
          if (hits.length) {
            systemDynamic =
              "# Base de conhecimento\n" +
              "Trechos relevantes da base da empresa. Use-os pra responder quando " +
              "fizer sentido. Se a resposta não estiver aqui, não invente.\n\n" +
              hits.map((h, i) => `[${i + 1}]\n${h.text}`).join("\n\n");
            log({ event: "flush.rag_hit", conversationId: conv.id, chunks: hits.length });
            if (renewalFaqHasAnswer && hasHublaRenewalDetails(hits)) {
              renewalAnswerDirective = buildRenewalAnswerDirective({
                tmbEligible,
                hublaAlreadyOffered,
              });
            }
          }
        } catch (err) {
          log({
            event: "flush.rag_error",
            conversationId: conv.id,
            error: String((err as Error)?.message ?? err),
          });
        }
      }

      // Catálogo + contexto do lead — sem estes a IA não conhece courseIds
      // (RAG só retorna texto) nem o que o lead já respondeu (memoryMode
      // pode ter cortado o histórico antigo). Ambos curtos pra caber no cache.
      const recentMessages = memory.map((m, i) => ({
        text: typeof m.content === "string" ? m.content : null,
        // memory é ordenada cronologicamente; usa o index como tiebreaker pseudo-data.
        // Pra a heurística (pegar a menção mais recente), basta a ORDEM, então
        // sintetizamos createdAt como um delta crescente.
        createdAt: new Date(Date.now() - (memory.length - i) * 1000),
      }));
      // Tipos com módulo próprio (agendamento, delivery…): sem catálogo de
      // cursos/CTA; ganham contexto e tools do módulo (ver lib/agent-modules.ts).
      const isModuleAgent = isModuleRole(decision.agentSession.role);
      const [catalogBlock, leadContextBlock, roleModule] = await Promise.all([
        isModuleAgent
          ? Promise.resolve(null)
          : buildCatalogBlock({
              lead: { interestCourseIds: lead.interestCourseIds },
              recentMessages,
              conversationId: conv.id,
            }),
        buildLeadContextBlock(lead.id, ident.contactId),
        isModuleAgent
          ? prepareRoleModule({
              agentSession: decision.agentSession,
              contactId: ident.contactId,
              conversationId: conv.id,
              channel: channel as ChannelId,
              externalId,
            })
          : Promise.resolve<RoleModule | null>(null),
      ]);
      if (isModuleAgent) skipQualificationEnqueue = true;
      // CTA_SYSTEM_BLOCK só faz sentido se a session tem get_checkout_link
      // habilitado. Caso contrário, instruir a chamar tool inexistente confunde.
      const { tools: sessionTools, enabled: enabledNames } = isModuleAgent
        ? { tools: [HANDOFF_TOOL], enabled: new Set<ToolName>(["request_handoff"]) }
        : resolveToolsFromSession(decision.agentSession.tools);
      const enabledTools = [...sessionTools, ...(roleModule?.tools ?? [])];
      const hasCta = enabledNames.has("get_checkout_link");
      const dynBlocks = [
        systemDynamic,
        catalogBlock,
        leadContextBlock,
        roleModule?.contextBlock,
        ...buildDirectiveBlocks({ hasCta, salesContext: !isModuleAgent }),
        renewalAnswerDirective,
        humanizeDirective(normalizeHumanize(decision.agentSession.humanize)),
      ].filter((s): s is string => Boolean(s));
      systemDynamic = dynBlocks.join("\n\n");

      log({
        event: "flush.llm_call",
        provider: decision.agentSession.provider,
        model: decision.agentSession.model,
        tools: enabledTools.map((t) => t.name),
      });

      const providerApiKey = await resolveProviderKey(decision.agentSession.provider);
      const callLLM = (messages: LLMTurn[]) =>
        generateReply(decision.agentSession.provider, {
          model: decision.agentSession.model,
          temperature: decision.agentSession.temperature,
          maxTokens: decision.agentSession.maxTokens,
          systemStatic: decision.agentSession.systemPrompt,
          systemDynamic,
          messages,
          tools: enabledTools,
          apiKey: providerApiKey,
        });
      let resp = await callLLM(memory);

      // Agente com módulo (agendamento, delivery…): encadeia os tools do módulo
      // no mesmo turno (ex.: quote_order → place_order). request_handoff
      // encerra o loop e cai no tratamento abaixo.
      if (roleModule && resp.toolUses?.some((t) => roleModule.handles(t.name))) {
        const loop = await runToolLoop({
          first: resp,
          messages: memory,
          handles: roleModule.handles,
          execute: roleModule.execute,
          call: callLLM,
          maxSteps: 5,
        });
        resp = loop.resp;
        log({
          event: `flush.${roleModule.name}_tool_loop`,
          conversationId: conv.id,
          steps: loop.steps,
          tools: loop.executed.map((e) => e.name),
        });
      }

      // A IA pode pedir handoff por intenção (tool), captando casos que a
      // regra de palavra-chave não pega. Curto-circuita igual à regra.
      if (resp.toolUses?.some((t) => t.name === "request_handoff")) {
        const installmentFacts = await getInstallmentAnswerFacts(
          memory,
          lead.interestCourseIds,
        );
        if (installmentFacts) {
          resp = {
            ...resp,
            text: installmentFacts.answer,
            toolUses: undefined,
          };
          log({
            event: "flush.installment_answer_instead_of_handoff",
            conversationId: conv.id,
            courseName: installmentFacts.courseName,
          });
        } else {
          log({
            event: "flush.llm_handoff",
            conversationId: conv.id,
            tokensIn: resp.tokensIn,
            tokensOut: resp.tokensOut,
          });
          await runHandoff(conv, businessConfig().handoffNotice);
          return;
        }
      }

      // A IA pode sinalizar intenção de compra (Parte 10).
      if (resp.toolUses?.some((t) => t.name === "flagReadyToBuy")) {
        // Caminho A: numa sessão não-closer, passa pro Closer entregando o link
        // no MESMO turno. Se tratou o turno, encerra aqui (não manda o texto do SDR).
        if (await runAgentHandoffWithCheckout(conv.id)) {
          log({ event: "flush.ready_to_buy_checkout_handoff", conversationId: conv.id, leadId: lead.id });
          return;
        }
        // Sessão já closer (ou caso degenerado) → comportamento legado.
        await handleReadyToBuy(conv.id, lead.id, lead.stage);
        if (qualificationConfig().handoffOnReady) {
          log({
            event: "flush.ready_to_buy_handoff",
            conversationId: conv.id,
            leadId: lead.id,
          });
          await runHandoff(conv, businessConfig().handoffNotice);
          return;
        }
      }

      // CTA tool — round-trip: executa, devolve resultado, IA reescreve com a URL.
      const ctaCall = resp.toolUses?.find((t) => t.name === "get_checkout_link");
      let outboundResp = resp;
      if (ctaCall) {
        const courseIdInput = String(
          (ctaCall.input as { courseId?: unknown }).courseId ?? "",
        );
        const planIdInput = (ctaCall.input as { planId?: unknown }).planId;
        const baseUrl = process.env.PUBLIC_BASE_URL ?? "";
        const ctaResult = await getCheckoutLink({
          prisma,
          leadId: lead.id,
          courseId: courseIdInput,
          planId: typeof planIdInput === "string" ? planIdInput : null,
          conversationId: conv.id,
          agentSessionId: decision.agentSession.id,
          baseUrl,
        });

        if (!ctaResult.ok && "handoff" in ctaResult && ctaResult.handoff) {
          log({
            event: "flush.cta_handoff",
            conversationId: conv.id,
            leadId: lead.id,
            courseId: courseIdInput,
          });
          await runHandoff(conv, businessConfig().handoffNotice);
          return;
        }

        // Constrói o histórico ampliado pra 2ª chamada.
        const memoryWithTool: LLMTurn[] = [
          ...memory,
          {
            role: "assistant",
            content: resp.text ?? "",
            toolUse: {
              id: ctaCall.id,
              name: ctaCall.name,
              input: ctaCall.input,
            },
          },
          {
            role: "tool",
            content: "",
            toolResult: {
              toolUseId: ctaCall.id,
              content: JSON.stringify(ctaResult),
            },
          },
        ];

        log({
          event: "flush.cta_round_trip",
          conversationId: conv.id,
          courseId: courseIdInput,
        });

        const resp2 = await generateReply(decision.agentSession.provider, {
          model: decision.agentSession.model,
          temperature: decision.agentSession.temperature,
          maxTokens: decision.agentSession.maxTokens,
          systemStatic: decision.agentSession.systemPrompt,
          systemDynamic,
          messages: memoryWithTool,
          apiKey: providerApiKey,
          // Sem `tools` na 2ª chamada — loop guard.
        });

        // Round-trip pode voltar vazio (modelo sem nada a acrescentar quando o
        // link já saiu antes). Nunca engole o turno: cai no texto da 1ª chamada
        // e reanexa a URL do tool, se houver. Sem isso o bot fica "mudo".
        const checkoutUrl =
          ctaResult.ok && "url" in ctaResult ? ctaResult.url : null;
        const { text: roundTripText, usedFallback } = resolveRoundTripText({
          roundTripText: resp2.text,
          firstText: resp.text,
          checkoutUrl,
        });
        if (usedFallback) {
          log({
            event: "flush.cta_round_trip_empty_fallback",
            conversationId: conv.id,
            recoveredFirstText: Boolean(resp.text.trim()),
            appendedUrl: Boolean(checkoutUrl),
          });
        }

        outboundResp = {
          ...resp2,
          text: roundTripText,
          // Agrega tokens das duas chamadas pra registro de custo.
          tokensIn: (resp.tokensIn ?? 0) + (resp2.tokensIn ?? 0),
          tokensOut: (resp.tokensOut ?? 0) + (resp2.tokensOut ?? 0),
          tokensCached: (resp.tokensCached ?? 0) + (resp2.tokensCached ?? 0),
          costUsd:
            resp.costUsd != null && resp2.costUsd != null
              ? Number((resp.costUsd + resp2.costUsd).toFixed(6))
              : (resp2.costUsd ?? resp.costUsd),
        };
      }

      outboundText = outboundResp.text;
      usage = {
        tokensIn: outboundResp.tokensIn,
        tokensOut: outboundResp.tokensOut,
        costUsd: outboundResp.costUsd,
        modelUsed: outboundResp.modelUsed,
      };
    }

    if (!outboundText.trim()) {
      log({ event: "flush.empty_reply", conversationId: conv.id });
      return;
    }

    // ── 6+7. envia + persiste outbound — com "digitando…" e quebra em balões
    // conforme o agente (resposta fixa de regra: só "digitando…", sem quebrar).
    const humanize =
      decision.action === "respond"
        ? normalizeHumanize(decision.agentSession.humanize)
        : { ...DEFAULT_HUMANIZE, splitMessages: false };
    const sendResult = await sendOutboundReply({
      conversationId: conv.id,
      channel: channel as ChannelId,
      externalId,
      text: outboundText,
      usage,
      humanize,
    });
    if (!sendResult.ok) {
      log({
        event: "flush.outbound_failed",
        conversationId: conv.id,
        reason: sendResult.reason,
      });
      return;
    }

    // Outbound enviada — registra pra rastrear a janela 24h (Parte 6).
    await prisma.conversation.update({
      where: { id: conv.id },
      data: { lastOutboundAt: new Date() },
    });

    // SLA — resposta enviada dentro do prazo: cancela a verificação (Parte 4).
    await cancelSlaCheck(conv.id, { markResponded: true });

    // Qualificação — classifica o lead em background (Parte 10). jobId keyed
    // no leadId + delay dá debounce: turnos em rajada colapsam numa
    // classificação só. removeOnComplete libera o jobId pro próximo turno.
    // Gotcha BullMQ 5.x: `:` é proibido em Custom Id ("Custom Id cannot
    // contain :") — usar `__` como separador.
    if (qualificationConfig().enabled && !classifiedInline && !skipQualificationEnqueue) {
      try {
        await enqueue(
          "qualify",
          "lead",
          { conversationId: conv.id },
          {
            jobId: `qualify__${lead.id}`,
            delay: 15_000,
            removeOnComplete: true,
            removeOnFail: 50,
          },
        );
      } catch (err) {
        log({
          event: "flush.qualify_enqueue_failed",
          conversationId: conv.id,
          error: String((err as Error)?.message ?? err),
        });
      }
    }

    log({ event: "flush.done", conversationId: conv.id, durationMs: Date.now() - startedAt });
  } catch (err) {
    log({
      event: "flush.error",
      channel,
      externalId,
      error: String((err as Error)?.message ?? err),
      stack: (err as Error)?.stack,
    });
  }
}

/**
 * Trata o `flagReadyToBuy` (Parte 10): avança o stage do lead para `proposal`
 * e enfileira uma classificação imediata. Idempotente — não rebaixa o stage
 * (leads em `proposal`/`won`/`lost` não regridem nem reabrem).
 */
async function handleReadyToBuy(
  conversationId: string,
  leadId: string,
  currentStage: string,
): Promise<void> {
  if (!["proposal", "won", "lost"].includes(currentStage)) {
    await prisma.lead.update({
      where: { id: leadId },
      data: { stage: "proposal" },
    });
    await prisma.pipelineEvent.create({
      data: {
        leadId,
        type: "stage_change",
        payload: { from: currentStage, to: "proposal", via: "ready_to_buy" },
      },
    });
    log({ event: "flush.ready_to_buy", conversationId, leadId, from: currentStage });
  }
  // Classificação imediata — sem jobId/delay, roda já (lead quente não espera
  // o debounce de 15s). É evento raro; não precisa de dedup.
  try {
    await enqueue(
      "qualify",
      "lead",
      { conversationId },
      { removeOnComplete: true, removeOnFail: 50 },
    );
  } catch (err) {
    log({
      event: "flush.ready_to_buy_enqueue_failed",
      conversationId,
      error: String((err as Error)?.message ?? err),
    });
  }
}

/**
 * Gotcha 0.9.5: prisma.upsert() não é atômico — duas conexões podem passar o SELECT
 * juntas e colidir no INSERT. Pattern correto: try CREATE → no P2002 → fallback findUnique.
 */
async function ensureContactIdentity(
  channel: ChannelId,
  externalId: string,
  displayName?: string,
) {
  try {
    return await prisma.contactIdentity.create({
      data: {
        channel,
        externalId,
        contact: {
          create: { displayName: displayName ?? externalId },
        },
      },
    });
  } catch (err) {
    if (
      err instanceof Prisma.PrismaClientKnownRequestError &&
      err.code === "P2002"
    ) {
      const ident = await prisma.contactIdentity.findUnique({
        where: { channel_externalId: { channel, externalId } },
      });
      if (ident) return ident;
    }
    throw err;
  }
}

/** RAG ligado? Lê o flag tools.rag do setup.config.json — falha de leitura = off. */
function ragEnabled(): boolean {
  try {
    return loadConfig().tools.rag === true;
  } catch {
    return false;
  }
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
