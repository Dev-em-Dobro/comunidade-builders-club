/**
 * Dispatcher de webhook pro n8n.
 *
 * Espelha o padrão do `@/lib/email/resend.ts`: no-op (só loga) quando a env da
 * URL não está setada — dev/local não quebra por falta de integração. O n8n é
 * quem monta e envia o email; aqui só mandamos os dados do evento.
 */
export interface NewConversationEvent {
  conversationId: string;
  contactName: string | null;
  channel: string;
  externalId: string | null;
  leadId: string | null;
  firstMessage: string | null;
  conversationUrl: string;
  at: string;
}

export async function notifyNewConversation(
  event: NewConversationEvent,
): Promise<void> {
  const url = process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL;
  if (!url) {
    log({ event: "n8n.skipped_no_url", conversationId: event.conversationId });
    return;
  }

  const token = process.env.N8N_WEBHOOK_TOKEN;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      ...(token ? { "x-webhook-token": token } : {}),
    },
    body: JSON.stringify(event),
  });
  if (!res.ok) {
    throw new Error(`n8n webhook: ${res.status} ${res.statusText}`);
  }
}

function log(payload: Record<string, unknown>): void {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
