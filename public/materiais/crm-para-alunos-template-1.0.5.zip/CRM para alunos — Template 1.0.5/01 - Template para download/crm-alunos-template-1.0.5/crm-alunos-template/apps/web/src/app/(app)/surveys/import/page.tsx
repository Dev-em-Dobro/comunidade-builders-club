import { ImportForm } from "./import-form";

export const dynamic = "force-dynamic";

export default function SurveysImportPage() {
  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Importar respostas de pesquisa
        </h1>
        <p className="text-muted-foreground mt-1 text-sm">
          Faça upload de um CSV. Colunas reservadas (case-insensitive):{" "}
          <code className="font-mono">phone</code>,{" "}
          <code className="font-mono">email</code>,{" "}
          <code className="font-mono">submitted_at</code>. As demais viram
          perguntas/respostas.
        </p>
      </header>
      <ImportForm />
    </div>
  );
}
