import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/api-auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Patch {
  aiEnabled?: boolean;
  handoffRequested?: boolean;
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const { id } = await params;
  const body = (await req.json()) as Patch;
  const data: Patch = {};
  if (typeof body.aiEnabled === "boolean") data.aiEnabled = body.aiEnabled;
  if (typeof body.handoffRequested === "boolean") data.handoffRequested = body.handoffRequested;
  try {
    const conv = await prisma.conversation.update({ where: { id }, data });
    return NextResponse.json({ ok: true, conversation: conv });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: String((err as Error)?.message ?? err) },
      { status: 500 },
    );
  }
}
