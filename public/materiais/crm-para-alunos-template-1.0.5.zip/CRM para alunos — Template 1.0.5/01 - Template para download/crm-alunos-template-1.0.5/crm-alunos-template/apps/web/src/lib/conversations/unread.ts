import { prisma } from "@/lib/db";
import { sendEmail } from "@/lib/email/resend";

/** Preview do texto no email — o resto o atendente lê no CRM. */
const PREVIEW_MAX = 200;

export interface BumpUnreadArgs {
  conversationId: string;
  /** nº de mensagens inbound persistidas na rajada. */
  count: number;
  /** texto concatenado da rajada, pro corpo do email. */
  preview: string | null;
}

export interface BumpUnreadResult {
  previousUnread: number;
  emailed: boolean;
}

/**
 * Incrementa `Conversation.unreadCount` e, na transição lida → não lida
 * (contador anterior era 0), avisa por email o endereço fixo `NOTIFY_EMAIL`.
 * Enquanto ninguém abrir a conversa, rajadas novas só incrementam — sem
 * re-enviar email. Falha de email nunca propaga (best-effort).
 * Lança se a conversa não existir (P2025) — o caller do flush embrulha em catch.
 */
export async function bumpUnreadAndNotify(
  args: BumpUnreadArgs,
): Promise<BumpUnreadResult> {
  if (args.count <= 0) return { previousUnread: 0, emailed: false };

  const updated = await prisma.conversation.update({
    where: { id: args.conversationId },
    data: { unreadCount: { increment: args.count } },
    select: {
      unreadCount: true,
      channel: true,
      contact: { select: { displayName: true } },
    },
  });
  const previousUnread = updated.unreadCount - args.count;

  const to = process.env.NOTIFY_EMAIL;
  if (previousUnread > 0 || !to) return { previousUnread, emailed: false };

  const name = updated.contact?.displayName ?? "(sem nome)";
  const baseUrl = process.env.PUBLIC_BASE_URL ?? "";
  const preview = (args.preview ?? "").slice(0, PREVIEW_MAX);
  try {
    await sendEmail({
      to: [to],
      subject: `Nova mensagem de ${name}`,
      text:
        `${name} mandou mensagem no ${updated.channel}:\n\n` +
        `"${preview}"\n\n` +
        `Responder: ${baseUrl}/conversations/${args.conversationId}`,
    });
    return { previousUnread, emailed: true };
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "unread.email_failed",
        conversationId: args.conversationId,
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
    return { previousUnread, emailed: false };
  }
}

/**
 * Marca a conversa como lida (unreadCount = 0). Idempotente; updateMany
 * pra não lançar em id inexistente e não escrever quando já está em 0.
 */
export async function markConversationRead(conversationId: string): Promise<void> {
  await prisma.conversation.updateMany({
    where: { id: conversationId, unreadCount: { gt: 0 } },
    data: { unreadCount: 0 },
  });
}
