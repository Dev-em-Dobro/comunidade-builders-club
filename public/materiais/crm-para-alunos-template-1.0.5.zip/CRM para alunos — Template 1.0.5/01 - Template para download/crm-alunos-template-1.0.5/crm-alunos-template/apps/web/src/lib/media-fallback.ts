import type { ChannelMessage, MediaType } from "@/lib/channels/types";

/**
 * Aviso automático para mídia não suportada.
 *
 * Hoje o agente não "vê" imagens, não "ouve" áudios e não lê documentos —
 * a mídia nunca chega ao LLM (ver flush.ts / anthropic.ts). Em vez de
 * responder a um placeholder vazio, devolvemos um aviso curto pedindo texto.
 *
 * Regra: o aviso só dispara quando o turno é PURAMENTE mídia. Se vier
 * qualquer texto real junto (inclui legenda promovida a texto no parsing),
 * o fluxo normal segue e o agente responde ao texto.
 */

/** As 4 categorias de aviso. Figurinha cai em "image" (é visual). */
type MediaCategory = "audio" | "image" | "video" | "document";

const CATEGORY_OF: Record<MediaType, MediaCategory> = {
  audio: "audio",
  image: "image",
  sticker: "image",
  video: "video",
  document: "document",
};

const NOTICE: Record<MediaCategory, string> = {
  audio: "Não consigo ouvir áudios por aqui 😅 Pode mandar por texto, por favor?",
  image: "Não consigo ver imagens por aqui 😅 Pode mandar por texto, por favor?",
  video: "Não consigo ver vídeos por aqui 😅 Pode mandar por texto, por favor?",
  document:
    "Não consigo abrir arquivos por aqui 😅 Pode mandar por texto, por favor?",
};

/** Ordem estável de junção quando o turno tem tipos misturados. */
const CATEGORY_ORDER: MediaCategory[] = ["audio", "image", "video", "document"];

/** Placeholders que o parsing grava em `text` para mídia sem legenda. */
const MEDIA_PLACEHOLDER = /^\[(image|audio|video|document|sticker)\]$/;

const PLACEHOLDER_CATEGORY: Record<string, MediaCategory> = {
  image: "image",
  sticker: "image",
  audio: "audio",
  video: "video",
  document: "document",
};

/** Texto que o LLM consegue responder de fato (não vazio, não placeholder de mídia). */
function hasRealText(text: string): boolean {
  const t = text.trim();
  if (!t) return false;
  return !MEDIA_PLACEHOLDER.test(t);
}

type InboundLike = Pick<ChannelMessage, "text" | "media">;

/**
 * Devolve o aviso de mídia não suportada para o lote, ou `null` quando há
 * texto real (deixa o fluxo normal responder) ou quando não há mídia alguma.
 */
export function unsupportedMediaReply(msgs: InboundLike[]): string | null {
  if (msgs.some((m) => hasRealText(m.text))) return null;

  const present = new Set<MediaCategory>();
  for (const m of msgs) {
    for (const media of m.media ?? []) {
      present.add(CATEGORY_OF[media.type]);
    }
    // Fallback robusto: se o parsing não populou `media` mas deixou o
    // placeholder no texto, ainda reconhecemos a categoria.
    const ph = m.text.trim().match(MEDIA_PLACEHOLDER);
    if (ph) present.add(PLACEHOLDER_CATEGORY[ph[1]!]!);
  }
  if (present.size === 0) return null;

  return CATEGORY_ORDER.filter((c) => present.has(c))
    .map((c) => NOTICE[c])
    .join(" ");
}
