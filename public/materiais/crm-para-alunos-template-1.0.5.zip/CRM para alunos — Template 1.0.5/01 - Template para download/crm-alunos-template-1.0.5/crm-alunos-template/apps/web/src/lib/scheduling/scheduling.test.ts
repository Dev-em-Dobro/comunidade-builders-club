import { describe, expect, it } from "vitest";
import { addDays, dayLabel, isValidDate, weekdayOf, zonedParts, zonedToUtc } from "./time";
import { computeSlots, groupSlotsByDate } from "./availability";
import { csvCell, toCsv } from "./csv";
import {
  DEFAULT_WORKING_HOURS,
  formatDayIntervals,
  normalizeIntervals,
  normalizeWorkingHours,
  parseDayIntervals,
  summarizeWorkingHours,
} from "./working-hours";
import {
  cleanIntakeAnswers,
  missingRequired,
  normalizeIntakeFields,
  patientNameFrom,
  slugifyKey,
} from "./intake";
import { parseSpreadsheetId } from "@/lib/google/sheets";

const SP = "America/Sao_Paulo";

describe("time", () => {
  it("converte hora de parede de São Paulo (UTC−3) pra UTC", () => {
    expect(zonedToUtc("2026-11-16", "09:00", SP).toISOString()).toBe("2026-11-16T12:00:00.000Z");
  });

  it("respeita horário de verão (Nova York: EST vs EDT)", () => {
    expect(zonedToUtc("2026-01-15", "09:00", "America/New_York").toISOString()).toBe("2026-01-15T14:00:00.000Z");
    expect(zonedToUtc("2026-07-15", "09:00", "America/New_York").toISOString()).toBe("2026-07-15T13:00:00.000Z");
  });

  it("zonedParts devolve data, hora e dia da semana locais", () => {
    // 02:30 UTC de terça = 23:30 de segunda em SP
    expect(zonedParts(new Date("2026-11-17T02:30:00Z"), SP)).toEqual({
      date: "2026-11-16",
      time: "23:30",
      weekday: 1,
    });
  });

  it("aritmética de datas", () => {
    expect(addDays("2026-12-31", 1)).toBe("2027-01-01");
    expect(weekdayOf("2026-11-16")).toBe(1);
    expect(isValidDate("2026-02-30")).toBe(false);
    expect(isValidDate("2026-02-28")).toBe(true);
    expect(dayLabel("2026-11-16")).toBe("segunda-feira, 16/11");
  });
});

describe("working hours", () => {
  it("parseia vários intervalos e ordena", () => {
    expect(parseDayIntervals("14:00-18:00, 8:00 - 12:00")).toEqual([
      { start: "08:00", end: "12:00" },
      { start: "14:00", end: "18:00" },
    ]);
    expect(parseDayIntervals("  ")).toEqual([]);
  });

  it("rejeita intervalos inválidos ou sobrepostos", () => {
    expect(() => parseDayIntervals("12:00-08:00")).toThrow(/depois do início/);
    expect(() => parseDayIntervals("08:00-12:00, 11:00-13:00")).toThrow(/sobrepor/);
    expect(() => parseDayIntervals("manhã")).toThrow(/inválido/);
  });

  it("normaliza JSON do banco ignorando lixo", () => {
    expect(
      normalizeWorkingHours({ "1": [{ start: "08:00", end: "12:00" }, { start: "x", end: "y" }], "9": [], foo: 1 }),
    ).toEqual({ "1": [{ start: "08:00", end: "12:00" }] });
    expect(formatDayIntervals(DEFAULT_WORKING_HOURS["1"])).toBe("08:00-12:00, 14:00-18:00");
    expect(summarizeWorkingHours({})).toBe("sem horário cadastrado");
  });
});

describe("computeSlots", () => {
  const wh = { "1": [{ start: "08:00", end: "10:00" }] }; // segunda 08–10
  const base = {
    workingHours: wh,
    durationMin: 30,
    fromDate: "2026-11-16", // segunda
    days: 1,
    tz: SP,
    now: new Date("2026-11-10T12:00:00Z"),
    busy: [],
  };

  it("gera slots dentro do horário de atendimento", () => {
    expect(computeSlots(base).map((s) => s.time)).toEqual(["08:00", "08:30", "09:00", "09:30"]);
  });

  it("desconta horários ocupados (inclusive sobreposição parcial)", () => {
    const busy = [
      { start: zonedToUtc("2026-11-16", "08:45", SP), end: zonedToUtc("2026-11-16", "09:10", SP) },
    ];
    expect(computeSlots({ ...base, busy }).map((s) => s.time)).toEqual(["08:00", "09:30"]);
  });

  it("respeita a antecedência mínima", () => {
    const now = zonedToUtc("2026-11-16", "08:10", SP); // +60 min → só a partir de 09:10
    expect(computeSlots({ ...base, now }).map((s) => s.time)).toEqual(["09:30"]);
  });

  it("não cria slot que ultrapassa o fim do intervalo", () => {
    expect(computeSlots({ ...base, durationMin: 45 }).map((s) => s.time)).toEqual(["08:00", "08:45"]);
  });

  it("pula dias sem atendimento e agrupa por dia", () => {
    const slots = computeSlots({ ...base, fromDate: "2026-11-15", days: 9 }); // dom..seg seguinte
    expect(groupSlotsByDate(slots).map((g) => g.date)).toEqual(["2026-11-16", "2026-11-23"]);
  });

  it("exceção vazia fecha o dia (folga/feriado)", () => {
    expect(computeSlots({ ...base, overrides: { "2026-11-16": [] } })).toEqual([]);
  });

  it("exceção com intervalos substitui a semana padrão só naquele dia", () => {
    const overrides = { "2026-11-16": [{ start: "14:00", end: "15:00" }] };
    expect(computeSlots({ ...base, overrides }).map((s) => s.time)).toEqual(["14:00", "14:30"]);
    // dia extra: domingo normalmente fechado
    const sunday = computeSlots({
      ...base,
      fromDate: "2026-11-15",
      overrides: { "2026-11-15": [{ start: "09:00", end: "10:00" }] },
    });
    expect(sunday.map((s) => `${s.date} ${s.time}`)).toEqual(["2026-11-15 09:00", "2026-11-15 09:30"]);
  });
});

describe("normalizeIntervals", () => {
  it("descarta itens inválidos e aceita lista vazia", () => {
    expect(normalizeIntervals([{ start: "09:00", end: "10:00" }, { start: "10:00", end: "09:00" }, null])).toEqual([
      { start: "09:00", end: "10:00" },
    ]);
    expect(normalizeIntervals([])).toEqual([]);
    expect(normalizeIntervals("lixo")).toEqual([]);
  });
});

describe("csv", () => {
  it("usa ponto e vírgula, BOM e aspas quando precisa", () => {
    const out = toCsv([
      ["Paciente", "Pré-consulta"],
      ['Ana "Lu"', "Motivo: dor; febre\nConvênio: não"],
    ]);
    expect(out.startsWith("﻿")).toBe(true);
    expect(out).toBe('﻿Paciente;Pré-consulta\r\n"Ana ""Lu""";"Motivo: dor; febre\nConvênio: não"\r\n');
  });

  it("neutraliza fórmulas", () => {
    expect(csvCell("=HYPERLINK(\"x\")")).toBe('"\'=HYPERLINK(""x"")"');
    expect(csvCell("+5511999")).toBe("'+5511999");
    expect(csvCell("-")).toBe("'-");
    expect(csvCell(null)).toBe("");
  });
});

describe("intake", () => {
  it("gera chaves estáveis sem acento e sem duplicata", () => {
    expect(slugifyKey("Convênio ou particular?")).toBe("convenio_ou_particular");
    expect(
      normalizeIntakeFields([
        { label: "Nome completo", required: true },
        { label: "Nome completo" },
        { label: "   " },
        "lixo",
      ]),
    ).toEqual([
      { key: "nome_completo", label: "Nome completo", required: true },
      { key: "nome_completo_2", label: "Nome completo", required: false },
    ]);
  });

  it("limpa respostas e aponta obrigatórios faltando", () => {
    const fields = normalizeIntakeFields([
      { key: "nome_completo", label: "Nome", required: true },
      { key: "motivo", label: "Motivo", required: true },
      { key: "convenio", label: "Convênio", required: false },
    ]);
    const answers = cleanIntakeAnswers(fields, { nome_completo: "  Maria  ", motivo: "", extra: "x" });
    expect(answers).toEqual({ nome_completo: "Maria" });
    expect(missingRequired(fields, answers).map((f) => f.key)).toEqual(["motivo"]);
    expect(patientNameFrom(fields, answers)).toBe("Maria");
  });
});

describe("parseSpreadsheetId", () => {
  it("aceita URL ou ID", () => {
    const id = "1AbCdEfGhIjKlMnOpQrStUvWxYz0123456789_-";
    expect(parseSpreadsheetId(`https://docs.google.com/spreadsheets/d/${id}/edit#gid=0`)).toBe(id);
    expect(parseSpreadsheetId(id)).toBe(id);
    expect(parseSpreadsheetId("https://example.com")).toBeNull();
  });
});
