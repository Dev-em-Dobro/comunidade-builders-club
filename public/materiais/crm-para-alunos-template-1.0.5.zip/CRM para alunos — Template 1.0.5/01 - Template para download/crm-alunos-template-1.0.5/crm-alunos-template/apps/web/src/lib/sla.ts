import { getQueue } from "@/lib/queue";
import { prisma } from "@/lib/db";
import { slaConfig } from "@/lib/config";
import type { SlaJobData } from "@/lib/queue/types";

const SLA_JOB_NAME = "deadline";

/**
 * Agenda a verificação de SLA pra daqui a `sla.thresholdMin` minutos.
 * Salva o jobId em `Conversation.slaJobId` — usado pra cancelar e revalidar.
 */
export async function scheduleSlaCheck(
  conversationId: string,
  inboundMessageId?: string,
): Promise<void> {
  const delay = slaConfig().thresholdMin * 60_000;
  const data: SlaJobData = { conversationId, inboundMessageId };
  const job = await getQueue("sla").add(SLA_JOB_NAME, data, {
    delay,
    removeOnComplete: true,
    removeOnFail: 50,
  });
  await prisma.conversation.update({
    where: { id: conversationId },
    data: { slaJobId: job.id ?? null },
  });
}

/**
 * Cancela a verificação de SLA pendente — chamado quando a IA/humano responde
 * (`markResponded`) ou quando a mensagem é dropada.
 *
 * Limpa `slaJobId` no DB ANTES de remover o job do Redis: o worker revalida
 * pelo `slaJobId` do DB, então ele precisa cair primeiro pra evitar corrida
 * com um job que já entrou em execução.
 */
export async function cancelSlaCheck(
  conversationId: string,
  opts: { markResponded?: boolean } = {},
): Promise<void> {
  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { slaJobId: true, leadId: true },
  });
  if (conv?.slaJobId) {
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { slaJobId: null },
    });
    await getQueue("sla").remove(conv.slaJobId).catch(() => {});
  }
  if (opts.markResponded && conv?.leadId) {
    await prisma.lead.updateMany({
      where: { id: conv.leadId, firstResponseAt: null },
      data: { firstResponseAt: new Date() },
    });
  }
}
