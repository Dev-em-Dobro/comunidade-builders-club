-- AlterTable: add persona (human-facing name) to AgentSession
ALTER TABLE "AgentSession" ADD COLUMN "persona" TEXT;
