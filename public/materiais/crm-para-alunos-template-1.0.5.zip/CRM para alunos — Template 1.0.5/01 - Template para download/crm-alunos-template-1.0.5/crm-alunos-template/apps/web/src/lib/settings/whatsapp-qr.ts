import { prisma } from "@/lib/db";
import { decryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";
import { WAQR_FIELDS, type WaqrKey } from "./whatsapp-qr-fields";

const PREFIX = "waqr:";

/** Valores do banco têm precedência sobre o ambiente, sem cache de processo. Segredos ficam no servidor. */
export async function resolveWaqrSettings(): Promise<Partial<Record<WaqrKey, string>>> {
  const values: Partial<Record<WaqrKey, string>> = {};
  for (const { key } of WAQR_FIELDS) if (process.env[key]) values[key] = process.env[key];
  if (secretsKeyConfigured()) {
    const rows = await prisma.providerCredential.findMany({
      where: { provider: { in: WAQR_FIELDS.map(({ key }) => `${PREFIX}${key}`) } },
      select: { provider: true, apiKeyEnc: true },
    });
    for (const row of rows) values[row.provider.slice(PREFIX.length) as WaqrKey] = decryptSecret(row.apiKeyEnc);
  }
  return values;
}

/** Só presença e origem atravessam a fronteira servidor/cliente. */
export async function waqrSettingsStatus() {
  const rows = await prisma.providerCredential.findMany({
    where: { provider: { in: WAQR_FIELDS.map(({ key }) => `${PREFIX}${key}`) } }, select: { provider: true },
  });
  return Object.fromEntries(WAQR_FIELDS.map(({ key }) => [key,
    rows.some((row) => row.provider === `${PREFIX}${key}`) ? "painel" : process.env[key] ? "ambiente" : "ausente",
  ]));
}

export const WAQR_CREDENTIAL_PREFIX = PREFIX;
