/** Vocabulário + matcher de objeções do lead (Parte 11). Módulo puro. */

export const OBJECTION_TAGS = [
  "preco",
  "tempo",
  "conjuge",
  "outro_curso",
  "medo",
  "outro",
] as const;
export type ObjectionTag = (typeof OBJECTION_TAGS)[number];

const OBJECTION_SET = new Set<string>(OBJECTION_TAGS);

/** Janela de "tag ativa" — não re-inserimos a mesma tag dentro desse horizonte. */
const ACTIVE_WINDOW_MS = 24 * 60 * 60 * 1000;

/** Labels PT-BR pra UI e prompts. */
export const OBJECTION_LABEL: Record<ObjectionTag, string> = {
  preco: "preço",
  tempo: "tempo",
  conjuge: "cônjuge",
  outro_curso: "outro curso",
  medo: "medo",
  outro: "outro",
};

/**
 * Normaliza o array bruto retornado pelo LLM contra o enum:
 *  - aceita só strings que batem com OBJECTION_TAGS
 *  - faz dedup preservando ordem de primeira aparição
 *  - entrada não-array (null/undefined/string) → []
 */
export function normalizeObjections(raw: unknown): ObjectionTag[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: ObjectionTag[] = [];
  for (const v of raw) {
    if (typeof v !== "string") continue;
    if (!OBJECTION_SET.has(v)) continue;
    if (seen.has(v)) continue;
    seen.add(v);
    out.push(v as ObjectionTag);
  }
  return out;
}

/**
 * Delta entre o que o LLM detectou e o que já está ativo (criado < 24h atrás).
 * Retorna só as tags que devem virar `ObjectionTag` row nova.
 */
export function diffObjections(
  detected: ObjectionTag[],
  existing: { tag: string; createdAt: Date }[],
  now: Date,
): ObjectionTag[] {
  if (!detected.length) return [];
  const cutoff = now.getTime() - ACTIVE_WINDOW_MS;
  const activeTags = new Set(
    existing
      .filter((e) => e.createdAt.getTime() >= cutoff)
      .map((e) => e.tag),
  );
  return detected.filter((t) => !activeTags.has(t));
}

/**
 * Bloco que vai no `systemDynamic` do reengajamento. Lista as objeções
 * pra IA endereçar uma delas naturalmente.
 */
export function buildObjectionsPrompt(tags: ObjectionTag[]): string {
  if (!tags.length) return "";
  const labels = tags.map((t) => OBJECTION_LABEL[t]).join(", ");
  return (
    "# Objeções levantadas pelo lead\n" +
    `Esse lead já levantou as seguintes objeções: ${labels}. ` +
    "Ao retomar o assunto, endereça UMA delas de forma natural — " +
    "sem pedir desculpa, sem soar argumentativo, sem repetir a objeção textualmente."
  );
}

/**
 * Heurística leve pra detectar quando o lead está se referindo a uma oferta
 * que já encerrou. Cobre dois sinais:
 *  - referências genéricas a promoções: "aquele preço de aniversário",
 *    "ainda dá pra pegar pelo preço de X", etc.
 *  - menção direta ao name de um Launch com status='closed'.
 *
 * Quando detectado, o caller (flush.ts) força handoff humano — preço de
 * oferta encerrada é decisão comercial, não da IA.
 *
 * Sem NLP — regex case-insensitive + includes.
 */
const CLOSED_OFFER_PATTERNS: RegExp[] = [
  /aquel[ea]\s+(preç|valor|oferta|promo|desconto)/i,
  /preç[oa]\s+(de|do)\s+(aniversário|black|natal|cyber|lançamento|promoção)/i,
  /(ainda\s+(da|dá|vale)|consigo\s+pegar).*\b(promo|oferta|desconto|preço)/i,
];

export function detectClosedOfferReference(
  text: string,
  closedLaunches: { name: string; status: string }[] = [],
): boolean {
  if (!text) return false;
  for (const re of CLOSED_OFFER_PATTERNS) {
    if (re.test(text)) return true;
  }
  const lower = text.toLowerCase();
  for (const l of closedLaunches) {
    if (l.status === "closed" && lower.includes(l.name.toLowerCase())) {
      return true;
    }
  }
  return false;
}
