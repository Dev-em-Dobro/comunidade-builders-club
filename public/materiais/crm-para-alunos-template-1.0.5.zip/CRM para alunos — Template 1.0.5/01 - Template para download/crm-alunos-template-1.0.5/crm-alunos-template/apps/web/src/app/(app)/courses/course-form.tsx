"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { saveCourse, type CourseFormState } from "./actions";
import { Loader2, Save } from "lucide-react";

interface InitialCourse {
  id?: string;
  name?: string;
  slug?: string;
  /** preço em reais (priceCents / 100) */
  price?: number;
  active?: boolean;
  checkoutUrl?: string | null;
  description?: string | null;
  guaranteePolicy?: string | null;
  paymentMethods?: string | null;
}

export function CourseForm({ initial }: { initial?: InitialCourse }) {
  const [state, action, pending] = useActionState<CourseFormState, FormData>(
    async (_prev, formData) => saveCourse(formData),
    {},
  );

  return (
    <form action={action} className="space-y-6 max-w-xl">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <div className="space-y-2">
        <Label htmlFor="name">Nome</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initial?.name ?? ""}
          placeholder="Curso de Tráfego Pago"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="slug">Slug</Label>
        <Input
          id="slug"
          name="slug"
          required
          defaultValue={initial?.slug ?? ""}
          placeholder="trafego-pago"
        />
        <p className="text-xs text-muted-foreground">
          Identificador único — letras minúsculas, números e hífen.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="price">Preço (R$)</Label>
        <Input
          id="price"
          name="price"
          type="number"
          step="0.01"
          min="0"
          required
          defaultValue={initial?.price ?? ""}
          placeholder="497.00"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="checkoutUrl">URL de Checkout</Label>
        <Input
          id="checkoutUrl"
          name="checkoutUrl"
          type="url"
          defaultValue={initial?.checkoutUrl ?? ""}
          placeholder="https://pay.hotmart.com/..."
        />
        <p className="text-xs text-muted-foreground">
          URL real do checkout. Deixe em branco se ainda não tiver — a IA passa
          pra um atendente humano quando o lead pedir o link.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Descrição</Label>
        <Textarea
          id="description"
          name="description"
          rows={10}
          defaultValue={initial?.description ?? ""}
          placeholder="O que tem dentro do curso, pra quem é, bônus..."
        />
        <p className="text-xs text-muted-foreground">
          Aceita Markdown básico (listas, negrito). A IA usa este texto literal
          quando o lead pergunta sobre o conteúdo do curso. Máx. 5000
          caracteres.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="guaranteePolicy">Política de garantia</Label>
        <Input
          id="guaranteePolicy"
          name="guaranteePolicy"
          defaultValue={initial?.guaranteePolicy ?? ""}
          placeholder="7 dias de garantia incondicional"
        />
        <p className="text-xs text-muted-foreground">
          Deixe vazio se não houver — o bot vai chamar um humano quando
          perguntarem.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="paymentMethods">Formas de pagamento</Label>
        <Textarea
          id="paymentMethods"
          name="paymentMethods"
          rows={3}
          defaultValue={initial?.paymentMethods ?? ""}
          placeholder="Pix à vista ou cartão em até 12x sem juros"
        />
      </div>

      <div className="flex items-center justify-between rounded-md border border-border p-3">
        <div>
          <Label htmlFor="active" className="text-sm">
            Ativo?
          </Label>
          <p className="text-xs text-muted-foreground">
            Cursos inativos não aparecem como opção de interesse.
          </p>
        </div>
        <Switch
          id="active"
          name="active"
          defaultChecked={initial?.active ?? true}
        />
      </div>

      {state?.error && (
        <p className="text-sm text-destructive font-mono">{state.error}</p>
      )}

      <div className="flex gap-2">
        <Button type="submit" disabled={pending}>
          {pending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Save className="size-4" />
          )}
          Salvar
        </Button>
      </div>
    </form>
  );
}
