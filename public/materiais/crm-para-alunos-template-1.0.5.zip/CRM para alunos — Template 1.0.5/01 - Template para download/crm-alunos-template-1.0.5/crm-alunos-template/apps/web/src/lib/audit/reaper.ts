/**
 * Reaper de AuditReports com status='running' órfãos.
 *
 * Um report é considerado órfão quando permanece em 'running' por mais de
 * ORPHAN_THRESHOLD_MS (indica crash do worker ou node restart).
 */
import { prisma } from "@/lib/db";

/** Idade em ms a partir da qual considera report 'running' órfão. */
export const ORPHAN_THRESHOLD_MS = 15 * 60 * 1000;

/** Tempo entre execuções do reaper. */
export const REAP_INTERVAL_MS = 5 * 60 * 1000;

/** Retorna true se o report está em 'running' há mais de ORPHAN_THRESHOLD_MS. */
export function isOrphan(
  report: { status: string; runAt: Date },
  now = Date.now(),
): boolean {
  if (report.status !== "running") return false;
  return now - report.runAt.getTime() > ORPHAN_THRESHOLD_MS;
}

/**
 * Marca como 'error' todos os AuditReports em 'running' cujo `runAt` é mais
 * antigo que `now - ORPHAN_THRESHOLD_MS`.
 *
 * Retorna o número de reports marcados.
 */
export async function reapOrphans(now = new Date()): Promise<{ reaped: number }> {
  const threshold = new Date(now.getTime() - ORPHAN_THRESHOLD_MS);

  const result = await prisma.auditReport.updateMany({
    where: {
      status: "running",
      runAt: { lt: threshold },
    },
    data: {
      status: "error",
      errorMessage: `Marcado como error pelo reaper: ainda em 'running' após ${ORPHAN_THRESHOLD_MS / 60_000} minutos.`,
      finishedAt: now,
    },
  });

  return { reaped: result.count };
}
