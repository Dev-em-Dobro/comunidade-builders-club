"use client";

import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface Template {
  id: string;
  metaName: string;
  language: string;
  category: string;
  status: string;
  bodyText: string | null;
  variableCount: number;
  syncedAt: Date | string;
}

function statusIcon(status: string): string {
  if (status === "APPROVED") return "✅";
  if (status === "PENDING") return "⏳";
  if (status === "REJECTED") return "❌";
  if (status === "DISABLED" || status === "PAUSED") return "⏸️";
  return "❔";
}

export function TemplatesTable({ templates }: { templates: Template[] }) {
  const [preview, setPreview] = useState<Template | null>(null);

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-12">Status</TableHead>
            <TableHead>Nome</TableHead>
            <TableHead>Idioma</TableHead>
            <TableHead>Categoria</TableHead>
            <TableHead className="text-right">Vars</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {templates.length === 0 && (
            <TableRow>
              <TableCell colSpan={5} className="text-center text-muted-foreground">
                Nenhum template ainda. Clique &quot;Sincronizar com Meta&quot;.
              </TableCell>
            </TableRow>
          )}
          {templates.map((t) => (
            <TableRow
              key={t.id}
              className="cursor-pointer hover:bg-muted/50"
              onClick={() => setPreview(t)}
            >
              <TableCell aria-label={t.status}>{statusIcon(t.status)}</TableCell>
              <TableCell className="font-mono text-xs">{t.metaName}</TableCell>
              <TableCell className="font-mono text-xs">{t.language}</TableCell>
              <TableCell className="text-xs">{t.category}</TableCell>
              <TableCell className="text-right text-xs">
                {t.variableCount}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={preview !== null} onOpenChange={(open) => !open && setPreview(null)}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle className="font-mono">{preview?.metaName}</DialogTitle>
          </DialogHeader>
          <pre className="text-xs whitespace-pre-wrap font-mono bg-muted p-3 rounded">
            {preview?.bodyText ?? "(sem body)"}
          </pre>
          <div className="text-xs text-muted-foreground font-mono">
            Status: {preview?.status} · Idioma: {preview?.language} · Vars:{" "}
            {preview?.variableCount}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
