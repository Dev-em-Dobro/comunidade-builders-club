export const META_FIELDS = [
  { key: "META_APP_ID", label: "ID do aplicativo Meta", secret: false },
  { key: "META_APP_SECRET", label: "Segredo do aplicativo (App Secret)", secret: true },
  { key: "META_WEBHOOK_VERIFY_TOKEN", label: "Token de verificação dos webhooks", secret: true },
  { key: "META_PHONE_NUMBER_ID", label: "ID do número WhatsApp (Phone Number ID)", secret: false },
  { key: "META_BUSINESS_ACCOUNT_ID", label: "ID da conta WhatsApp Business (WABA ID)", secret: false },
  { key: "META_SYSTEM_USER_TOKEN", label: "Token do usuário de sistema — WhatsApp", secret: true },
  { key: "META_IG_PAGE_ID", label: "ID da Página Facebook vinculada ao Instagram", secret: false },
  { key: "META_IG_BUSINESS_ACCOUNT_ID", label: "ID da conta profissional Instagram", secret: false },
  { key: "META_IG_PAGE_ACCESS_TOKEN", label: "Token de acesso da Página — Instagram", secret: true },
] as const;
export type MetaKey = typeof META_FIELDS[number]["key"];
