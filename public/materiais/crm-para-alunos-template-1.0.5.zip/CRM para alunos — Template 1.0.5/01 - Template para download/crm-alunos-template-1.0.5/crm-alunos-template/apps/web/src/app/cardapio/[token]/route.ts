/**
 * GET /cardapio/<token> — cardápio do delivery, público (o cliente abre pelo
 * link no WhatsApp, sem login). Plano B quando o provedor de WhatsApp não
 * envia arquivo. O token é aleatório e troca a cada novo upload.
 */
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ token: string }> }): Promise<Response> {
  const { token } = await params;
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(token)) return new Response("Não encontrado", { status: 404 });
  const store = await prisma.deliveryStore
    .findUnique({ where: { menuToken: token }, select: { menuFile: true, menuMimeType: true, menuFileName: true } })
    .catch(() => null);
  if (!store?.menuFile || !store.menuMimeType) return new Response("Não encontrado", { status: 404 });

  const fileName = (store.menuFileName ?? "cardapio").replace(/[^\w.\- ]/g, "_");
  return new Response(new Uint8Array(store.menuFile), {
    headers: {
      "Content-Type": store.menuMimeType,
      "Content-Disposition": `inline; filename="${fileName}"`,
      "Cache-Control": "public, max-age=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
