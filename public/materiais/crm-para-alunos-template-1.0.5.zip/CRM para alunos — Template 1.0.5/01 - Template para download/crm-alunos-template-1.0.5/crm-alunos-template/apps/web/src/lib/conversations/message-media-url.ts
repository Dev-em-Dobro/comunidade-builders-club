/** URL autenticado do CRM, sem expor o token ou o URL temporário da Meta. */
export function messageMediaUrl(message: {
  id: string;
  mediaType: string | null;
  mediaId: string | null;
  mediaUrl: string | null;
}): string | null {
  if (message.mediaType !== "image" && message.mediaType !== "audio" && message.mediaType !== "document") return null;
  if (!message.mediaId && !message.mediaUrl) return null;
  return `/api/messages/${encodeURIComponent(message.id)}/media`;
}
