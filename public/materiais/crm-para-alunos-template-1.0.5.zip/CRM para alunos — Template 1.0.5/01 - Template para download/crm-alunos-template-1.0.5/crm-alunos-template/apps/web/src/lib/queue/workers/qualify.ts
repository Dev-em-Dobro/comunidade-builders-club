import type { Job } from "bullmq";
import { classifyLead } from "@/lib/qualification";
import type { QualifyJobData } from "@/lib/queue/types";

/**
 * Processa `qualify.lead`: classifica a conversa e re-pontua o lead (Parte 10).
 *
 * `classifyLead` é best-effort — engole as próprias falhas e revalida o estado
 * fresco do DB. O processor só delega.
 */
export async function qualifyProcessor(job: Job): Promise<void> {
  const { conversationId } = job.data as QualifyJobData;
  if (!conversationId) return;
  await classifyLead(conversationId);
}
