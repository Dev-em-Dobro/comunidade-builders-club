/**
 * Chunking de texto pra embedding.
 *
 * Estratégia:
 *  - Docs markdown com headers (`#`..`######`): uma SEÇÃO por chunk, sem misturar
 *    seções (preserva a precisão do retrieval — o embedding de cada chunk fica
 *    focado num assunto só). Seção maior que MAX_CHARS é empacotada por parágrafo
 *    com overlap, mas nunca atravessa a fronteira de outra seção.
 *  - Texto sem headers: agrupa parágrafos até MAX_CHARS, com overlap entre chunks
 *    pra não perder contexto na fronteira. Parágrafo gigante é fatiado por frase
 *    (e, em último caso, por tamanho bruto).
 */

// ~1200 chars (~300-400 tokens) — bom equilíbrio: contexto suficiente sem diluir o vetor.
const MAX_CHARS = 1200;
const OVERLAP_CHARS = 150;

export function chunkText(raw: string): string[] {
  const text = raw.replace(/\r\n/g, "\n").replace(/[ \t]+/g, " ").trim();
  if (!text) return [];

  const sections = splitMarkdownSections(text);
  if (sections.length > 1) {
    // Uma seção por chunk; seção grande é fatiada SEM atravessar a fronteira.
    return sections.flatMap((sec) =>
      sec.length <= MAX_CHARS ? [sec] : packParagraphs(sec),
    );
  }

  return packParagraphs(text);
}

/**
 * Divide o texto nas linhas de header markdown (`#`..`######`), mantendo o header
 * no início de cada seção. Remove separadores `---` isolados. Sem headers → uma
 * seção só (cai no empacotamento por parágrafo).
 */
function splitMarkdownSections(text: string): string[] {
  const lines = text.split("\n");
  if (!lines.some((l) => /^#{1,6}\s/.test(l))) return [text];

  const sections: string[] = [];
  let cur: string[] = [];
  for (const line of lines) {
    if (/^#{1,6}\s/.test(line) && cur.length) {
      sections.push(cur.join("\n"));
      cur = [line];
    } else {
      cur.push(line);
    }
  }
  if (cur.length) sections.push(cur.join("\n"));

  return sections
    .map((s) => s.replace(/^\s*-{3,}\s*$/gm, "").trim())
    .filter(Boolean);
}

/** Agrupa parágrafos em chunks até MAX_CHARS, com overlap entre chunks. */
function packParagraphs(text: string): string[] {
  const paragraphs = text
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean);

  // Quebra parágrafos maiores que MAX_CHARS em unidades menores.
  const units: string[] = [];
  for (const p of paragraphs) {
    if (p.length <= MAX_CHARS) units.push(p);
    else units.push(...splitLong(p));
  }

  // Agrupa unidades em chunks respeitando MAX_CHARS, com overlap.
  const chunks: string[] = [];
  let current = "";
  for (const u of units) {
    if (current && current.length + u.length + 2 > MAX_CHARS) {
      chunks.push(current);
      const tail = current.slice(-OVERLAP_CHARS);
      current = `${tail}\n\n${u}`;
    } else {
      current = current ? `${current}\n\n${u}` : u;
    }
  }
  if (current.trim()) chunks.push(current);

  return chunks;
}

/** Fatia um parágrafo grande por frase; se ainda assim estourar, corta por tamanho. */
function splitLong(p: string): string[] {
  const sentences = p.match(/[^.!?]+[.!?]+|\S[^.!?]*$/g) ?? [p];
  const out: string[] = [];
  let cur = "";
  for (const s of sentences) {
    const piece = s.trim();
    if (!piece) continue;
    if (cur && cur.length + piece.length + 1 > MAX_CHARS) {
      out.push(cur);
      cur = piece;
    } else {
      cur = cur ? `${cur} ${piece}` : piece;
    }
  }
  if (cur) out.push(cur);

  return out.flatMap((c) =>
    c.length <= MAX_CHARS
      ? [c]
      : (c.match(new RegExp(`.{1,${MAX_CHARS}}`, "gs")) ?? [c]),
  );
}
