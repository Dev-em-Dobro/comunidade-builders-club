import IORedis, { type RedisOptions } from "ioredis";

declare global {
  // eslint-disable-next-line no-var
  var __bullConnection: IORedis | undefined;
}

/**
 * Conexão ioredis DEDICADA ao BullMQ.
 *
 * BullMQ exige `maxRetriesPerRequest: null` na conexão compartilhada — por isso
 * NÃO reusa `lib/redis.ts` (que usa `maxRetriesPerRequest: 3` pro debounce).
 * Singleton via globalThis pra sobreviver ao HMR em dev e evitar conexões duplicadas.
 */
export function getQueueConnection(): IORedis {
  if (globalThis.__bullConnection) return globalThis.__bullConnection;

  const url = process.env.REDIS_URL;
  if (!url) {
    throw new Error(
      "REDIS_URL ausente — BullMQ precisa de Redis. Em dev: docker compose up -d",
    );
  }

  const conn = new IORedis(url, {
    maxRetriesPerRequest: null,
    lazyConnect: true,
  });
  globalThis.__bullConnection = conn;
  return conn;
}

/** Fecha e descarta o singleton. Síncrono e seguro mesmo se nunca conectou. */
export function closeQueueConnection(): void {
  globalThis.__bullConnection?.disconnect();
  globalThis.__bullConnection = undefined;
}

/**
 * Opções de conexão pros WORKERS (não a instância).
 *
 * Workers não compartilham a conexão singleton: passando `RedisOptions`, o
 * BullMQ cria E é dono da conexão de cada worker, fechando-a por completo no
 * `worker.close()`. Compartilhar uma única instância entre vários workers causa
 * corrida de "Connection is closed" no shutdown.
 */
export function queueConnectionOptions(): RedisOptions {
  const url = process.env.REDIS_URL;
  if (!url) {
    throw new Error(
      "REDIS_URL ausente — BullMQ precisa de Redis. Em dev: docker compose up -d",
    );
  }
  const u = new URL(url);
  const db = u.pathname.length > 1 ? Number(u.pathname.slice(1)) : NaN;
  return {
    host: u.hostname,
    port: u.port ? Number(u.port) : 6379,
    username: u.username ? decodeURIComponent(u.username) : undefined,
    password: u.password ? decodeURIComponent(u.password) : undefined,
    db: Number.isFinite(db) ? db : undefined,
    tls: u.protocol === "rediss:" ? {} : undefined,
    maxRetriesPerRequest: null,
  };
}
