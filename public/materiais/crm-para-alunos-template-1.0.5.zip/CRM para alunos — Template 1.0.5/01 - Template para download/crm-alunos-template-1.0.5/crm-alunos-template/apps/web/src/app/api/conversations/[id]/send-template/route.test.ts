import { describe, it, expect, vi, beforeAll, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));
vi.mock("@/lib/channels/meta-templates", () => ({
  sendTemplateMessage: vi.fn(),
}));
vi.mock("@/lib/realtime/notify", () => ({
  notifyMessage: vi.fn().mockResolvedValue(undefined),
  notifyConvEvent: vi.fn().mockResolvedValue(undefined),
}));
vi.mock("@/lib/conversations/claim", () => ({
  claimConversation: vi.fn().mockResolvedValue({ claimed: false, previousOwnerId: null }),
}));

import { POST } from "./route";
import { auth } from "@/auth";
import { sendTemplateMessage } from "@/lib/channels/meta-templates";
import { notifyMessage } from "@/lib/realtime/notify";

const created = {
  conversationIds: [] as string[],
  contactIds: [] as string[],
  userIds: [] as string[],
  templateIds: [] as string[],
};

let userId: string;
let convId: string;
let templateApproved: { id: string; metaName: string; language: string };
let templatePending: { id: string; metaName: string; language: string };

beforeAll(async () => {
  const user = await prisma.user.create({
    data: { email: `sendtpl-${Date.now()}@t.local`, name: "Atendente" },
  });
  userId = user.id;
  created.userIds.push(user.id);

  const contact = await prisma.contact.create({ data: { displayName: "L" } });
  created.contactIds.push(contact.id);
  await prisma.contactIdentity.create({
    data: {
      contactId: contact.id,
      channel: "whatsapp_cloud",
      externalId: "5511988887777",
    },
  });

  const lead = await prisma.lead.create({
    data: { contactId: contact.id },
  });

  const conv = await prisma.conversation.create({
    data: {
      contactId: contact.id,
      leadId: lead.id,
      channel: "whatsapp_cloud",
      assignedUserId: user.id,
      aiEnabled: false,
    },
  });
  convId = conv.id;
  created.conversationIds.push(conv.id);

  const a = await prisma.messageTemplate.create({
    data: {
      metaName: `tpl_ok_${Date.now()}`,
      language: "pt_BR",
      category: "UTILITY",
      status: "APPROVED",
      components: [{ type: "BODY", text: "Oi {{1}}, sobre {{2}}" }],
      bodyText: "Oi {{1}}, sobre {{2}}",
      variableCount: 2,
    },
  });
  templateApproved = { id: a.id, metaName: a.metaName, language: a.language };
  created.templateIds.push(a.id);

  const p = await prisma.messageTemplate.create({
    data: {
      metaName: `tpl_pending_${Date.now()}`,
      language: "pt_BR",
      category: "UTILITY",
      status: "PENDING",
      components: [],
      variableCount: 0,
    },
  });
  templatePending = { id: p.id, metaName: p.metaName, language: p.language };
  created.templateIds.push(p.id);
});

afterAll(async () => {
  await prisma.message.deleteMany({
    where: { conversationId: { in: created.conversationIds } },
  });
  await prisma.conversation.deleteMany({
    where: { id: { in: created.conversationIds } },
  });
  // ContactIdentity cascades from Contact
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.messageTemplate.deleteMany({
    where: { id: { in: created.templateIds } },
  });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
  vi.mocked(sendTemplateMessage).mockReset();
  vi.mocked(notifyMessage).mockClear();
});

function req(body: unknown): Request {
  return new Request("http://test", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

const validBody = {
  templateMetaName: "", // overridden per test
  language: "pt_BR",
  variables: ["João", "React"],
};

describe("POST /api/conversations/[id]/send-template", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(
      req({ ...validBody, templateMetaName: templateApproved.metaName }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(401);
  });

  it("404 conversa inexistente", async () => {
    const res = await POST(
      req({ ...validBody, templateMetaName: templateApproved.metaName }),
      { params: Promise.resolve({ id: "missing" }) },
    );
    expect(res.status).toBe(404);
  });

  it("403 quando IA ativa e atendente não é dono", async () => {
    const other = await prisma.user.create({
      data: { email: `other-${Date.now()}@t.local`, name: "Other" },
    });
    created.userIds.push(other.id);
    await prisma.conversation.update({
      where: { id: convId },
      data: { aiEnabled: true, assignedUserId: other.id },
    });
    const res = await POST(
      req({ ...validBody, templateMetaName: templateApproved.metaName }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(403);
    // restore
    await prisma.conversation.update({
      where: { id: convId },
      data: { aiEnabled: false, assignedUserId: userId },
    });
  });

  it("404 template não cadastrado", async () => {
    const res = await POST(
      req({ ...validBody, templateMetaName: "tpl_nonexistent" }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(404);
    const body = await res.json();
    expect(body.error).toMatch(/encontrado/i);
  });

  it("400 template não aprovado", async () => {
    const res = await POST(
      req({
        templateMetaName: templatePending.metaName,
        language: templatePending.language,
        variables: [],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.error).toMatch(/aprovado/i);
  });

  it("400 variables.length errado", async () => {
    const res = await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["só uma"], // template espera 2
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(400);
    const body = await res.json();
    expect(body.error).toMatch(/variáveis/i);
  });

  it("200 sucesso: persiste Message com templateMetaName + notifyMessage", async () => {
    vi.mocked(sendTemplateMessage).mockResolvedValueOnce({
      providerMsgId: `wamid.test-${Date.now()}`,
    });
    const res = await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(200);
    const msgs = await prisma.message.findMany({
      where: { conversationId: convId, direction: "outbound" },
      orderBy: { createdAt: "desc" },
      take: 1,
    });
    expect(msgs).toHaveLength(1);
    expect(msgs[0].templateMetaName).toBe(templateApproved.metaName);
    expect(msgs[0].text).toContain("João");
    expect(notifyMessage).toHaveBeenCalledTimes(1);
  });

  it("502 quando Meta API rejeita (ChannelSendError)", async () => {
    const { ChannelSendError } = await import("@/lib/channels/meta-graph");
    vi.mocked(sendTemplateMessage).mockRejectedValueOnce(
      new ChannelSendError(
        { code: 132000, name: "TemplatePaused", action: "x", message: "Template paused" },
        400,
      ),
    );
    const res = await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(502);
    const body = await res.json();
    expect(body.error).toMatch(/meta/i);
  });

  it("incrementa lead.lastFollowUpStep + atualiza lastFollowUpAt", async () => {
    // Reset cadência antes do teste
    const lead = await prisma.lead.findFirstOrThrow({
      where: { contactId: { in: created.contactIds } },
    });
    await prisma.lead.update({
      where: { id: lead.id },
      data: { lastFollowUpStep: null, lastFollowUpAt: null },
    });
    vi.mocked(sendTemplateMessage).mockResolvedValueOnce({
      providerMsgId: `wamid.cadence-${Date.now()}`,
    });
    const res = await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBe(1);
    expect(after.lastFollowUpAt).not.toBeNull();
  });

  it("incremento sucessivo: 1 → 2 → 3, cap em 3 no 4º envio", async () => {
    const lead = await prisma.lead.findFirstOrThrow({
      where: { contactId: { in: created.contactIds } },
    });
    await prisma.lead.update({
      where: { id: lead.id },
      data: { lastFollowUpStep: 1 },
    });
    // 2º envio (step 1 → 2)
    vi.mocked(sendTemplateMessage).mockResolvedValueOnce({
      providerMsgId: `wamid.cadence2-${Date.now()}`,
    });
    await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    let after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBe(2);

    // 3º envio (step 2 → 3)
    vi.mocked(sendTemplateMessage).mockResolvedValueOnce({
      providerMsgId: `wamid.cadence3-${Date.now()}`,
    });
    await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBe(3);

    // 4º envio — cap em 3
    vi.mocked(sendTemplateMessage).mockResolvedValueOnce({
      providerMsgId: `wamid.cadence4-${Date.now()}`,
    });
    await POST(
      req({
        templateMetaName: templateApproved.metaName,
        language: templateApproved.language,
        variables: ["João", "React"],
      }),
      { params: Promise.resolve({ id: convId }) },
    );
    after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.lastFollowUpStep).toBe(3);
  });
});
