/**
 * Módulos por tipo de agente — o que um agente de AGENDAMENTO, DELIVERY (e
 * tipos futuros) ganha a cada mensagem: tools próprias, bloco de contexto no
 * system prompt e o executor dos tools.
 *
 * O flush só conversa com esta interface; pra um tipo novo, crie o módulo em
 * lib/<tipo>/agent.ts e registre aqui (e as abas em settings/agents/_roles.ts).
 */
import type { AgentSession } from "@prisma/client";
import type { ChannelId } from "@/lib/channels/types";
import type { LLMToolDef, LLMToolUse } from "@/lib/llm/types";
import { DELIVERY_ROLE, executeDeliveryTool, isDeliveryTool, prepareDelivery } from "@/lib/delivery/agent";
import {
  executeSchedulingTool,
  isSchedulingTool,
  prepareScheduling,
  SCHEDULING_ROLE,
} from "@/lib/scheduling/agent";

export interface RoleModule {
  /** Nome curto pros logs (flush.<nome>_tool_loop). */
  name: string;
  tools: LLMToolDef[];
  contextBlock: string;
  handles(toolName: string): boolean;
  execute(call: LLMToolUse): Promise<string>;
}

export interface RoleModuleContext {
  agentSession: Pick<AgentSession, "id" | "role" | "intakeFields">;
  contactId: string;
  conversationId: string;
  channel: ChannelId;
  externalId: string;
}

const MODULE_ROLES = new Set<string>([SCHEDULING_ROLE, DELIVERY_ROLE]);

/** O tipo do agente tem módulo próprio? (sem catálogo de cursos/CTA de vendas) */
export function isModuleRole(role: string | null | undefined): boolean {
  return Boolean(role && MODULE_ROLES.has(role));
}

export async function prepareRoleModule(ctx: RoleModuleContext): Promise<RoleModule | null> {
  const agentSessionId = ctx.agentSession.id;
  if (ctx.agentSession.role === SCHEDULING_ROLE) {
    const setup = await prepareScheduling({
      agentSessionId,
      intakeFieldsRaw: ctx.agentSession.intakeFields,
      contactId: ctx.contactId,
    });
    return {
      name: "scheduling",
      tools: setup.tools,
      contextBlock: setup.contextBlock,
      handles: isSchedulingTool,
      execute: (call) =>
        executeSchedulingTool(call, {
          agentSessionId,
          contactId: ctx.contactId,
          conversationId: ctx.conversationId,
          intakeFields: setup.intakeFields,
        }),
    };
  }
  if (ctx.agentSession.role === DELIVERY_ROLE) {
    const setup = await prepareDelivery({ agentSessionId, contactId: ctx.contactId });
    return {
      name: "delivery",
      tools: setup.tools,
      contextBlock: setup.contextBlock,
      handles: isDeliveryTool,
      execute: (call) =>
        executeDeliveryTool(call, {
          agentSessionId,
          contactId: ctx.contactId,
          conversationId: ctx.conversationId,
          channel: ctx.channel,
          externalId: ctx.externalId,
        }),
    };
  }
  return null;
}
