import { describe, it, expect } from "vitest";
import {
  extractLeadIdFromUtm,
  extractPayerEmail,
  extractPurchaseData,
} from "./parser";

const BASE_INVOICE_PAID = {
  type: "invoice.payment_succeeded",
  event: {
    invoice: {
      id: "inv_123",
      status: "paid",
      currency: "BRL",
      paymentMethod: "credit_card",
      installments: 12,
      saleDate: "2026-05-28T14:30:00.000Z",
      amount: { totalCents: 112320 },
      firstPaymentSession: { utm: { content: "lead_abc" } },
      products: [{ id: "prod_1", offers: [{ id: "offer_1" }] }],
    },
    payer: { email: "buyer@example.com" },
  },
};

describe("extractLeadIdFromUtm", () => {
  it("retorna utm.content quando presente", () => {
    expect(extractLeadIdFromUtm(BASE_INVOICE_PAID)).toBe("lead_abc");
  });

  it("retorna null quando firstPaymentSession ausente", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    delete p.event.invoice.firstPaymentSession;
    expect(extractLeadIdFromUtm(p)).toBeNull();
  });

  it("retorna null quando utm.content vazio", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    p.event.invoice.firstPaymentSession.utm.content = "";
    expect(extractLeadIdFromUtm(p)).toBeNull();
  });

  it("retorna null pra payload malformado", () => {
    expect(extractLeadIdFromUtm(null)).toBeNull();
    expect(extractLeadIdFromUtm({})).toBeNull();
    expect(extractLeadIdFromUtm({ event: "string" })).toBeNull();
  });

  it("estrutura real v2: extrai de paymentSession.utm.content", () => {
    const p = {
      event: {
        invoice: {
          id: "x",
          paymentSession: { utm: { content: "lead_real_v2" } },
        },
      },
    };
    expect(extractLeadIdFromUtm(p)).toBe("lead_real_v2");
  });

  it("paymentSession tem prioridade sobre firstPaymentSession", () => {
    const p = {
      event: {
        invoice: {
          id: "x",
          paymentSession: { utm: { content: "from_payment_session" } },
          firstPaymentSession: { utm: { content: "from_first" } },
        },
      },
    };
    expect(extractLeadIdFromUtm(p)).toBe("from_payment_session");
  });
});

describe("extractPayerEmail", () => {
  it("retorna email do payer quando presente", () => {
    expect(extractPayerEmail(BASE_INVOICE_PAID)).toBe("buyer@example.com");
  });

  it("retorna null quando email ausente ou vazio", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    delete p.event.payer.email;
    expect(extractPayerEmail(p)).toBeNull();
    p.event.payer = { email: "" };
    expect(extractPayerEmail(p)).toBeNull();
  });

  it("retorna null pra payload malformado", () => {
    expect(extractPayerEmail(null)).toBeNull();
    expect(extractPayerEmail({})).toBeNull();
  });

  it("estrutura real v2: extrai de event.invoice.payer.email", () => {
    const p = {
      event: { invoice: { payer: { email: "real@test.com" } } },
    };
    expect(extractPayerEmail(p)).toBe("real@test.com");
  });

  it("fallback final: event.user.email quando outros caminhos faltam", () => {
    const p = { event: { user: { email: "from_user@test.com" } } };
    expect(extractPayerEmail(p)).toBe("from_user@test.com");
  });

  it("prioridade: invoice.payer > event.payer > event.user", () => {
    const p = {
      event: {
        invoice: { payer: { email: "a@test.com" } },
        payer: { email: "b@test.com" },
        user: { email: "c@test.com" },
      },
    };
    expect(extractPayerEmail(p)).toBe("a@test.com");
  });
});

describe("extractPurchaseData", () => {
  it("extrai todos os campos do payload válido", () => {
    expect(extractPurchaseData(BASE_INVOICE_PAID)).toEqual({
      invoiceId: "inv_123",
      saleDate: new Date("2026-05-28T14:30:00.000Z"),
      productId: "prod_1",
      offerId: "offer_1",
      totalCents: 112320,
      currency: "BRL",
      paymentMethod: "credit_card",
      installments: 12,
    });
  });

  it("aceita products vazio — productId/offerId viram null", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    p.event.invoice.products = [];
    const data = extractPurchaseData(p);
    expect(data?.productId).toBeNull();
    expect(data?.offerId).toBeNull();
  });

  it("aceita produto sem offers — offerId vira null", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    p.event.invoice.products = [{ id: "prod_1" }];
    const data = extractPurchaseData(p);
    expect(data?.productId).toBe("prod_1");
    expect(data?.offerId).toBeNull();
  });

  it("retorna null se invoice.id ausente (payload inválido)", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    delete p.event.invoice.id;
    expect(extractPurchaseData(p)).toBeNull();
  });

  it("retorna null pra payload completamente malformado", () => {
    expect(extractPurchaseData(null)).toBeNull();
    expect(extractPurchaseData({ event: {} })).toBeNull();
  });

  it("saleDate string inválida → cai no fallback (sem Invalid Date)", () => {
    const p = JSON.parse(JSON.stringify(BASE_INVOICE_PAID));
    p.event.invoice.saleDate = "28/05/2026"; // formato BR, inválido pro Date
    const data = extractPurchaseData(p);
    expect(data).not.toBeNull();
    expect(Number.isNaN(data!.saleDate.getTime())).toBe(false);
  });

  it("estrutura real v2: products em event.products (não event.invoice.products)", () => {
    const p = {
      event: {
        invoice: {
          id: "inv_v2",
          saleDate: "2026-05-28T14:00:00.000Z",
          currency: "BRL",
          paymentMethod: "pix",
          installments: 1,
          amount: { totalCents: 1000 },
        },
        products: [
          { id: "prod_real", offers: [{ id: "offer_real" }] },
        ],
      },
    };
    const data = extractPurchaseData(p);
    expect(data?.productId).toBe("prod_real");
    expect(data?.offerId).toBe("offer_real");
  });
});
