"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Save } from "lucide-react";
import { savePlan, deletePlan } from "@/app/(app)/launches/actions";

interface Plan {
  id?: string;
  name: string;
  priceCents: number;
  checkoutUrl: string | null;
  description: string | null;
  sortOrder: number;
}

/** Plano + buffer de texto do preço (pra deixar o usuário digitar sem reformatação). */
interface PlanRow extends Plan {
  priceText: string;
}

interface Props {
  launchId: string;
  initial: Plan[];
}

/** Converte texto BR ("1.497,50" ou "1497,50" ou "1497.5" ou "1497") em centavos. */
function parsePriceTextToCents(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  // remove separador de milhar (ponto se vier antes da vírgula, ou vírgula se vier antes do ponto)
  // estratégia simples: remove todo "." se houver "," (formato BR), senão deixa o "." como decimal
  const normalized = trimmed.includes(",")
    ? trimmed.replace(/\./g, "").replace(",", ".")
    : trimmed;
  const n = parseFloat(normalized);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.round(n * 100);
}

/** Formata centavos pra texto BR ("1497.50" → "1497,50"). */
function formatCentsToPriceText(cents: number): string {
  if (!cents) return "";
  return (cents / 100).toFixed(2).replace(".", ",");
}

/**
 * Editor inline de planos do Launch. Cada linha:
 *  - nome (Input)
 *  - preço em R$ (Input numeric)
 *  - checkout URL (Input)
 *  - descrição opcional (Textarea)
 *  - botões Salvar (por linha — chama savePlan) e Remover (deletePlan)
 *
 * Linhas novas (sem id) ficam só em state local até clicar Salvar.
 */
export function PlansEditor({ launchId, initial }: Props) {
  const [plans, setPlans] = useState<PlanRow[]>(
    initial.map((p) => ({ ...p, priceText: formatCentsToPriceText(p.priceCents) })),
  );
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const updateRow = (i: number, patch: Partial<PlanRow>) => {
    const next = [...plans];
    next[i] = { ...next[i]!, ...patch };
    setPlans(next);
  };

  const submit = (p: PlanRow) =>
    start(async () => {
      setError(null);
      const priceCents = parsePriceTextToCents(p.priceText);
      const payload: Plan = {
        id: p.id,
        name: p.name,
        priceCents,
        checkoutUrl: p.checkoutUrl,
        description: p.description,
        sortOrder: p.sortOrder,
      };
      const r = await savePlan(launchId, payload);
      if (r.error) setError(r.error);
      else if (!p.id) {
        // linha nova foi criada — recarrega a página pra puxar o id real
        // (ou poderia voltar o objeto criado; simplifica via reload)
        window.location.reload();
      }
    });

  const remove = (i: number, planId: string) =>
    start(async () => {
      setError(null);
      const r = await deletePlan(launchId, planId);
      if (r.error) setError(r.error);
      else setPlans(plans.filter((_, idx) => idx !== i));
    });

  const addRow = () =>
    setPlans([
      ...plans,
      {
        name: "",
        priceCents: 0,
        priceText: "",
        checkoutUrl: null,
        description: null,
        sortOrder: plans.length,
      },
    ]);

  return (
    <div className="space-y-3">
      {plans.length === 0 && (
        <p className="text-sm text-muted-foreground italic">
          Nenhum plano cadastrado. Sem planos, a oferta não pode ser ativada.
        </p>
      )}
      {plans.map((p, i) => (
        <div
          key={p.id ?? `new-${i}`}
          className="grid gap-2 md:grid-cols-12 rounded-md border p-3 items-end"
        >
          <div className="md:col-span-3 space-y-1">
            <Label className="text-xs text-muted-foreground" htmlFor={`plan-name-${i}`}>
              Nome
            </Label>
            <Input
              id={`plan-name-${i}`}
              value={p.name}
              onChange={(e) => updateRow(i, { name: e.target.value })}
              placeholder="1 ano"
            />
          </div>
          <div className="md:col-span-2 space-y-1">
            <Label className="text-xs text-muted-foreground" htmlFor={`plan-price-${i}`}>
              Preço (R$)
            </Label>
            <Input
              id={`plan-price-${i}`}
              type="text"
              inputMode="decimal"
              value={p.priceText}
              onChange={(e) => updateRow(i, { priceText: e.target.value })}
              placeholder="1497,50"
            />
          </div>
          <div className="md:col-span-5 space-y-1">
            <Label className="text-xs text-muted-foreground" htmlFor={`plan-url-${i}`}>
              Checkout URL
            </Label>
            <Input
              id={`plan-url-${i}`}
              value={p.checkoutUrl ?? ""}
              onChange={(e) => updateRow(i, { checkoutUrl: e.target.value || null })}
              placeholder="https://..."
            />
          </div>
          <div className="md:col-span-2 flex gap-1 justify-end">
            <Button
              type="button"
              size="sm"
              disabled={pending}
              onClick={() => submit(p)}
              aria-label="Salvar plano"
            >
              <Save className="size-4" />
            </Button>
            {p.id && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                disabled={pending}
                onClick={() => remove(i, p.id!)}
                aria-label="Remover plano"
              >
                <Trash2 className="size-4" />
              </Button>
            )}
          </div>
          <div className="md:col-span-12 space-y-1">
            <Label className="text-xs text-muted-foreground" htmlFor={`plan-desc-${i}`}>
              Descrição (opcional)
            </Label>
            <Textarea
              id={`plan-desc-${i}`}
              rows={1}
              value={p.description ?? ""}
              onChange={(e) => updateRow(i, { description: e.target.value || null })}
              placeholder="ex: inclui mentoria semanal"
            />
          </div>
        </div>
      ))}
      {error && <p className="text-sm text-destructive font-mono">{error}</p>}
      <Button type="button" variant="outline" size="sm" onClick={addRow}>
        <Plus className="size-4" /> Adicionar plano
      </Button>
    </div>
  );
}
