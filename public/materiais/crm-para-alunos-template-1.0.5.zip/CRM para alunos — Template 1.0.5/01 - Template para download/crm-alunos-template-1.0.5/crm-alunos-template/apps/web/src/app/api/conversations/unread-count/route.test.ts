import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));

import { GET } from "./route";
import { auth } from "@/auth";

const created = { contactIds: [] as string[], userIds: [] as string[] };
let userId: string;

beforeAll(async () => {
  const u = await prisma.user.create({
    data: { email: `unreadcount-${Date.now()}@t.local`, name: "User U" },
  });
  userId = u.id;
  created.userIds.push(u.id);
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

async function countFromRoute(): Promise<number> {
  const res = await GET();
  expect(res.status).toBe(200);
  const body = (await res.json()) as { count: number };
  return body.count;
}

describe("GET /api/conversations/unread-count", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await GET();
    expect(res.status).toBe(401);
  });

  it("conta conversas com unreadCount > 0 (não soma mensagens)", async () => {
    const baseline = await countFromRoute();
    const contact = await prisma.contact.create({ data: { displayName: "U" } });
    created.contactIds.push(contact.id);
    // 2 não lidas (5 e 1 msgs) + 1 lida → baseline deve subir exatamente 2.
    await prisma.conversation.createMany({
      data: [
        { contactId: contact.id, channel: "whatsapp_cloud", unreadCount: 5 },
        { contactId: contact.id, channel: "whatsapp_cloud", unreadCount: 1 },
        { contactId: contact.id, channel: "whatsapp_cloud", unreadCount: 0 },
      ],
    });
    const after = await countFromRoute();
    expect(after - baseline).toBe(2);
  });
});
