import type { ChannelMedia, ChannelMessage, SessionState } from "../types";
import type { WaqrProviderId } from "@/lib/settings/whatsapp-qr-fields";

/** Configuração resolvida (painel > .env) de um provedor de WhatsApp via QR. */
export interface WaqrSettings {
  provider: string;
  /** URL base da API do provedor, sem barra final. */
  baseUrl?: string;
  session: string;
  apiKey?: string;
  webhookSecret?: string;
  /** URL completa que o provedor chama ao receber mensagem. */
  webhookUrl: string;
}

/**
 * Contrato de um provedor não oficial (WAHA hoje; Uazapi depois).
 * O adapter do canal (`index.ts`) resolve a configuração e delega para cá —
 * adicionar um provedor = novo arquivo que implementa esta interface.
 */
export interface WhatsAppQrProvider {
  id: WaqrProviderId;
  status(s: WaqrSettings): Promise<SessionState>;
  /** Idempotente: cria/atualiza a sessão e o webhook; estado final vem de nova leitura. */
  ensureSession(s: WaqrSettings): Promise<SessionState>;
  /**
   * Desconecta o número (logout do WhatsApp) sem apagar a sessão: reconectar é
   * gerar o QR de novo. Nada do CRM é apagado (agentes, conversas, contatos).
   */
  logout?(s: WaqrSettings): Promise<SessionState>;
  /** Imagem do QR code para parear o número. */
  qr(s: WaqrSettings): Promise<Response>;
  /** Valida a assinatura e normaliza. Lança HmacFailure se a assinatura não confere. */
  parseWebhook(rawBody: string, headers: Headers, s: WaqrSettings): ChannelMessage | null;
  sendText(s: WaqrSettings, externalId: string, text: string): Promise<void>;
  /** Envia imagem ou documento (base64). Lança se o provedor recusar (ex.: edição sem suporte). */
  sendMedia?(s: WaqrSettings, externalId: string, media: ChannelMedia): Promise<void>;
  /** "digitando…" na conversa. Opcional: provedor sem suporte simplesmente não mostra. */
  setTyping?(s: WaqrSettings, externalId: string, on: boolean): Promise<void>;
  /** Baixa uma mídia recebida, sempre no host configurado (nunca no host informado pelo payload). */
  fetchMedia(s: WaqrSettings, mediaUrl: string, range: string | null): Promise<Response>;
}
