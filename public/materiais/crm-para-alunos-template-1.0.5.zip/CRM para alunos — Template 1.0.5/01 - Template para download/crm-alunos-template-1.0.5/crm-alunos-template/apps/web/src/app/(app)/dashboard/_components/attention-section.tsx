import Link from "next/link";
import { prisma } from "@/lib/db";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { AlertTriangle, UserCheck, Clock, ChevronRight } from "lucide-react";

interface AttentionData {
  slaBreached: number;
  handoffWaiting: number;
  windowClosing: number;
  error: boolean;
}

async function getAttention(): Promise<AttentionData> {
  try {
    const now = new Date();
    const [slaBreached, handoffWaiting, windowClosing] = await Promise.all([
      prisma.lead.count({ where: { slaBreachedAt: { not: null } } }),
      prisma.conversation.count({
        where: {
          handoffRequested: true,
          lead: {
            pipelineEvents: { none: { type: "handoff_accepted" } },
          },
        },
      }),
      prisma.conversation.count({
        where: { windowClosingSoon: true, windowClosesAt: { gt: now } },
      }),
    ]);
    return { slaBreached, handoffWaiting, windowClosing, error: false };
  } catch {
    return {
      slaBreached: 0,
      handoffWaiting: 0,
      windowClosing: 0,
      error: true,
    };
  }
}

export async function AttentionSection() {
  const { slaBreached, handoffWaiting, windowClosing, error } =
    await getAttention();

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">Exigindo atenção</CardTitle>
        <CardDescription>Conversas que precisam de ação humana</CardDescription>
      </CardHeader>
      <CardContent className="space-y-1">
        {error ? (
          <p className="text-sm text-destructive">Banco indisponível.</p>
        ) : (
          <>
            <AttentionRow
              icon={<AlertTriangle className="size-4 text-destructive" />}
              label="SLA estourado"
              count={slaBreached}
              href="/conversations?filter=sla"
            />
            <AttentionRow
              icon={<UserCheck className="size-4 text-warning" />}
              label="Bot solicitou humano"
              count={handoffWaiting}
              href="/conversations?filter=handoff"
            />
            <AttentionRow
              icon={<Clock className="size-4 text-warning" />}
              label="Janela fechando"
              count={windowClosing}
              href="/conversations?filter=closing"
            />
          </>
        )}
      </CardContent>
    </Card>
  );
}

function AttentionRow({
  icon,
  label,
  count,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  count: number;
  href: string;
}) {
  const content = (
    <>
      <span className="flex items-center gap-2">
        {icon}
        {label}
      </span>
      <span className="flex items-center gap-1.5">
        <span className="font-mono font-semibold">{count}</span>
        {count > 0 && (
          <ChevronRight className="size-4 text-muted-foreground" />
        )}
      </span>
    </>
  );

  if (count === 0) {
    return (
      <div className="flex items-center justify-between rounded-md px-2 py-2 text-sm text-muted-foreground">
        {content}
      </div>
    );
  }
  return (
    <Link
      href={href}
      className="flex items-center justify-between rounded-md px-2 py-2 text-sm transition-colors hover:bg-muted/50"
    >
      {content}
    </Link>
  );
}
