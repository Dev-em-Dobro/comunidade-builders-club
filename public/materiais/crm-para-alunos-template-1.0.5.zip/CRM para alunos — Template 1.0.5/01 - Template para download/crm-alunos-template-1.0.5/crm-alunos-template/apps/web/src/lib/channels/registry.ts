import { getEnabledChannels } from "@/lib/config";
import type { ChannelAdapter, ChannelId } from "./types";
import { whatsappCloudAdapter } from "./whatsapp-cloud";
import { instagramAdapter } from "./instagram";
import { whatsappQrAdapter } from "./whatsapp-qr";

const ALL_ADAPTERS: Record<ChannelId, ChannelAdapter> = {
  whatsapp_cloud: whatsappCloudAdapter,
  instagram: instagramAdapter,
  whatsapp_qr: whatsappQrAdapter,
};

/**
 * Mapeamento entre o slug usado em setup.config.json (`instagram_direct`)
 * e o id interno do adapter (`instagram`). Cloud API é 1:1.
 */
const SLUG_TO_ID: Record<string, ChannelId> = {
  whatsapp_cloud: "whatsapp_cloud",
  instagram_direct: "instagram",
  instagram: "instagram",
  whatsapp_qr: "whatsapp_qr",
};

export function getAdapter(id: ChannelId): ChannelAdapter {
  const adapter = ALL_ADAPTERS[id];
  if (!adapter) throw new Error(`Adapter desconhecido: ${id}`);
  return adapter;
}

export function getEnabledAdapters(): ChannelAdapter[] {
  const enabled = getEnabledChannels();
  const ids = enabled
    .map((slug) => SLUG_TO_ID[slug as string])
    .filter((x): x is ChannelId => !!x);
  return ids.map((id) => ALL_ADAPTERS[id]);
}

/** Resolve um id de URL (whatsapp-cloud, instagram) pro adapter correto. */
export function getAdapterByUrlSlug(slug: string): ChannelAdapter | null {
  const normalized = slug.replace(/-/g, "_");
  // whatsapp-cloud → whatsapp_cloud ; instagram → instagram
  const idCandidate = (SLUG_TO_ID[normalized] ?? normalized) as ChannelId;
  return ALL_ADAPTERS[idCandidate] ?? null;
}
