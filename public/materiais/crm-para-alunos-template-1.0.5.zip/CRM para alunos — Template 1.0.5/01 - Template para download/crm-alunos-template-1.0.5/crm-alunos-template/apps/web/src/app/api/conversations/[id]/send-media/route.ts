import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { isWithin24hWindow } from "@/lib/window24h";
import { inspectOutgoingMedia } from "@/lib/channels/outgoing-media";
import { sendWhatsAppMedia } from "@/lib/channels/whatsapp-send-media";
import { ChannelSendError, META_OUT_OF_WINDOW } from "@/lib/channels/meta-graph";
import { claimConversation } from "@/lib/conversations/claim";
import { notifyConvEvent, notifyMessage } from "@/lib/realtime/notify";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { user } = gate;
  const { id: conversationId } = await params;

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    include: { contact: { include: { identities: true } } },
  });
  if (!conv) return NextResponse.json({ error: "not_found" }, { status: 404 });
  if (conv.channel !== "whatsapp_cloud") {
    return NextResponse.json({ error: "channel_unsupported" }, { status: 400 });
  }
  if (conv.aiEnabled) return NextResponse.json({ error: "ai_active" }, { status: 409 });
  if (conv.assignedUserId && conv.assignedUserId !== user.id) {
    return NextResponse.json({ error: "owned_by_other" }, { status: 403 });
  }
  if (!isWithin24hWindow(conv.windowClosesAt)) {
    return NextResponse.json({ error: "window_closed" }, { status: 409 });
  }
  const externalId = conv.contact.identities.find((identity) => identity.channel === "whatsapp_cloud")?.externalId;
  if (!externalId) return NextResponse.json({ error: "no_identity" }, { status: 500 });

  let file: File;
  let caption: string;
  try {
    const form = await request.formData();
    const candidate = form.get("file");
    if (!(candidate instanceof File)) {
      return NextResponse.json({ error: "file_required" }, { status: 400 });
    }
    file = candidate;
    caption = String(form.get("caption") ?? "").trim();
  } catch {
    return NextResponse.json({ error: "invalid_form" }, { status: 400 });
  }

  let info: ReturnType<typeof inspectOutgoingMedia>;
  try {
    info = inspectOutgoingMedia(file);
  } catch (error) {
    return NextResponse.json({ error: "invalid_file", detail: (error as Error).message }, { status: 400 });
  }
  if (caption.length > 1024) {
    return NextResponse.json({ error: "caption_too_long" }, { status: 400 });
  }
  if (info.kind === "audio" && caption) {
    return NextResponse.json({ error: "audio_caption_unsupported" }, { status: 400 });
  }

  let claimResult: Awaited<ReturnType<typeof claimConversation>>;
  try {
    claimResult = await claimConversation(conversationId, user.id);
    if (claimResult.assignedUserId !== user.id) {
      return NextResponse.json({ error: "owned_by_other" }, { status: 403 });
    }
  } catch {
    return NextResponse.json({ error: "claim_failed" }, { status: 500 });
  }

  let mediaId: string;
  let providerMsgId: string;
  try {
    ({ mediaId, providerMsgId } = await sendWhatsAppMedia(externalId, file, info, caption));
  } catch (error) {
    if (error instanceof ChannelSendError && error.code === META_OUT_OF_WINDOW) {
      await prisma.conversation.update({
        where: { id: conversationId },
        data: { windowExpired: true },
      });
      return NextResponse.json({ error: "window_closed_meta" }, { status: 409 });
    }
    return NextResponse.json({
      error: "send_failed",
      detail: String((error as Error)?.message ?? error),
    }, { status: 502 });
  }

  const saved = await prisma.message.create({
    data: {
      conversationId,
      direction: "outbound",
      role: "assistant",
      text: caption || `[${info.kind}]`,
      mediaType: info.kind,
      mediaId,
      mediaMimeType: info.mimeType,
      providerMsgId,
      sentByUserId: user.id,
    },
  });
  const now = new Date();
  await prisma.conversation.update({
    where: { id: conversationId },
    data: { lastMessageAt: now, lastOutboundAt: now },
  });
  await notifyMessage(conversationId, saved.id);

  if (claimResult.claimed) {
    const actor = await prisma.user.findUnique({
      where: { id: user.id },
      select: { name: true },
    });
    await notifyConvEvent(conversationId, {
      type: "claim",
      userId: user.id,
      userName: actor?.name ?? null,
      previousOwnerId: claimResult.previousOwnerId,
    });
  }
  return NextResponse.json({ ok: true, messageId: saved.id });
}
