import { randomBytes } from "node:crypto";

export const BASE62_ALPHABET =
  "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

/**
 * Gera um código aleatório base62 (0-9a-zA-Z) com o tamanho pedido.
 * Usa crypto.randomBytes pra entropia (não Math.random).
 * Descarta bytes >= 248 pra evitar viés do modulo (256 % 62 != 0).
 */
export function generateBase62Code(length: number): string {
  if (!Number.isInteger(length) || length <= 0) {
    throw new Error(`generateBase62Code: length deve ser inteiro > 0, recebeu ${length}`);
  }
  const out: string[] = [];
  while (out.length < length) {
    const buf = randomBytes(length * 2);
    for (const byte of buf) {
      if (byte >= 248) continue;
      out.push(BASE62_ALPHABET[byte % 62]!);
      if (out.length >= length) break;
    }
  }
  return out.join("");
}
