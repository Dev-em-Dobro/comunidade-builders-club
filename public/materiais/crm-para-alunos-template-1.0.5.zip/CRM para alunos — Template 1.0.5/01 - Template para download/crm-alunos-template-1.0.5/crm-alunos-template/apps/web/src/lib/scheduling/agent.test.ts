import { describe, expect, it } from "vitest";
import { buildSchedulingTools, isSchedulingTool } from "./agent";
import { DEFAULT_INTAKE_FIELDS } from "./intake";

describe("buildSchedulingTools", () => {
  const [check, book] = buildSchedulingTools(["p1", "p2"], DEFAULT_INTAKE_FIELDS);

  it("restringe professionalId aos profissionais cadastrados", () => {
    const props = (check!.inputSchema as { properties: Record<string, { enum?: string[] }> }).properties;
    expect(props.professionalId!.enum).toEqual(["p1", "p2"]);
  });

  it("transforma os campos da pré-consulta no schema do book_appointment", () => {
    const intake = (book!.inputSchema as {
      properties: { intake: { properties: Record<string, unknown>; required: string[] } };
    }).properties.intake;
    expect(Object.keys(intake.properties)).toEqual(DEFAULT_INTAKE_FIELDS.map((f) => f.key));
    expect(intake.required).toEqual(["nome_completo", "data_nascimento", "motivo_consulta"]);
  });

  it("identifica as tools locais do loop", () => {
    expect(isSchedulingTool("book_appointment")).toBe(true);
    expect(isSchedulingTool("request_handoff")).toBe(false);
  });
});
