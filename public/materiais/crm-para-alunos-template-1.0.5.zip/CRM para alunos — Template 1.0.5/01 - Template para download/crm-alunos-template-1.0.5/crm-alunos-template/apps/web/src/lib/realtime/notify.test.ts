import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock do prisma — só queremos verificar a SQL chamada.
vi.mock("@/lib/db", () => ({
  prisma: {
    $executeRawUnsafe: vi.fn().mockResolvedValue(1),
  },
}));

import { prisma } from "@/lib/db";
import { notifyMessage, notifyConvEvent } from "./notify";

describe("notifyMessage", () => {
  beforeEach(() => {
    vi.mocked(prisma.$executeRawUnsafe).mockClear();
  });

  it("chama pg_notify com canal 'msg_new' e payload JSON", async () => {
    await notifyMessage("conv-1", "msg-42");
    expect(prisma.$executeRawUnsafe).toHaveBeenCalledTimes(1);
    const [sql, payload] = vi.mocked(prisma.$executeRawUnsafe).mock.calls[0]!;
    expect(sql).toMatch(/pg_notify\('msg_new', \$1\)/);
    expect(JSON.parse(payload as string)).toEqual({
      conversationId: "conv-1",
      messageId: "msg-42",
    });
  });
});

describe("notifyConvEvent", () => {
  beforeEach(() => {
    vi.mocked(prisma.$executeRawUnsafe).mockClear();
  });

  it("chama pg_notify no canal 'conv_event' com payload JSON e conversationId", async () => {
    await notifyConvEvent("conv-7", {
      type: "claim",
      userId: "u-9",
      userName: "Cliente Exemplo",
      previousOwnerId: null,
    });
    expect(prisma.$executeRawUnsafe).toHaveBeenCalledTimes(1);
    const [sql, payload] = vi.mocked(prisma.$executeRawUnsafe).mock.calls[0]!;
    expect(sql).toMatch(/pg_notify\('conv_event', \$1\)/);
    expect(JSON.parse(payload as string)).toEqual({
      conversationId: "conv-7",
      type: "claim",
      userId: "u-9",
      userName: "Cliente Exemplo",
      previousOwnerId: null,
    });
  });
});
