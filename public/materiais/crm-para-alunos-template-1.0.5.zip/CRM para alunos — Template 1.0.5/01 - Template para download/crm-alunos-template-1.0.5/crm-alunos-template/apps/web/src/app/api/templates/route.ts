import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const templates = await prisma.messageTemplate.findMany({
    where: { status: "APPROVED" },
    orderBy: { metaName: "asc" },
    select: {
      id: true,
      metaName: true,
      language: true,
      category: true,
      bodyText: true,
      variableCount: true,
    },
  });
  return NextResponse.json({ templates });
}
