import { auth } from "@/auth";
import { Client } from "pg";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * SSE endpoint — escuta `pg_notify('msg_new')` e relay pro cliente.
 * 1 conexão PG dedicada por aba aberta. Filtragem por convId em userland.
 * Keep-alive a cada 25s evita proxy timeout (Railway, Cloudflare etc).
 */
export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const session = await auth();
  if (!session?.user?.id) {
    return new Response("unauthorized", { status: 401 });
  }
  const { id: convId } = await params;

  const client = new Client({ connectionString: process.env.DATABASE_URL });
  await client.connect();
  await client.query("LISTEN msg_new");
  await client.query("LISTEN conv_event");

  const enc = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      const keepAlive = setInterval(() => {
        try {
          controller.enqueue(enc.encode(": keep-alive\n\n"));
        } catch {
          // controller já fechado — limpa abaixo via abort.
        }
      }, 25_000);

      client.on("notification", (msg) => {
        if (!msg.payload) return;
        try {
          const parsed = JSON.parse(msg.payload) as {
            conversationId?: string;
          };
          if (parsed.conversationId !== convId) return;
          if (msg.channel === "msg_new") {
            controller.enqueue(enc.encode(`data: ${msg.payload}\n\n`));
          } else if (msg.channel === "conv_event") {
            // Evento SSE nomeado pra cliente discriminar via addEventListener.
            controller.enqueue(
              enc.encode(`event: conv_event\ndata: ${msg.payload}\n\n`),
            );
          }
        } catch {
          // payload malformado — ignora.
        }
      });

      client.on("error", (err) => {
        console.error("[sse] pg client error", err);
        try {
          controller.error(err);
        } catch {}
      });

      req.signal.addEventListener("abort", () => {
        clearInterval(keepAlive);
        client.end().catch(() => {});
        try {
          controller.close();
        } catch {}
      });
    },
  });

  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream",
      "cache-control": "no-cache, no-transform",
      "connection": "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
