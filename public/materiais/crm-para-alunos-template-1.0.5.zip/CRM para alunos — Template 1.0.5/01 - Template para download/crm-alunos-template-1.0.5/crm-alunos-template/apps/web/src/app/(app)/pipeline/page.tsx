import { prisma } from "@/lib/db";
import { deriveColumn, COLUMN_IDS, type ColumnId } from "@/lib/pipeline/columns";
import type { LeadView, Assignee } from "./_components/types";
import { PipelineBoard } from "./_components/pipeline-board";

export const dynamic = "force-dynamic";

const LEADS_PER_COLUMN = 100;

export default async function PipelinePage() {
  const leads = await prisma.lead.findMany({
    orderBy: [{ lastActivityAt: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      stage: true,
      score: true,
      lastFollowUpStep: true,
      lastFollowUpAt: true,
      lastActivityAt: true,
      interestCourseIds: true,
      contact: {
        select: {
          displayName: true,
          conversations: {
            orderBy: { lastMessageAt: "desc" },
            take: 1,
            select: {
              id: true,
              channel: true,
              aiEnabled: true,
              windowClosesAt: true,
              windowExpired: true,
              assignedUser: { select: { name: true } },
              agentSession: {
                select: { name: true, persona: true, role: true },
              },
            },
          },
        },
      },
    },
    take: LEADS_PER_COLUMN * COLUMN_IDS.length,
  });

  // Mapeia courseId → name (uma query)
  const courseIds = [...new Set(leads.flatMap((l) => l.interestCourseIds))];
  const courses = courseIds.length
    ? await prisma.course.findMany({
        where: { id: { in: courseIds } },
        select: { id: true, name: true },
      })
    : [];
  const courseById = new Map(courses.map((c) => [c.id, c.name]));

  const grouped: Record<ColumnId, LeadView[]> = {
    new: [],
    contacted: [],
    qualified: [],
    proposal: [],
    f1: [],
    f2: [],
    f3: [],
    closed: [],
  };

  for (const l of leads) {
    const col = deriveColumn({ stage: l.stage, lastFollowUpStep: l.lastFollowUpStep });
    if (grouped[col].length >= LEADS_PER_COLUMN) continue;
    const conv = l.contact.conversations[0];
    let assignee: Assignee | null = null;
    if (conv) {
      if (!conv.aiEnabled) {
        assignee = {
          type: "human",
          name: conv.assignedUser?.name ?? "Humano",
        };
      } else if (conv.agentSession) {
        assignee = {
          type: "bot",
          name: conv.agentSession.persona ?? conv.agentSession.name,
          role: conv.agentSession.role,
        };
      }
    }
    grouped[col].push({
      id: l.id,
      contactDisplayName: l.contact.displayName,
      score: l.score,
      stage: l.stage,
      lastFollowUpStep: l.lastFollowUpStep,
      lastFollowUpAt: l.lastFollowUpAt?.toISOString() ?? null,
      lastActivityAt: l.lastActivityAt?.toISOString() ?? null,
      conversationId: conv?.id ?? null,
      channel: conv?.channel ?? null,
      courseName: l.interestCourseIds[0]
        ? (courseById.get(l.interestCourseIds[0]) ?? null)
        : null,
      assignee,
      windowClosesAt: conv?.windowClosesAt?.toISOString() ?? null,
      windowExpired: conv?.windowExpired ?? false,
    });
  }

  const totalActive = COLUMN_IDS.filter((c) => c !== "closed").reduce(
    (sum, c) => sum + grouped[c].length,
    0,
  );

  return (
    <div className="p-4 md:p-6 max-w-full">
      <header className="mb-4 flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Pipeline
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            {totalActive} leads ativos em {COLUMN_IDS.length - 1} estágios.
          </p>
        </div>
      </header>

      <PipelineBoard grouped={grouped} />
    </div>
  );
}
