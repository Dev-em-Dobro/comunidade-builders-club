import { auth } from "@/auth";
import Link from "next/link";
import { businessConfig, loadConfig } from "@/lib/config";
import { BusinessForm } from "./business-form";
export const dynamic = "force-dynamic";
export default async function SettingsGeneralPage() {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const cfg = loadConfig(); const b = businessConfig();
  return <div className="p-6 md:p-8 max-w-3xl space-y-6">
    <header><h1 className="text-3xl font-semibold tracking-tight">Sua empresa</h1><p className="text-muted-foreground mt-2">Personalize a identidade e escolha os canais de atendimento.</p></header>
    <nav className="flex flex-wrap gap-5 underline text-sm"><Link href="/settings/meta">Conectar Meta</Link><Link href="/settings/whatsapp-qr">WhatsApp via QR</Link><Link href="/settings/credentials">Chaves de IA</Link><Link href="/settings/agents">Agentes</Link></nav>
    <BusinessForm initial={{ ...b, accessUrl: b.accessUrl || "", legalName: cfg.business?.legalName || "", timezone: cfg.schedule.timezone, windowMs: cfg.cache.debounce.windowMs, whatsapp: cfg.channels.whatsapp_cloud.enabled, instagram: cfg.channels.instagram_direct.enabled, whatsappQr: cfg.channels.whatsapp_qr?.enabled ?? false }} />
    <p className="text-xs text-muted-foreground">Automações avançadas, qualificação e auditoria: configure setup.config.json seguindo o README. As páginas de privacidade e exclusão são modelos e devem ser revisadas para o seu negócio.</p>
  </div>;
}
