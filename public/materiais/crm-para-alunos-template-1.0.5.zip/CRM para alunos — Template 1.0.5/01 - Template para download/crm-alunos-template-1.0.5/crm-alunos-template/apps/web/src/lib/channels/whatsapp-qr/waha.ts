/**
 * Provedor WAHA (https://waha.devlike.pro) — WhatsApp Web via QR, self-hosted.
 *
 * Gotchas:
 *  - Conexão NÃO oficial: a sessão pode cair e o número pode ser bloqueado
 *    conforme o uso. O CRM só responde quem escreveu; não faça disparo frio.
 *  - Webhook assinado: X-Webhook-Hmac = HMAC-SHA512(hex) do corpo cru.
 *  - `fromMe` chega também para o que o próprio CRM enviou — ignorar evita loop.
 *  - `media.url` aponta para o host que o WAHA conhece (WAHA_BASE_URL), que pode
 *    não ser alcançável pelo CRM; baixamos sempre pelo baseUrl configurado.
 */
import { verifyHmacSha512Hex } from "../hmac";
import { HmacFailure } from "../whatsapp-cloud";
import type { ChannelMedia, ChannelMessage, MediaType, SessionState } from "../types";
import type { WaqrSettings, WhatsAppQrProvider } from "./types";
import { chatIdToExternalId, externalIdToChatId } from "./ids";

const TIMEOUT_MS = 10_000;

async function wahaFetch(s: WaqrSettings, path: string, init: RequestInit = {}): Promise<Response> {
  const headers = new Headers(init.headers);
  headers.set("X-Api-Key", s.apiKey ?? "");
  if (!headers.has("Accept")) headers.set("Accept", "application/json");
  if (init.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  return fetch(`${s.baseUrl}${path}`, {
    ...init,
    headers,
    cache: "no-store",
    signal: init.signal ?? AbortSignal.timeout(TIMEOUT_MS),
  });
}

function base(s: WaqrSettings, status: SessionState["status"], message: string, details?: Record<string, unknown>): SessionState {
  return { channel: "whatsapp_qr", status, webhookUrl: s.webhookUrl, message, details };
}

function missing(s: WaqrSettings): SessionState | null {
  const absent = [
    !s.baseUrl && "WAQR_BASE_URL",
    !s.apiKey && "WAQR_API_KEY",
    !s.webhookSecret && "WAQR_WEBHOOK_SECRET",
  ].filter(Boolean);
  return absent.length
    ? base(s, "missing_credentials", `Faltam: ${absent.join(", ")}. Preencha em Configurações → WhatsApp via QR.`)
    : null;
}

interface WahaSession {
  name?: string;
  status?: string;
  me?: { id?: string; pushName?: string } | null;
  config?: {
    webhooks?: Array<{ url?: string; events?: string[]; hmac?: { key?: string } | null }>;
    [key: string]: unknown;
  } | null;
}

async function readSession(s: WaqrSettings): Promise<{ http: number; session?: WahaSession }> {
  const res = await wahaFetch(s, `/api/sessions/${encodeURIComponent(s.session)}`);
  if (!res.ok) return { http: res.status };
  return { http: res.status, session: (await res.json()) as WahaSession };
}

function mapStatus(s: WaqrSettings, session: WahaSession): SessionState {
  const st = session.status ?? "UNKNOWN";
  const details = { sessionStatus: st, session: s.session };
  switch (st) {
    case "WORKING": {
      const phone = chatIdToExternalId(session.me?.id) ?? session.me?.id ?? "—";
      return base(s, "connected", `${session.me?.pushName ?? "Conectado"} (${phone})`, details);
    }
    case "SCAN_QR_CODE":
      return base(s, "needs_verification", "Escaneie o QR code com o WhatsApp do número de atendimento.", details);
    case "STARTING":
      return base(s, "needs_verification", "Sessão iniciando — aguarde alguns segundos e confira o status.", details);
    case "STOPPED":
      return base(s, "error", "Sessão parada. Use \"Garantir sessão\" para iniciá-la.", details);
    case "FAILED":
      return base(s, "error", "Sessão falhou (aparelho desconectado?). Use \"Garantir sessão\"; se persistir, escaneie o QR novamente.", details);
    default:
      return base(s, "needs_verification", `Status do WAHA: ${st}.`, details);
  }
}

function unreachable(s: WaqrSettings, err: unknown): SessionState {
  return base(s, "error", `WAHA inacessível em ${s.baseUrl}: ${String((err as Error)?.message ?? err)}`);
}

function webhookMatches(s: WaqrSettings, session: WahaSession): boolean {
  const hooks = session.config?.webhooks ?? [];
  return hooks.some((h) =>
    h.url === s.webhookUrl && (h.events ?? []).includes("message") && h.hmac?.key === s.webhookSecret);
}

function mediaTypeFromMime(mime: string | undefined): MediaType {
  const m = (mime ?? "").toLowerCase();
  if (m.startsWith("image/")) return "image";
  if (m.startsWith("audio/")) return "audio";
  if (m.startsWith("video/")) return "video";
  return "document";
}

function contactNameOf(p: Record<string, unknown>): string | undefined {
  const data = (p._data ?? {}) as Record<string, unknown>;
  const info = (data.Info ?? data.info ?? {}) as Record<string, unknown>;
  for (const candidate of [data.notifyName, data.pushName, data.PushName, info.PushName, info.pushName]) {
    if (typeof candidate === "string" && candidate.trim()) return candidate.trim();
  }
  return undefined;
}

/** Texto legível para mensagens sem corpo e sem mídia (localização, contato). Nunca vazio. */
function describeNonText(p: Record<string, unknown>): string {
  const loc = p.location as { latitude?: number | string; longitude?: number | string; description?: string } | undefined;
  if (loc && loc.latitude != null && loc.longitude != null) {
    const parts = ["[localização]"];
    if (loc.description) parts.push(String(loc.description));
    parts.push(`(${loc.latitude}, ${loc.longitude})`);
    parts.push(`https://www.google.com/maps?q=${loc.latitude},${loc.longitude}`);
    return parts.join(" ");
  }
  const vCards = Array.isArray(p.vCards) ? p.vCards : [];
  if (vCards.length) {
    const names = vCards
      .map((v) => (typeof v === "string" ? /FN:(.+)/.exec(v)?.[1]?.trim() : undefined))
      .filter(Boolean);
    return names.length ? `[contato] ${names.join(" | ")}` : "[contato]";
  }
  return "[mensagem não suportada]";
}

export const wahaProvider: WhatsAppQrProvider = {
  id: "waha",

  async status(s) {
    const gap = missing(s);
    if (gap) return gap;
    try {
      const { http, session } = await readSession(s);
      if (http === 401 || http === 403) return base(s, "error", "WAHA recusou a chave (WAQR_API_KEY deve ser igual a WAHA_API_KEY do container).");
      if (http === 404) return base(s, "needs_verification", "Sessão ainda não existe no WAHA. Use \"Garantir sessão\".");
      if (!session) return base(s, "error", `WAHA respondeu HTTP ${http}.`);
      return mapStatus(s, session);
    } catch (err) {
      return unreachable(s, err);
    }
  },

  async logout(s) {
    const gap = missing(s);
    if (gap) return gap;
    try {
      const path = `/api/sessions/${encodeURIComponent(s.session)}`;
      const { http, session } = await readSession(s);
      if (http === 404 || !session) return base(s, "needs_verification", "Nenhum número conectado.");
      // Só desloga o número; a sessão (e o webhook) continuam configurados no WAHA,
      // então reconectar é só gerar o QR de novo.
      if (session.status === "WORKING" || session.status === "SCAN_QR_CODE" || session.status === "STARTING") {
        const res = await wahaFetch(s, `${path}/logout`, { method: "POST" });
        if (!res.ok) {
          const detail = (await res.text().catch(() => "")).slice(0, 200);
          return base(s, "error", `O WAHA não desconectou o número (HTTP ${res.status}). ${detail}`.trim());
        }
      }
      console.log(JSON.stringify({ event: "whatsapp_qr.logout", provider: "waha", session: s.session, at: new Date().toISOString() }));
      const after = await readSession(s);
      return after.session ? mapStatus(s, after.session) : base(s, "needs_verification", "Número desconectado.");
    } catch (err) {
      return unreachable(s, err);
    }
  },

  async ensureSession(s) {
    const gap = missing(s);
    if (gap) return gap;
    const webhooks = [{ url: s.webhookUrl, events: ["message"], hmac: { key: s.webhookSecret } }];
    let action = "sessão já configurada";
    try {
      const current = await readSession(s);
      if (current.http === 404) {
        const res = await wahaFetch(s, "/api/sessions", {
          method: "POST",
          body: JSON.stringify({ name: s.session, start: true, config: { webhooks } }),
        });
        if (!res.ok) return base(s, "error", `Não foi possível criar a sessão: HTTP ${res.status}.`);
        action = "sessão criada";
      } else if (current.session) {
        if (!webhookMatches(s, current.session)) {
          const res = await wahaFetch(s, `/api/sessions/${encodeURIComponent(s.session)}`, {
            method: "PUT",
            body: JSON.stringify({ name: s.session, config: { ...(current.session.config ?? {}), webhooks } }),
          });
          if (!res.ok) return base(s, "error", `Não foi possível atualizar o webhook da sessão: HTTP ${res.status}.`);
          action = "webhook atualizado";
        }
        const st = current.session.status;
        if (st === "STOPPED" || st === "FAILED") {
          const verb = st === "STOPPED" ? "start" : "restart";
          await wahaFetch(s, `/api/sessions/${encodeURIComponent(s.session)}/${verb}`, { method: "POST" });
          action += st === "STOPPED" ? " · sessão iniciada" : " · sessão reiniciada";
        }
      } else {
        return base(s, "error", `WAHA respondeu HTTP ${current.http} ao ler a sessão.`);
      }
    } catch (err) {
      return unreachable(s, err);
    }
    const state = await wahaProvider.status(s);
    return { ...state, message: `${state.message} · ${action}` };
  },

  async qr(s) {
    const fail = (status: number, error: string) => Response.json({ error }, { status });
    const gap = missing(s);
    if (gap) return fail(409, gap.message ?? "Configuração incompleta.");
    const path = `/api/sessions/${encodeURIComponent(s.session)}`;
    // Os QRs expiram (~6 tentativas). Depois disso a sessão vai para FAILED/STOPPED e
    // GET /auth/qr fica pendurado esperando um QR que não vem — por isso conferimos antes.
    const first = await readSession(s);
    const http = first.http;
    let session = first.session;
    if (http === 404) return fail(409, "Sessão ainda não existe. Clique em \"Garantir sessão\" primeiro.");
    if (!session) return fail(502, `WAHA respondeu HTTP ${http} ao ler a sessão.`);
    if (session.status === "WORKING") return fail(409, "O número já está conectado. Clique em \"Status\".");
    if (session.status === "STOPPED" || session.status === "FAILED") {
      await wahaFetch(s, `${path}/${session.status === "STOPPED" ? "start" : "restart"}`, { method: "POST" });
    }
    for (let attempt = 0; attempt < 15 && session?.status !== "SCAN_QR_CODE"; attempt++) {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      ({ session } = await readSession(s));
      if (session?.status === "WORKING") return fail(409, "O número já está conectado. Clique em \"Status\".");
    }
    if (session?.status !== "SCAN_QR_CODE") {
      return fail(409, `A sessão não ficou pronta para leitura (status ${session?.status ?? "desconhecido"}). Tente de novo em alguns segundos.`);
    }
    return wahaFetch(s, `/api/${encodeURIComponent(s.session)}/auth/qr`, { headers: { Accept: "image/png" } });
  },

  parseWebhook(rawBody, headers, s) {
    const algorithm = headers.get("x-webhook-hmac-algorithm");
    if (
      !s.webhookSecret ||
      (algorithm && algorithm.toLowerCase() !== "sha512") ||
      !verifyHmacSha512Hex(rawBody, headers.get("x-webhook-hmac"), s.webhookSecret)
    ) {
      throw new HmacFailure("invalid signature");
    }

    const envelope = JSON.parse(rawBody) as { event?: string; session?: string; payload?: Record<string, unknown> };
    if (envelope.event !== "message" || envelope.session !== s.session) return null;
    const p = envelope.payload;
    if (!p || p.fromMe === true) return null;

    const contactId = chatIdToExternalId(p.from);
    if (!contactId) return null; // grupo, status, canal ou id desconhecido

    const body = typeof p.body === "string" ? p.body.trim() : "";
    let media: ChannelMedia[] | undefined;
    if (p.hasMedia === true) {
      const m = (p.media ?? {}) as { url?: string | null; mimetype?: string };
      const type = mediaTypeFromMime(m.mimetype);
      media = [{
        type,
        url: typeof m.url === "string" && m.url ? m.url : undefined,
        mimeType: m.mimetype,
        caption: body || undefined,
      }];
    }
    const text = body || (media ? `[${media[0]!.type}]` : describeNonText(p));
    const ts = typeof p.timestamp === "number" ? p.timestamp : Number(p.timestamp);

    return {
      channel: "whatsapp_qr",
      contactId,
      contactName: contactNameOf(p),
      text,
      media,
      providerMsgId: typeof p.id === "string" ? p.id : undefined,
      receivedAt: Number.isFinite(ts) && ts > 0 ? new Date(ts * 1000).toISOString() : new Date().toISOString(),
      raw: p,
    } satisfies ChannelMessage;
  },

  async sendText(s, externalId, text) {
    if (/^c[a-z0-9]{24}$/.test(externalId)) {
      throw new Error(`sendText(whatsapp_qr) recebeu cuid (${externalId}); use ContactIdentity.externalId.`);
    }
    const gap = missing(s);
    if (gap) throw new Error(gap.message);
    const chatId = externalIdToChatId(externalId);
    // Recomendação do WAHA: marcar como lida antes de responder. Best-effort.
    await wahaFetch(s, "/api/sendSeen", { method: "POST", body: JSON.stringify({ session: s.session, chatId }) })
      .catch(() => undefined);
    const res = await wahaFetch(s, "/api/sendText", {
      method: "POST",
      body: JSON.stringify({ session: s.session, chatId, text, linkPreview: true }),
    });
    if (!res.ok) {
      const detail = (await res.text().catch(() => "")).slice(0, 300);
      console.error(JSON.stringify({ event: "whatsapp_qr.send_error", provider: "waha", status: res.status, detail, at: new Date().toISOString() }));
      throw new Error(`WAHA sendText falhou: HTTP ${res.status}`);
    }
  },

  async sendMedia(s, externalId, media) {
    const gap = missing(s);
    if (gap) throw new Error(gap.message);
    if (!media.base64 || !media.mimeType) throw new Error("sendMedia(whatsapp_qr) precisa de base64 e mimeType");
    const chatId = externalIdToChatId(externalId);
    const isImage = media.type === "image";
    const res = await wahaFetch(s, isImage ? "/api/sendImage" : "/api/sendFile", {
      method: "POST",
      body: JSON.stringify({
        session: s.session,
        chatId,
        file: { mimetype: media.mimeType, filename: media.fileName ?? (isImage ? "imagem" : "arquivo"), data: media.base64 },
        ...(media.caption ? { caption: media.caption } : {}),
      }),
      signal: AbortSignal.timeout(60_000),
    });
    if (!res.ok) {
      // WAHA Core costuma responder 422 "available only in Plus" — quem chama cai no plano B (link).
      const detail = (await res.text().catch(() => "")).slice(0, 300);
      console.error(JSON.stringify({ event: "whatsapp_qr.send_media_error", provider: "waha", status: res.status, detail, at: new Date().toISOString() }));
      throw new Error(`WAHA sendMedia falhou: HTTP ${res.status}`);
    }
  },

  async setTyping(s, externalId, on) {
    if (missing(s)) return;
    const chatId = externalIdToChatId(externalId);
    // Best-effort: falhar o "digitando…" nunca pode impedir a resposta.
    await wahaFetch(s, on ? "/api/startTyping" : "/api/stopTyping", {
      method: "POST",
      body: JSON.stringify({ session: s.session, chatId }),
    }).catch(() => undefined);
  },

  async fetchMedia(s, mediaUrl, range) {
    const gap = missing(s);
    if (gap) throw new Error(gap.message);
    // Só o caminho do arquivo é aproveitado; o host é sempre o baseUrl configurado (anti-SSRF).
    const { pathname } = new URL(mediaUrl, "http://placeholder.invalid");
    if (!/^\/api\/files\/[A-Za-z0-9._@/-]+$/.test(pathname) || pathname.includes("..")) {
      throw new Error("Caminho de mídia inválido");
    }
    return wahaFetch(s, pathname, {
      headers: { Accept: "*/*", ...(range ? { Range: range } : {}) },
      signal: AbortSignal.timeout(60_000),
    });
  },
};
