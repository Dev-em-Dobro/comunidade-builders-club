"use client";

import { useActionState, useState } from "react";
import { ptBR } from "react-day-picker/locale";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { saveDayOverride, type ProfessionalFormState } from "./actions";
import { Loader2, Save } from "lucide-react";

/** Date local do navegador → "YYYY-MM-DD" (o calendário trabalha em dias locais). */
function toIso(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function fromIso(iso: string): Date {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y!, m! - 1, d!);
}

export function DayOverridesForm({
  agentId,
  professionalId,
  today,
  existing,
}: {
  agentId: string;
  professionalId: string;
  /** Hoje no fuso do negócio (YYYY-MM-DD). */
  today: string;
  existing: { date: string; closed: boolean }[];
}) {
  const [selected, setSelected] = useState<Date[]>([]);
  const [mode, setMode] = useState<"closed" | "custom">("closed");
  const [state, action, pending] = useActionState<ProfessionalFormState, FormData>(async (_prev, formData) => {
    const res = await saveDayOverride(agentId, professionalId, formData);
    if (res.savedAt) setSelected([]);
    return res;
  }, {});

  const closedDays = existing.filter((e) => e.closed).map((e) => fromIso(e.date));
  const customDays = existing.filter((e) => !e.closed).map((e) => fromIso(e.date));

  return (
    <form action={action} className="grid gap-6 md:grid-cols-[auto_1fr]">
      <div className="space-y-2">
        <Calendar
          mode="multiple"
          locale={ptBR}
          selected={selected}
          onSelect={(days) => setSelected(days ?? [])}
          disabled={{ before: fromIso(today) }}
          modifiers={{ closed: closedDays, custom: customDays }}
          modifiersClassNames={{
            closed: "[&_button]:line-through [&_button]:text-destructive",
            custom: "[&_button]:underline [&_button]:decoration-primary [&_button]:decoration-2 [&_button]:underline-offset-4",
          }}
          className="rounded-lg border border-border"
        />
        <p className="text-xs text-muted-foreground flex flex-wrap gap-x-3">
          <span>
            <span className="text-destructive line-through">12</span> não atende
          </span>
          <span>
            <span className="underline decoration-primary decoration-2 underline-offset-4">12</span> horário diferente
          </span>
        </p>
        {selected.map((d) => (
          <input key={toIso(d)} type="hidden" name="date" value={toIso(d)} />
        ))}
      </div>

      <div className="space-y-4">
        <p className="text-sm">
          {selected.length === 0
            ? "Clique nos dias do calendário (pode escolher vários)."
            : `${selected.length} dia(s) selecionado(s).`}
        </p>

        <fieldset className="space-y-2">
          <legend className="text-sm font-medium mb-1">Nesses dias o profissional…</legend>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="radio"
              name="mode"
              value="closed"
              checked={mode === "closed"}
              onChange={() => setMode("closed")}
            />
            não atende (folga, feriado, férias)
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input
              type="radio"
              name="mode"
              value="custom"
              checked={mode === "custom"}
              onChange={() => setMode("custom")}
            />
            atende em horário diferente (ou dia extra)
          </label>
        </fieldset>

        {mode === "custom" && (
          <div className="space-y-2">
            <Label htmlFor="intervals">Horário desses dias</Label>
            <Input id="intervals" name="intervals" placeholder="09:00-12:00" className="font-mono text-xs" />
            <p className="text-xs text-muted-foreground">Substitui a semana padrão só nesses dias.</p>
          </div>
        )}

        <div className="space-y-2">
          <Label htmlFor="note">Motivo (opcional)</Label>
          <Input id="note" name="note" maxLength={120} placeholder="Feriado, congresso, plantão extra…" />
        </div>

        {state.error && <p className="text-sm text-destructive">{state.error}</p>}
        <p className="text-xs text-muted-foreground">
          Consultas já marcadas nesses dias não são canceladas — confira em Consultas.
        </p>

        <Button type="submit" disabled={pending || selected.length === 0}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          Salvar exceção
        </Button>
      </div>
    </form>
  );
}
