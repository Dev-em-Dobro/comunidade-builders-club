"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { markRead, markAllRead } from "@/lib/notifications";

/** Marca uma notificação do usuário logado como lida. */
export async function markNotificationRead(id: string): Promise<void> {
  const session = await auth();
  if (!session?.user?.id) return;
  await markRead(session.user.id, id);
  revalidatePath("/", "layout");
}

/** Marca todas as notificações do usuário logado como lidas. */
export async function markAllNotificationsRead(): Promise<void> {
  const session = await auth();
  if (!session?.user?.id) return;
  await markAllRead(session.user.id);
  revalidatePath("/", "layout");
}
