import { prisma } from "@/lib/db";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CadenceForm } from "./_components/cadence-form";

export const dynamic = "force-dynamic";

export default async function FollowupSettingsPage() {
  const [templates, steps] = await Promise.all([
    prisma.messageTemplate.findMany({
      where: { status: "APPROVED" },
      orderBy: { metaName: "asc" },
      select: { metaName: true, language: true },
    }),
    prisma.followupCadenceStep.findMany({ orderBy: { step: "asc" } }),
  ]);

  const byStep = new Map(steps.map((s) => [s.step, s]));
  const initial = [1, 2, 3].map((step) => {
    const row = byStep.get(step);
    return {
      step,
      value: row?.metaName && row.language ? `${row.metaName}::${row.language}` : "",
    };
  });

  return (
    <div className="p-6 md:p-8 max-w-2xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Follow-up automático (fora da janela)
        </h1>
        <p className="text-muted-foreground mt-1">
          Escolha os templates aprovados que o bot envia aos leads quentes depois
          que a janela de 24h fecha. Intervalos e ativação ficam no
          <code> setup.config.json</code>.
        </p>
      </header>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Templates da cadência</CardTitle>
          <CardDescription>
            Só templates <strong>APPROVED</strong> aparecem. Steps sem template são pulados.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {templates.length === 0 ? (
            <p className="text-sm text-warning">
              Nenhum template aprovado. Cadastre e sincronize em /settings/templates.
            </p>
          ) : (
            <CadenceForm templates={templates} initial={initial} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
