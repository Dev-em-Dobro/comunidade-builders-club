"use server";

import bcrypt from "bcryptjs";
import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export type ChangePasswordState =
  | { ok: true; message: string }
  | { ok: false; error: string }
  | undefined;

export async function changePasswordAction(
  _prev: ChangePasswordState,
  formData: FormData,
): Promise<ChangePasswordState> {
  const session = await auth();
  if (!session?.user?.id) {
    return { ok: false, error: "Sessão expirada. Faça login novamente." };
  }

  const currentPassword = String(formData.get("currentPassword") ?? "");
  const newPassword = String(formData.get("newPassword") ?? "");
  const confirmPassword = String(formData.get("confirmPassword") ?? "");

  if (!currentPassword || !newPassword || !confirmPassword) {
    return { ok: false, error: "Preencha todos os campos." };
  }
  if (newPassword.length < 8) {
    return { ok: false, error: "Nova senha precisa ter no mínimo 8 caracteres." };
  }
  if (newPassword !== confirmPassword) {
    return { ok: false, error: "Confirmação não bate com a nova senha." };
  }
  if (newPassword === currentPassword) {
    return { ok: false, error: "A nova senha precisa ser diferente da atual." };
  }

  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { passwordHash: true },
  });

  if (!user?.passwordHash) {
    return { ok: false, error: "Usuário sem senha cadastrada — contate o admin." };
  }

  const ok = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!ok) {
    return { ok: false, error: "Senha atual incorreta." };
  }

  const newHash = await bcrypt.hash(newPassword, 12);
  await prisma.user.update({
    where: { id: session.user.id },
    data: { passwordHash: newHash },
  });

  revalidatePath("/settings/password");
  return { ok: true, message: "Senha alterada com sucesso." };
}
