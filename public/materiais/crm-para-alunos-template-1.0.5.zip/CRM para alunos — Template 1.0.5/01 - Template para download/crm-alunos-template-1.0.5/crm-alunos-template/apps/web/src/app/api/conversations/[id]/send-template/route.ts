import { NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { ChannelSendError } from "@/lib/channels/meta-graph";
import { notifyConvEvent } from "@/lib/realtime/notify";
import { claimConversation } from "@/lib/conversations/claim";
import { sendApprovedTemplate } from "@/lib/conversations/send-template-core";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const BodySchema = z.object({
  templateMetaName: z.string().min(1),
  language: z.string().min(1),
  variables: z.array(z.string()),
});

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { user } = gate;
  const { id: conversationId } = await params;
  const raw = await req.json().catch(() => null);
  const parsed = BodySchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Payload inválido" },
      { status: 400 },
    );
  }

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: {
      id: true,
      channel: true,
      contactId: true,
      leadId: true,
      aiEnabled: true,
      assignedUserId: true,
    },
  });
  if (!conv) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  // Mesma regra do /send: se IA ativa, precisa ser dono. Se IA pausada,
  // qualquer atendente autenticado pode enviar.
  if (conv.aiEnabled && conv.assignedUserId !== user.id) {
    return NextResponse.json(
      { error: "Você precisa assumir a conversa antes" },
      { status: 403 },
    );
  }

  const tpl = await prisma.messageTemplate.findUnique({
    where: {
      metaName_language: {
        metaName: parsed.data.templateMetaName,
        language: parsed.data.language,
      },
    },
  });
  if (!tpl) {
    return NextResponse.json(
      { error: "Template não encontrado" },
      { status: 404 },
    );
  }
  if (tpl.status !== "APPROVED") {
    return NextResponse.json(
      { error: "Template não está aprovado na Meta" },
      { status: 400 },
    );
  }
  if (parsed.data.variables.length !== tpl.variableCount) {
    return NextResponse.json(
      {
        error: `Quantidade de variáveis incorreta (esperado ${tpl.variableCount}, recebido ${parsed.data.variables.length})`,
      },
      { status: 400 },
    );
  }

  const ident = await prisma.contactIdentity.findFirst({
    where: { contactId: conv.contactId, channel: conv.channel },
    select: { externalId: true },
  });
  if (!ident) {
    return NextResponse.json(
      { error: "Identidade do contato não encontrada pra esse canal" },
      { status: 404 },
    );
  }

  // Calcula o próximo step ANTES do envio (cap em 3) — mesma semântica de antes.
  const leadRow = conv.leadId
    ? await prisma.lead.findUnique({
        where: { id: conv.leadId },
        select: { lastFollowUpStep: true },
      })
    : null;
  const nextStep = conv.leadId ? Math.min((leadRow?.lastFollowUpStep ?? 0) + 1, 3) : 0;

  try {
    const { messageId } = await sendApprovedTemplate({
      conversationId: conv.id,
      leadId: conv.leadId,
      externalId: ident.externalId,
      template: {
        metaName: tpl.metaName,
        language: tpl.language,
        bodyText: tpl.bodyText,
      },
      variables: parsed.data.variables,
      step: nextStep,
      sentByUserId: user.id,
    });

    // Auto-claim: quem envia o 1º template numa conversa sem dono vira dono.
    // Mesma semântica do /send. Falha não bloqueia o envio.
    let claimResult: Awaited<ReturnType<typeof claimConversation>> | null = null;
    try {
      claimResult = await claimConversation(conv.id, user.id);
    } catch (err) {
      console.error(
        JSON.stringify({
          event: "send_template.auto_claim_failed",
          conversationId: conv.id,
          error: String((err as Error)?.message ?? err),
        }),
      );
    }

    if (claimResult?.claimed) {
      const u = await prisma.user.findUnique({
        where: { id: user.id },
        select: { name: true },
      });
      await notifyConvEvent(conv.id, {
        type: "claim",
        userId: user.id,
        userName: u?.name ?? null,
        previousOwnerId: claimResult.previousOwnerId,
      });
    }

    return NextResponse.json({ ok: true, messageId });
  } catch (err) {
    if (err instanceof ChannelSendError) {
      return NextResponse.json(
        { error: `Meta rejeitou o template: ${err.message}` },
        { status: 502 },
      );
    }
    const msg = (err as Error)?.message ?? "send failed";
    console.error(
      JSON.stringify({
        event: "send_template.error",
        error: msg,
        at: new Date().toISOString(),
      }),
    );
    return NextResponse.json(
      { error: `Falha de conexão com a Meta: ${msg}` },
      { status: 502 },
    );
  }
}
