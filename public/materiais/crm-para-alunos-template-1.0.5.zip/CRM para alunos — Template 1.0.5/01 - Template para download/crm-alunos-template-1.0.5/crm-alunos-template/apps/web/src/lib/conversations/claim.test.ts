import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { claimConversation } from "./claim";

const created = {
  contactIds: [] as string[],
  userIds: [] as string[],
  leadIds: [] as string[],
};
let userA: string;
let userB: string;

beforeAll(async () => {
  const a = await prisma.user.create({
    data: { email: `claim-a-${Date.now()}@t.local`, name: "User A" },
  });
  const b = await prisma.user.create({
    data: { email: `claim-b-${Date.now()}@t.local`, name: "User B" },
  });
  userA = a.id;
  userB = b.id;
  created.userIds.push(a.id, b.id);
});

afterAll(async () => {
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

async function mkConv(opts: {
  assignedUserId?: string | null;
  withLead?: boolean;
}): Promise<{ convId: string; leadId: string | null }> {
  const contact = await prisma.contact.create({ data: { displayName: "T" } });
  created.contactIds.push(contact.id);
  let leadId: string | null = null;
  if (opts.withLead) {
    const lead = await prisma.lead.create({ data: { contactId: contact.id } });
    leadId = lead.id;
    created.leadIds.push(lead.id);
  }
  const conv = await prisma.conversation.create({
    data: {
      contactId: contact.id,
      channel: "whatsapp_cloud",
      assignedUserId: opts.assignedUserId ?? null,
      leadId,
    },
  });
  return { convId: conv.id, leadId };
}

describe("claimConversation", () => {
  it("claima conversa sem dono + cria PipelineEvent auto_claim quando há lead", async () => {
    const { convId, leadId } = await mkConv({ withLead: true });
    const r = await claimConversation(convId, userA);
    expect(r.claimed).toBe(true);
    expect(r.assignedUserId).toBe(userA);
    expect(r.previousOwnerId).toBeNull();
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.assignedUserId).toBe(userA);
    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: leadId!, type: "handoff_accepted" },
    });
    expect(events.length).toBe(1);
    expect((events[0]!.payload as { via?: string }).via).toBe("auto_claim");
  });

  it("no-op quando o mesmo user já é dono", async () => {
    const { convId } = await mkConv({ assignedUserId: userA, withLead: true });
    const r = await claimConversation(convId, userA);
    expect(r.claimed).toBe(false);
    expect(r.assignedUserId).toBe(userA);
  });

  it("no-op sem force quando outro user já é dono", async () => {
    const { convId } = await mkConv({ assignedUserId: userA, withLead: true });
    const r = await claimConversation(convId, userB);
    expect(r.claimed).toBe(false);
    expect(r.assignedUserId).toBe(userA);
    expect(r.previousOwnerId).toBe(userA);
  });

  it("com force sobrescreve e grava previousOwnerId + via=manual_claim", async () => {
    const { convId, leadId } = await mkConv({ assignedUserId: userA, withLead: true });
    const r = await claimConversation(convId, userB, { force: true });
    expect(r.claimed).toBe(true);
    expect(r.assignedUserId).toBe(userB);
    expect(r.previousOwnerId).toBe(userA);
    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: leadId!, type: "handoff_accepted" },
      orderBy: { createdAt: "desc" },
      take: 1,
    });
    expect((events[0]!.payload as { via?: string; previousOwnerId?: string }).via).toBe(
      "manual_claim",
    );
    expect((events[0]!.payload as { previousOwnerId?: string }).previousOwnerId).toBe(userA);
  });

  it("claima conversa sem lead sem tentar criar PipelineEvent", async () => {
    const { convId } = await mkConv({ withLead: false });
    const r = await claimConversation(convId, userA);
    expect(r.claimed).toBe(true);
    expect(r.assignedUserId).toBe(userA);
  });
});
