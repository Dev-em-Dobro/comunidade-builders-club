"use client";

import Link from "next/link";
import { Bell, Check } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  markNotificationRead,
  markAllNotificationsRead,
} from "@/app/(app)/notification-actions";

export interface BellNotification {
  id: string;
  title: string;
  body: string;
  read: boolean;
  /** rota interna pra abrir o contexto da notificação (ex: conversa). null = sem deep-link. */
  href: string | null;
  /** já formatado pra exibição */
  createdAt: string;
}

export function NotificationBell({
  notifications,
  className,
}: {
  notifications: BellNotification[];
  className?: string;
}) {
  const unread = notifications.filter((n) => !n.read).length;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label="Notificações"
        className={`relative inline-flex size-7 items-center justify-center rounded-md text-sidebar-foreground/80 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors ${className ?? ""}`}
      >
        <Bell className="size-4" />
        {unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-semibold text-white">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between border-b border-border px-3 py-2">
          <span className="text-sm font-medium">Notificações</span>
          {unread > 0 && (
            <button
              type="button"
              onClick={() => markAllNotificationsRead()}
              className="text-xs text-primary hover:underline"
            >
              Marcar todas como lidas
            </button>
          )}
        </div>

        {notifications.length === 0 ? (
          <p className="px-3 py-8 text-center text-sm text-muted-foreground">
            Nenhuma notificação.
          </p>
        ) : (
          <ul className="max-h-80 overflow-y-auto">
            {notifications.map((n) => {
              const content = (
                <>
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="text-xs text-muted-foreground">{n.body}</p>
                  <p className="mt-0.5 font-mono text-[10px] text-muted-foreground/70">
                    {n.createdAt}
                  </p>
                </>
              );
              return (
                <li
                  key={n.id}
                  className={`flex items-start gap-2 border-b border-border/50 last:border-0 ${
                    n.read ? "" : "bg-primary/5"
                  }`}
                >
                  {n.href ? (
                    <Link
                      href={n.href}
                      onClick={() => {
                        if (!n.read) void markNotificationRead(n.id);
                      }}
                      className="min-w-0 flex-1 px-3 py-2.5 hover:bg-accent/40"
                    >
                      {content}
                    </Link>
                  ) : (
                    <div className="min-w-0 flex-1 px-3 py-2.5">{content}</div>
                  )}
                  {!n.read && (
                    <button
                      type="button"
                      onClick={() => markNotificationRead(n.id)}
                      aria-label="Marcar como lida"
                      className="mr-3 mt-2.5 text-muted-foreground hover:text-primary"
                    >
                      <Check className="size-4" />
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
