import type { Metadata } from "next";
import {
  LegalLink,
  LegalList,
  LegalPage,
  LegalSection,
  LegalStrong,
} from "../_components/legal-page";
import { businessConfig } from "@/lib/config";




export const metadata: Metadata = { title: "Exclusão de Dados" };
export const dynamic = "force-dynamic";

export default function DataDeletionPage() {
  const { contactEmail: CONTACT_EMAIL, legalName: LEGAL_ENTITY } = businessConfig();
  return (
    <LegalPage title="Exclusão de Dados" updatedAt="22 de maio de 2026">
      <p>
        Você pode solicitar, a qualquer momento, a exclusão dos dados pessoais
        que a <LegalStrong>{LEGAL_ENTITY}</LegalStrong> tenha coletado
        durante o seu atendimento pelo WhatsApp ou pelo Instagram. Esta página
        explica como fazer esse pedido e o que acontece em seguida.
      </p>

      <LegalSection title="1. Como solicitar a exclusão">
        <p>
          Envie um e-mail para{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>{" "}
          com as seguintes informações:
        </p>
        <LegalList
          items={[
            <>
              Assunto: <LegalStrong>“Exclusão de dados”</LegalStrong>;
            </>,
            "O número de telefone (WhatsApp) ou o nome de usuário do Instagram que você usou para falar conosco;",
            "Opcionalmente, qualquer detalhe que ajude a localizar o seu atendimento.",
          ]}
        />
        <p>
          Como alternativa, você também pode fazer o pedido pela própria
          conversa, enviando no WhatsApp ou no Instagram a mensagem{" "}
          <LegalStrong>“Solicito a exclusão dos meus dados”</LegalStrong>.
        </p>
      </LegalSection>

      <LegalSection title="2. O que será excluído">
        <p>Ao concluir a solicitação, removemos:</p>
        <LegalList
          items={[
            "O histórico das mensagens trocadas com você;",
            "O cadastro de contato (lead) associado a você no nosso CRM;",
            "Nome de perfil, número ou nome de usuário e as informações de relacionamento comercial vinculadas ao seu atendimento.",
          ]}
        />
        <p>
          Alguns dados podem ser mantidos quando a sua guarda for exigida por lei
          — por exemplo, para o cumprimento de obrigações fiscais. Nesses casos,
          os dados ficam restritos e são eliminados ao fim do prazo legal.
        </p>
      </LegalSection>

      <LegalSection title="3. Prazo para conclusão">
        <p>
          Confirmamos o recebimento do seu pedido e concluímos a exclusão em até{" "}
          <LegalStrong>30 dias</LegalStrong>. Esse prazo pode ser prorrogado
          quando houver justificativa, e nesse caso avisaremos você.
        </p>
      </LegalSection>

      <LegalSection title="4. Dúvidas e contato">
        <p>
          Para dúvidas sobre a exclusão dos seus dados, fale com a{" "}
          <LegalStrong>{LEGAL_ENTITY}</LegalStrong> pelo e-mail{" "}
          <LegalLink href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</LegalLink>.
          Veja também a nossa{" "}
          <LegalLink href="/privacy">Política de Privacidade</LegalLink>.
        </p>
      </LegalSection>
    </LegalPage>
  );
}
