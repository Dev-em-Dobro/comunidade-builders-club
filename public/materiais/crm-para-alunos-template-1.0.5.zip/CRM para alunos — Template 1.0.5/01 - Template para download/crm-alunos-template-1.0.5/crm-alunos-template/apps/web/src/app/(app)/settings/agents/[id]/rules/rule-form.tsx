"use client";

import { useActionState, useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Loader2, Save } from "lucide-react";
import { saveRule, type RuleFormState } from "./actions";
import { RULE_ACTIONS, RULE_MODES, type SerializedRule } from "./types";

/** Dias da semana — idx bate com Date.getDay() / `evaluateRule`. */
const DAYS = [
  { idx: 1, label: "Seg" },
  { idx: 2, label: "Ter" },
  { idx: 3, label: "Qua" },
  { idx: 4, label: "Qui" },
  { idx: 5, label: "Sex" },
  { idx: 6, label: "Sáb" },
  { idx: 0, label: "Dom" },
];

function asStringArray(v: unknown): string[] {
  return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
}
function asNumberArray(v: unknown): number[] {
  return Array.isArray(v) ? v.filter((x): x is number => typeof x === "number") : [];
}

export function RuleForm({
  agentId,
  rule,
  onSaved,
  onCancel,
}: {
  agentId: string;
  /** Sem `rule` = criando. Com `rule` = editando. */
  rule?: SerializedRule;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const [state, action, pending] = useActionState<RuleFormState, FormData>(
    async (_prev, fd) => saveRule(fd),
    {},
  );

  const p = rule?.params ?? {};
  const [mode, setMode] = useState(rule?.mode ?? "always_on");
  const [actionType, setActionType] = useState(rule?.action ?? "respond");
  const initialDays = asNumberArray(p.days);
  const [days, setDays] = useState<number[]>(
    initialDays.length ? initialDays : [1, 2, 3, 4, 5],
  );

  // Fecha o dialog quando o save dá certo.
  useEffect(() => {
    if (state.ok) onSaved();
  }, [state.ok, onSaved]);

  const isKeyword = mode === "keyword_trigger" || mode === "keyword_pause";
  const isContact =
    mode === "contact_whitelist" || mode === "contact_blacklist";
  const isSchedule = mode === "schedule";

  const modeMeta = RULE_MODES.find((m) => m.id === mode);
  const actionMeta = RULE_ACTIONS.find((a) => a.id === actionType);

  return (
    <form action={action} className="space-y-4">
      {rule?.id && <input type="hidden" name="id" value={rule.id} />}
      <input type="hidden" name="agentSessionId" value={agentId} />

      {/* Tipo de regra */}
      <div className="space-y-1.5">
        <Label>Tipo de regra</Label>
        <Select
          name="mode"
          defaultValue={mode}
          onValueChange={(v) => setMode(String(v))}
        >
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {RULE_MODES.map((m) => (
              <SelectItem key={m.id} value={m.id}>
                {m.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {modeMeta && (
          <p className="text-xs text-muted-foreground">{modeMeta.desc}</p>
        )}
      </div>

      {/* Params: keyword_trigger / keyword_pause */}
      {isKeyword && (
        <>
          <div className="space-y-1.5">
            <Label htmlFor="keywords">Palavras-chave</Label>
            <Textarea
              id="keywords"
              name="keywords"
              rows={3}
              defaultValue={asStringArray(p.keywords).join("\n")}
              placeholder={"falar com humano\natendente\noperador"}
            />
            <p className="text-xs text-muted-foreground">
              Uma por linha (ou separadas por vírgula).
            </p>
          </div>
          <div className="space-y-1.5">
            <Label>Casar quando</Label>
            <Select
              name="matchMode"
              defaultValue={(p.matchMode as string | undefined) ?? "any"}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="any">Contém qualquer palavra</SelectItem>
                <SelectItem value="all">Contém todas as palavras</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between rounded-md border border-border px-3 py-2">
            <Label htmlFor="caseSensitive">
              Diferenciar maiúsculas/minúsculas
            </Label>
            <Switch
              id="caseSensitive"
              name="caseSensitive"
              defaultChecked={!!p.caseSensitive}
            />
          </div>
        </>
      )}

      {/* Params: contact_whitelist / contact_blacklist */}
      {isContact && (
        <div className="space-y-1.5">
          <Label htmlFor="contactIds">IDs de contato</Label>
          <Textarea
            id="contactIds"
            name="contactIds"
            rows={3}
            defaultValue={asStringArray(p.contactIds).join("\n")}
            placeholder="um ID de contato por linha"
            className="font-mono text-xs"
          />
          <p className="text-xs text-muted-foreground">
            Um ID por linha. (Seletor de contatos no roadmap.)
          </p>
        </div>
      )}

      {/* Params: schedule */}
      {isSchedule && (
        <>
          <input type="hidden" name="days" value={days.join(",")} />
          <div className="space-y-1.5">
            <Label>Dias da semana</Label>
            <div className="flex flex-wrap gap-1.5">
              {DAYS.map((d) => {
                const on = days.includes(d.idx);
                return (
                  <button
                    key={d.idx}
                    type="button"
                    onClick={() =>
                      setDays((cur) =>
                        cur.includes(d.idx)
                          ? cur.filter((x) => x !== d.idx)
                          : [...cur, d.idx],
                      )
                    }
                    className={cn(
                      "rounded-md border px-2.5 py-1 text-xs transition-colors",
                      on
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border text-muted-foreground hover:border-primary/40",
                    )}
                  >
                    {d.label}
                  </button>
                );
              })}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="start">Início</Label>
              <Input
                id="start"
                name="start"
                type="time"
                defaultValue={(p.start as string | undefined) ?? "09:00"}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="end">Fim</Label>
              <Input
                id="end"
                name="end"
                type="time"
                defaultValue={(p.end as string | undefined) ?? "18:00"}
              />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="timezone">Fuso horário</Label>
            <Input
              id="timezone"
              name="timezone"
              defaultValue={
                (p.timezone as string | undefined) ?? "America/Sao_Paulo"
              }
            />
          </div>
        </>
      )}

      {/* Ação */}
      <div className="space-y-1.5">
        <Label>Ação quando casar</Label>
        <Select
          name="action"
          defaultValue={actionType}
          onValueChange={(v) => setActionType(String(v))}
        >
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {RULE_ACTIONS.map((a) => (
              <SelectItem key={a.id} value={a.id}>
                {a.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {actionMeta && (
          <p className="text-xs text-muted-foreground">{actionMeta.desc}</p>
        )}
      </div>

      {(actionType === "static_reply" || actionType === "handoff") && (
        <div className="space-y-1.5">
          <Label htmlFor="staticReply">
            {actionType === "handoff"
              ? "Mensagem antes de transferir"
              : "Texto da resposta fixa"}
          </Label>
          <Textarea
            id="staticReply"
            name="staticReply"
            rows={3}
            defaultValue={rule?.staticReply ?? ""}
            placeholder={
              actionType === "handoff"
                ? "Estou transferindo você para um dos nossos especialistas, só um momento."
                : "Olá! Recebemos sua mensagem, um atendente já vai te responder."
            }
          />
          {actionType === "handoff" && (
            <p className="text-xs text-muted-foreground">
              Opcional — enviada ao cliente antes de pausar a IA. Em branco,
              usa um texto padrão.
            </p>
          )}
        </div>
      )}

      {/* Prioridade + ativa */}
      <div className="space-y-1.5">
        <Label htmlFor="priority">Prioridade</Label>
        <Input
          id="priority"
          name="priority"
          type="number"
          min="0"
          step="1"
          defaultValue={rule?.priority ?? 100}
        />
        <p className="text-xs text-muted-foreground">
          Menor é avaliada antes. A primeira regra que casar vence.
        </p>
      </div>
      <div className="flex items-center justify-between rounded-md border border-border px-3 py-2">
        <Label htmlFor="enabled">Regra ativa</Label>
        <Switch
          id="enabled"
          name="enabled"
          defaultChecked={rule?.enabled ?? true}
        />
      </div>

      {state.error && (
        <p className="text-sm text-destructive">{state.error}</p>
      )}

      <div className="flex justify-end gap-2 pt-1">
        <Button
          type="button"
          variant="ghost"
          onClick={onCancel}
          disabled={pending}
        >
          Cancelar
        </Button>
        <Button type="submit" disabled={pending}>
          {pending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Save className="size-4" />
          )}
          {rule ? "Salvar alterações" : "Criar regra"}
        </Button>
      </div>
    </form>
  );
}
