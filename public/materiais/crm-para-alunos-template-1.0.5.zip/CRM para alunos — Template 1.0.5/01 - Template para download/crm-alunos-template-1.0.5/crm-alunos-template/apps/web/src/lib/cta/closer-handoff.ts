import { pickPrimaryCourseId } from "@/lib/launches/multi-course";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { loadMemory } from "@/lib/memory";
import { buildLeadContextBlock } from "@/lib/llm/context-blocks";
import { sendOutboundMessage } from "@/lib/outbound";
import { runHandoff } from "@/lib/handoff";
import { getCheckoutLink } from "@/lib/cta/get-checkout-link";
import { resolveTargetSession } from "@/lib/agent-handoff";
import { businessConfig } from "@/lib/config";
import type { ChannelId } from "@/lib/channels/types";

/**
 * Escolhe o courseId pro checkout do Caminho A (lead pediu o link).
 * Prioriza interesses que são cursos ativos (mais recente mencionado vence);
 * se o lead não tem interesse ativo válido e há exatamente 1 curso ativo, usa
 * esse. Caso contrário null → o Closer entra e pergunta qual curso.
 */
export function resolveCheckoutCourseId(
  interestCourseIds: string[],
  messages: { text: string | null; createdAt: Date }[],
  courses: { id: string; name: string; slug: string }[],
): string | null {
  const activeIds = new Set(courses.map((c) => c.id));
  const validInterest = interestCourseIds.filter((id) => activeIds.has(id));
  if (validInterest.length > 0) {
    return pickPrimaryCourseId({ interestCourseIds: validInterest, messages, courses });
  }
  if (courses.length === 1) return courses[0]!.id;
  return null;
}

const STAGE_NO_REGRESS = new Set(["proposal", "won", "lost"]);

const LINK_DIRECTIVE = (persona: string) =>
  `[Instrução interna do sistema — esta mensagem não veio do lead]

O lead acabou de pedir o link de compra. Sua tarefa AGORA: mande UMA saudação curtíssima e calorosa, se apresentando como ${persona} do time comercial, dizendo que o link de checkout segue logo abaixo.

Regras rígidas (não negocia):
- Apenas texto natural — proibido markdown, código, backticks
- NÃO escreva o link você mesmo — o sistema anexa logo após sua mensagem
- Sem perguntas, sem preço, 1 a 2 frases no máximo
- Não chame nenhuma tool (sua resposta não terá tools disponíveis)`;

const ASK_DIRECTIVE = (persona: string, ask: string) =>
  `[Instrução interna do sistema — esta mensagem não veio do lead]

O lead quer comprar, mas falta um detalhe. Sua tarefa AGORA: mande UMA saudação curtíssima se apresentando como ${persona} do time comercial e ${ask}

Regras rígidas (não negocia):
- Apenas texto natural — proibido markdown, código, backticks
- 1 a 2 frases, uma pergunta só
- Não chame nenhuma tool (sua resposta não terá tools disponíveis)`;

/**
 * Caminho A: lead pediu o link / sinalizou compra estando numa sessão NÃO-closer.
 * Passa pro Closer e entrega o link no mesmo turno. Retorna `true` quando tratou
 * o turno (mandou msg do closer OU disparou handoff humano); `false` quando
 * declinou (já é closer / sem lead) e o caller deve cair no comportamento legado.
 *
 * Idempotência: ao flipar pro closer + stage `proposal`, o job de qualify em
 * background vira no-op (shouldHandoff exige stage=qualified e sessão≠closer).
 */
export async function runAgentHandoffWithCheckout(
  conversationId: string,
): Promise<boolean> {
  const conv = await prisma.conversation.findUnique({ where: { id: conversationId } });
  if (!conv || !conv.leadId) {
    log("cta_handoff.skipped", { conversationId, reason: "no_conversation_or_lead" });
    return false;
  }
  const lead = await prisma.lead.findUnique({
    where: { id: conv.leadId },
    select: { id: true, stage: true, interestCourseIds: true },
  });
  if (!lead) {
    log("cta_handoff.skipped", { conversationId, reason: "no_lead" });
    return false;
  }

  // Já no closer → deixa o caminho legado (handleReadyToBuy) tratar.
  const current = conv.agentSessionId
    ? await prisma.agentSession.findUnique({
        where: { id: conv.agentSessionId },
        select: { role: true },
      })
    : null;
  if (current?.role === "closer") {
    log("cta_handoff.skipped", { conversationId, reason: "already_closer" });
    return false;
  }

  const sessions = await prisma.agentSession.findMany({
    where: { role: { in: ["sdr", "closer"] } },
    select: {
      id: true, name: true, persona: true, role: true, systemPrompt: true,
      memoryMode: true, provider: true, model: true, temperature: true, createdAt: true,
    },
  });
  const closer = resolveTargetSession(sessions, "closer");
  if (!closer) {
    // Sem closer não dá pra entregar via bot → humano. `conv` aqui ainda tem
    // handoffRequested=false (snapshot pré-getCheckoutLink) → runHandoff procede.
    log("cta_handoff.no_closer_human", { conversationId, leadId: lead.id });
    await runHandoff(conv, businessConfig().handoffNotice);
    return true;
  }

  // courseId pelo interesse + menções recentes (fallback: curso único).
  const courses = await prisma.course.findMany({
    where: { active: true },
    select: { id: true, name: true, slug: true },
  });
  const recent = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: "desc" },
    take: 20,
    select: { text: true, createdAt: true },
  });
  const courseId = resolveCheckoutCourseId(lead.interestCourseIds, recent, courses);

  // Resolve o desfecho: link direto, perguntar (plano/curso) ou humano.
  let url: string | null = null;
  let ask: string | null = null;

  if (!courseId) {
    ask = "pergunte qual curso ele quer fechar.";
  } else {
    const r = await getCheckoutLink({
      prisma,
      leadId: lead.id,
      courseId,
      conversationId,
      agentSessionId: closer.id,
      baseUrl: process.env.PUBLIC_BASE_URL ?? "",
    });
    if (r.ok && "url" in r) {
      url = r.url;
    } else if (r.ok && "needsPlanChoice" in r) {
      // Decisão de produto: o Closer assume e avança o lead pra `proposal` já
      // aqui (intenção clara de compra), mesmo sem mandar o link neste turno —
      // o link sai no turno seguinte quando o lead escolher o plano.
      ask = `pergunte qual plano ele prefere: ${r.plans.map((p) => p.name).join(" ou ")}.`;
    } else if (!r.ok && "handoff" in r && r.handoff) {
      // no_checkout_url: getCheckoutLink já marcou handoffRequested no DB; passamos
      // o snapshot `conv` (handoffRequested=false) p/ runHandoff não pular.
      log("cta_handoff.no_url_human", { conversationId, leadId: lead.id, courseId });
      await runHandoff(conv, businessConfig().handoffNotice);
      return true;
    } else {
      // course_not_found / invalid_plan_id — defensivo: closer pergunta o curso.
      // Praticamente inalcançável (courseId vem de curso ativo, sem planId),
      // mas logamos pra ter visibilidade caso dispare em produção.
      log("cta_handoff.course_unresolved", {
        conversationId,
        leadId: lead.id,
        courseId,
        error: "error" in r ? r.error : "unknown",
      });
      ask = "pergunte qual curso ele quer fechar.";
    }
  }

  // Saudação do closer (system prompt do closer + diretivo como user-turn).
  const memory = await loadMemory(conversationId, closer.memoryMode);
  const leadContext = await buildLeadContextBlock(lead.id, conv.contactId);
  const persona = closer.persona ?? closer.name;
  const directive = url ? LINK_DIRECTIVE(persona) : ASK_DIRECTIVE(persona, ask!);

  const reply = await generateReplyWithKey(closer.provider, {
    model: closer.model,
    temperature: closer.temperature,
    maxTokens: 150,
    systemStatic: closer.systemPrompt,
    systemDynamic: leadContext ?? undefined,
    messages: [...memory, { role: "user" as const, content: directive }],
    tools: [],
  });

  const greeting = reply.text.trim();
  const text = url ? `${greeting}\n${url}` : greeting;

  const ident = await prisma.contactIdentity.findFirst({
    where: { contactId: conv.contactId, channel: conv.channel },
    select: { externalId: true },
  });
  if (!ident) {
    log("cta_handoff.skipped", { conversationId, reason: "no_contact_identity" });
    return false;
  }

  const sent = await sendOutboundMessage({
    conversationId,
    channel: conv.channel as ChannelId,
    externalId: ident.externalId,
    text,
    usage: {
      tokensIn: reply.tokensIn,
      tokensOut: reply.tokensOut,
      costUsd: reply.costUsd,
      modelUsed: reply.modelUsed,
    },
  });
  if (!sent.ok) {
    log("cta_handoff.send_failed", { conversationId, reason: sent.reason });
    if (sent.reason === "window_expired") {
      throw new Error(`cta_handoff window_expired for conversation ${conversationId}`);
    }
    return true; // turno tratado (tentado); não flipa sessão
  }

  const ops: Prisma.PrismaPromise<unknown>[] = [
    prisma.conversation.update({
      where: { id: conversationId },
      data: { agentSessionId: closer.id, lastOutboundAt: new Date() },
    }),
    prisma.pipelineEvent.create({
      data: {
        leadId: lead.id,
        type: "agent_handoff",
        payload: {
          from: conv.agentSessionId,
          to: closer.id,
          toName: closer.name,
          toPersona: closer.persona ?? null,
          leadId: lead.id,
          via: "ready_to_buy",
          withLink: Boolean(url),
        },
      },
    }),
  ];
  if (!STAGE_NO_REGRESS.has(lead.stage)) {
    ops.push(
      prisma.lead.update({ where: { id: lead.id }, data: { stage: "proposal" } }),
      prisma.pipelineEvent.create({
        data: {
          leadId: lead.id,
          type: "stage_change",
          payload: { from: lead.stage, to: "proposal", via: "ready_to_buy" },
        },
      }),
    );
  }
  await prisma.$transaction(ops);

  log("cta_handoff.done", { conversationId, leadId: lead.id, to: closer.id, withLink: Boolean(url) });
  return true;
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
