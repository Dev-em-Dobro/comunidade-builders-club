import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { matchContact } from "./match-contact";

const created = { contactIds: [] as string[] };
let contactWithPhone: string;
let contactWithEmail: string;

beforeAll(async () => {
  const c1 = await prisma.contact.create({
    data: {
      displayName: "Phone-only",
      identities: {
        create: { channel: "whatsapp_cloud", externalId: "5511988887776" },
      },
    },
  });
  contactWithPhone = c1.id;
  created.contactIds.push(c1.id);

  const c2 = await prisma.contact.create({
    data: { displayName: "Email-only", email: `match-${Date.now()}@x.com` },
  });
  contactWithEmail = c2.id;
  created.contactIds.push(c2.id);
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

describe("matchContact", () => {
  it("match por phone E.164 exato", async () => {
    const r = await matchContact({ phoneRaw: "+5511988887776", emailRaw: null });
    expect(r.contactId).toBe(contactWithPhone);
    expect(r.via).toBe("phone");
  });

  it("match por phone com prefixo 55 adicionado quando vier sem DDI", async () => {
    // CSV trouxe '(11) 98888-7776' que normaliza pra '11988887776' (11 dígitos)
    // Matcher tenta '11988887776' (falha) e refaz com '5511988887776' (acha).
    const r = await matchContact({ phoneRaw: "(11) 98888-7776", emailRaw: null });
    expect(r.contactId).toBe(contactWithPhone);
    expect(r.via).toBe("phone");
  });

  it("match por email lowercase + trim", async () => {
    const contact = await prisma.contact.findUniqueOrThrow({
      where: { id: contactWithEmail },
    });
    const r = await matchContact({
      phoneRaw: null,
      emailRaw: `  ${contact.email!.toUpperCase()}  `,
    });
    expect(r.contactId).toBe(contactWithEmail);
    expect(r.via).toBe("email");
  });

  it("phone falha + email casa → via='email'", async () => {
    const contact = await prisma.contact.findUniqueOrThrow({
      where: { id: contactWithEmail },
    });
    const r = await matchContact({
      phoneRaw: "+5511000000000", // não existe
      emailRaw: contact.email,
    });
    expect(r.contactId).toBe(contactWithEmail);
    expect(r.via).toBe("email");
  });

  it("nenhum match → contactId null + via null", async () => {
    const r = await matchContact({
      phoneRaw: "+5519999999999",
      emailRaw: "nao-existe-mesmo@x.com",
    });
    expect(r.contactId).toBeNull();
    expect(r.via).toBeNull();
  });
});
