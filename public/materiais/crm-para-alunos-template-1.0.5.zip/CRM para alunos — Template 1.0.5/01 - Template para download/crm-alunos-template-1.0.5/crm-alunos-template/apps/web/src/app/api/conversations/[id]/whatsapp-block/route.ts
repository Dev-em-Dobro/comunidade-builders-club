import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireSession } from "@/lib/api-auth";
import {
  isWhatsAppUserBlocked,
  setWhatsAppUserBlocked,
} from "@/lib/channels/whatsapp-block-users";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function contactWaId(id: string): Promise<string | NextResponse> {
  const conversation = await prisma.conversation.findUnique({
    where: { id },
    select: { channel: true, contactId: true },
  });
  if (!conversation) return NextResponse.json({ error: "Conversa não encontrada." }, { status: 404 });
  if (conversation.channel !== "whatsapp_cloud") {
    return NextResponse.json({ error: "Esta conversa não é do WhatsApp." }, { status: 400 });
  }
  const contactIdentity = await prisma.contactIdentity.findFirst({
    where: { contactId: conversation.contactId, channel: "whatsapp_cloud" },
    select: { externalId: true },
  });
  if (!contactIdentity || !/^\d{6,15}$/.test(contactIdentity.externalId)) {
    return NextResponse.json({ error: "Número WhatsApp inválido para esta conversa." }, { status: 400 });
  }
  return contactIdentity.externalId;
}

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const waId = await contactWaId((await params).id);
  if (waId instanceof NextResponse) return waId;
  try {
    return NextResponse.json({ blocked: await isWhatsAppUserBlocked(waId) });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 502 });
  }
}

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const id = (await params).id;
  const waId = await contactWaId(id);
  if (waId instanceof NextResponse) return waId;
  try {
    await setWhatsAppUserBlocked(waId, true);
    let aiPaused = true;
    try {
      await prisma.conversation.update({ where: { id }, data: { aiEnabled: false } });
    } catch (error) {
      // O bloqueio na Meta já aconteceu; não informar falsamente que falhou.
      console.error("whatsapp.block.ai_pause_failed", { conversationId: id, error });
      aiPaused = false;
    }
    return NextResponse.json({ blocked: true, aiPaused });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 502 });
  }
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const waId = await contactWaId((await params).id);
  if (waId instanceof NextResponse) return waId;
  try {
    await setWhatsAppUserBlocked(waId, false);
    return NextResponse.json({ blocked: false });
  } catch (error) {
    return NextResponse.json({ error: (error as Error).message }, { status: 502 });
  }
}
