"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { saveCredential, type CredentialFormState } from "../actions";
import { Loader2, Save } from "lucide-react";

interface Props {
  provider: string;
  label: string;
  configured: boolean;
  hint: string | null;
}

export function CredentialForm({ provider, label, configured, hint }: Props) {
  const [state, action, pending] = useActionState<CredentialFormState, FormData>(
    async (_prev, formData) => saveCredential(formData),
    {},
  );

  return (
    <form action={action} className="space-y-3 rounded-md border border-border p-4">
      <input type="hidden" name="provider" value={provider} />
      <div className="flex items-center justify-between">
        <Label className="text-base">{label}</Label>
        {configured ? (
          <Badge className="font-mono text-[10px]">configurada · ••••{hint}</Badge>
        ) : (
          <Badge variant="outline" className="font-mono text-[10px]">não configurada</Badge>
        )}
      </div>
      <Input
        name="apiKey"
        type="password"
        autoComplete="off"
        placeholder={configured ? "Cole uma nova chave para substituir" : "Cole a chave de API"}
      />
      {state?.error && <p className="text-sm text-destructive font-mono">{state.error}</p>}
      {state?.message && <p className="text-sm text-emerald-600 font-mono">{state.message}</p>}
      <Button type="submit" disabled={pending} size="sm">
        {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
        Salvar
      </Button>
    </form>
  );
}
