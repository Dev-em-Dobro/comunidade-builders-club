"use client";

/**
 * Toca o som de alerta da janela 24h. Falha silenciosa:
 *  - autoplay bloqueado (sem interação prévia do usuário) — ignora
 *  - aba sem foco no Safari — ignora
 *  - SSR / Audio inexistente — ignora
 *
 * O caminho é absoluto pra evitar problemas em rotas aninhadas.
 */
export function playWindowWarningSound(): void {
  try {
    if (typeof Audio === "undefined") return;
    const audio = new Audio("/sounds/window-warning.mp3");
    audio.volume = 0.6;
    audio.play().catch(() => {
      // autoplay policy bloqueou — silencioso
    });
  } catch {
    // silencioso
  }
}
