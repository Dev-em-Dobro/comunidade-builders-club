"use client";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Eye } from "lucide-react";

interface Props {
  markdown: string;
}

/**
 * Mostra exatamente o markdown que `renderOfferBlock` produz e que o bot
 * recebe no contexto. Útil pra debug ("por que o bot tá citando esse bônus?")
 * e pra QA antes de virar a chave de ativação.
 */
export function OfferPreviewModal({ markdown }: Props) {
  return (
    <Dialog>
      <DialogTrigger render={<Button variant="outline" size="sm" />}>
        <Eye className="size-4" /> Ver como o bot enxerga
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>Bloco de contexto que vai pra LLM</DialogTitle>
        </DialogHeader>
        <pre className="whitespace-pre-wrap text-xs font-mono bg-muted p-4 rounded max-h-[60vh] overflow-auto">
          {markdown}
        </pre>
      </DialogContent>
    </Dialog>
  );
}
