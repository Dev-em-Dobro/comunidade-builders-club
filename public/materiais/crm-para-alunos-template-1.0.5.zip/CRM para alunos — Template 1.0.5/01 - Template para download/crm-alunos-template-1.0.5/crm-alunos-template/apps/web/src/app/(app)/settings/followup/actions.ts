"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

export interface CadenceFormState {
  ok?: boolean;
  error?: string;
  message?: string;
}

/**
 * Salva a seleção de template de cada step (1/2/3). O value de cada select é
 * "metaName::language" (ou "" pra limpar). Faz upsert por step.
 */
export async function saveCadence(formData: FormData): Promise<CadenceFormState> {
  const session = await auth();
  if (!session?.user?.id) {
    return { error: "Sessão expirada. Faça login novamente." };
  }

  try {
    for (const step of [1, 2, 3]) {
      const raw = String(formData.get(`step_${step}`) ?? "").trim();
      const sep = raw.lastIndexOf("::");
      const [metaName, language] =
        sep !== -1 ? [raw.slice(0, sep), raw.slice(sep + 2)] : [null, null];
      await prisma.followupCadenceStep.upsert({
        where: { step },
        update: { metaName, language },
        create: { step, metaName, language },
      });
    }
    revalidatePath("/settings/followup");
    return { ok: true, message: "Cadência salva." };
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
}
