import { describe, it, expect, beforeAll, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { runLaunchTransitionScan } from "./launch-transitions";
import { _resetActiveLaunchCache } from "@/lib/launches/active";

let courseId: string;
const created = { courseIds: [] as string[] };

beforeAll(async () => {
  const c = await prisma.course.create({
    data: { name: "Cron test course", slug: `cron-${Date.now()}`, priceCents: 1000 },
  });
  courseId = c.id;
  created.courseIds.push(c.id);
});

afterAll(async () => {
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId: { in: created.courseIds } } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId: { in: created.courseIds } } } });
  await prisma.launch.deleteMany({ where: { courseId: { in: created.courseIds } } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.$disconnect();
});

beforeEach(async () => {
  _resetActiveLaunchCache();
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId } } });
  await prisma.launchStatusChange.deleteMany({ where: { launch: { courseId } } });
  await prisma.launch.deleteMany({ where: { courseId } });
});

async function makeLaunch(opts: {
  status: "planned" | "live" | "closed";
  startsAt: Date;
  endsAt: Date;
  withPlan?: boolean;
}) {
  const launch = await prisma.launch.create({
    data: {
      name: `T-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      slug: `t-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      startsAt: opts.startsAt,
      endsAt: opts.endsAt,
      status: opts.status,
      courseId,
    },
  });
  if (opts.withPlan ?? true) {
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "P1", priceCents: 1000, checkoutUrl: "x", sortOrder: 0 },
    });
  }
  return launch;
}

describe("runLaunchTransitionScan", () => {
  it("ativa planned com startsAt<=now (cron_start) e grava changelog", async () => {
    const l = await makeLaunch({
      status: "planned",
      startsAt: new Date(Date.now() - 60_000),
      endsAt: new Date(Date.now() + 86400000),
    });
    await runLaunchTransitionScan();
    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("live");
    expect(after.startsAt.getTime()).toBe(l.startsAt.getTime()); // cron_start NÃO move

    const changes = await prisma.launchStatusChange.findMany({ where: { launchId: l.id } });
    expect(changes).toHaveLength(1);
    expect(changes[0]!.reason).toBe("cron_start");
    expect(changes[0]!.toStatus).toBe("live");
  });

  it("encerra live com endsAt<=now (cron_end) e grava changelog", async () => {
    const orig = new Date(Date.now() - 60_000);
    const l = await makeLaunch({
      status: "live",
      startsAt: new Date(Date.now() - 86400000),
      endsAt: orig,
    });
    await runLaunchTransitionScan();
    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("closed");
    expect(after.endsAt.getTime()).toBe(orig.getTime()); // cron_end NÃO move

    const changes = await prisma.launchStatusChange.findMany({ where: { launchId: l.id } });
    expect(changes.some((c) => c.reason === "cron_end" && c.toStatus === "closed")).toBe(true);
  });

  it("não toca em planned futuro (startsAt>now)", async () => {
    const l = await makeLaunch({
      status: "planned",
      startsAt: new Date(Date.now() + 86400000),
      endsAt: new Date(Date.now() + 7 * 86400000),
    });
    await runLaunchTransitionScan();
    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("planned");
  });

  it("não toca em live ainda na janela (endsAt>now)", async () => {
    const l = await makeLaunch({
      status: "live",
      startsAt: new Date(Date.now() - 86400000),
      endsAt: new Date(Date.now() + 86400000),
    });
    await runLaunchTransitionScan();
    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("live");
  });

  it("não derruba o worker quando uma transição falha (ex: overlap)", async () => {
    // L1 live, L2 planned com sobreposição → activateLaunch vai retornar erro
    // mas o scan deve continuar.
    const l1 = await makeLaunch({
      status: "live",
      startsAt: new Date(Date.now() - 86400000),
      endsAt: new Date(Date.now() + 7 * 86400000),
    });
    const l2 = await makeLaunch({
      status: "planned",
      startsAt: new Date(Date.now() - 60_000),
      endsAt: new Date(Date.now() + 7 * 86400000),
    });
    await expect(runLaunchTransitionScan()).resolves.not.toThrow();
    // L2 continua planned (overlap rejeitou)
    const l2After = await prisma.launch.findUniqueOrThrow({ where: { id: l2.id } });
    expect(l2After.status).toBe("planned");
    // L1 continua live
    const l1After = await prisma.launch.findUniqueOrThrow({ where: { id: l1.id } });
    expect(l1After.status).toBe("live");
  });

  it("ignora planned com courseId null (não tenta ativar)", async () => {
    const l = await prisma.launch.create({
      data: {
        name: `null-${Date.now()}`,
        slug: `null-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 60_000),
        endsAt: new Date(Date.now() + 86400000),
        status: "planned",
        courseId: null,
      },
    });
    await runLaunchTransitionScan();
    const after = await prisma.launch.findUniqueOrThrow({ where: { id: l.id } });
    expect(after.status).toBe("planned");
    // cleanup
    await prisma.launch.delete({ where: { id: l.id } });
  });
});
