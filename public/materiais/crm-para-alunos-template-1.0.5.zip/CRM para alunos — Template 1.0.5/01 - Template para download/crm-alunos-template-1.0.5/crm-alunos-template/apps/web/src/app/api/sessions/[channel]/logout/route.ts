import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { logoutWaqr } from "@/lib/channels/whatsapp-qr";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * POST /api/sessions/whatsapp-qr/logout — desconecta o número do WhatsApp via QR.
 * Só administrador. Não apaga nada do CRM (agentes, conversas, contatos, pedidos):
 * pra voltar, é só gerar o QR de novo e ler com o celular (o mesmo número ou outro).
 */
export async function POST(_req: Request, { params }: { params: Promise<{ channel: string }> }) {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  if (gate.user.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { channel } = await params;
  if (channel !== "whatsapp-qr") {
    return NextResponse.json({ ok: false, error: "Desconectar pelo CRM só está disponível no WhatsApp via QR." }, { status: 404 });
  }
  try {
    const state = await logoutWaqr();
    return NextResponse.json({ ok: state.status !== "error", state });
  } catch (err) {
    return NextResponse.json({ ok: false, error: String((err as Error)?.message ?? err) }, { status: 500 });
  }
}
