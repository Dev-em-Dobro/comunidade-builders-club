import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { setWhatsAppUserBlocked } from "./whatsapp-block-users";

describe("setWhatsAppUserBlocked", () => {
  const originalPhoneId = process.env.META_PHONE_NUMBER_ID;
  const originalToken = process.env.META_SYSTEM_USER_TOKEN;

  beforeEach(() => {
    process.env.META_PHONE_NUMBER_ID = "123456789";
    process.env.META_SYSTEM_USER_TOKEN = "test-token";
  });

  afterEach(() => {
    vi.unstubAllGlobals();
    if (originalPhoneId === undefined) delete process.env.META_PHONE_NUMBER_ID;
    else process.env.META_PHONE_NUMBER_ID = originalPhoneId;
    if (originalToken === undefined) delete process.env.META_SYSTEM_USER_TOKEN;
    else process.env.META_SYSTEM_USER_TOKEN = originalToken;
  });

  it("só confirma bloqueio quando a Meta inclui o número em added_users", async () => {
    const fetchMock = vi.fn().mockResolvedValue(new Response(JSON.stringify({
      messaging_product: "whatsapp",
      block_users: { added_users: [{ input: "5511999999999", wa_id: "5511999999999" }] },
    }), { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    await expect(setWhatsAppUserBlocked("5511999999999", true)).resolves.toBeUndefined();
    expect(fetchMock).toHaveBeenCalledWith(
      "https://graph.facebook.com/v25.0/123456789/block_users",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({
          messaging_product: "whatsapp",
          block_users: [{ user: "5511999999999" }],
        }),
      }),
    );
  });

  it("não trata HTTP 200 com failed_users como bloqueio concluído", async () => {
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(new Response(JSON.stringify({
      messaging_product: "whatsapp",
      block_users: {
        added_users: [],
        failed_users: [{
          input: "5511999999999",
          errors: [{ message: "Re-engagement required" }],
        }],
      },
    }), { status: 200 })));

    await expect(setWhatsAppUserBlocked("5511999999999", true))
      .rejects.toThrow("Re-engagement required");
  });
});
