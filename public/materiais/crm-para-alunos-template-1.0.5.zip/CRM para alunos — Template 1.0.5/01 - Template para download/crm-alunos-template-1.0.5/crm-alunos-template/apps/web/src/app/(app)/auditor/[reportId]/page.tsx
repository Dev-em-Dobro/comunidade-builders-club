import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { Card } from "@/components/ui/card";
import { buttonVariants } from "@/components/ui/button";
import { PollingClient } from "./_polling-client";

export const dynamic = "force-dynamic";

interface FindingGroup {
  criterionNameSnapshot: string;
  weight: number;
  findings: Array<{
    id: string;
    conversationId: string;
    contactDisplaySnapshot: string | null;
    verdict: string;
    severity: number | null;
    evidence: string | null;
    recommendation: string | null;
  }>;
}

export default async function ReportDetailPage({
  params,
}: {
  params: Promise<{ reportId: string }>;
}) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const { reportId } = await params;
  const report = await prisma.auditReport.findUnique({
    where: { id: reportId },
    include: {
      findings: {
        orderBy: [{ criterionNameSnapshot: "asc" }, { createdAt: "asc" }],
        include: { criterion: { select: { weight: true } } },
      },
    },
  });
  if (!report) notFound();

  // Agrupar findings por criterionNameSnapshot.
  const groups = new Map<string, FindingGroup>();
  for (const f of report.findings) {
    let g = groups.get(f.criterionNameSnapshot);
    if (!g) {
      g = {
        criterionNameSnapshot: f.criterionNameSnapshot,
        weight: f.criterion?.weight ?? 0,
        findings: [],
      };
      groups.set(f.criterionNameSnapshot, g);
    }
    g.findings.push({
      id: f.id,
      conversationId: f.conversationId,
      contactDisplaySnapshot: f.contactDisplaySnapshot,
      verdict: f.verdict,
      severity: f.severity,
      evidence: f.evidence,
      recommendation: f.recommendation,
    });
  }

  // Ordenar grupos: weight × fail_count desc.
  const groupArr = Array.from(groups.values()).sort((a, b) => {
    const aF = a.findings.filter((f) => f.verdict === "fail").length;
    const bF = b.findings.filter((f) => f.verdict === "fail").length;
    return b.weight * bF - a.weight * aF;
  });

  // freeNotes (criterionId=null findings) ficam em grupo separado.
  const freeNotesFindings = report.findings.filter(
    (f) => f.criterionId === null && f.verdict !== "error",
  );
  const errorFindings = report.findings.filter((f) => f.verdict === "error");

  return (
    <div className="flex flex-col gap-6 p-6">
      <PollingClient
        reportId={report.id}
        initialStatus={report.status}
      />

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">
            Relatório de {report.runAt.toLocaleString("pt-BR")}
          </h1>
          <p className="text-sm text-muted-foreground">
            {report.status} · {report.conversationIds.length} conversas
            {report.costUsd ? ` · $${Number(report.costUsd).toFixed(4)}` : ""}
            {report.modelUsed ? ` · ${report.modelUsed}` : ""}
          </p>
        </div>
        <Link href="/auditor" className={buttonVariants({ variant: "outline" })}>
          ← Voltar
        </Link>
      </div>

      {report.status === "error" && (
        <Card className="p-4 border-red-200 bg-red-50">
          <h3 className="font-medium text-red-900">Falhou</h3>
          <p className="text-sm text-red-700 mt-1">
            {report.errorMessage ?? "Sem mensagem de erro."}
          </p>
        </Card>
      )}

      {report.summary && (
        <Card className="p-4">
          <h2 className="font-semibold mb-2">Visão geral</h2>
          <pre className="whitespace-pre-wrap text-sm font-sans">{report.summary}</pre>
        </Card>
      )}

      {groupArr.length > 0 && (
        <Card className="p-4">
          <h2 className="font-semibold mb-3">Achados por critério</h2>
          <div className="flex flex-col gap-4">
            {groupArr.map((g) => {
              const fails = g.findings.filter((f) => f.verdict === "fail");
              const passes = g.findings.filter((f) => f.verdict === "pass").length;
              const nas = g.findings.filter((f) => f.verdict === "na").length;
              return (
                <details key={g.criterionNameSnapshot} className="border rounded p-3" open={fails.length > 0}>
                  <summary className="cursor-pointer font-medium">
                    {g.criterionNameSnapshot} — {fails.length} fails / {passes} pass / {nas} na
                  </summary>
                  <div className="mt-3 flex flex-col gap-3">
                    {fails.map((f) => (
                      <div key={f.id} className="border-l-4 border-red-400 pl-3 py-1">
                        <div className="text-sm font-medium">
                          {f.contactDisplaySnapshot ?? "Sem nome"}
                          {f.severity ? ` · severity ${f.severity}` : ""}
                        </div>
                        {f.evidence && (
                          <div className="text-sm text-muted-foreground mt-1">
                            <strong>Evidência:</strong> {f.evidence}
                          </div>
                        )}
                        {f.recommendation && (
                          <div className="text-sm mt-1">
                            <strong>Recomendação:</strong> {f.recommendation}
                          </div>
                        )}
                        <Link
                          href={`/conversations/${f.conversationId}`}
                          className="text-xs text-blue-600 hover:underline mt-1 inline-block"
                        >
                          Abrir conversa →
                        </Link>
                      </div>
                    ))}
                  </div>
                </details>
              );
            })}
          </div>
        </Card>
      )}

      {freeNotesFindings.length > 0 && (
        <Card className="p-4">
          <h2 className="font-semibold mb-2">Observações livres</h2>
          <ul className="list-disc pl-5 text-sm">
            {freeNotesFindings.map((f) => (
              <li key={f.id} className="mb-2">
                <strong>{f.contactDisplaySnapshot ?? "Conv " + f.conversationId.slice(-6)}:</strong>{" "}
                {f.freeNotes}
              </li>
            ))}
          </ul>
        </Card>
      )}

      {errorFindings.length > 0 && (
        <Card className="p-4 border-yellow-200 bg-yellow-50">
          <h2 className="font-semibold mb-2">Erros do auditor</h2>
          <ul className="text-sm">
            {errorFindings.map((f) => (
              <li key={f.id}>
                {f.contactDisplaySnapshot ?? f.conversationId}: {f.freeNotes ?? "sem detalhes"}
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
