"use client";

import { useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { playWindowWarningSound } from "@/lib/audio";

/**
 * Recarrega a lista de pedidos a cada `seconds` e toca um som quando o número
 * de pedidos novos aumenta (a cozinha não precisa ficar atualizando a página).
 */
export function OrdersAutoRefresh({ newCount, seconds = 15 }: { newCount: number; seconds?: number }) {
  const router = useRouter();
  const previous = useRef(newCount);

  useEffect(() => {
    if (newCount > previous.current) playWindowWarningSound();
    previous.current = newCount;
  }, [newCount]);

  useEffect(() => {
    const id = setInterval(() => router.refresh(), seconds * 1000);
    return () => clearInterval(id);
  }, [router, seconds]);

  return null;
}
