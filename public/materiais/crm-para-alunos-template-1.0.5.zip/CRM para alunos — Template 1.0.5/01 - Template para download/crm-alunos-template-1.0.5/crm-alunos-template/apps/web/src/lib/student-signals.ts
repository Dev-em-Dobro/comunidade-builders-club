/**
 * Detecção DETERMINÍSTICA de que o inbound é de um ALUNO/ex-aluno ou uma dúvida
 * de acesso/login — pra rotear direto pro agente de suporte (Bia) SEM depender
 * do classificador LLM.
 *
 * Por quê: o roteamento SDR→suporte dependia só do classificador (Haiku), que é
 * frágil e deixou passar um caso óbvio — "comprei o curso, quero voltar a
 * acessá-lo, qual site pra login" foi parar no SDR, que escalou pra humano em
 * vez de a Bia mandar o link (incidente 2026-08-20).
 *
 * Alta precisão de propósito: só frases que fortemente implicam cliente
 * existente (já comprou / já tem conta / perdeu acesso / login / senha).
 * Prospects ("quero comprar", "quanto custa") NÃO batem — pra esses o fluxo
 * normal do SDR + classificador continua valendo. Rede de segurança: se um
 * prospect cair na Bia por engano, o prompt dela já manda escalar pra vendas.
 */

/** minúsculas + remove acentos, pra casar "á"/"a", "é"/"e" etc. */
function normalize(s: string): string {
  // ̀-ͯ = marcas diacríticas combinantes (acentos) separadas pelo NFD.
  return s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
}

/** Frases já normalizadas (sem acento) que indicam aluno/acesso existente. */
const STUDENT_SIGNALS: readonly string[] = [
  // já é cliente
  "ja comprei",
  "comprei o curso",
  "ja sou aluno",
  "sou aluno",
  "ja tenho acesso",
  "curso antigo",
  "aluno antigo",
  // login / senha / conta
  "fazer login",
  "faco login",
  "site de login",
  "site pra login",
  "link de login",
  "esqueci a senha",
  "esqueci minha senha",
  "recuperar senha",
  "recuperar acesso",
  "recuperar o acesso",
  "perdi o acesso",
  "nao consigo acessar",
  "acessar minha conta",
  "minha conta",
  // acesso ao conteúdo já adquirido
  "voltar a acessa", // cobre "acessar" e "acessá-lo"
  "acessar as aulas",
  "acessar a plataforma",
];

/** true se o texto tem sinal claro de aluno/ex-aluno ou dúvida de acesso. */
export function looksLikeReturningStudent(text: string | null | undefined): boolean {
  if (!text) return false;
  const t = normalize(text);
  return STUDENT_SIGNALS.some((p) => t.includes(p));
}
