import { describe, it, expect, afterAll } from "vitest";
import { startWorkers, stopWorkers } from "./workers";
import { closeQueueConnection } from "./connection";
import { QUEUE_NAMES } from "./types";

afterAll(async () => {
  await stopWorkers();
  closeQueueConnection();
});

describe("startWorkers", () => {
  it("cria um worker por fila", () => {
    expect(startWorkers()).toHaveLength(QUEUE_NAMES.length);
  });

  it("é idempotente — chamadas repetidas devolvem o mesmo array", () => {
    expect(startWorkers()).toBe(startWorkers());
  });
});
