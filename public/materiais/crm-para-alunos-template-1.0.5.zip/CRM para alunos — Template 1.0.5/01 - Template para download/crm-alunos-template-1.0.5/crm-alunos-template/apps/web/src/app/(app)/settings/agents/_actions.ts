"use server";

import { auth } from "@/auth";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/db";
import type { Prisma } from "@prisma/client";
import { normalizeIntakeFields, type IntakeField } from "@/lib/scheduling/intake";
import { DEFAULT_HUMANIZE, normalizeHumanize } from "@/lib/humanize";
import { AGENT_ROLE_VALUES, roleTabs } from "./_roles";

export interface AgentFormState {
  ok?: boolean;
  error?: string;
}

const ALLOWED_MEMORY = /^(stateless|window_\d+|summary_plus_\d+)$/;

export async function saveAgent(
  formData: FormData,
): Promise<AgentFormState> {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Acesso exclusivo do administrador." };
  const id = formData.get("id") as string | null;
  const name = String(formData.get("name") ?? "").trim();
  const personaRaw = String(formData.get("persona") ?? "").trim();
  const persona = personaRaw.length > 0 ? personaRaw : null;
  const systemPrompt = String(formData.get("systemPrompt") ?? "").trim();
  const model = String(formData.get("model") ?? "claude-sonnet-4-6").trim();
  const provider = String(formData.get("provider") ?? "anthropic").trim();
  const temperature = Number(formData.get("temperature") ?? 0.7);
  const maxTokens = Number(formData.get("maxTokens") ?? 1024);
  const memoryMode = String(formData.get("memoryMode") ?? "window_20").trim();
  const isDefault = formData.get("isDefault") === "on";
  const roleRaw = String(formData.get("role") ?? "").trim();
  if (!AGENT_ROLE_VALUES.includes(roleRaw)) return { error: "Tipo de agente inválido" };
  const role = roleRaw || null;
  let intakeFields: IntakeField[] = [];
  if (role === "scheduling") {
    try {
      intakeFields = normalizeIntakeFields(JSON.parse(String(formData.get("intakeFields") ?? "[]")));
    } catch {
      return { error: "Campos da pré-consulta inválidos" };
    }
  }

  // Switch desmarcado não vai no form → off. Espera é limitada em normalizeHumanize.
  const humanize = normalizeHumanize({
    waitSeconds: Number(formData.get("humanizeWait") ?? DEFAULT_HUMANIZE.waitSeconds),
    typing: formData.get("humanizeTyping") === "on",
    splitMessages: formData.get("humanizeSplit") === "on",
  });

  if (!name) return { error: "Nome obrigatório" };
  if (!systemPrompt) return { error: "systemPrompt obrigatório" };
  if (!ALLOWED_MEMORY.test(memoryMode)) {
    return { error: "memoryMode inválido — use stateless | window_N | summary_plus_N" };
  }
  if (temperature < 0 || temperature > 1.5) {
    return { error: "temperature fora do range [0, 1.5]" };
  }

  // Se marcar como default, desmarcar os outros.
  if (isDefault) {
    await prisma.agentSession.updateMany({
      where: id ? { id: { not: id } } : {},
      data: { isDefault: false },
    });
  }

  let createdId: string | null = null;
  try {
    const data = {
      name, persona, systemPrompt, model, provider, temperature, maxTokens, memoryMode, isDefault,
      role,
      humanize: humanize as unknown as Prisma.InputJsonValue,
      // Só sobrescreve os campos da pré-consulta quando o agente é de consulta.
      ...(role === "scheduling" ? { intakeFields: intakeFields as unknown as Prisma.InputJsonValue } : {}),
    };
    if (id) {
      await prisma.agentSession.update({ where: { id }, data });
    } else {
      createdId = (await prisma.agentSession.create({ data, select: { id: true } })).id;
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }

  revalidatePath("/settings/agents");
  // Tipo com módulo próprio (ex.: agendamento): o agente novo cai na primeira
  // aba do módulo, pra pessoa já cadastrar o que ele precisa.
  const firstTab = roleTabs(role)[0];
  if (createdId && firstTab) redirect(`/settings/agents/${createdId}/${firstTab.slug}`);
  redirect("/settings/agents");
}

export async function deleteAgent(id: string) {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Acesso exclusivo do administrador." };
  try {
    await prisma.agentSession.delete({ where: { id } });
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }
  revalidatePath("/settings/agents");
  redirect("/settings/agents");
}
