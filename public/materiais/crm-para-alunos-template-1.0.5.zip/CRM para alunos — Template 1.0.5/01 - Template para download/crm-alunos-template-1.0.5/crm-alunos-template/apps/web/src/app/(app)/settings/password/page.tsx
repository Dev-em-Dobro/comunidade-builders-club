import { KeyRound } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { auth } from "@/auth";
import { PasswordForm } from "./password-form";

export const metadata = {
  title: "Trocar senha · CRM Template",
};

export default async function PasswordPage() {
  const session = await auth();

  return (
    <div className="p-6 md:p-10 max-w-xl">
      <div className="mb-6">
        <h1 className="text-xl font-semibold tracking-tight flex items-center gap-2">
          <KeyRound className="size-4 text-primary" /> Trocar senha
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Logado como <code>{session?.user?.email}</code>
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Nova senha</CardTitle>
          <CardDescription>
            Você vai precisar usar a senha atual pra confirmar a troca.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <PasswordForm />
        </CardContent>
      </Card>
    </div>
  );
}
