import { describe, expect, it, vi } from "vitest";
import { runToolLoop } from "./tool-loop";
import type { LLMResponse, LLMTurn } from "./types";

const resp = (text: string, tools: { name: string; id?: string }[] = [], tokens = 10): LLMResponse => ({
  text,
  modelUsed: "m",
  tokensIn: tokens,
  tokensOut: tokens,
  costUsd: 0.001,
  toolUses: tools.length
    ? tools.map((t, i) => ({ id: t.id ?? `t${i}`, name: t.name, input: { n: i } }))
    : undefined,
});

const local = (n: string) => n === "check_availability" || n === "book_appointment";
const history: LLMTurn[] = [{ role: "user", content: "quero marcar" }];

describe("runToolLoop", () => {
  it("encadeia várias tools e soma tokens/custo", async () => {
    const calls: LLMTurn[][] = [];
    const call = vi
      .fn<(m: LLMTurn[]) => Promise<LLMResponse>>()
      .mockImplementationOnce(async (m) => (calls.push(m), resp("", [{ name: "book_appointment", id: "b" }])))
      .mockImplementationOnce(async (m) => (calls.push(m), resp("Marcado para segunda às 9h!")));
    const out = await runToolLoop({
      first: resp("Vou verificar", [{ name: "check_availability", id: "a" }]),
      messages: history,
      handles: local,
      execute: async (c) => JSON.stringify({ ok: true, tool: c.name }),
      call,
    });
    expect(out.steps).toBe(2);
    expect(out.executed.map((e) => e.name)).toEqual(["check_availability", "book_appointment"]);
    expect(out.resp.text).toBe("Marcado para segunda às 9h!");
    expect(out.resp.tokensIn).toBe(30);
    expect(out.resp.costUsd).toBe(0.003);
    expect(out.resp.toolUses).toBeUndefined();
    // 2ª chamada carrega tool_use + tool_result das duas idas.
    expect(calls[1]!.filter((t) => t.role === "tool").map((t) => t.toolResult?.toolUseId)).toEqual(["a", "b"]);
    expect(history).toHaveLength(1); // não muta o histórico do chamador
  });

  it("para e devolve tools não locais (handoff) pro chamador", async () => {
    const call = vi.fn(async () => resp("", [{ name: "request_handoff" }]));
    const out = await runToolLoop({
      first: resp("", [{ name: "check_availability" }]),
      messages: history,
      handles: local,
      execute: async () => "{}",
      call,
    });
    expect(call).toHaveBeenCalledTimes(1);
    expect(out.resp.toolUses?.map((t) => t.name)).toEqual(["request_handoff"]);
  });

  it("não engole o turno quando a última resposta vem vazia", async () => {
    const out = await runToolLoop({
      first: resp("Um instante, vou olhar a agenda.", [{ name: "check_availability" }]),
      messages: history,
      handles: local,
      execute: async () => "{}",
      call: async () => resp(""),
    });
    expect(out.resp.text).toBe("Um instante, vou olhar a agenda.");
  });

  it("respeita maxSteps e descarta chamadas locais pendentes", async () => {
    const execute = vi.fn(async () => "{}");
    const out = await runToolLoop({
      first: resp("a", [{ name: "check_availability" }]),
      messages: history,
      handles: local,
      execute,
      call: async () => resp("b", [{ name: "check_availability" }]),
      maxSteps: 2,
    });
    expect(execute).toHaveBeenCalledTimes(2);
    expect(out.resp.toolUses).toBeUndefined();
    expect(out.resp.text).toBe("b");
  });

  it("não faz nada sem tool local", async () => {
    const call = vi.fn();
    const out = await runToolLoop({ first: resp("oi"), messages: history, handles: local, execute: vi.fn(), call });
    expect(call).not.toHaveBeenCalled();
    expect(out.steps).toBe(0);
    expect(out.resp.text).toBe("oi");
  });
});
