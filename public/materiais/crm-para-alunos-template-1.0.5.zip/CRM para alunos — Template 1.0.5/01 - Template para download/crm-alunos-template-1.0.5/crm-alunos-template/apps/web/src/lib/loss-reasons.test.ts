import { describe, it, expect } from "vitest";
import {
  LOSS_REASONS,
  LOSS_REASON_CODES,
  lossReasonLabel,
  lossReasonShort,
} from "./loss-reasons";

describe("loss-reasons", () => {
  it("expõe os 7 códigos canônicos", () => {
    expect(LOSS_REASON_CODES).toEqual([
      "preco",
      "tempo",
      "conjuge",
      "outro_curso",
      "medo",
      "no_response",
      "outro",
    ]);
  });

  it("todo código tem label e short não vazios", () => {
    for (const r of LOSS_REASONS) {
      expect(r.label.length).toBeGreaterThan(0);
      expect(r.short.length).toBeGreaterThan(0);
    }
  });

  it("lossReasonLabel devolve o label longo (pro dropdown / detalhe)", () => {
    expect(lossReasonLabel("preco")).toBe("Preço");
    expect(lossReasonLabel("no_response")).toBe("Sem resposta");
  });

  it("lossReasonShort devolve o label curto (pro selo)", () => {
    expect(lossReasonShort("preco")).toBe("preço");
    expect(lossReasonShort("conjuge")).toBe("cônjuge");
  });

  it("null/undefined → null (lead sem motivo)", () => {
    expect(lossReasonLabel(null)).toBeNull();
    expect(lossReasonLabel(undefined)).toBeNull();
    expect(lossReasonShort(null)).toBeNull();
  });

  it("código desconhecido (ex: legado) cai no próprio código, sem quebrar", () => {
    expect(lossReasonLabel("algo_legado")).toBe("algo_legado");
    expect(lossReasonShort("algo_legado")).toBe("algo_legado");
  });
});
