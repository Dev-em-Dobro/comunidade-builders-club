import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { fetchWhatsAppMedia, isMetaMediaHost } from "@/lib/channels/whatsapp-media";
import { fetchWaqrMedia } from "@/lib/channels/whatsapp-qr";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;

  const { id } = await params;
  const message = await prisma.message.findUnique({
    where: { id },
    select: { mediaId: true, mediaUrl: true, mediaType: true, conversation: { select: { channel: true } } },
  });
  if (!message || (message.mediaType !== "image" && message.mediaType !== "audio" && message.mediaType !== "document")) {
    return NextResponse.json({ error: "Mídia não encontrada" }, { status: 404 });
  }

  if (message.conversation.channel === "instagram" && message.mediaUrl) {
    try {
      const url = new URL(message.mediaUrl);
      if (url.protocol !== "https:" || !isMetaMediaHost(url.hostname)) throw new Error();
      return Response.redirect(url, 302);
    } catch {
      return NextResponse.json({ error: "URL da mídia inválido" }, { status: 502 });
    }
  }

  if (message.conversation.channel === "whatsapp_qr") {
    if (!message.mediaUrl) return NextResponse.json({ error: "Mídia não disponível" }, { status: 404 });
    try {
      const upstream = await fetchWaqrMedia(message.mediaUrl, request.headers.get("range"));
      if (!upstream.ok && upstream.status !== 206) throw new Error(`HTTP ${upstream.status}`);
      const mimeType = upstream.headers.get("content-type") ?? "application/octet-stream";
      const headers = new Headers({
        "Content-Type": mimeType,
        "Content-Disposition": message.mediaType === "document" && mimeType.toLowerCase() !== "application/pdf"
          ? "attachment"
          : "inline",
        "Cache-Control": "private, max-age=300",
        "X-Content-Type-Options": "nosniff",
      });
      for (const name of ["content-range", "content-length", "accept-ranges"]) {
        const value = upstream.headers.get(name);
        if (value) headers.set(name, value);
      }
      return new Response(upstream.body, { status: upstream.status, headers });
    } catch (error) {
      console.error("whatsapp_qr.media.unavailable", { messageId: id, error: String(error) });
      return NextResponse.json({ error: "Mídia indisponível no provedor" }, { status: 502 });
    }
  }

  if (message.conversation.channel !== "whatsapp_cloud" || !message.mediaId) {
    return NextResponse.json({ error: "Mídia não disponível" }, { status: 404 });
  }

  try {
    const { upstream, mimeType } = await fetchWhatsAppMedia(
      message.mediaId,
      message.mediaType,
      request.headers.get("range"),
    );
    const headers = new Headers({
      "Content-Type": mimeType,
      "Content-Disposition": message.mediaType === "document" && mimeType.toLowerCase() !== "application/pdf"
        ? "attachment"
        : "inline",
      "Cache-Control": "private, max-age=300",
      "X-Content-Type-Options": "nosniff",
    });
    for (const name of ["content-range", "content-length", "accept-ranges"]) {
      const value = upstream.headers.get(name);
      if (value) headers.set(name, value);
    }
    return new Response(upstream.body, { status: upstream.status, headers });
  } catch (error) {
    console.error("whatsapp.media.unavailable", { messageId: id, error: String(error) });
    return NextResponse.json({ error: "Mídia indisponível na Meta" }, { status: 502 });
  }
}
