/**
 * Estado do badge de janela 24h na listagem de conversas.
 *
 * `windowClosingSoon` é um flag de *claim* setado pelo worker `window24h`
 * (false→true) e nunca volta para false — portanto não pode, sozinho, decidir
 * o rótulo. A fonte de verdade do "fechou ou não" é temporal: `windowClosesAt`
 * comparado a `now` (ou `windowExpired`, quando um envio foi recusado pela Meta).
 *
 * - "closing": janela ainda aberta e reivindicada como prestes a fechar.
 * - "closed":  janela já fechou (passou de `windowClosesAt` ou `windowExpired`).
 * - null:      nenhum badge (janela aberta sem claim, ou conversa sem janela).
 */
export interface WindowBadgeInput {
  windowClosingSoon: boolean;
  windowExpired: boolean;
  windowClosesAt: Date | null;
}

export type WindowBadgeStatus = "closing" | "closed" | null;

export function windowBadgeStatus(
  c: WindowBadgeInput,
  now: Date,
): WindowBadgeStatus {
  const closed =
    c.windowExpired ||
    (c.windowClosesAt != null && c.windowClosesAt.getTime() <= now.getTime());

  if (closed) {
    // Só sinaliza "fechada" pra quem entrou no ciclo de fechamento (claim) ou
    // teve um envio recusado — evita inundar a lista com toda conversa antiga.
    return c.windowClosingSoon || c.windowExpired ? "closed" : null;
  }
  return c.windowClosingSoon ? "closing" : null;
}
