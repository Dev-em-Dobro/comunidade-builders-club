import { describe, expect, it } from "vitest";
import {
  buildRenewalAnswerDirective,
  hasHublaRenewalDetails,
  hasNoCardOrLimitSignal,
  hasRenewalDetails,
  hasTmbRenewalDetails,
  isRenewalFollowup,
  isRenewalRequest,
} from "./renewal";

describe("renewal RAG handling", () => {
  it("detecta renovar e renovação sem depender de acentos", () => {
    expect(isRenewalRequest("queria renovar o curso")).toBe(true);
    expect(isRenewalRequest("informações sobre renovação do acesso")).toBe(true);
    expect(isRenewalRequest("qual é o valor do curso?")).toBe(false);
  });

  it("só permite responder quando os trechos trazem renovação, preço e link", () => {
    expect(
      hasRenewalDetails([
        {
          score: 0.72,
          text: "Opções para renovar: 1 ano por R$ 997,00 https://pay.example/renovacao",
        },
      ]),
    ).toBe(true);
    expect(
      hasRenewalDetails([
        { score: 0.72, text: "Para renovar, entre em contato com o suporte." },
      ]),
    ).toBe(false);
  });

  it("reconhece as ofertas Hubla e TMB do FAQ", () => {
    const hits = [
      {
        score: 0.72,
        text: "Renovação 1 ano R$ 997,00 https://pay.hub.la/abc",
      },
      {
        score: 0.68,
        text: "Boleto parcelado R$ 1.297,00 https://pay.tmb.com.br/abc",
      },
    ];
    expect(hasHublaRenewalDetails(hits)).toBe(true);
    expect(hasTmbRenewalDetails(hits)).toBe(true);
  });

  it("mantém o fluxo de venda na renovação e em escolhas de prazo", () => {
    expect(isRenewalFollowup([{ role: "user", content: "queria renovar o curso" }])).toBe(true);
    expect(
      isRenewalFollowup([
        { role: "user", content: "queria renovar o curso" },
        { role: "assistant", content: "1 ano R$ 997 https://pay.hub.la/abc" },
        { role: "user", content: "não tenho cartão" },
      ]),
    ).toBe(true);
    expect(
      isRenewalFollowup([
        { role: "user", content: "queria renovar o curso" },
        { role: "assistant", content: "1 ano R$ 997 https://pay.hub.la/abc" },
        { role: "user", content: "quero falar com a Bia" },
      ]),
    ).toBe(false);
    expect(
      hasNoCardOrLimitSignal([
        { role: "user", content: "queria renovar" },
        { role: "assistant", content: "Hubla: https://pay.hub.la/abc" },
        { role: "user", content: "meu cartão não tem limite" },
      ]),
    ).toBe(true);
    expect(
      hasNoCardOrLimitSignal([{ role: "user", content: "queria renovar" }]),
    ).toBe(false);
  });

  it("prioriza Hubla e só libera TMB com falta de cartão/limite", () => {
    const firstReply = buildRenewalAnswerDirective({
      tmbEligible: false,
      hublaAlreadyOffered: false,
    });
    expect(firstReply).toContain("PRIMEIRO somente os planos Hubla");
    expect(firstReply).toContain("Não mencione TMB");

    const fallbackReply = buildRenewalAnswerDirective({
      tmbEligible: true,
      hublaAlreadyOffered: true,
    });
    expect(fallbackReply).toContain("Os links Hubla já foram enviados");
    expect(fallbackReply).toContain("TMB como alternativa de boleto parcelado");
    expect(fallbackReply).not.toContain("Ofereça PRIMEIRO somente os planos Hubla");
  });
});
