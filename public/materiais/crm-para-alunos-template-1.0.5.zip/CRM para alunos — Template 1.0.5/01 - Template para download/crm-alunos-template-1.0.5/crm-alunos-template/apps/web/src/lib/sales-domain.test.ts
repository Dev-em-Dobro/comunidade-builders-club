import { describe, it, expect, afterAll } from "vitest";
import { prisma } from "@/lib/db";

/**
 * Verificação da migration 003_sales_domain: os novos models existem, as
 * relações ligam e os defaults aplicam. Integração — precisa do Postgres local.
 */

const created = {
  contactIds: [] as string[],
  launchIds: [] as string[],
  courseIds: [] as string[],
  userIds: [] as string[],
};

afterAll(async () => {
  // Contact cascateia pra Lead → PipelineEvent; User cascateia pra Notification.
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.launch.deleteMany({ where: { id: { in: created.launchIds } } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.$disconnect();
});

describe("schema do domínio comercial (Parte 2)", () => {
  it("cria Lead 1:1 com Contact e bloqueia 2 Leads no mesmo Contact", async () => {
    const contact = await prisma.contact.create({
      data: { displayName: "Teste P2 lead" },
    });
    created.contactIds.push(contact.id);

    const lead = await prisma.lead.create({ data: { contactId: contact.id } });
    expect(lead.stage).toBe("new");
    expect(lead.score).toBe(0);
    expect(lead.interestCourseIds).toEqual([]);

    // contactId @unique — segundo Lead no mesmo Contact deve falhar.
    await expect(
      prisma.lead.create({ data: { contactId: contact.id } }),
    ).rejects.toThrow();
  });

  it("registra PipelineEvent ligado ao Lead", async () => {
    const contact = await prisma.contact.create({
      data: { displayName: "Teste P2 evt" },
    });
    created.contactIds.push(contact.id);
    const lead = await prisma.lead.create({ data: { contactId: contact.id } });

    const evt = await prisma.pipelineEvent.create({
      data: { leadId: lead.id, type: "stage_change", payload: { to: "new" } },
    });
    expect(evt.type).toBe("stage_change");

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id },
    });
    expect(events).toHaveLength(1);
  });

  it("cria Launch e Course com seus defaults", async () => {
    const launch = await prisma.launch.create({
      data: {
        name: "Lançamento Teste",
        slug: `launch-${Date.now()}`,
        startsAt: new Date(),
        endsAt: new Date(Date.now() + 7 * 86_400_000),
      },
    });
    created.launchIds.push(launch.id);
    expect(launch.status).toBe("planned");

    const course = await prisma.course.create({
      data: {
        name: "Curso Teste",
        slug: `course-${Date.now()}`,
        priceCents: 49_700,
      },
    });
    created.courseIds.push(course.id);
    expect(course.active).toBe(true);
  });

  it("cria Notification ligada a User; isOnDuty default false", async () => {
    const user = await prisma.user.create({
      data: { email: `p2-${Date.now()}@test.local` },
    });
    created.userIds.push(user.id);
    expect(user.isOnDuty).toBe(false);

    const notif = await prisma.notification.create({
      data: { userId: user.id, type: "sla_breach", payload: { leadId: "x" } },
    });
    expect(notif.readAt).toBeNull();
  });

  it("Conversation ganha os campos comerciais com defaults", async () => {
    const contact = await prisma.contact.create({
      data: { displayName: "Teste P2 conv" },
    });
    created.contactIds.push(contact.id);

    const conv = await prisma.conversation.create({
      data: { contactId: contact.id, channel: "whatsapp_cloud" },
    });
    expect(conv.followupCount).toBe(0);
    expect(conv.windowClosingSoon).toBe(false);
    expect(conv.windowExpired).toBe(false);
    expect(conv.leadId).toBeNull();
    expect(conv.windowClosesAt).toBeNull();
  });
});
