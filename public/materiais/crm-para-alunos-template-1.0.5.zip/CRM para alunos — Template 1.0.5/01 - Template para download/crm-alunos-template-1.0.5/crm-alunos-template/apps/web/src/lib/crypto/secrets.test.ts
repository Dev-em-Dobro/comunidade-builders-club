import { describe, it, expect, beforeAll } from "vitest";
import { encryptSecret, decryptSecret, secretsKeyConfigured } from "./secrets";

beforeAll(() => {
  process.env.SECRETS_KEY = "vitest-secret-key-para-testes";
});

describe("secrets crypto", () => {
  it("round-trip encrypt→decrypt devolve o texto original", () => {
    const plain = "sk-openai-abc123";
    expect(decryptSecret(encryptSecret(plain))).toBe(plain);
  });

  it("dois encrypts do mesmo texto geram ciphertexts diferentes (IV aleatório)", () => {
    expect(encryptSecret("mesmo-texto")).not.toBe(encryptSecret("mesmo-texto"));
  });

  it("decrypt de formato inválido lança", () => {
    expect(() => decryptSecret("lixo-sem-separador")).toThrow();
  });

  it("secretsKeyConfigured reflete a env var", () => {
    expect(secretsKeyConfigured()).toBe(true);
  });

  it("encryptSecret lança quando SECRETS_KEY ausente", () => {
    const saved = process.env.SECRETS_KEY;
    delete process.env.SECRETS_KEY;
    expect(() => encryptSecret("x")).toThrow("SECRETS_KEY ausente");
    process.env.SECRETS_KEY = saved;
  });
});
