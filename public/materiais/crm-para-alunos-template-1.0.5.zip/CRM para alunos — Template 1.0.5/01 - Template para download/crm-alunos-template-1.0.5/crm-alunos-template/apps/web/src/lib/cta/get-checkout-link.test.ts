import { describe, it, expect, afterAll, beforeAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { getCheckoutLink } from "./get-checkout-link";
import { _resetActiveLaunchCache } from "@/lib/launches/active";

const created = {
  contactIds: [] as string[],
  courseIds: [] as string[],
};

let leadId: string;
let conversationId: string;
let courseWithUrlId: string;
let courseWithoutUrlId: string;
const agentSessionId = "test-agent";

beforeAll(async () => {
  const contact = await prisma.contact.create({
    data: { displayName: "Lead CTA test" },
  });
  created.contactIds.push(contact.id);
  const lead = await prisma.lead.create({
    data: { contactId: contact.id, stage: "qualified", interestCourseIds: [] },
  });
  leadId = lead.id;
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp", leadId: lead.id },
  });
  conversationId = conv.id;

  const c1 = await prisma.course.create({
    data: {
      name: "Curso A",
      slug: "curso-a",
      priceCents: 49700,
      checkoutUrl: "https://pay.example.com/curso-a",
    },
  });
  courseWithUrlId = c1.id;
  created.courseIds.push(c1.id);

  const c2 = await prisma.course.create({
    data: { name: "Curso B", slug: "curso-b", priceCents: 19700 },
  });
  courseWithoutUrlId = c2.id;
  created.courseIds.push(c2.id);
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.$disconnect();
});

describe("getCheckoutLink", () => {
  it("retorna course_not_found quando courseId não existe", async () => {
    const r = await getCheckoutLink({
      prisma,
      leadId,
      courseId: "does-not-exist",
      conversationId,
      agentSessionId,
      baseUrl: "https://app.example.com",
    });
    expect(r).toEqual({ ok: false, error: "course_not_found" });
  });

  it("dispara handoff quando checkoutUrl é null", async () => {
    const r = await getCheckoutLink({
      prisma,
      leadId,
      courseId: courseWithoutUrlId,
      conversationId,
      agentSessionId,
      baseUrl: "https://app.example.com",
    });
    expect(r).toEqual({ ok: false, error: "no_checkout_url", handoff: true });

    const conv = await prisma.conversation.findUniqueOrThrow({
      where: { id: conversationId },
    });
    expect(conv.handoffRequested).toBe(true);

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId, type: { in: ["cta_link_missing", "handoff"] } },
    });
    expect(events.map((e) => e.type).sort()).toEqual(["cta_link_missing", "handoff"]);
  });

  it("cria ShortLink e adiciona courseId ao interesse na primeira chamada", async () => {
    const r = await getCheckoutLink({
      prisma,
      leadId,
      courseId: courseWithUrlId,
      conversationId,
      agentSessionId,
      baseUrl: "https://app.example.com",
    });
    expect(r.ok).toBe(true);
    if (!r.ok) throw new Error("expected ok");
    if ("needsPlanChoice" in r) throw new Error("expected url, got needsPlanChoice");
    expect(r.url).toMatch(/^https:\/\/app\.example\.com\/l\/[0-9a-zA-Z]{6}$/);

    const link = await prisma.shortLink.findUniqueOrThrow({
      where: { leadId_courseId: { leadId, courseId: courseWithUrlId } },
    });
    expect(link.sentCount).toBe(1);
    expect(link.code).toBe(r.code);

    const lead = await prisma.lead.findUniqueOrThrow({ where: { id: leadId } });
    expect(lead.interestCourseIds).toContain(courseWithUrlId);

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId, type: { in: ["cta_sent", "interest_added"] } },
    });
    expect(events.map((e) => e.type).sort()).toEqual(["cta_sent", "interest_added"]);
  });

  it("reutiliza o mesmo code na segunda chamada e incrementa sentCount", async () => {
    const r2 = await getCheckoutLink({
      prisma,
      leadId,
      courseId: courseWithUrlId,
      conversationId,
      agentSessionId,
      baseUrl: "https://app.example.com",
    });
    if (!r2.ok) throw new Error("expected ok");
    if ("needsPlanChoice" in r2) throw new Error("expected url, got needsPlanChoice");

    const link = await prisma.shortLink.findUniqueOrThrow({
      where: { leadId_courseId: { leadId, courseId: courseWithUrlId } },
    });
    expect(link.sentCount).toBe(2);
    expect(r2.code).toBe(link.code);

    const interestEvents = await prisma.pipelineEvent.findMany({
      where: { leadId, type: "interest_added" },
    });
    expect(interestEvents).toHaveLength(1);
  });
});

describe("getCheckoutLink — com oferta ativa", () => {
  let launchId: string;
  let plan1Id: string;
  let plan2Id: string;

  beforeAll(async () => {
    const launch = await prisma.launch.create({
      data: {
        name: "Oferta CTA test",
        slug: "oferta-cta-test",
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: courseWithUrlId,
      },
    });
    launchId = launch.id;
    const p1 = await prisma.launchPlan.create({
      data: { launchId, name: "1 ano", priceCents: 49700, checkoutUrl: "https://pay.example.com/1ano", sortOrder: 0 },
    });
    plan1Id = p1.id;
    const p2 = await prisma.launchPlan.create({
      data: { launchId, name: "2 anos", priceCents: 79700, checkoutUrl: "https://pay.example.com/2anos", sortOrder: 1 },
    });
    plan2Id = p2.id;
  });

  afterAll(async () => {
    await prisma.shortLink.deleteMany({ where: { leadId, courseId: courseWithUrlId } });
    await prisma.launchPlan.deleteMany({ where: { launchId } });
    await prisma.launch.delete({ where: { id: launchId } });
  });

  beforeEach(() => {
    _resetActiveLaunchCache();
  });

  it("oferta com 2+ planos sem planId → needsPlanChoice com lista de planos", async () => {
    const r = await getCheckoutLink({
      prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
      baseUrl: "https://app.example.com",
    });
    expect(r.ok).toBe(true);
    if (r.ok && "needsPlanChoice" in r) {
      expect(r.needsPlanChoice).toBe(true);
      expect(r.plans).toHaveLength(2);
      expect(r.plans.map((p) => p.id).sort()).toEqual([plan1Id, plan2Id].sort());
    } else {
      throw new Error("Esperava needsPlanChoice, recebeu: " + JSON.stringify(r));
    }
  });

  it("oferta com 2+ planos com planId válido → URL daquele plano", async () => {
    await prisma.shortLink.deleteMany({ where: { leadId, courseId: courseWithUrlId } });
    const r = await getCheckoutLink({
      prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
      baseUrl: "https://app.example.com", planId: plan2Id,
    });
    expect(r.ok).toBe(true);
    if (r.ok && "url" in r) {
      expect(r.url).toMatch(/^https:\/\/app\.example\.com\/l\/[a-z0-9]{6}$/i);
      expect(r.planName).toBe("2 anos");
    } else {
      throw new Error("Esperava url, recebeu: " + JSON.stringify(r));
    }

    const sl = await prisma.shortLink.findUnique({
      where: { leadId_courseId: { leadId, courseId: courseWithUrlId } },
    });
    expect(sl?.launchPlanId).toBe(plan2Id);
  });

  it("planId inválido → invalid_plan_id sem handoff", async () => {
    const r = await getCheckoutLink({
      prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
      baseUrl: "https://app.example.com", planId: "plan_does_not_exist",
    });
    expect(r).toEqual({ ok: false, error: "invalid_plan_id" });
  });

  it("plano com checkoutUrl null → no_checkout_url handoff", async () => {
    const p3 = await prisma.launchPlan.create({
      data: { launchId, name: "sem-url", priceCents: 1000, checkoutUrl: null, sortOrder: 2 },
    });
    try {
      const r = await getCheckoutLink({
        prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
        baseUrl: "https://app.example.com", planId: p3.id,
      });
      expect(r).toEqual({ ok: false, error: "no_checkout_url", handoff: true });
    } finally {
      await prisma.launchPlan.delete({ where: { id: p3.id } });
    }
  });

  it("2+ planos compartilhando MESMA URL → trata como single-plan e devolve URL direto (sem needsPlanChoice)", async () => {
    // setup: força os 2 planos pra mesma URL
    const sharedUrl = "https://pay.example.com/landing-aniversario";
    await prisma.launchPlan.update({
      where: { id: plan1Id },
      data: { checkoutUrl: sharedUrl },
    });
    await prisma.launchPlan.update({
      where: { id: plan2Id },
      data: { checkoutUrl: sharedUrl },
    });
    _resetActiveLaunchCache();
    await prisma.shortLink.deleteMany({ where: { leadId, courseId: courseWithUrlId } });

    try {
      const r = await getCheckoutLink({
        prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
        baseUrl: "https://app.example.com",
      });

      expect(r.ok).toBe(true);
      if (r.ok && "url" in r) {
        expect(r.url).toMatch(/^https:\/\/app\.example\.com\/l\/[a-z0-9]{6}$/i);
        // plans[0] tem sortOrder=0 e name "1 ano"
        expect(r.planName).toBe("1 ano");
      } else {
        throw new Error("Esperava url direta, recebeu: " + JSON.stringify(r));
      }

      // ShortLink criado com launchPlanId apontando pro plans[0]
      const sl = await prisma.shortLink.findUnique({
        where: { leadId_courseId: { leadId, courseId: courseWithUrlId } },
      });
      expect(sl?.launchPlanId).toBe(plan1Id);
    } finally {
      // restaura URLs diferentes pros outros testes
      await prisma.launchPlan.update({
        where: { id: plan1Id },
        data: { checkoutUrl: "https://pay.example.com/1ano" },
      });
      await prisma.launchPlan.update({
        where: { id: plan2Id },
        data: { checkoutUrl: "https://pay.example.com/2anos" },
      });
      _resetActiveLaunchCache();
    }
  });

  it("atribui launchId no Lead quando há oferta ativa única", async () => {
    // Resetar estado do lead para simular novo interesse
    await prisma.lead.update({
      where: { id: leadId },
      data: { launchId: null, interestCourseIds: [] },
    });
    await prisma.shortLink.deleteMany({ where: { leadId, courseId: courseWithUrlId } });

    await getCheckoutLink({
      prisma, leadId, courseId: courseWithUrlId, conversationId, agentSessionId,
      baseUrl: "https://app.example.com", planId: plan1Id,
    });

    // tryAttributeLaunchId é fire-and-forget (void), aguarda DB write assíncrono
    await new Promise((r) => setTimeout(r, 300));

    const leadAfter = await prisma.lead.findUniqueOrThrow({ where: { id: leadId } });
    expect(leadAfter.launchId).toBe(launchId);
  });
});

describe("getCheckoutLink — oferta com 1 plano só", () => {
  let launchId: string;
  let course1planId: string;

  beforeAll(async () => {
    const c = await prisma.course.create({
      data: { name: "Curso 1plan", slug: "curso-1plan", priceCents: 100, checkoutUrl: "https://pay.example.com/fallback" },
    });
    course1planId = c.id;
    created.courseIds.push(c.id);

    const launch = await prisma.launch.create({
      data: {
        name: "Oferta 1 plano",
        slug: "oferta-1plano",
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: course1planId,
      },
    });
    launchId = launch.id;
    await prisma.launchPlan.create({
      data: { launchId, name: "Único", priceCents: 12345, checkoutUrl: "https://pay.example.com/unico", sortOrder: 0 },
    });
  });

  afterAll(async () => {
    await prisma.shortLink.deleteMany({ where: { leadId, courseId: course1planId } });
    await prisma.launchPlan.deleteMany({ where: { launchId } });
    await prisma.launch.delete({ where: { id: launchId } });
  });

  beforeEach(() => _resetActiveLaunchCache());

  it("sem planId, 1 plano → usa o único, devolve URL", async () => {
    const r = await getCheckoutLink({
      prisma, leadId, courseId: course1planId, conversationId, agentSessionId,
      baseUrl: "https://app.example.com",
    });
    expect(r.ok).toBe(true);
    if (r.ok && "url" in r) {
      expect(r.planName).toBe("Único");
    } else {
      throw new Error("esperava url, recebeu: " + JSON.stringify(r));
    }
  });
});
