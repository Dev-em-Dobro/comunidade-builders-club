/**
 * Classificador de qualificação do lead (Parte 10).
 *
 * Chamado pelo job `qualify.lead` e pela triagem inline. Jev decide primeiro;
 * Haiku é fallback para incerteza/falhas ou quando Jev não está configurado.
 * Valida com Zod e regrava o score.
 * Best-effort: qualquer falha loga e retorna sem mexer no Lead.
 */
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { type LLMToolDef } from "@/lib/llm";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { qualificationConfig, jevQualificationConfig } from "@/lib/config";
import { classifyWithJev } from "@/lib/qualification-jev";
import { computeScore, type Qualification } from "@/lib/scoring";
import {
  normalizeObjections,
  diffObjections,
  type ObjectionTag,
} from "@/lib/objections";
import { mergeAskedFields, QUAL_FIELDS, type AskedFieldsMap } from "@/lib/asked-fields";
import { enqueue } from "@/lib/queue";
import { isRenewalFollowup } from "@/lib/rag/renewal";

/** Quantas mensagens recentes da conversa entram no classificador.
 *  Maior que a window_20 do bot — classifier precisa ver perguntas antigas
 *  pra detectar askedFields que saíram da memória curta do bot. */
const MESSAGE_WINDOW = 50;

// ---------------------------------------------------------------------------
// Stage promotion (Fix B)
// ---------------------------------------------------------------------------

const TERMINAL_STAGES = new Set(["proposal", "won", "lost"]);

interface PromotionDecision {
  to: string;
}

/**
 * Audiências que vão pro agente de suporte (não pro funil de vendas). O
 * classificador infere `audience` a cada mensagem; só "prospect" (ou ausente)
 * segue como lead de vendas.
 */
export function isSupportAudience(audience: string | undefined): boolean {
  return audience === "student" || audience === "support" || audience === "refund";
}

/**
 * Função pura: decide se o lead deve ser promovido para um estágio mais
 * avançado a partir do classificador.
 *
 * Regras (em ordem):
 * 1. Stages terminais (proposal/won/lost) → null (não regride)
 * 2. Já em "qualified" → null (idempotente)
 * 3. 4 askedFields respondidos → "qualified" (score/budget/interest NÃO entram —
 *    decisão de design: lead que respondeu as 4 perguntas merece o closer,
 *    mesmo com sinais fracos; caso real do Cliente Exemplo 2026-05-25 protegido por teste)
 * 4. Handoff cedo (2026-08-12): qualquer sinal de interesse + >=1 dos 4 campos
 *    respondido → "qualified" (passa pro especialista sem esperar 4/4)
 * 5. Em "new" com qualquer sinal extraído mas sem campo respondido → "contacted"
 * 6. Caso contrário → null
 */
export function determineStagePromotion(
  currentStage: string,
  score: number,
  qualification: Qualification,
): PromotionDecision | null {
  if (TERMINAL_STAGES.has(currentStage)) return null;
  if (currentStage === "qualified") return null;

  const askedFields = qualification.askedFields;
  const answeredCount = askedFields
    ? QUAL_FIELDS.filter((f) => !!askedFields[f]?.answeredAt).length
    : 0;
  const allFieldsAnswered = answeredCount === QUAL_FIELDS.length;

  // Caminho clássico: qualificação completa (4/4) sempre qualifica, mesmo com
  // sinais fracos (caso real do Cliente Exemplo 2026-05-25, protegido por teste).
  if (allFieldsAnswered) return { to: "qualified" };

  const anySignal =
    qualification.budgetSignal !== "unknown" ||
    qualification.interestLevel !== "low" ||
    qualification.decisionTimeline !== "unknown" ||
    qualification.courseInterestIds.length > 0;

  // Handoff cedo (2026-08-12): passa pro especialista no mínimo sinal de
  // interesse — qualquer sinal + pelo menos 1 dos 4 campos respondido. Não
  // espera a qualificação completa; o especialista termina o que faltar.
  if (anySignal && answeredCount >= 1) return { to: "qualified" };

  // Primeiro sinal, ainda sem campo respondido: só sobe new → contacted.
  if (currentStage === "new" && anySignal) return { to: "contacted" };

  return null;
}

const AskedFieldSchema = z.object({
  askedAt: z.string(),
  answeredAt: z.string().optional(),
  answer: z.string().optional(),
});

/** Schema Zod da saída do classificador — espelha `Qualification` de scoring.ts. */
export const QualificationSchema = z.object({
  interestLevel: z.enum(["low", "medium", "high"]),
  budgetSignal: z.enum(["unknown", "weak", "strong"]),
  decisionTimeline: z.enum(["unknown", "long", "medium", "short"]),
  courseInterestIds: z.array(z.string()).default([]),
  rationale: z.string().default(""),
  audience: z.enum(["prospect", "student", "support", "refund"]).optional(),
  /** Objeções levantadas pelo lead (Parte 11). Normalizado fora do Zod. */
  objections: z.array(z.string()).default([]),
  askedFields: z
    .object({
      objetivo: AskedFieldSchema.optional(),
      nivel: AskedFieldSchema.optional(),
      urgencia: AskedFieldSchema.optional(),
      tempo_disponivel: AskedFieldSchema.optional(),
    })
    .optional(),
});

/** Tool forçada (tool_choice) que devolve a qualificação estruturada. */
export const RECORD_QUALIFICATION_TOOL: LLMToolDef = {
  name: "record_qualification",
  description:
    "Registra a qualificação do lead a partir da conversa. Chame uma única " +
    "vez, com a sua melhor leitura. Use 'unknown' quando o sinal não aparecer " +
    "na conversa — não invente.",
  inputSchema: {
    type: "object",
    properties: {
      interestLevel: {
        type: "string",
        enum: ["low", "medium", "high"],
        description: "Quão engajado e interessado o lead está no produto.",
      },
      budgetSignal: {
        type: "string",
        enum: ["unknown", "weak", "strong"],
        description:
          "Sinais de capacidade/disposição de investir. 'unknown' se não houver pista.",
      },
      decisionTimeline: {
        type: "string",
        enum: ["unknown", "long", "medium", "short"],
        description:
          "Prazo provável de decisão. 'short' = decide nos próximos dias.",
      },
      courseInterestIds: {
        type: "array",
        items: { type: "string" },
        description:
          "IDs de cursos do catálogo que o lead demonstrou interesse. Use só IDs da lista fornecida.",
      },
      rationale: {
        type: "string",
        description: "Uma frase curta justificando a classificação.",
      },
      audience: {
        type: "string",
        enum: ["prospect", "student", "support", "refund"],
        description:
          "Quem é este contato: 'prospect' (potencial comprador interessado, " +
          "ainda não comprou), 'student' (já é aluno/matriculado), 'support' " +
          "(tirando dúvida de acesso/conteúdo/uso de algo já adquirido), " +
          "'refund' (pedindo reembolso/cancelamento). Quem SINALIZA que já é " +
          "aluno/já comprou ('curso antigo', 'já sou aluno', 'já tenho acesso', " +
          "'comprei') é 'student' MESMO que agora pergunte sobre pagar ou migrar " +
          "pra outra versão (ex.: acesso ao Dev Quest 2.0) — o acesso atual dela " +
          "precisa ser verificado antes de qualquer venda. Só use 'prospect' pra " +
          "quem NUNCA comprou nada e avalia a primeira compra.",
      },
      objections: {
        type: "array",
        items: {
          type: "string",
          enum: ["preco", "tempo", "conjuge", "outro_curso", "medo", "outro"],
        },
        description:
          "Objeções CLARAS que o lead levantou na conversa. Use só os valores do " +
          "enum: 'preco' (caro/sem grana), 'tempo' (sem tempo agora), 'conjuge' " +
          "(precisa falar com cônjuge/sócio), 'outro_curso' (vai fazer outro curso), " +
          "'medo' (insegurança/medo de não dar conta), 'outro' (catch-all). " +
          "Lista vazia se nenhuma objeção apareceu — não invente.",
      },
      askedFields: {
        type: "object",
        description:
          "Pra cada uma das 4 perguntas de qualificação: marcar askedAt se o " +
          "bot já fez essa pergunta em algum turno visível, e answeredAt+answer " +
          "se o lead respondeu. Use ISO timestamp do turno onde a pergunta " +
          "apareceu. Se NÃO viu a pergunta no histórico, OMITA o campo. NÃO " +
          "invente — é melhor omitir do que poluir o tracking.",
        properties: {
          objetivo: {
            type: "object",
            properties: {
              askedAt: { type: "string" },
              answeredAt: { type: "string" },
              answer: { type: "string" },
            },
          },
          nivel: {
            type: "object",
            properties: {
              askedAt: { type: "string" },
              answeredAt: { type: "string" },
              answer: { type: "string" },
            },
          },
          urgencia: {
            type: "object",
            properties: {
              askedAt: { type: "string" },
              answeredAt: { type: "string" },
              answer: { type: "string" },
            },
          },
          tempo_disponivel: {
            type: "object",
            properties: {
              askedAt: { type: "string" },
              answeredAt: { type: "string" },
              answer: { type: "string" },
            },
          },
        },
      },
    },
    required: ["interestLevel", "budgetSignal", "decisionTimeline", "audience"],
  },
};

export const CLASSIFIER_SYSTEM =
  "Você é um analista de vendas. Leia a conversa entre um lead e o " +
  "atendimento e classifique o lead chamando a tool `record_qualification`. " +
  "Baseie-se só no que está na conversa; quando um sinal não aparecer, use " +
  "'unknown'. Não converse — apenas chame a tool.\n\n" +
  "## Audiência\n" +
  "Classifique 'audience': 'prospect' (interessado em comprar, ainda não " +
  "comprou), 'student' (já é aluno), 'support' (dúvida de suporte sobre algo " +
  "já adquirido) ou 'refund' (reembolso/cancelamento). Isso decide se o lead " +
  "entra em follow-up proativo — só 'prospect' entra. Quem já sinaliza ser " +
  "aluno ('curso antigo', 'já sou aluno', 'já comprei', 'já tenho acesso') é " +
  "'student', mesmo que pergunte sobre pagar/migrar pra outra versão — não é " +
  "'prospect'.\n\n" +
  "## Tracking de perguntas (askedFields)\n" +
  "Você também rastreia quais das 4 perguntas de qualificação o bot já fez e " +
  "quais o lead respondeu. Reconheça a pergunta por SENTIDO, não por frase exata — " +
  "o bot varia o jeito de perguntar. As 4 perguntas e exemplos de como podem aparecer:\n\n" +
  "- objetivo (o que a pessoa quer alcançar com programação)\n" +
  '  exemplos: "qual seu objetivo com programação?", "o que você quer alcançar?", ' +
  '"por que quer aprender a programar?", "qual sua meta?"\n' +
  "- nivel (zero / iniciante / intermediário / avançado)\n" +
  '  exemplos: "você já programa?", "qual seu nível?", "já tem experiência?", ' +
  '"está começando do zero?"\n' +
  "- urgencia (quando quer essa mudança)\n" +
  '  exemplos: "pra quando você quer isso?", "qual sua urgência?", ' +
  '"quando pretende começar/decidir?", "tem prazo?"\n' +
  "- tempo_disponivel (horas por semana de estudo)\n" +
  '  exemplos: "quantas horas por semana você tem?", "quanto tempo consegue dedicar?", ' +
  '"tem tempo pra estudar?"\n\n' +
  "Pra cada campo:\n" +
  "- Se você vê uma mensagem do bot perguntando isso em qualquer turno (mesmo que " +
  "com palavras diferentes dos exemplos, desde que o SENTIDO seja o mesmo), preencha " +
  "askedAt com o ISO do turno mais antigo onde ela aparece.\n" +
  "- Se o lead respondeu, preencha answeredAt com o ISO da resposta + answer " +
  "com o conteúdo resumido (até 80 chars).\n" +
  "- Se a pergunta NÃO aparece no histórico que você está vendo, OMITA o " +
  "campo. NÃO invente — é melhor omitir do que poluir o tracking.";

/** Bloco do catálogo de cursos pro classificador escolher IDs válidos. */
function buildCourseCatalog(courses: { id: string; name: string }[]): string {
  if (!courses.length) return "Catálogo de cursos: (nenhum curso cadastrado).";
  return (
    "Catálogo de cursos (use estes IDs em courseInterestIds):\n" +
    courses.map((c) => `- ${c.id}: ${c.name}`).join("\n")
  );
}

/**
 * Transcrição da conversa, uma linha por mensagem com timestamp ISO.
 * O timestamp é necessário pra o classifier preencher askedAt/answeredAt
 * com valores reais em vez de alucinar.
 */
function buildTranscript(
  messages: { direction: string; text: string; createdAt: Date }[],
): string {
  return messages
    .map((m) => {
      const who = m.direction === "inbound" ? "LEAD" : "ATENDIMENTO";
      return `[${m.createdAt.toISOString()}] ${who}: ${m.text}`;
    })
    .join("\n");
}

/**
 * Classifica a conversa e regrava `Lead.qualification` / `interestCourseIds` /
 * `score`. Cria `PipelineEvent('score_update')` só quando o score muda.
 */
export async function classifyLead(conversationId: string): Promise<void> {
  const cfg = qualificationConfig();

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    include: {
      lead: {
        select: {
          id: true,
          stage: true,
          score: true,
          qualification: true,
        },
      },
    },
  });
  if (!conv || !conv.lead) {
    log("qualify.abort", { conversationId, reason: "no_lead" });
    return;
  }
  const lead = conv.lead;

  const recent = await prisma.message.findMany({
    where: { conversationId },
    orderBy: { createdAt: "desc" },
    take: MESSAGE_WINDOW,
    select: { direction: true, text: true, createdAt: true },
  });
  if (!recent.length) {
    log("qualify.abort", { conversationId, reason: "no_messages" });
    return;
  }
  const messages = recent.reverse();
  const inboundCount = messages.filter((m) => m.direction === "inbound").length;

  const courses = await prisma.course.findMany({
    where: { active: true },
    select: { id: true, name: true },
  });
  const validCourseIds = new Set(courses.map((c) => c.id));

  let qualification: Qualification;
  let parsed: z.infer<typeof QualificationSchema> | null = null;
  try {
    const previousAsked =
      (lead.qualification as { askedFields?: AskedFieldsMap } | null)?.askedFields;
    const jev = jevQualificationConfig();
    if (jev.enabled) {
      try {
        const result = await classifyWithJev({ messages, courses, previousAsked }, jev,
          (metrics) => log("qualify.jev_usage", { conversationId, ...metrics }));
        parsed = QualificationSchema.parse(result.qualification);
        log("qualify.jev_accepted", {
          conversationId, model: result.model, minConfidence: result.minConfidence,
          inputTokens: result.inputTokens, costUsd: result.costUsd, durationMs: result.durationMs,
        });
      } catch (error) {
        const reason = error instanceof Error && /^jev_[\w:]+$/.test(error.message)
          ? error.message : "jev_invalid_output";
        log("qualify.jev_fallback", { conversationId, reason });
      }
    }
    if (!parsed) {
      const started = Date.now();
      const resp = await generateReplyWithKey("anthropic", {
        model: cfg.model,
        maxTokens: 512,
        temperature: 0,
        systemStatic: CLASSIFIER_SYSTEM,
        systemDynamic: buildCourseCatalog(courses),
        messages: [{ role: "user", content: buildTranscript(messages) }],
        tools: [RECORD_QUALIFICATION_TOOL],
        toolChoice: { type: "tool", name: "record_qualification" },
      });
      log("qualify.haiku_completed", {
        conversationId, model: resp.modelUsed, durationMs: Date.now() - started,
        tokensIn: resp.tokensIn, tokensOut: resp.tokensOut, tokensCached: resp.tokensCached,
        costUsd: resp.costUsd, fallback: jev.enabled,
      });
      const call = resp.toolUses?.find((t) => t.name === "record_qualification");
      if (!call) {
        log("qualify.abort", { conversationId, reason: "no_tool_call" });
        return;
      }
      const parseResult = QualificationSchema.safeParse(call.input);
      if (!parseResult.success) {
        log("qualify.abort", {
          conversationId,
          reason: "invalid_output",
          error: parseResult.error.message,
        });
        return;
      }
      parsed = parseResult.data;
    }
    log("qualify.classifier_raw", {
      conversationId,
      askedFieldsRaw: parsed.askedFields ?? null,
    });
    const mergedAsked = mergeAskedFields(previousAsked, parsed.askedFields);
    qualification = {
      ...parsed,
      courseInterestIds: parsed.courseInterestIds.filter((id) =>
        validCourseIds.has(id),
      ),
      askedFields: mergedAsked,
    };
  } catch (err) {
    log("qualify.error", {
      conversationId,
      error: String((err as Error)?.message ?? err),
    });
    return;
  }

  // Objeções (Parte 11) — best-effort. Delta vs tags ativas (<24h),
  // inserções append-only. Falha aqui loga e não derruba o classifier.
  // Roda ANTES do computeScore pra a penalidade considerar o que foi inserido.
  let activeObjections: string[] = [];
  try {
    const detected: ObjectionTag[] = normalizeObjections(parsed?.objections ?? []);
    const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const existing = await prisma.objectionTag.findMany({
      where: { leadId: lead.id, createdAt: { gte: cutoff } },
      select: { tag: true, createdAt: true },
    });
    if (detected.length) {
      const toInsert = diffObjections(detected, existing, new Date());
      if (toInsert.length) {
        await prisma.objectionTag.createMany({
          data: toInsert.map((tag) => ({
            leadId: lead.id,
            tag,
            conversationId,
            rationale: parsed?.rationale || null,
          })),
        });
        log("qualify.objections_inserted", {
          conversationId,
          leadId: lead.id,
          tags: toInsert,
        });
      }
    }
    // Tags ativas pós-insert = existing + toInsert (sem precisar refetchar).
    const existingTagSet = new Set(existing.map((e) => e.tag));
    activeObjections = [...existingTagSet, ...detected.filter((t) => !existingTagSet.has(t))];
  } catch (err) {
    log("qualify.objections_failed", {
      conversationId,
      error: String((err as Error)?.message ?? err),
    });
  }

  const score = computeScore({
    qualification,
    inboundCount,
    stage: lead.stage,
    activeObjections,
  });

  await prisma.lead.update({
    where: { id: lead.id },
    data: {
      qualification: qualification as unknown as Prisma.InputJsonValue,
      interestCourseIds: qualification.courseInterestIds,
      score,
    },
  });

  // Roteamento por audience (2026-07-02): aluno/suporte/reembolso vão pro agente
  // de suporte, independente de qualificação. Idempotente — runAgentHandoff faz
  // no-op se a conversa já estiver com o suporte; o guard de role abaixo evita
  // re-enfileirar em toda classificação de uma conversa já roteada.
  const renewalInteraction = isRenewalFollowup(
    messages.map((message) => ({
      role: message.direction === "inbound" ? "user" : "assistant",
      content: message.text,
    })),
  );
  if (isSupportAudience(qualification.audience) && !renewalInteraction) {
    try {
      const convRow = await prisma.conversation.findUnique({
        where: { id: conversationId },
        select: { agentSession: { select: { role: true } } },
      });
      if (convRow?.agentSession?.role !== "support") {
        await enqueue(
          "sla",
          "agent.handoff",
          { conversationId, toRole: "support" },
          { jobId: `agent-handoff-support__${conversationId}` },
        );
        log("support_handoff.enqueued", {
          conversationId,
          leadId: lead.id,
          audience: qualification.audience,
        });
      }
    } catch (err) {
      log("support_handoff.enqueue_failed", {
        conversationId,
        leadId: lead.id,
        error: String((err as Error)?.message ?? err),
      });
    }
  } else if (isSupportAudience(qualification.audience) && renewalInteraction) {
    log("support_handoff.skipped_renewal_flow", {
      conversationId,
      leadId: lead.id,
    });
  }

  if (score !== lead.score) {
    await prisma.pipelineEvent.create({
      data: {
        leadId: lead.id,
        type: "score_update",
        payload: {
          score,
          prevScore: lead.score,
          qualification: qualification as unknown as Prisma.InputJsonValue,
        },
      },
    });
  }

  // Auto-promote stage baseado no novo score + qualification (Fix B).
  const promotion = determineStagePromotion(lead.stage, score, qualification);
  if (promotion && promotion.to !== lead.stage) {
    await prisma.lead.update({
      where: { id: lead.id },
      data: { stage: promotion.to },
    });
    await prisma.pipelineEvent.create({
      data: {
        leadId: lead.id,
        type: "stage_change",
        payload: { from: lead.stage, to: promotion.to, via: "auto_classify" },
      },
    });
    if (promotion.to === "qualified" && !isSupportAudience(qualification.audience)) {
      try {
        await enqueue(
          "sla",
          "agent.handoff",
          { conversationId, toRole: "closer" },
          { jobId: `agent-handoff__${conversationId}` },
        );
        log("agent_handoff.enqueued", { conversationId, leadId: lead.id });
      } catch (err) {
        // Falha de enqueue não derruba o classifier — o stage já foi promovido,
        // próximo trigger re-tenta. Loga e segue.
        log("agent_handoff.enqueue_failed", {
          conversationId,
          leadId: lead.id,
          error: String((err as Error)?.message ?? err),
        });
      }
    }
    log("qualify.stage_promoted", {
      conversationId,
      leadId: lead.id,
      from: lead.stage,
      to: promotion.to,
    });
  }

  log("qualify.done", { conversationId, leadId: lead.id, score });
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
