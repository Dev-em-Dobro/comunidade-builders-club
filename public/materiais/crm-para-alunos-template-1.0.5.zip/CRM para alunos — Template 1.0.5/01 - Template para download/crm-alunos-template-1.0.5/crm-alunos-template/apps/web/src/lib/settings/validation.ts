import { z } from "zod";
const email = z.union([z.literal(""), z.email().max(254)]);
const optionalHttps = z.union([z.literal(""), z.url().max(2048).refine((value) => new URL(value).protocol === "https:", "Use https://")]);
export const businessSettingsSchema = z.object({
  brandName: z.string().trim().min(1).max(120), legalName: z.string().trim().max(200),
  supportEmail: email, contactEmail: email, accessUrl: optionalHttps,
  handoffNotice: z.string().trim().min(1).max(500),
  timezone: z.string().max(80).refine((value) => {
    try { new Intl.DateTimeFormat("pt-BR", { timeZone: value }); return true; } catch { return false; }
  }, "Fuso horário inválido"),
  windowMs: z.coerce.number().int().min(1000).max(30000), whatsapp: z.boolean(), instagram: z.boolean(),
  whatsappQr: z.boolean().default(false),
});
export function validateMetaValue(value: string, secret: boolean): boolean {
  return value.length <= 8192 && (secret ? /^[\x21-\x7e]+$/.test(value) : /^\d{1,64}$/.test(value));
}
