import type { Job } from "bullmq";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { followupConfig, loadConfig } from "@/lib/config";
import { isQuietHours } from "@/lib/quiet-hours";
import { hoursUntilClose } from "@/lib/window24h";
import {
  buildObjectionsPrompt,
  OBJECTION_LABEL,
  type ObjectionTag,
} from "@/lib/objections";
import { loadMemory } from "@/lib/memory";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { retrieveContext } from "@/lib/rag/retrieve";
import { getAdapter } from "@/lib/channels/registry";
import { ChannelSendError, META_OUT_OF_WINDOW } from "@/lib/channels/meta-graph";
import type { ChannelId } from "@/lib/channels/types";
import type { FollowupJobData } from "@/lib/queue/types";

/** Stages de Lead elegíveis a follow-up — espelha `window24h.ts`. */
const ELIGIBLE_STAGES = ["new", "contacted", "qualified"];

/** Turn sintético que dispara a geração quando o histórico termina no assistant. */
const REENGAGE_TRIGGER =
  "[Instrução interna: gere agora a mensagem de follow-up de reengajamento " +
  "conforme o bloco 'Reengajamento proativo'. Responda só com a mensagem.]";

/**
 * Monta o `systemDynamic` de reengajamento. Função pura — testável.
 * `hoursSince` é `null` quando não há `lastInboundAt` registrado.
 */
export function buildReengagementSystem(
  hoursSince: number | null,
  hoursLeft: number,
): string {
  const since = hoursSince != null ? ` (${hoursSince}h sem responder)` : "";
  return (
    "# Reengajamento proativo\n" +
    "Esta NÃO é uma resposta a uma mensagem nova — é um follow-up que você está " +
    `iniciando porque o lead esfriou${since} e a janela de atendimento fecha em ` +
    `~${hoursLeft}h. Gere UMA mensagem curta, calorosa e específica que retome o ` +
    "último assunto da conversa e convide o lead a responder. Não soe robótico, " +
    "não se desculpe por incomodar, não repita mensagens anteriores literalmente."
  );
}

/**
 * Processa `followup.generate`: gera e envia 1 mensagem de reengajamento.
 *
 * O job carrega só `conversationId` (padrão de idempotência do `BaseJobData`).
 * O estado é recarregado fresco e revalidado — pode ter mudado entre o
 * enfileiramento e a execução. Cada guarda aborta com um motivo logado.
 */
export async function followupProcessor(job: Job): Promise<void> {
  const { conversationId, reason = "window_closing" } = job.data as FollowupJobData;
  const cfg = followupConfig();
  const isReengagement = reason === "reengagement_12h";

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    include: { lead: { select: { id: true, stage: true } } },
  });
  if (!conv) {
    log("followup.abort", { conversationId, reason: "no_conversation" });
    return;
  }

  const now = new Date();
  if (!conv.windowClosesAt || conv.windowClosesAt.getTime() <= now.getTime()) {
    log("followup.abort", { conversationId, reason: "window_closed" });
    return;
  }
  if (conv.followupCount >= cfg.maxPerWindow) {
    log("followup.abort", { conversationId, reason: "already_sent" });
    return;
  }
  if (!conv.aiEnabled || conv.handoffRequested) {
    log("followup.abort", { conversationId, reason: "ai_disabled" });
    return;
  }
  if (!conv.lead || !ELIGIBLE_STAGES.includes(conv.lead.stage)) {
    log("followup.abort", { conversationId, reason: "stage_changed" });
    return;
  }
  if (isQuietHours(now, cfg.quietHours)) {
    log("followup.abort", { conversationId, reason: "quiet_hours" });
    return;
  }

  // Resolve a AgentSession da conversa (mesma lógica de decideAction).
  const agent = conv.agentSessionId
    ? await prisma.agentSession.findUnique({ where: { id: conv.agentSessionId } })
    : await prisma.agentSession.findFirst({ where: { isDefault: true } });
  if (!agent) {
    log("followup.abort", { conversationId, reason: "no_agent" });
    return;
  }

  // Destino do envio: o externalId da identidade do contato nesse canal.
  const channel = conv.channel as ChannelId;
  const ident = await prisma.contactIdentity.findFirst({
    where: { contactId: conv.contactId, channel },
  });
  if (!ident) {
    log("followup.abort", { conversationId, reason: "no_identity" });
    return;
  }

  // Memória — sem histórico não há o que reengajar.
  const memory = await loadMemory(conv.id, agent.memoryMode);
  if (!memory.length) {
    log("followup.abort", { conversationId, reason: "no_history" });
    return;
  }

  const hoursSince = conv.lastInboundAt
    ? Math.round((now.getTime() - conv.lastInboundAt.getTime()) / 3_600_000)
    : null;
  const hoursLeft = Math.max(
    0,
    Math.round(hoursUntilClose(conv.windowClosesAt, now) ?? 0),
  );

  let systemDynamic = buildReengagementSystem(hoursSince, hoursLeft);

  // Objeções (Parte 11) — só pro ramo reengagement_12h. Carrega tags ativas
  // (<24h) e injeta no prompt pra IA endereçar uma delas. Filtra contra o enum
  // pra blindar de tags fora do vocabulário (vocab evolution sem backfill).
  if (isReengagement && conv.lead) {
    try {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const tags = await prisma.objectionTag.findMany({
        where: { leadId: conv.lead.id, createdAt: { gte: cutoff } },
        distinct: ["tag"],
        select: { tag: true },
      });
      const activeTags = tags
        .map((t) => t.tag as ObjectionTag)
        .filter((t): t is ObjectionTag => t in OBJECTION_LABEL);
      const block = buildObjectionsPrompt(activeTags);
      if (block) systemDynamic += "\n\n" + block;
    } catch (err) {
      log("followup.objections_load_failed", {
        conversationId,
        error: String((err as Error)?.message ?? err),
      });
    }
  }

  // RAG: gated por tools.rag; falha nunca derruba o follow-up (só loga).
  if (ragEnabled()) {
    try {
      const query = memory.map((m) => m.content).join("\n").slice(-2000);
      const hits = await retrieveContext(agent.id, query, 5);
      if (hits.length) {
        systemDynamic +=
          "\n\n# Base de conhecimento\n" +
          hits.map((h, i) => `[${i + 1}]\n${h.text}`).join("\n\n");
      }
    } catch (err) {
      log("followup.rag_error", {
        conversationId,
        error: String((err as Error)?.message ?? err),
      });
    }
  }

  // Garante que a última turn seja `user` — Anthropic gera a próxima turn de
  // assistant. Se o histórico já termina em `user`, ele mesmo é o gatilho.
  const last = memory[memory.length - 1];
  const messages =
    last && last.role === "assistant"
      ? [...memory, { role: "user" as const, content: REENGAGE_TRIGGER }]
      : memory;

  log("followup.llm_call", {
    conversationId,
    provider: agent.provider,
    model: agent.model,
  });
  const resp = await generateReplyWithKey(agent.provider, {
    model: agent.model,
    temperature: agent.temperature,
    maxTokens: agent.maxTokens,
    systemStatic: agent.systemPrompt,
    systemDynamic,
    messages,
  });
  const text = resp.text.trim();
  if (!text) {
    log("followup.abort", { conversationId, reason: "empty_reply" });
    return;
  }

  // A janela pode ter fechado durante a chamada LLM.
  if (conv.windowClosesAt.getTime() <= Date.now()) {
    log("followup.abort", { conversationId, reason: "window_closed_late" });
    return;
  }

  try {
    await getAdapter(channel).sendText(ident.externalId, text);
  } catch (err) {
    // 131047 = fora da janela 24h da Meta — marca a conversa (Parte 6).
    if (err instanceof ChannelSendError && err.code === META_OUT_OF_WINDOW) {
      await prisma.conversation.update({
        where: { id: conv.id },
        data: { windowExpired: true },
      });
      log("followup.window_expired", { conversationId });
      return;
    }
    log("followup.send_failed", {
      conversationId,
      error: String((err as Error)?.message ?? err),
    });
    return;
  }

  await prisma.message.create({
    data: {
      conversationId: conv.id,
      direction: "outbound",
      role: "assistant",
      text,
      tokensIn: resp.tokensIn || null,
      tokensOut: resp.tokensOut || null,
      costUsd:
        resp.costUsd !== undefined ? new Prisma.Decimal(resp.costUsd) : null,
      modelUsed: resp.modelUsed ?? null,
    },
  });
  await prisma.conversation.update({
    where: { id: conv.id },
    data: { lastOutboundAt: new Date(), followupCount: { increment: 1 } },
  });
  await prisma.pipelineEvent.create({
    data: {
      leadId: conv.lead.id,
      type: isReengagement ? "reengagement_sent" : "followup_sent",
      payload: { conversationId: conv.id, reason },
    },
  });
  log(isReengagement ? "followup.reengagement_sent" : "followup.sent", {
    conversationId,
    leadId: conv.lead.id,
  });
}

/** RAG ligado? Lê tools.rag do setup.config.json — falha de leitura = off. */
function ragEnabled(): boolean {
  try {
    return loadConfig().tools.rag === true;
  } catch {
    return false;
  }
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
