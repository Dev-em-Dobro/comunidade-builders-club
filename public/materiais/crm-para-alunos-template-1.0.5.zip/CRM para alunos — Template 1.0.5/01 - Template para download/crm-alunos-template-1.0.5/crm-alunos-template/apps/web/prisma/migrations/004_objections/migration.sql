-- CreateTable
CREATE TABLE "ObjectionTag" (
    "id" TEXT NOT NULL,
    "leadId" TEXT NOT NULL,
    "tag" TEXT NOT NULL,
    "rationale" TEXT,
    "conversationId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ObjectionTag_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ObjectionTag_leadId_createdAt_idx" ON "ObjectionTag"("leadId", "createdAt" DESC);
CREATE INDEX "ObjectionTag_tag_createdAt_idx" ON "ObjectionTag"("tag", "createdAt" DESC);

-- AddForeignKey
ALTER TABLE "ObjectionTag" ADD CONSTRAINT "ObjectionTag_leadId_fkey"
    FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "ObjectionTag" ADD CONSTRAINT "ObjectionTag_conversationId_fkey"
    FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AlterTable
ALTER TABLE "Lead" ADD COLUMN "reengagementSentAt" TIMESTAMP(3);
CREATE INDEX "Lead_reengagementSentAt_idx" ON "Lead"("reengagementSentAt");
