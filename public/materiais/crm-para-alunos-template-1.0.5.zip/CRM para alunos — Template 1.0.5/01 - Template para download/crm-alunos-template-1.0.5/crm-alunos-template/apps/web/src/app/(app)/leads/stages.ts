/** Rótulos e variantes de badge dos estágios do funil (Lead.stage). */

type StageVariant = "default" | "secondary" | "outline" | "destructive";

export const STAGE_LABEL: Record<string, string> = {
  new: "novo",
  contacted: "contatado",
  qualified: "qualificado",
  proposal: "proposta",
  won: "ganho",
  lost: "perdido",
};

export const STAGE_VARIANT: Record<string, StageVariant> = {
  new: "secondary",
  contacted: "outline",
  qualified: "default",
  proposal: "default",
  won: "default",
  lost: "destructive",
};
