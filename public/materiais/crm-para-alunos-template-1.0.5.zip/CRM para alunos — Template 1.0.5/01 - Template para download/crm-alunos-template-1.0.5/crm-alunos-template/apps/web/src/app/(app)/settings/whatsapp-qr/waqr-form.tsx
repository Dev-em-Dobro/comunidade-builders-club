"use client";
import { useActionState, useRef, useEffect } from "react";
import { WAQR_FIELDS } from "@/lib/settings/whatsapp-qr-fields";
import { saveWaqr } from "./actions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export function WaqrForm({ status }: { status: Record<string, string> }) {
  const [state, action, pending] = useActionState(saveWaqr, {});
  const ref = useRef<HTMLFormElement>(null);
  useEffect(() => { if (state.message) ref.current?.reset(); }, [state]);
  return <form ref={ref} action={action} className="space-y-5" autoComplete="off">
    {WAQR_FIELDS.map(({ key, label, secret }) => <div key={key} className="space-y-2">
      <Label htmlFor={key}>{label}</Label>
      <Input name={key} id={key} type={secret ? "password" : "text"} autoComplete="new-password" maxLength={8192}
        placeholder={status[key] === "ausente" ? "Ainda não configurado" : `Configurado via ${status[key]} — deixe vazio para manter`} />
    </div>)}
    {state.error && <p role="alert" className="text-destructive">{state.error}</p>}
    {state.message && <p role="status">{state.message}</p>}
    <Button disabled={pending} type="submit">{pending ? "Salvando…" : "Salvar WhatsApp via QR"}</Button>
  </form>;
}
