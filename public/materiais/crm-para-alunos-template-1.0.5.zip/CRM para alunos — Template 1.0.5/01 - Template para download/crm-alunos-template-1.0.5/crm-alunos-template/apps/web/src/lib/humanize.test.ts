import { describe, expect, it } from "vitest";
import { DEFAULT_HUMANIZE, humanizeDirective, normalizeHumanize, splitReply, typingDelayMs } from "./humanize";

describe("normalizeHumanize", () => {
  it("agente antigo ({}) ganha o padrão: 8 s, digitando e balões", () => {
    expect(normalizeHumanize({})).toEqual({ waitSeconds: 8, typing: true, splitMessages: true });
    expect(normalizeHumanize(null)).toEqual(DEFAULT_HUMANIZE);
  });

  it("respeita o que foi salvo e limita a espera entre 2 e 30 s", () => {
    expect(normalizeHumanize({ waitSeconds: 15, typing: false, splitMessages: false })).toEqual({
      waitSeconds: 15,
      typing: false,
      splitMessages: false,
    });
    expect(normalizeHumanize({ waitSeconds: 0 }).waitSeconds).toBe(2);
    expect(normalizeHumanize({ waitSeconds: 999 }).waitSeconds).toBe(30);
    expect(normalizeHumanize({ waitSeconds: "abc" }).waitSeconds).toBe(8);
  });
});

describe("splitReply", () => {
  it("um parágrafo continua uma mensagem", () => {
    expect(splitReply("Olá! Tudo bem?")).toEqual(["Olá! Tudo bem?"]);
  });

  it("quebra por linha em branco", () => {
    expect(splitReply("Prontinho, consulta marcada!\n\nChegue 15 min antes.")).toEqual([
      "Prontinho, consulta marcada!",
      "Chegue 15 min antes.",
    ]);
  });

  it("não quebra em quebra de linha simples (listas continuam juntas)", () => {
    expect(splitReply("Horários:\n- 08:00\n- 08:30")).toEqual(["Horários:\n- 08:00\n- 08:30"]);
  });

  it("no máximo 3 balões — o excedente vai junto no último", () => {
    expect(splitReply("a\n\nb\n\nc\n\nd")).toEqual(["a", "b", "c\n\nd"]);
  });
});

describe("typingDelayMs", () => {
  it("proporcional ao texto, entre 1,2 s e 6 s", () => {
    expect(typingDelayMs("oi")).toBe(1_200);
    expect(typingDelayMs("x".repeat(100))).toBe(3_500);
    expect(typingDelayMs("x".repeat(1_000))).toBe(6_000);
  });
});

describe("humanizeDirective", () => {
  it("só instrui o modelo quando a quebra em balões está ligada", () => {
    expect(humanizeDirective({ ...DEFAULT_HUMANIZE, splitMessages: false })).toBeNull();
    expect(humanizeDirective(DEFAULT_HUMANIZE)).toMatch(/linha em branco/);
  });
});
