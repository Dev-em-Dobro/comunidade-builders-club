/**
 * Handoff automático entre agentes (SDR → closer) quando o lead é promovido
 * a "qualified". Espelha o padrão da Parte 8 (handoff humano):
 *  - funções puras (`shouldHandoff`, `resolveTargetSession`) testadas isoladamente
 *  - orquestrador (`runAgentHandoff`) — wires tudo junto
 */

import { prisma } from "@/lib/db";
import { generateReplyWithKey } from "@/lib/llm/reply";
import { loadMemory } from "@/lib/memory";
import { buildLeadContextBlock } from "@/lib/llm/context-blocks";
import { sendOutboundMessage } from "@/lib/outbound";
import type { ChannelId } from "@/lib/channels/types";

export interface HandoffContext {
  conv: { id: string; aiEnabled: boolean; agentSessionId: string | null };
  lead: { id: string; stage: string } | null;
  targetSessionId: string | null;
}

/**
 * Predicado de idempotência. Retorna true só quando vale a pena trocar a session.
 * O gate de `stage === "qualified"` só se aplica ao handoff de CLOSER (disparado por
 * qualificação). O handoff de SUPPORT é disparado por `audience` (student/support/
 * refund), então não gateia stage.
 */
export function shouldHandoff(
  ctx: HandoffContext,
  toRole: "closer" | "support" = "closer",
): boolean {
  if (!ctx.lead) return false;
  if (toRole === "closer" && ctx.lead.stage !== "qualified") return false;
  if (!ctx.conv.aiEnabled) return false;
  if (!ctx.targetSessionId) return false;
  if (ctx.conv.agentSessionId === ctx.targetSessionId) return false;
  return true;
}

interface SessionRow {
  id: string;
  role: string | null;
  createdAt: Date;
}

/**
 * Escolhe a primeira session com o `role` pedido (createdAt asc — determinístico).
 * Retorna null se nenhuma session bater.
 */
export function resolveTargetSession<T extends SessionRow>(
  sessions: T[],
  role: "closer" | "support",
): T | null {
  const matches = sessions.filter((s) => s.role === role);
  if (matches.length === 0) return null;
  matches.sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  return matches[0];
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}

// Directive injetado como ÚLTIMA mensagem user (não no system prompt).
// Motivo: ao rodar o orquestrador, a última msg do histórico é assistant
// (resposta normal do SDR ao último inbound). Se passarmos messages
// terminando em assistant pra Anthropic, a API trata como "prefill" e o
// modelo frequentemente retorna texto vazio (já encerrou aquela fala).
// Apêndice como user-turn force a API a gerar um novo turno assistant.
const HANDOFF_USER_PROMPT = (closerName: string) =>
  `[Instrução interna do sistema — esta mensagem não veio do lead]

O lead acabou de completar a qualificação. Sua tarefa AGORA: despeça-se com 1-2 frases curtas e calorosas, dizendo que ${closerName} vai continuar o atendimento daqui pra frente pra fechar a matrícula.

Regras rígidas (não negocia):
- Apenas texto natural — proibido markdown, código, backticks
- Proibido mencionar tools/funções (ex: get_checkout_link)
- Proibido oferecer link, preço, condição de pagamento — trabalho do ${closerName}
- Proibido fazer perguntas
- Não chame nenhuma tool (sua resposta não terá tools disponíveis)

Exemplo do tom: "Foi ótimo conversar com você! Vou te passar agora pro ${closerName}, que continua te ajudando daqui pra frente."`;

// Diretiva de transição SDR → suporte ao aluno. Mesmo mecanismo do
// HANDOFF_USER_PROMPT (injetada como última msg user pra forçar novo turno
// assistant), mas o texto avisa que quem assume é o suporte, não o closer.
const SUPPORT_HANDOFF_USER_PROMPT = (supportName: string) =>
  `[Instrução interna do sistema — esta mensagem não veio do lead]

Este contato é um aluno / pedido de suporte. Sua tarefa AGORA: em 1-2 frases curtas e calorosas, diga que vai passar o atendimento pro ${supportName}, do suporte ao aluno, que cuida disso daqui pra frente.

Regras rígidas (não negocia):
- Apenas texto natural — proibido markdown, código, backticks
- Proibido mencionar tools/funções
- Proibido fazer perguntas
- Não chame nenhuma tool (sua resposta não terá tools disponíveis)

Exemplo do tom: "Ah, entendi! Então já te passo pro ${supportName}, do nosso suporte, que te ajuda com isso daqui pra frente."`;

/**
 * Orquestrador da passagem SDR → closer.
 *  1. Carrega conv + lead + sessions
 *  2. Resolve closer; se null, exit
 *  3. shouldHandoff valida; se false, exit
 *  4. Gera despedida via LLM (system prompt do SDR + diretivo)
 *  5. Envia + persiste via sendOutboundMessage
 *  6. Em transação: flipa agentSessionId + cria PipelineEvent("agent_handoff")
 *
 * Idempotente — re-execução sobre estado já trocado é no-op.
 */
export async function runAgentHandoff(
  conversationId: string,
  toRole: "closer" | "support" = "closer",
): Promise<void> {
  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: {
      id: true,
      channel: true,
      aiEnabled: true,
      agentSessionId: true,
      contactId: true,
      leadId: true,
      lead: { select: { id: true, stage: true } },
    },
  });
  if (!conv) {
    log("agent_handoff.skipped", { conversationId, reason: "no_conversation" });
    return;
  }
  if (!conv.lead) {
    log("agent_handoff.skipped", { conversationId, reason: "no_lead" });
    return;
  }

  const sessions = await prisma.agentSession.findMany({
    where: { role: { in: ["sdr", "closer", "support"] } },
    select: {
      id: true,
      name: true,
      persona: true,
      role: true,
      systemPrompt: true,
      memoryMode: true,
      provider: true,
      model: true,
      temperature: true,
      createdAt: true,
    },
  });

  const target = resolveTargetSession(sessions, toRole);
  if (!target) {
    log("agent_handoff.skipped", {
      conversationId,
      leadId: conv.lead.id,
      reason: "no_target",
      toRole,
    });
    return;
  }

  const ok = shouldHandoff(
    {
      conv: {
        id: conv.id,
        aiEnabled: conv.aiEnabled,
        agentSessionId: conv.agentSessionId,
      },
      lead: conv.lead,
      targetSessionId: target.id,
    },
    toRole,
  );
  if (!ok) {
    log("agent_handoff.skipped", {
      conversationId,
      leadId: conv.lead.id,
      toRole,
      reason:
        target.id === conv.agentSessionId
          ? "already_done"
          : !conv.aiEnabled
            ? "ai_disabled"
            : "wrong_stage",
    });
    return;
  }

  // `current` = session ATUAL da conversa (tipicamente a SDR). Usamos o systemPrompt
  // dela pra gerar a despedida no tom certo, seja o handoff pro closer ou pro suporte.
  const current = sessions.find((s) => s.id === conv.agentSessionId);
  if (!current) {
    // Caso defensivo — agente atual deveria existir. Aborta sem flipar.
    log("agent_handoff.skipped", {
      conversationId,
      leadId: conv.lead.id,
      reason: "current_session_missing",
    });
    return;
  }

  // Geração da despedida usando o system prompt da session atual + diretivo como
  // user-turn. A diretiva muda conforme o destino (closer vs suporte).
  const memory = await loadMemory(conv.id, current.memoryMode);
  const leadContext = await buildLeadContextBlock(conv.lead.id, conv.contactId);
  const targetDisplayName = target.persona ?? target.name;
  const directive =
    toRole === "support"
      ? SUPPORT_HANDOFF_USER_PROMPT(targetDisplayName)
      : HANDOFF_USER_PROMPT(targetDisplayName);
  const messagesForLLM = [
    ...memory,
    { role: "user" as const, content: directive },
  ];

  const reply = await generateReplyWithKey(current.provider, {
    model: current.model,
    temperature: current.temperature,
    maxTokens: 150,
    systemStatic: current.systemPrompt,
    systemDynamic: leadContext ?? undefined,
    messages: messagesForLLM,
    tools: [],
  });

  log("agent_handoff.message_generated", {
    conversationId,
    tokensIn: reply.tokensIn,
    tokensOut: reply.tokensOut,
    costUsd: reply.costUsd,
  });

  // externalId vem da ContactIdentity matching channel+contactId — gotcha 0.9.27:
  // NUNCA usar Contact.id como destino do sendText.
  const ident = await prisma.contactIdentity.findFirst({
    where: { contactId: conv.contactId, channel: conv.channel },
    select: { externalId: true },
  });
  if (!ident) {
    log("agent_handoff.skipped", {
      conversationId,
      leadId: conv.lead.id,
      reason: "no_contact_identity",
    });
    return;
  }

  // Send ANTES da transação — se send falhar, nada muda no DB.
  const sent = await sendOutboundMessage({
    conversationId: conv.id,
    channel: conv.channel as ChannelId,
    externalId: ident.externalId,
    text: reply.text,
    usage: {
      tokensIn: reply.tokensIn,
      tokensOut: reply.tokensOut,
      costUsd: reply.costUsd,
      modelUsed: reply.modelUsed,
    },
  });
  if (!sent.ok) {
    log("agent_handoff.error", {
      conversationId,
      reason: sent.reason,
      error: sent.error,
    });
    if (sent.reason === "window_expired") {
      // Throw so BullMQ marca job como failed (visível no dashboard).
      // Janela 24h não auto-recupera — operador precisa reabrir conversa
      // ou re-enfileirar manualmente. Ver DEPLOY_RAILWAY.md.
      throw new Error(
        `agent_handoff window_expired for conversation ${conversationId}`,
      );
    }
    // Outros motivos (empty_text, send_failed) — não joga; shouldHandoff
    // garante idempotência se for re-tentado.
    return;
  }

  await prisma.$transaction([
    prisma.conversation.update({
      where: { id: conv.id },
      data: {
        agentSessionId: target.id,
        lastOutboundAt: new Date(),
      },
    }),
    prisma.pipelineEvent.create({
      data: {
        leadId: conv.lead.id,
        type: "agent_handoff",
        payload: {
          from: current.id,
          to: target.id,
          fromName: current.name,
          toName: target.name,
          fromPersona: current.persona ?? null,
          toPersona: target.persona ?? null,
          leadId: conv.lead.id,
          via: toRole === "support" ? "student_triage" : "auto_qualified",
        },
      },
    }),
  ]);

  log("agent_handoff.done", {
    conversationId,
    leadId: conv.lead.id,
    toRole,
    from: current.id,
    to: target.id,
  });
}
