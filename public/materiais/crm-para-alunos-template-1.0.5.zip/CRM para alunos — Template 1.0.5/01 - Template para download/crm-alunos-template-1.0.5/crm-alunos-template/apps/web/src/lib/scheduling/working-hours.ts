/**
 * Horário de atendimento de um profissional.
 *
 * Formato no banco (Professional.workingHours):
 *   { "1": [{ "start": "08:00", "end": "12:00" }, { "start": "14:00", "end": "18:00" }], ... }
 * Chave = dia da semana (0 = domingo). Dia ausente ou vazio = não atende.
 *
 * Na tela, cada dia é um texto livre "08:00-12:00, 14:00-18:00".
 */
import { TIME_RE, minutesOf } from "./time";

export interface TimeInterval {
  start: string;
  end: string;
}

export type WorkingHours = Partial<Record<string, TimeInterval[]>>;

export const WEEKDAYS: { day: number; label: string }[] = [
  { day: 1, label: "Segunda" },
  { day: 2, label: "Terça" },
  { day: 3, label: "Quarta" },
  { day: 4, label: "Quinta" },
  { day: 5, label: "Sexta" },
  { day: 6, label: "Sábado" },
  { day: 0, label: "Domingo" },
];

/** Horário sugerido pra um profissional novo: seg–sex, 08–12 e 14–18. */
export const DEFAULT_WORKING_HOURS: WorkingHours = Object.fromEntries(
  [1, 2, 3, 4, 5].map((d) => [
    String(d),
    [
      { start: "08:00", end: "12:00" },
      { start: "14:00", end: "18:00" },
    ],
  ]),
);

/**
 * "08:00-12:00, 14:00-18:00" → intervalos ordenados. Vazio → [].
 * Lança Error com mensagem amigável quando o texto é inválido.
 */
export function parseDayIntervals(text: string): TimeInterval[] {
  const trimmed = text.trim();
  if (!trimmed) return [];
  const intervals = trimmed.split(/[,;]+/).map((chunk) => {
    const m = /^\s*(\d{1,2}:\d{2})\s*(?:-|–|às|a|ate|até)\s*(\d{1,2}:\d{2})\s*$/i.exec(chunk);
    if (!m) throw new Error(`Intervalo inválido: "${chunk.trim()}". Use o formato 08:00-12:00.`);
    const start = m[1]!.padStart(5, "0");
    const end = m[2]!.padStart(5, "0");
    if (!TIME_RE.test(start) || !TIME_RE.test(end)) {
      throw new Error(`Horário inválido em "${chunk.trim()}".`);
    }
    if (minutesOf(end) <= minutesOf(start)) {
      throw new Error(`O fim precisa ser depois do início em "${chunk.trim()}".`);
    }
    return { start, end };
  });
  intervals.sort((a, b) => minutesOf(a.start) - minutesOf(b.start));
  for (let i = 1; i < intervals.length; i++) {
    if (minutesOf(intervals[i]!.start) < minutesOf(intervals[i - 1]!.end)) {
      throw new Error("Os intervalos de um mesmo dia não podem se sobrepor.");
    }
  }
  return intervals;
}

export function formatDayIntervals(intervals: TimeInterval[] | undefined): string {
  return (intervals ?? []).map((i) => `${i.start}-${i.end}`).join(", ");
}

/** Lista de intervalos vinda do banco — itens inválidos são descartados. */
export function normalizeIntervals(raw: unknown): TimeInterval[] {
  if (!Array.isArray(raw)) return [];
  return raw.filter(
    (i): i is TimeInterval =>
      Boolean(i) &&
      typeof (i as TimeInterval).start === "string" &&
      typeof (i as TimeInterval).end === "string" &&
      TIME_RE.test((i as TimeInterval).start) &&
      TIME_RE.test((i as TimeInterval).end) &&
      minutesOf((i as TimeInterval).end) > minutesOf((i as TimeInterval).start),
  );
}

/** Lê o JSON do banco de forma defensiva — entradas inválidas são ignoradas. */
export function normalizeWorkingHours(raw: unknown): WorkingHours {
  const out: WorkingHours = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [day, list] of Object.entries(raw as Record<string, unknown>)) {
    if (!/^[0-6]$/.test(day)) continue;
    const intervals = normalizeIntervals(list);
    if (intervals.length) out[day] = intervals;
  }
  return out;
}

/**
 * Exceções por data (YYYY-MM-DD → intervalos daquele dia, substituindo a semana
 * padrão). Lista vazia = não atende nesse dia.
 */
export type DayOverrides = Record<string, TimeInterval[]>;

/** Resumo curto pra listagens e pro contexto do agente: "seg 08:00-12:00, 14:00-18:00; ter …". */
export function summarizeWorkingHours(wh: WorkingHours): string {
  const short = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
  const parts = WEEKDAYS.filter(({ day }) => wh[String(day)]?.length).map(
    ({ day }) => `${short[day]} ${formatDayIntervals(wh[String(day)])}`,
  );
  return parts.length ? parts.join("; ") : "sem horário cadastrado";
}
