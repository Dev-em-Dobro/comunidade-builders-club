import { resolveMetaSettings } from "@/lib/settings/meta";
import { ChannelSendError, describeMetaError } from "./meta-graph";
import type { OutgoingMediaInfo } from "./outgoing-media";

import { META_GRAPH_BASE as META_MEDIA_GRAPH_BASE } from "./meta-graph";

export async function sendWhatsAppMedia(
  externalId: string,
  file: File,
  info: OutgoingMediaInfo,
  caption?: string,
): Promise<{ mediaId: string; providerMsgId: string }> {
  const meta = await resolveMetaSettings();
  const token = meta.META_SYSTEM_USER_TOKEN;
  const phoneNumberId = meta.META_PHONE_NUMBER_ID;
  if (!token || !phoneNumberId) throw new Error("Credenciais WhatsApp ausentes.");
  if (!/^\d{6,15}$/.test(externalId)) throw new Error("Número de destino inválido.");

  const uploadForm = new FormData();
  uploadForm.set("messaging_product", "whatsapp");
  uploadForm.set("type", info.mimeType);
  uploadForm.set("file", new Blob([await file.arrayBuffer()], { type: info.mimeType }), file.name);
  const uploadResponse = await fetch(`${META_MEDIA_GRAPH_BASE}/${phoneNumberId}/media`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: uploadForm,
    cache: "no-store",
  });
  if (!uploadResponse.ok) {
    const body = await uploadResponse.text();
    const info = describeMetaError(uploadResponse.status, body);
    throw new ChannelSendError(info, uploadResponse.status);
  }
  const upload = (await uploadResponse.json()) as { id?: string };
  if (!upload.id) throw new Error("Meta não confirmou o upload da mídia.");

  const mediaObject = info.kind === "image" && caption
    ? { id: upload.id, caption }
    : { id: upload.id };
  const sendResponse = await fetch(`${META_MEDIA_GRAPH_BASE}/${phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: externalId,
      type: info.kind,
      [info.kind]: mediaObject,
    }),
    cache: "no-store",
  });
  if (!sendResponse.ok) {
    const body = await sendResponse.text();
    const info = describeMetaError(sendResponse.status, body);
    throw new ChannelSendError(info, sendResponse.status);
  }
  const sent = (await sendResponse.json()) as { messages?: Array<{ id?: string }> };
  const providerMsgId = sent.messages?.[0]?.id;
  if (!providerMsgId) throw new Error("Meta não confirmou o envio da mídia.");
  return { mediaId: upload.id, providerMsgId };
}
