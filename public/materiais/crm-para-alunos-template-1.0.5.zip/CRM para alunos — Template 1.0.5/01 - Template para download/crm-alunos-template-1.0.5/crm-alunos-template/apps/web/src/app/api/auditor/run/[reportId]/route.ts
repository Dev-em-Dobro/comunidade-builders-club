import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

interface Body {
  status?: "error";
  errorMessage?: string;
}

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ reportId: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { reportId } = await params;
  const body = (await req.json().catch(() => ({}))) as Body;

  if (body.status !== "error") {
    return NextResponse.json(
      { error: "invalid_status", allowed: ["error"] },
      { status: 400 },
    );
  }

  const report = await prisma.auditReport.findUnique({
    where: { id: reportId },
    select: { id: true, status: true },
  });
  if (!report) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }
  if (report.status === "done" || report.status === "error") {
    return NextResponse.json(
      { error: "already_finished", currentStatus: report.status },
      { status: 409 },
    );
  }

  await prisma.auditReport.update({
    where: { id: reportId },
    data: {
      status: "error",
      errorMessage: body.errorMessage ?? "marked as stuck by user",
      finishedAt: new Date(),
    },
  });

  return NextResponse.json({ ok: true });
}
