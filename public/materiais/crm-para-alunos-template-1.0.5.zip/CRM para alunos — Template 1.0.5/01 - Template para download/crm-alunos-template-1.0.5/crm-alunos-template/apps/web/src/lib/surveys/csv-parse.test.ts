import { describe, it, expect } from "vitest";
import { parseSurveyCsv } from "./csv-parse";

describe("parseSurveyCsv", () => {
  it("extrai colunas reservadas (case-insensitive) e o resto vira answers", () => {
    const csv = `Phone,EMAIL,submitted_at,Objetivo,Renda
+5511987654321,joao@x.com,2026-05-01,dobrar a renda,5-10k
`;
    const r = parseSurveyCsv(csv);
    expect(r.errors).toHaveLength(0);
    expect(r.rows).toHaveLength(1);
    const row = r.rows[0]!;
    expect(row.phoneRaw).toBe("+5511987654321");
    expect(row.emailRaw).toBe("joao@x.com");
    expect(row.submittedAt?.toISOString().slice(0, 10)).toBe("2026-05-01");
    expect(row.answers).toEqual({
      Objetivo: "dobrar a renda",
      Renda: "5-10k",
    });
  });

  it("rejeita row sem phone nem email", () => {
    const csv = `phone,email,Objetivo
,,dobrar
+5511987654321,,dobrar
`;
    const r = parseSurveyCsv(csv);
    expect(r.errors).toHaveLength(1);
    expect(r.errors[0]).toEqual({
      rowNumber: 1,
      reason: "row sem phone nem email",
    });
    expect(r.rows).toHaveLength(1);
    expect(r.rows[0]!.rowNumber).toBe(2);
  });

  it("header com espaços é trimado", () => {
    const csv = `  Phone  , email , Objetivo
+5511987654321,joao@x.com,xyz
`;
    const r = parseSurveyCsv(csv);
    expect(r.rows[0]!.phoneRaw).toBe("+5511987654321");
    expect(r.rows[0]!.emailRaw).toBe("joao@x.com");
    expect(r.rows[0]!.answers).toEqual({ Objetivo: "xyz" });
  });

  it("células vazias são removidas de answers", () => {
    const csv = `phone,Objetivo,Renda
+5511987654321,dobrar,
`;
    const r = parseSurveyCsv(csv);
    expect(r.rows[0]!.answers).toEqual({ Objetivo: "dobrar" });
  });

  it("aceita aliases PT-BR (Telefone, E-mail, Data de Envio) + delimitador ';'", () => {
    const csv = `Telefone;Confirme seu e-mail;Data de Envio;Objetivo principal
+5511987654321;joao@x.com;23/05/2026 21:57 PM;dobrar a renda
`;
    const r = parseSurveyCsv(csv);
    expect(r.errors).toHaveLength(0);
    expect(r.rows).toHaveLength(1);
    const row = r.rows[0]!;
    expect(row.phoneRaw).toBe("+5511987654321");
    expect(row.emailRaw).toBe("joao@x.com");
    expect(row.submittedAt?.getFullYear()).toBe(2026);
    expect(row.submittedAt?.getMonth()).toBe(4); // maio = 4 (0-indexed)
    expect(row.submittedAt?.getDate()).toBe(23);
    expect(row.submittedAt?.getHours()).toBe(21);
    expect(row.answers).toEqual({ "Objetivo principal": "dobrar a renda" });
  });

  it("BOM UTF-8 não quebra o parse", () => {
    const csv = "﻿phone,Objetivo\n+5511987654321,xyz\n";
    const r = parseSurveyCsv(csv);
    expect(r.errors).toHaveLength(0);
    expect(r.rows[0]!.phoneRaw).toBe("+5511987654321");
    expect(r.rows[0]!.answers).toEqual({ Objetivo: "xyz" });
  });
});
