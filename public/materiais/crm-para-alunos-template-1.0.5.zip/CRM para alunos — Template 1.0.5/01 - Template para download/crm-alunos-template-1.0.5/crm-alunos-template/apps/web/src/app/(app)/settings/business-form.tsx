"use client";
import { useActionState, useState } from "react";
import { saveBusiness } from "./actions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
type Initial = { brandName: string; legalName: string; supportEmail: string; contactEmail: string; accessUrl: string; handoffNotice: string; timezone: string; windowMs: number; whatsapp: boolean; instagram: boolean; whatsappQr: boolean };
export function BusinessForm({ initial }: { initial: Initial }) {
  const [state, action, pending] = useActionState(saveBusiness, {});
  const [values, setValues] = useState(() => ({ ...initial, windowMs: String(initial.windowMs) }));
  const fields = [
    ["brandName", "Nome da marca", "text"], ["legalName", "Razão social para as páginas públicas", "text"],
    ["supportEmail", "E-mail de suporte", "email"], ["contactEmail", "E-mail de privacidade e contato", "email"],
    ["accessUrl", "URL de acesso do seu produto (opcional)", "url"], ["handoffNotice", "Mensagem ao transferir para uma pessoa", "text"],
    ["timezone", "Fuso horário (ex.: America/Sao_Paulo)", "text"], ["windowMs", "Agrupar mensagens por até (milissegundos)", "number"],
  ] as const;
  return <form action={action} className="space-y-5">
    {fields.map(([key, label, type]) => <div className="space-y-2" key={key}>
      <Label htmlFor={key}>{label}</Label><Input id={key} name={key} type={type} value={values[key]} onChange={(event) => setValues((current) => ({ ...current, [key]: event.target.value }))} required={["brandName", "handoffNotice", "timezone", "windowMs"].includes(key)} min={type === "number" ? 1000 : undefined} max={type === "number" ? 30000 : undefined} />
    </div>)}
    <fieldset className="space-y-3 border rounded-md p-4"><legend className="px-2">Canais ativos</legend>
      <p className="text-sm text-muted-foreground">Cadastre suas credenciais (Meta ou WhatsApp via QR) e teste a conexão antes de ativar.</p>
      <label className="flex items-center gap-2"><input name="whatsapp" type="checkbox" checked={values.whatsapp} onChange={(event) => setValues((current) => ({ ...current, whatsapp: event.target.checked }))} /> WhatsApp Cloud API</label>
      <label className="flex items-center gap-2"><input name="instagram" type="checkbox" checked={values.instagram} onChange={(event) => setValues((current) => ({ ...current, instagram: event.target.checked }))} /> Instagram Direct</label>
      <label className="flex items-center gap-2"><input name="whatsappQr" type="checkbox" checked={values.whatsappQr} onChange={(event) => setValues((current) => ({ ...current, whatsappQr: event.target.checked }))} /> WhatsApp via QR (não oficial)</label>
    </fieldset>
    {state.error && <p role="alert" className="text-destructive text-sm">{state.error}</p>}
    {state.message && <p role="status" className="text-sm">{state.message}</p>}
    <Button type="submit" disabled={pending}>{pending ? "Salvando…" : "Salvar configurações"}</Button>
  </form>;
}
