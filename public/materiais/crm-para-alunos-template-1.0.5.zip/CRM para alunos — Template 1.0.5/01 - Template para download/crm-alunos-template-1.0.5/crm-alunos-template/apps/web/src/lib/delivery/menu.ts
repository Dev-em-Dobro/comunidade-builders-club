/**
 * Núcleo do delivery — funções puras (sem banco, sem canal, sem LLM).
 *
 * Regra de ouro: o PREÇO de tudo sai do cardápio guardado (itens que a IA leu
 * no upload). O modelo só informa nomes e quantidades; quem calcula itens,
 * taxa e total é o sistema — o agente nunca inventa preço.
 */

export interface MenuItem {
  category?: string;
  name: string;
  description?: string;
  priceCents: number;
}

export interface DeliveryArea {
  name: string;
  feeCents: number;
}

export type Fulfillment = "delivery" | "pickup";
export type PaymentMethod = "pix" | "card" | "cash";

export const PAYMENT_LABEL: Record<PaymentMethod, string> = { pix: "Pix", card: "Cartão", cash: "Dinheiro" };

export const ORDER_STATUSES = ["new", "preparing", "out_for_delivery", "delivered", "cancelled"] as const;
export type OrderStatus = (typeof ORDER_STATUSES)[number];
export const ORDER_STATUS_LABEL: Record<OrderStatus, string> = {
  new: "Novo",
  preparing: "Em preparo",
  out_for_delivery: "Saiu pra entrega",
  delivered: "Entregue",
  cancelled: "Cancelado",
};

/** "R$ 1.234,50" */
export function formatBRL(cents: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
}

/** "5,50" | "5.50" | "R$ 5" | 5.5 → 550. Inválido → null. */
export function parseMoneyToCents(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) && value >= 0 ? Math.round(value * 100) : null;
  if (typeof value !== "string") return null;
  const cleaned = value.replace(/R\$\s*/i, "").trim();
  if (!/^\d{1,6}([.,]\d{1,2})?$/.test(cleaned)) return null;
  return Math.round(Number(cleaned.replace(",", ".")) * 100);
}

/** Minúsculas, sem acento e com espaços simples — pra comparar nomes. */
export function normalizeText(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

/** JSON do banco → itens válidos (nome e preço obrigatórios). */
export function normalizeMenuItems(raw: unknown): MenuItem[] {
  if (!Array.isArray(raw)) return [];
  const out: MenuItem[] = [];
  for (const r of raw) {
    if (!r || typeof r !== "object") continue;
    const o = r as Record<string, unknown>;
    const name = typeof o.name === "string" ? o.name.trim() : "";
    const priceCents = typeof o.priceCents === "number" ? Math.round(o.priceCents) : parseMoneyToCents(o.price);
    if (!name || priceCents === null || priceCents < 0) continue;
    out.push({
      name: name.slice(0, 120),
      priceCents,
      ...(typeof o.category === "string" && o.category.trim() ? { category: o.category.trim().slice(0, 60) } : {}),
      ...(typeof o.description === "string" && o.description.trim()
        ? { description: o.description.trim().slice(0, 300) }
        : {}),
    });
  }
  return out.slice(0, 500);
}

export function normalizeAreas(raw: unknown): DeliveryArea[] {
  if (!Array.isArray(raw)) return [];
  return raw
    .filter((a): a is { name: string; feeCents: number } =>
      Boolean(a) && typeof (a as DeliveryArea).name === "string" && typeof (a as DeliveryArea).feeCents === "number",
    )
    .map((a) => ({ name: a.name.trim(), feeCents: Math.max(0, Math.round(a.feeCents)) }))
    .filter((a) => a.name);
}

/**
 * Texto da tela → bairros. Uma linha por bairro: "Centro: 5,00", "Centro - 5",
 * "Jardim América | R$ 7,50". Lança Error com a linha problemática.
 */
export function parseAreasText(text: string): DeliveryArea[] {
  const areas: DeliveryArea[] = [];
  const seen = new Set<string>();
  for (const [i, rawLine] of text.split(/\r?\n/).entries()) {
    const line = rawLine.trim();
    if (!line) continue;
    const m = /^(.+?)\s*[:\-–|=]?\s*(?:R\$\s*)?(\d{1,6}(?:[.,]\d{1,2})?)\s*$/i.exec(line);
    const feeCents = m ? parseMoneyToCents(m[2]!) : null;
    const name = m?.[1]?.replace(/[:\-–|=]\s*$/, "").trim();
    if (!m || feeCents === null || !name) {
      throw new Error(`Linha ${i + 1} ("${line}"): use o formato Bairro: 5,00`);
    }
    const key = normalizeText(name);
    if (seen.has(key)) throw new Error(`Bairro repetido: ${name}`);
    seen.add(key);
    areas.push({ name, feeCents });
  }
  return areas;
}

export function formatAreasText(areas: DeliveryArea[]): string {
  return areas.map((a) => `${a.name}: ${(a.feeCents / 100).toFixed(2).replace(".", ",")}`).join("\n");
}

export type MenuMatch = { item: MenuItem } | { ambiguous: string[] } | null;

/** Acha o item do cardápio por nome: exato (sem acento/caixa) ou trecho único. */
export function findMenuItem(menu: MenuItem[], name: string): MenuMatch {
  const q = normalizeText(name);
  if (!q) return null;
  const exact = menu.find((m) => normalizeText(m.name) === q);
  if (exact) return { item: exact };
  const partial = menu.filter((m) => {
    const n = normalizeText(m.name);
    return n.includes(q) || q.includes(n);
  });
  if (partial.length === 1) return { item: partial[0]! };
  if (partial.length > 1) return { ambiguous: partial.slice(0, 6).map((m) => m.name) };
  return null;
}

export function findArea(areas: DeliveryArea[], neighborhood: string): DeliveryArea | null {
  const q = normalizeText(neighborhood);
  if (!q) return null;
  return areas.find((a) => normalizeText(a.name) === q) ?? null;
}

export interface OrderInputItem {
  name: string;
  quantity: number;
  notes?: string;
}

export interface OrderLine {
  name: string;
  quantity: number;
  unitPriceCents: number;
  notes?: string;
}

export type PriceResult =
  | {
      ok: true;
      lines: OrderLine[];
      subtotalCents: number;
      deliveryFeeCents: number;
      totalCents: number;
      neighborhood: string | null;
    }
  | {
      ok: false;
      error: string;
      message: string;
      unknownItems?: string[];
      ambiguous?: Record<string, string[]>;
      servedNeighborhoods?: string[];
    };

/** Calcula o pedido com os preços do cardápio e a taxa do bairro. */
export function priceOrder(
  input: { items: unknown; fulfillment: unknown; neighborhood?: unknown },
  store: { menu: MenuItem[]; areas: DeliveryArea[]; pickupEnabled: boolean },
): PriceResult {
  const rawItems = Array.isArray(input.items) ? input.items : [];
  if (!rawItems.length) {
    return { ok: false, error: "empty_order", message: "O pedido está vazio. Pergunte o que o cliente quer." };
  }
  if (!store.menu.length) {
    return {
      ok: false,
      error: "no_menu",
      message: "Não há cardápio cadastrado. Peça desculpas e use request_handoff para a equipe atender.",
    };
  }

  const lines: OrderLine[] = [];
  const unknownItems: string[] = [];
  const ambiguous: Record<string, string[]> = {};
  for (const raw of rawItems) {
    const o = (raw ?? {}) as Record<string, unknown>;
    const name = typeof o.name === "string" ? o.name : "";
    const quantity = Math.floor(Number(o.quantity ?? 1));
    if (!Number.isFinite(quantity) || quantity < 1 || quantity > 50) {
      return { ok: false, error: "invalid_quantity", message: `Quantidade inválida para "${name}" (use de 1 a 50).` };
    }
    const match = findMenuItem(store.menu, name);
    if (!match) {
      unknownItems.push(name);
      continue;
    }
    if ("ambiguous" in match) {
      ambiguous[name] = match.ambiguous;
      continue;
    }
    const notes = typeof o.notes === "string" && o.notes.trim() ? o.notes.trim().slice(0, 200) : undefined;
    lines.push({ name: match.item.name, quantity, unitPriceCents: match.item.priceCents, ...(notes ? { notes } : {}) });
  }
  if (unknownItems.length || Object.keys(ambiguous).length) {
    return {
      ok: false,
      error: unknownItems.length ? "unknown_items" : "ambiguous_items",
      message:
        "Alguns itens não batem com o cardápio. Use exatamente os nomes do cardápio — pergunte ao cliente qual opção ele quer, sem inventar itens.",
      ...(unknownItems.length ? { unknownItems } : {}),
      ...(Object.keys(ambiguous).length ? { ambiguous } : {}),
    };
  }

  const fulfillment = input.fulfillment === "pickup" ? "pickup" : input.fulfillment === "delivery" ? "delivery" : null;
  if (!fulfillment) {
    return { ok: false, error: "missing_fulfillment", message: "Pergunte se é entrega ou retirada no local." };
  }
  let deliveryFeeCents = 0;
  let neighborhood: string | null = null;
  if (fulfillment === "pickup") {
    if (!store.pickupEnabled) {
      return { ok: false, error: "pickup_unavailable", message: "Não fazemos retirada no local — só entrega." };
    }
  } else {
    const area = findArea(store.areas, typeof input.neighborhood === "string" ? input.neighborhood : "");
    if (!area) {
      return {
        ok: false,
        error: "area_not_served",
        message: "Bairro fora da área de entrega (ou não informado). Confira o bairro com o cliente.",
        servedNeighborhoods: store.areas.map((a) => a.name),
      };
    }
    deliveryFeeCents = area.feeCents;
    neighborhood = area.name;
  }

  const subtotalCents = lines.reduce((sum, l) => sum + l.unitPriceCents * l.quantity, 0);
  return { ok: true, lines, subtotalCents, deliveryFeeCents, totalCents: subtotalCents + deliveryFeeCents, neighborhood };
}

/** Itens → texto editável: "Categoria | Nome | 25,90 | descrição". */
export function formatMenuLines(menu: MenuItem[]): string {
  return menu
    .map((i) =>
      [i.category ?? "", i.name, (i.priceCents / 100).toFixed(2).replace(".", ","), i.description ?? ""]
        .join(" | ")
        .replace(/ \| $/, ""),
    )
    .join("\n");
}

/**
 * Texto editável → itens. Por linha: "Categoria | Nome | Preço | descrição"
 * (descrição opcional) ou só "Nome | Preço". Lança Error com a linha ruim.
 */
export function parseMenuLines(text: string): MenuItem[] {
  const items: MenuItem[] = [];
  for (const [i, rawLine] of text.split(/\r?\n/).entries()) {
    const line = rawLine.trim();
    if (!line) continue;
    const parts = line.split("|").map((p) => p.trim());
    const [category, name, price, description] =
      parts.length === 2 ? ["", parts[0]!, parts[1]!, ""] : [parts[0]!, parts[1] ?? "", parts[2] ?? "", parts[3] ?? ""];
    const priceCents = parseMoneyToCents(price);
    if (!name || priceCents === null) {
      throw new Error(`Linha ${i + 1} ("${line}"): use Categoria | Nome | 25,90`);
    }
    items.push({
      name,
      priceCents,
      ...(category ? { category } : {}),
      ...(description ? { description } : {}),
    });
  }
  return items;
}

/** Cardápio em texto (pro contexto do agente e plano B sem arquivo). */
export function menuAsText(menu: MenuItem[]): string {
  const groups = new Map<string, MenuItem[]>();
  for (const item of menu) {
    const key = item.category ?? "Itens";
    groups.set(key, [...(groups.get(key) ?? []), item]);
  }
  return [...groups.entries()]
    .map(
      ([category, items]) =>
        `${category}:\n` +
        items
          .map((i) => `- ${i.name} — ${formatBRL(i.priceCents)}${i.description ? ` (${i.description})` : ""}`)
          .join("\n"),
    )
    .join("\n\n");
}
