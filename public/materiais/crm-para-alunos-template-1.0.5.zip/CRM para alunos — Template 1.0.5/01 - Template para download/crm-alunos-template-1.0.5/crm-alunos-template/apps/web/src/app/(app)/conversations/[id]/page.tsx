import { notFound, redirect } from "next/navigation";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { markConversationRead } from "@/lib/conversations/unread";
import { Badge } from "@/components/ui/badge";
import { ConversationView } from "./_components/conversation-view";
import { AgentPicker } from "./_components/agent-picker";
import { OBJECTION_LABEL, type ObjectionTag } from "@/lib/objections";
import { AlertTriangle } from "lucide-react";
import type { MessageView } from "./_components/messages-pane";
import { messageMediaUrl } from "@/lib/conversations/message-media-url";

export const dynamic = "force-dynamic";

export default async function ConversationPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const session = await auth();
  if (!session?.user?.id) redirect("/login");

  const { id } = await params;
  const [conv, agents] = await Promise.all([
    safeQuery(id),
    prisma.agentSession
      .findMany({
        orderBy: [{ isDefault: "desc" }, { name: "asc" }],
        select: { id: true, name: true, role: true, isDefault: true },
      })
      .catch(() => []),
  ]);
  if (!conv) notFound();

  // Abrir a conversa marca como lida — contador global (spec 2026-07-06).
  await markConversationRead(conv.id);

  const externalId =
    conv.contact?.identities?.find((i) => i.channel === conv.channel)
      ?.externalId ?? "—";

  const initialMessages: MessageView[] = conv.messages.map((m) => ({
    id: m.id,
    direction: m.direction as "inbound" | "outbound",
    role: m.role,
    text: m.text,
    mediaType: m.mediaType,
    mediaUrl: messageMediaUrl(m),
    modelUsed: m.modelUsed,
    sentByUserId: m.sentByUserId,
    sentBy: m.sentBy,
    createdAt: m.createdAt.toISOString(),
    templateMetaName: m.templateMetaName,
  }));

  const assignedUserName =
    conv.assignedUser?.name ?? conv.assignedUser?.email ?? null;

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <header className="mb-6 flex flex-wrap items-center gap-3 justify-between">
        <div>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl md:text-2xl font-semibold tracking-tight">
              {conv.contact?.displayName ?? externalId}
            </h1>
            {conv.objections.map((tag) => (
              <Badge
                key={tag}
                variant="outline"
                title="Objeção levantada nas últimas 24h"
                className="gap-1 text-[10px] border-warning/30 text-warning"
              >
                <AlertTriangle className="size-3" />
                {OBJECTION_LABEL[tag]}
              </Badge>
            ))}
          </div>
          <div className="text-xs text-muted-foreground font-mono mt-1">
            {conv.channel} · {externalId}
          </div>
        </div>
        <AgentPicker conversationId={conv.id} current={conv.agentSessionId} agents={agents} />
      </header>

      <ConversationView
        conversationId={conv.id}
        channel={conv.channel}
        externalId={externalId}
        aiEnabled={conv.aiEnabled}
        handoffRequested={conv.handoffRequested}
        handoffSummary={conv.handoffSummary}
        windowClosesAt={conv.windowClosesAt?.toISOString() ?? null}
        initialMessages={initialMessages}
        initialAssignedUserId={conv.assignedUserId}
        initialAssignedUserName={assignedUserName}
        sessionUserId={session.user.id}
        hasResponses={conv.surveyResponseCount > 0}
        leadId={conv.lead?.id ?? null}
        leadStage={conv.lead?.stage ?? null}
        leadLostReason={conv.lead?.lostReason ?? null}
      />
    </div>
  );
}

async function safeQuery(id: string) {
  try {
    const conv = await prisma.conversation.findUnique({
      where: { id },
      include: {
        contact: { include: { identities: true } },
        messages: {
          orderBy: { createdAt: "asc" },
          take: 200,
          include: { sentBy: { select: { id: true, name: true } } },
        },
        assignedUser: { select: { id: true, name: true, email: true } },
        lead: { select: { id: true, stage: true, lostReason: true } },
      },
    });
    if (!conv) return null;
    let objections: ObjectionTag[] = [];
    if (conv.lead) {
      const cutoff = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const tags = await prisma.objectionTag.findMany({
        where: { leadId: conv.lead.id, createdAt: { gte: cutoff } },
        distinct: ["tag"],
        orderBy: { createdAt: "desc" },
        select: { tag: true },
      });
      objections = tags
        .map((t) => t.tag as ObjectionTag)
        .filter((t): t is ObjectionTag => t in OBJECTION_LABEL);
    }
    const surveyResponseCount = await prisma.surveyResponse.count({
      where: { contactId: conv.contactId },
    });
    return { ...conv, objections, surveyResponseCount };
  } catch {
    return null;
  }
}
