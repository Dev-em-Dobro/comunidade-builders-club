/**
 * Seleção de conversas a auditar (Sub-Plan A do auditor).
 *
 * Critério: top N conversas com mais mensagens outbound assistant nas
 * últimas `windowHours`, filtrando por mínimo `minBotTurns`. Conversas sem
 * Contact (improvável mas defensivo) saem com `displayName: null`.
 */
import { prisma } from "@/lib/db";

export interface ConversationCandidate {
  conversationId: string;
  contactId: string;
  displayName: string | null;
  botTurnCount: number;
}

export async function selectConversations(
  windowHours = 24,
  limit = 5,
  minBotTurns = 2,
): Promise<ConversationCandidate[]> {
  const since = new Date(Date.now() - windowHours * 60 * 60 * 1000);

  // Agregação SQL: count outbound+assistant por conversationId desde `since`.
  // Filtra HAVING count >= minBotTurns. Ordena desc e limita.
  type Row = { conversationId: string; botTurnCount: bigint };
  const rows = await prisma.$queryRaw<Row[]>`
    SELECT m."conversationId" AS "conversationId",
           COUNT(*)::bigint AS "botTurnCount"
    FROM "Message" m
    WHERE m."direction" = 'outbound'
      AND m."role" = 'assistant'
      AND m."createdAt" >= ${since}
    GROUP BY m."conversationId"
    HAVING COUNT(*) >= ${minBotTurns}
    ORDER BY COUNT(*) DESC
    LIMIT ${limit}
  `;

  if (rows.length === 0) return [];

  // Hidrata com contactId + displayName.
  const convIds = rows.map((r) => r.conversationId);
  const convs = await prisma.conversation.findMany({
    where: { id: { in: convIds } },
    select: {
      id: true,
      contactId: true,
      contact: { select: { displayName: true } },
    },
  });
  const byId = new Map(convs.map((c) => [c.id, c]));

  return rows.map((r) => {
    const c = byId.get(r.conversationId);
    return {
      conversationId: r.conversationId,
      contactId: c?.contactId ?? "",
      displayName: c?.contact?.displayName ?? null,
      botTurnCount: Number(r.botTurnCount),
    };
  });
}
