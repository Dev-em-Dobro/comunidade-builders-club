"use client";

import { useActionState, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { saveAgent, type AgentFormState } from "../_actions";
import { Loader2, Save } from "lucide-react";
import { IntakeFieldsEditor, type IntakeFieldDraft } from "./intake-fields-editor";
import { DEFAULT_INTAKE_FIELDS } from "@/lib/scheduling/intake";
import { AGENT_ROLES, DEFAULT_PROMPTS, defaultPromptFor } from "../_roles";
import type { ProviderModels } from "@/lib/llm/models";
import {
  DEFAULT_HUMANIZE,
  MAX_BUBBLES,
  WAIT_SECONDS_MAX,
  WAIT_SECONDS_MIN,
  type HumanizeSettings,
} from "@/lib/humanize";

interface InitialAgent {
  id?: string;
  name?: string;
  persona?: string | null;
  systemPrompt?: string;
  model?: string;
  provider?: string;
  temperature?: number;
  maxTokens?: number;
  memoryMode?: string;
  isDefault?: boolean;
  role?: string | null;
  intakeFields?: IntakeFieldDraft[];
  humanize?: HumanizeSettings;
}

const NATIVE_SELECT =
  "h-8 w-full rounded-lg border border-input bg-transparent px-2.5 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 dark:bg-input/30";

const PROVIDERS = ["anthropic", "openai"];
const CUSTOM = "__custom__";

export function AgentForm({
  initial,
  configuredProviders = [],
  modelOptions,
}: {
  initial?: InitialAgent;
  configuredProviders?: string[];
  /** Modelos por provedor (lista da conta ou de reserva) — ver lib/llm/models.ts. */
  modelOptions: Record<string, ProviderModels>;
}) {
  const [state, action, pending] = useActionState<AgentFormState, FormData>(
    async (_prev, formData) => saveAgent(formData),
    {},
  );

  // Agente novo abre no provedor que já tem chave cadastrada (senão, Anthropic).
  const [provider, setProvider] = useState(
    initial?.provider ?? PROVIDERS.find((p) => configuredProviders.includes(p)) ?? "anthropic",
  );
  const firstModel = (p: string) => modelOptions[p]?.models[0]?.id ?? "";
  const [model, setModel] = useState(() => initial?.model ?? firstModel(provider));
  const [customModel, setCustomModel] = useState(false);
  const providerModels = modelOptions[provider];
  const options = providerModels?.models ?? [];
  // Modelo salvo que não está na lista (ex.: ID digitado à mão) continua selecionável.
  const savedOutsideList =
    initial?.model && initial.provider === provider && !options.some((m) => m.id === initial.model)
      ? initial.model
      : null;
  const [role, setRole] = useState(initial?.role ?? "");
  const humanize = initial?.humanize ?? DEFAULT_HUMANIZE;
  const [prompt, setPrompt] = useState(initial?.systemPrompt ?? DEFAULT_PROMPTS.generic);

  function changeRole(next: string) {
    setRole(next);
    // Troca o prompt só se ainda for um dos prompts-modelo (não apaga texto do usuário).
    const isTemplate = Object.values(DEFAULT_PROMPTS).some((p) => p.trim() === prompt.trim());
    if (isTemplate) setPrompt(defaultPromptFor(next));
  }

  return (
    <form action={action} className="space-y-6 max-w-2xl">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <div className="space-y-2">
        <Label htmlFor="role">Tipo de agente</Label>
        <select
          id="role"
          name="role"
          value={role}
          onChange={(e) => changeRole(e.target.value)}
          className={NATIVE_SELECT}
        >
          {AGENT_ROLES.map((r) => (
            <option key={r.value} value={r.value}>
              {r.label}
            </option>
          ))}
        </select>
        <p className="text-xs text-muted-foreground">
          {AGENT_ROLES.find((r) => r.value === role)?.hint}
        </p>
      </div>

      {role === "scheduling" && (
        <IntakeFieldsEditor
          initial={
            initial?.intakeFields?.length
              ? initial.intakeFields
              : DEFAULT_INTAKE_FIELDS.map(({ label, required, key }) => ({ key, label, required }))
          }
        />
      )}

      <div className="space-y-2">
        <Label htmlFor="name">Nome</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initial?.name ?? ""}
          placeholder="SDR Vendas B2B"
        />
        <p className="text-xs text-muted-foreground">
          Identificação interna da session (ex: produto/escopo).
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="persona">Persona</Label>
        <Input
          id="persona"
          name="persona"
          defaultValue={initial?.persona ?? ""}
          placeholder="Alex"
        />
        <p className="text-xs text-muted-foreground">
          Nome humano que o lead vê no chat (ex: &quot;Alex&quot;, &quot;Lucas&quot;). Usado no handoff entre agentes.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="systemPrompt">System prompt</Label>
        <Textarea
          id="systemPrompt"
          name="systemPrompt"
          required
          rows={10}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          className="font-mono text-sm"
        />
        <p className="text-xs text-muted-foreground">
          Parte estática vai com <code>cache_control: ephemeral</code> (Anthropic) — 90% de economia em chamadas repetidas.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label>Provider</Label>
          <Select
            name="provider"
            value={provider}
            onValueChange={(v) => {
              const p = v ?? "anthropic";
              setProvider(p);
              setModel(firstModel(p));
              setCustomModel(false);
            }}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {PROVIDERS.map((p) => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {!configuredProviders.includes(provider) && (
            <p className="text-xs text-amber-600">
              Chave da {provider} não configurada — defina em{" "}
              <a href="/settings/credentials" className="underline">Chaves de API</a>.
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="model">Modelo</Label>
          <select
            id="model"
            name={customModel ? undefined : "model"}
            value={customModel ? CUSTOM : model}
            onChange={(e) => {
              if (e.target.value === CUSTOM) {
                setCustomModel(true);
              } else {
                setCustomModel(false);
                setModel(e.target.value);
              }
            }}
            className={NATIVE_SELECT}
          >
            {savedOutsideList && <option value={savedOutsideList}>{savedOutsideList} (atual)</option>}
            {options.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
            <option value={CUSTOM}>Outro… (digitar o ID)</option>
          </select>
          {customModel && (
            <Input
              name="model"
              value={model}
              onChange={(event) => setModel(event.target.value.trim())}
              required
              placeholder="ID exato do modelo na API"
              className="font-mono text-xs"
            />
          )}
          <p className="text-xs text-muted-foreground">
            O padrão é o de melhor custo-benefício — a escolha é sua.{" "}
            {providerModels?.source === "api"
              ? "Lista com os modelos liberados na sua conta deste provedor."
              : "Lista básica: cadastre a chave em Chaves de API para ver todos os modelos da sua conta."}
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="temperature">Temperature</Label>
          <Input
            id="temperature"
            name="temperature"
            type="number"
            step="0.1"
            min="0"
            max="1.5"
            defaultValue={initial?.temperature ?? 0.7}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="maxTokens">Max tokens (resposta)</Label>
          <Input
            id="maxTokens"
            name="maxTokens"
            type="number"
            min="64"
            max="8192"
            defaultValue={initial?.maxTokens ?? 1024}
          />
        </div>

        <div className="space-y-2">
          <Label>Memória</Label>
          <Select name="memoryMode" defaultValue={initial?.memoryMode ?? "window_20"}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="window_20">window_20 (últimas 20 msgs)</SelectItem>
              <SelectItem value="window_10">window_10</SelectItem>
              <SelectItem value="summary_plus_10">summary_plus_10</SelectItem>
              <SelectItem value="stateless">stateless</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center justify-between rounded-md border border-border p-3">
          <div>
            <Label htmlFor="isDefault" className="text-sm">Default?</Label>
            <p className="text-xs text-muted-foreground">
              Usado quando a conversa não tem agente atribuído.
            </p>
          </div>
          <Switch
            id="isDefault"
            name="isDefault"
            defaultChecked={initial?.isDefault ?? false}
          />
        </div>
      </div>

      <fieldset className="space-y-4 rounded-md border border-border p-4">
        <legend className="px-1 text-sm font-medium">Jeito de responder</legend>
        <p className="text-xs text-muted-foreground">
          Deixa o agente com ritmo de gente no WhatsApp, em vez de responder na hora com um bloco de texto.
        </p>
        <div className="space-y-2 max-w-xs">
          <Label htmlFor="humanizeWait">Esperar o cliente terminar de escrever (segundos)</Label>
          <Input
            id="humanizeWait"
            name="humanizeWait"
            type="number"
            min={WAIT_SECONDS_MIN}
            max={WAIT_SECONDS_MAX}
            step={1}
            defaultValue={humanize.waitSeconds}
          />
          <p className="text-xs text-muted-foreground">
            Cada mensagem nova recomeça a contagem — se a pessoa manda 3 mensagens seguidas, o agente responde uma vez só.
          </p>
        </div>
        <div className="flex items-center justify-between gap-4">
          <div>
            <Label htmlFor="humanizeTyping" className="text-sm">Mostrar “digitando…”</Label>
            <p className="text-xs text-muted-foreground">
              Antes de cada mensagem, pelo tempo que uma pessoa levaria pra escrever o texto (WhatsApp via QR).
            </p>
          </div>
          <Switch id="humanizeTyping" name="humanizeTyping" defaultChecked={humanize.typing} />
        </div>
        <div className="flex items-center justify-between gap-4">
          <div>
            <Label htmlFor="humanizeSplit" className="text-sm">Quebrar respostas longas em várias mensagens</Label>
            <p className="text-xs text-muted-foreground">Um balão por parágrafo, até {MAX_BUBBLES} por resposta.</p>
          </div>
          <Switch id="humanizeSplit" name="humanizeSplit" defaultChecked={humanize.splitMessages} />
        </div>
      </fieldset>

      {state?.error && (
        <p className="text-sm text-destructive font-mono">{state.error}</p>
      )}

      <div className="flex gap-2">
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Save className="size-4" />}
          Salvar
        </Button>
      </div>
    </form>
  );
}
