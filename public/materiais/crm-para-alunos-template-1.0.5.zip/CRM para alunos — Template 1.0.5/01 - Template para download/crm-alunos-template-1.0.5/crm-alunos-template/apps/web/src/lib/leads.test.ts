import { describe, it, expect, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { ensureLeadForContact, touchLeadActivity, tryAttributeLaunchId } from "./leads";
import { _resetActiveLaunchCache } from "@/lib/launches/active";

const contactIds: string[] = [];

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: contactIds } } });
  await prisma.$disconnect();
});

describe("ensureLeadForContact", () => {
  it("cria Lead + PipelineEvent na primeira vez", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "P3 a" } });
    contactIds.push(contact.id);

    const { lead, created } = await ensureLeadForContact(contact.id);
    expect(created).toBe(true);
    expect(lead.stage).toBe("new");
    expect(lead.firstInboundAt).not.toBeNull();
    expect(lead.lastActivityAt).not.toBeNull();

    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: lead.id },
    });
    expect(events).toHaveLength(1);
    expect(events[0]!.type).toBe("stage_change");
  });

  it("é idempotente — segunda chamada não duplica Lead nem PipelineEvent", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "P3 b" } });
    contactIds.push(contact.id);

    const first = await ensureLeadForContact(contact.id);
    const second = await ensureLeadForContact(contact.id);

    expect(second.created).toBe(false);
    expect(second.lead.id).toBe(first.lead.id);

    const leads = await prisma.lead.findMany({ where: { contactId: contact.id } });
    expect(leads).toHaveLength(1);
    const events = await prisma.pipelineEvent.findMany({
      where: { leadId: first.lead.id },
    });
    expect(events).toHaveLength(1);
  });

  it("touchLeadActivity atualiza lastActivityAt", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "P3 c" } });
    contactIds.push(contact.id);
    const { lead } = await ensureLeadForContact(contact.id);

    const before = lead.lastActivityAt!.getTime();
    await new Promise((r) => setTimeout(r, 10));
    await touchLeadActivity(lead.id);

    const updated = await prisma.lead.findUnique({ where: { id: lead.id } });
    expect(updated!.lastActivityAt!.getTime()).toBeGreaterThan(before);
  });
});

describe("tryAttributeLaunchId", () => {
  beforeEach(() => _resetActiveLaunchCache());

  it("seta launchId quando há exatamente 1 oferta ativa pro course de interesse", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "Attr1" } });
    const course = await prisma.course.create({
      data: { name: "Attr course", slug: `attr-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, priceCents: 100 },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `Attr launch ${Date.now()}`,
        slug: `attr-l-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: course.id,
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });
    const lead = await prisma.lead.create({
      data: { contactId: contact.id, interestCourseIds: [course.id], stage: "new" },
    });

    await tryAttributeLaunchId(lead.id);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.launchId).toBe(launch.id);

    // cleanup
    await prisma.lead.delete({ where: { id: lead.id } });
    await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
    await prisma.launch.delete({ where: { id: launch.id } });
    await prisma.course.delete({ where: { id: course.id } });
    await prisma.contact.delete({ where: { id: contact.id } });
  });

  it("no-op quando launchId já está setado", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "Attr2" } });
    const course = await prisma.course.create({
      data: { name: "Attr2 course", slug: `attr2-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, priceCents: 100 },
    });
    const l1 = await prisma.launch.create({
      data: {
        name: `Attr2 l1 ${Date.now()}`,
        slug: `attr2-l1-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: course.id,
      },
    });
    await prisma.launchPlan.create({
      data: { launchId: l1.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });
    const otherLaunch = await prisma.launch.create({
      data: {
        name: `Attr2 other ${Date.now()}`,
        slug: `attr2-other-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(),
        endsAt: new Date(Date.now() + 86400000),
        status: "closed",
      },
    });
    const lead = await prisma.lead.create({
      data: {
        contactId: contact.id,
        interestCourseIds: [course.id],
        launchId: otherLaunch.id,
        stage: "new",
      },
    });

    await tryAttributeLaunchId(lead.id);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.launchId).toBe(otherLaunch.id); // NÃO mudou

    // cleanup
    await prisma.lead.delete({ where: { id: lead.id } });
    await prisma.launchPlan.deleteMany({ where: { launchId: l1.id } });
    await prisma.launch.deleteMany({ where: { id: { in: [l1.id, otherLaunch.id] } } });
    await prisma.course.delete({ where: { id: course.id } });
    await prisma.contact.delete({ where: { id: contact.id } });
  });

  it("no-op quando interestCourseIds está vazio", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "Attr3" } });
    const lead = await prisma.lead.create({
      data: { contactId: contact.id, interestCourseIds: [], stage: "new" },
    });
    await tryAttributeLaunchId(lead.id);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.launchId).toBeNull();
    await prisma.lead.delete({ where: { id: lead.id } });
    await prisma.contact.delete({ where: { id: contact.id } });
  });

  it("no-op quando 2+ courses têm oferta ativa (ambiguidade)", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "Attr4" } });
    const cA = await prisma.course.create({
      data: { name: "AttrA", slug: `attra-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, priceCents: 100 },
    });
    const cB = await prisma.course.create({
      data: { name: "AttrB", slug: `attrb-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`, priceCents: 100 },
    });
    const lA = await prisma.launch.create({
      data: {
        name: `lA ${Date.now()}`,
        slug: `la-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: cA.id,
      },
    });
    const lB = await prisma.launch.create({
      data: {
        name: `lB ${Date.now()}`,
        slug: `lb-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: cB.id,
      },
    });
    await prisma.launchPlan.create({ data: { launchId: lA.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 } });
    await prisma.launchPlan.create({ data: { launchId: lB.id, name: "P", priceCents: 100, checkoutUrl: "x", sortOrder: 0 } });
    const lead = await prisma.lead.create({
      data: { contactId: contact.id, interestCourseIds: [cA.id, cB.id], stage: "new" },
    });

    await tryAttributeLaunchId(lead.id);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.launchId).toBeNull(); // ambíguo

    // cleanup
    await prisma.lead.delete({ where: { id: lead.id } });
    await prisma.launchPlan.deleteMany({ where: { launchId: { in: [lA.id, lB.id] } } });
    await prisma.launch.deleteMany({ where: { id: { in: [lA.id, lB.id] } } });
    await prisma.course.deleteMany({ where: { id: { in: [cA.id, cB.id] } } });
    await prisma.contact.delete({ where: { id: contact.id } });
  });
});
