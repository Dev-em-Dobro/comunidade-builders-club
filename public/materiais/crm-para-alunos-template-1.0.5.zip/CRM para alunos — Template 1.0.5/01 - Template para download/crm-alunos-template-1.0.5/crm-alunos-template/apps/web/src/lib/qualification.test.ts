import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { determineStagePromotion, classifyLead, isSupportAudience } from "./qualification";
import { prisma } from "@/lib/db";

vi.mock("@/lib/llm", async () => {
  const actual = await vi.importActual<typeof import("@/lib/llm")>("@/lib/llm");
  return {
    ...actual,
    generateReply: vi.fn(),
  };
});

vi.mock("@/lib/queue", async () => {
  const actual = await vi.importActual<typeof import("@/lib/queue")>("@/lib/queue");
  return {
    ...actual,
    enqueue: vi.fn().mockResolvedValue(undefined),
  };
});

import { generateReply } from "@/lib/llm";
import { enqueue } from "@/lib/queue";

const fullQual = {
  budgetSignal: "strong" as const,
  interestLevel: "medium" as const,
  decisionTimeline: "short" as const,
  courseInterestIds: ["c1"],
  objections: [] as string[],
  rationale: "x",
};

const emptyQual = {
  budgetSignal: "unknown" as const,
  interestLevel: "low" as const,
  decisionTimeline: "unknown" as const,
  courseInterestIds: [] as string[],
  objections: [] as string[],
  rationale: "",
};

const fullAsked = {
  objetivo: { askedAt: "2026-05-25T10:00:00Z", answeredAt: "2026-05-25T10:01:00Z", answer: "migrar de área" },
  nivel: { askedAt: "2026-05-25T10:02:00Z", answeredAt: "2026-05-25T10:03:00Z", answer: "zero" },
  urgencia: { askedAt: "2026-05-25T10:04:00Z", answeredAt: "2026-05-25T10:05:00Z", answer: "ano que vem" },
  tempo_disponivel: { askedAt: "2026-05-25T10:06:00Z", answeredAt: "2026-05-25T10:07:00Z", answer: "10h/semana" },
};

const qualWithAsked = (asked: Record<string, unknown>) => ({
  ...emptyQual,
  askedFields: asked,
});

describe("isSupportAudience", () => {
  it("student/support/refund → true", () => {
    expect(isSupportAudience("student")).toBe(true);
    expect(isSupportAudience("support")).toBe(true);
    expect(isSupportAudience("refund")).toBe(true);
  });
  it("prospect/undefined → false", () => {
    expect(isSupportAudience("prospect")).toBe(false);
    expect(isSupportAudience(undefined)).toBe(false);
  });
});

describe("determineStagePromotion", () => {
  it("não promove a partir de stages terminais", () => {
    expect(determineStagePromotion("proposal", 100, fullQual)).toBeNull();
    expect(determineStagePromotion("won", 100, fullQual)).toBeNull();
    expect(determineStagePromotion("lost", 100, fullQual)).toBeNull();
  });

  it("não re-promove a partir de qualified", () => {
    expect(determineStagePromotion("qualified", 85, fullQual)).toBeNull();
  });

  it("promove new → qualified quando askedFields 6/6 answered", () => {
    expect(determineStagePromotion("new", 0, qualWithAsked(fullAsked))).toEqual({ to: "qualified" });
  });

  it("promove contacted → qualified quando askedFields 6/6 answered", () => {
    expect(determineStagePromotion("contacted", 0, qualWithAsked(fullAsked))).toEqual({ to: "qualified" });
  });

  it("não promove a qualified quando askedFields undefined", () => {
    expect(determineStagePromotion("contacted", 100, emptyQual)).toBeNull();
  });

  it("não promove a qualified quando askedFields ausente um field", () => {
    const { tempo_disponivel: _t, ...without1 } = fullAsked;
    expect(determineStagePromotion("contacted", 100, qualWithAsked(without1))).toBeNull();
  });

  it("não promove a qualified quando um field tem askedAt mas sem answeredAt", () => {
    const partial = { ...fullAsked, tempo_disponivel: { askedAt: "2026-05-25T10:06:00Z" } };
    expect(determineStagePromotion("contacted", 100, qualWithAsked(partial))).toBeNull();
  });

  it("score / budgetSignal / interestLevel não importam mais pra promotion a qualified", () => {
    // Score alto + sinais fortes mas sem askedFields → não promove
    expect(determineStagePromotion("contacted", 100, fullQual)).toBeNull();
    // Score zero + sinais fracos mas askedFields 6/6 → promove
    const weakButComplete = { ...emptyQual, askedFields: fullAsked };
    expect(determineStagePromotion("contacted", 0, weakButComplete)).toEqual({ to: "qualified" });
  });

  it("o caminho real do Cliente Exemplo: 6/6 askedFields com sinais fracos promove", () => {
    // Caso real 2026-05-25 — Cliente Exemplo preencheu tudo mas budgetSignal=unknown
    const robertoQual = {
      ...emptyQual,
      decisionTimeline: "long" as const,
      interestLevel: "medium" as const,
      askedFields: fullAsked,
    };
    expect(determineStagePromotion("contacted", 58, robertoQual)).toEqual({ to: "qualified" });
  });

  // --- Handoff cedo (2026-08-12): qualquer sinal + >=1 campo → qualified ---
  const oneField = {
    objetivo: {
      askedAt: "2026-08-12T10:00:00Z",
      answeredAt: "2026-08-12T10:01:00Z",
      answer: "trocar de carreira",
    },
  };

  it("cedo: interesse medium + 1 campo respondido → qualified", () => {
    const q = { ...emptyQual, interestLevel: "medium" as const, askedFields: oneField };
    expect(determineStagePromotion("contacted", 40, q)).toEqual({ to: "qualified" });
  });

  it("cedo: courseInterest presente + 1 campo respondido → qualified", () => {
    const q = { ...emptyQual, courseInterestIds: ["c1"], askedFields: oneField };
    expect(determineStagePromotion("new", 20, q)).toEqual({ to: "qualified" });
  });

  it("cedo: sinal de interesse mas 0 campos respondidos → NÃO qualifica", () => {
    const q = { ...emptyQual, interestLevel: "high" as const };
    expect(determineStagePromotion("contacted", 90, q)).toBeNull();
    expect(determineStagePromotion("new", 90, q)).toEqual({ to: "contacted" });
  });

  it("cedo: 1 campo respondido mas nenhum sinal de interesse → NÃO qualifica", () => {
    const q = { ...emptyQual, askedFields: oneField };
    expect(determineStagePromotion("contacted", 10, q)).toBeNull();
  });

  it("promove new → contacted quando qualification tem qualquer sinal mas score baixo", () => {
    const partial = { ...emptyQual, decisionTimeline: "medium" as const };
    expect(determineStagePromotion("new", 30, partial)).toEqual({ to: "contacted" });
  });

  it("não promove new → contacted quando qualification está totalmente vazia", () => {
    expect(determineStagePromotion("new", 0, emptyQual)).toBeNull();
  });

  it("não promove contacted quando não há sinal forte (já está em contacted)", () => {
    expect(determineStagePromotion("contacted", 30, emptyQual)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Integration tests: classifyLead persisting askedFields
// ---------------------------------------------------------------------------

const createdIds = {
  conversationIds: [] as string[],
  leadIds: [] as string[],
  contactIds: [] as string[],
};

async function createFixture(qualSeed?: Record<string, unknown>) {
  const contact = await prisma.contact.create({
    data: { displayName: "AskedFields Test" },
  });
  createdIds.contactIds.push(contact.id);
  const lead = await prisma.lead.create({
    data: {
      contactId: contact.id,
      stage: "new",
      score: 0,
      ...(qualSeed ? { qualification: qualSeed as object } : {}),
    },
  });
  createdIds.leadIds.push(lead.id);
  const conv = await prisma.conversation.create({
    data: {
      channel: "test",
      contactId: contact.id,
      leadId: lead.id,
    },
  });
  createdIds.conversationIds.push(conv.id);
  // Pelo menos 1 mensagem inbound — classifier aborta se não houver mensagens.
  await prisma.message.create({
    data: {
      conversationId: conv.id,
      direction: "inbound",
      role: "user",
      text: "oi tudo bem?",
    },
  });
  return { lead, conv };
}

function mockClassifierOutput(input: Record<string, unknown>) {
  (generateReply as unknown as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
    text: "",
    modelUsed: "test",
    tokensIn: 0,
    tokensOut: 0,
    toolUses: [{ id: "test_id", name: "record_qualification", input }],
  });
}

afterAll(async () => {
  await prisma.message.deleteMany({
    where: { conversationId: { in: createdIds.conversationIds } },
  });
  await prisma.conversation.deleteMany({
    where: { id: { in: createdIds.conversationIds } },
  });
  await prisma.lead.deleteMany({ where: { id: { in: createdIds.leadIds } } });
  await prisma.contact.deleteMany({
    where: { id: { in: createdIds.contactIds } },
  });
  await prisma.$disconnect();
});

describe("classifyLead — askedFields persistence", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
  });

  it("persiste askedFields completos quando lead não tinha nada antes", async () => {
    const { lead, conv } = await createFixture();
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
      objections: [],
      askedFields: {
        objetivo: { askedAt: "2026-05-24T10:00:00Z" },
        nivel: {
          askedAt: "2026-05-24T10:05:00Z",
          answeredAt: "2026-05-24T10:06:00Z",
          answer: "iniciante",
        },
      },
    });
    await classifyLead(conv.id);
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { qualification: true },
    });
    const q = fresh?.qualification as { askedFields?: Record<string, unknown> } | null;
    expect(q?.askedFields).toMatchObject({
      objetivo: { askedAt: "2026-05-24T10:00:00Z" },
      nivel: {
        askedAt: "2026-05-24T10:05:00Z",
        answeredAt: "2026-05-24T10:06:00Z",
        answer: "iniciante",
      },
    });
  });

  it("preserva askedAt antigo quando classifier retorna timestamp novo", async () => {
    const { lead, conv } = await createFixture({
      askedFields: { objetivo: { askedAt: "2026-05-20T08:00:00Z" } },
      interestLevel: "low",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
    });
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
      objections: [],
      askedFields: {
        objetivo: { askedAt: "2026-05-24T10:00:00Z" }, // mais novo
      },
    });
    await classifyLead(conv.id);
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { qualification: true },
    });
    const q = fresh?.qualification as { askedFields?: Record<string, { askedAt: string }> } | null;
    expect(q?.askedFields?.objetivo?.askedAt).toBe("2026-05-20T08:00:00Z");
  });

  it("preserva campo que classifier omite (fora da window)", async () => {
    const { lead, conv } = await createFixture({
      askedFields: {
        objetivo: { askedAt: "2026-05-20T08:00:00Z" },
        nome: { askedAt: "2026-05-21T08:00:00Z" },
      },
      interestLevel: "low",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
    });
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
      objections: [],
      askedFields: {
        // só "objetivo" agora — "nome" saiu da window
        objetivo: {
          askedAt: "2026-05-20T08:00:00Z",
          answeredAt: "2026-05-24T09:00:00Z",
          answer: "virar dev",
        },
      },
    });
    await classifyLead(conv.id);
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { qualification: true },
    });
    const q = fresh?.qualification as {
      askedFields?: Record<string, { askedAt: string; answeredAt?: string; answer?: string }>;
    } | null;
    expect(q?.askedFields?.objetivo?.answeredAt).toBe("2026-05-24T09:00:00Z");
    expect(q?.askedFields?.objetivo?.answer).toBe("virar dev");
    expect(q?.askedFields?.nome?.askedAt).toBe("2026-05-21T08:00:00Z");
  });

  it("não apaga askedFields quando classifier omite a chave inteira", async () => {
    const { lead, conv } = await createFixture({
      askedFields: { objetivo: { askedAt: "2026-05-20T08:00:00Z" } },
      interestLevel: "low",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
    });
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
      objections: [],
      // sem askedFields no output
    });
    await classifyLead(conv.id);
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { qualification: true },
    });
    const q = fresh?.qualification as {
      askedFields?: Record<string, { askedAt: string }>;
    } | null;
    expect(q?.askedFields?.objetivo?.askedAt).toBe("2026-05-20T08:00:00Z");
  });

  it("preserva tudo quando classifier retorna askedFields vazio", async () => {
    const { lead, conv } = await createFixture({
      askedFields: { objetivo: { askedAt: "2026-05-20T08:00:00Z" } },
      interestLevel: "low",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
    });
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "",
      objections: [],
      askedFields: {}, // vazio: nada novo, nada some
    });
    await classifyLead(conv.id);
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { qualification: true },
    });
    const q = fresh?.qualification as {
      askedFields?: Record<string, { askedAt: string }>;
    } | null;
    expect(q?.askedFields?.objetivo?.askedAt).toBe("2026-05-20T08:00:00Z");
  });
});

describe("classifyLead — enqueue agent.handoff on promotion", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
    (enqueue as unknown as ReturnType<typeof vi.fn>).mockClear();
  });

  it("enfileira agent.handoff quando lead 'new' é promovido a 'qualified'", async () => {
    const { lead, conv } = await createFixture();
    // createFixture já cria lead com stage="new" — só reafirma.
    await prisma.lead.update({ where: { id: lead.id }, data: { stage: "new" } });

    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "long",
      courseInterestIds: [],
      rationale: "qualificação completa",
      objections: [],
      askedFields: {
        objetivo: { askedAt: "2026-05-25T10:00:00Z", answeredAt: "2026-05-25T10:01:00Z", answer: "migrar de área" },
        nivel: { askedAt: "2026-05-25T10:02:00Z", answeredAt: "2026-05-25T10:03:00Z", answer: "zero" },
        urgencia: { askedAt: "2026-05-25T10:04:00Z", answeredAt: "2026-05-25T10:05:00Z", answer: "ano que vem" },
        tempo_disponivel: { askedAt: "2026-05-25T10:06:00Z", answeredAt: "2026-05-25T10:07:00Z", answer: "10h" },
      },
    });

    await classifyLead(conv.id);

    // Confirma que stage foi promovido a qualified
    const fresh = await prisma.lead.findUnique({
      where: { id: lead.id },
      select: { stage: true },
    });
    expect(fresh?.stage).toBe("qualified");

    // Confirma que enqueue foi chamado com agent.handoff
    expect(enqueue).toHaveBeenCalledWith(
      "sla",
      "agent.handoff",
      { conversationId: conv.id, toRole: "closer" },
      { jobId: `agent-handoff__${conv.id}` },
    );
  });

  it("NÃO enfileira agent.handoff quando lead já é 'qualified'", async () => {
    const { lead, conv } = await createFixture();
    await prisma.lead.update({
      where: { id: lead.id },
      data: { stage: "qualified" },
    });

    mockClassifierOutput({
      interestLevel: "high",
      budgetSignal: "strong",
      decisionTimeline: "short",
      courseInterestIds: [],
      rationale: "x",
      objections: [],
    });

    await classifyLead(conv.id);

    const handoffCalls = (enqueue as unknown as ReturnType<typeof vi.fn>).mock.calls
      .filter((c) => c[1] === "agent.handoff");
    expect(handoffCalls).toHaveLength(0);
  });
});

describe("classifyLead — roteamento por audience", () => {
  beforeEach(() => {
    (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
    (enqueue as unknown as ReturnType<typeof vi.fn>).mockClear();
  });

  it("enfileira support handoff quando audience=student", async () => {
    const { lead, conv } = await createFixture();
    mockClassifierOutput({
      interestLevel: "low",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "aluno pedindo acesso",
      objections: [],
      audience: "student",
    });

    await classifyLead(conv.id);

    expect(enqueue).toHaveBeenCalledWith(
      "sla",
      "agent.handoff",
      { conversationId: conv.id, toRole: "support" },
      { jobId: `agent-handoff-support__${conv.id}` },
    );
    const closerCalls = (enqueue as unknown as ReturnType<typeof vi.fn>).mock.calls
      .filter((c) => c[1] === "agent.handoff" && c[2]?.toRole === "closer");
    expect(closerCalls).toHaveLength(0);
    void lead;
  });

  it("audience=support e audience=refund também roteiam pro suporte", async () => {
    for (const audience of ["support", "refund"] as const) {
      (enqueue as unknown as ReturnType<typeof vi.fn>).mockClear();
      const { conv } = await createFixture();
      mockClassifierOutput({
        interestLevel: "low",
        budgetSignal: "unknown",
        decisionTimeline: "unknown",
        courseInterestIds: [],
        rationale: audience,
        objections: [],
        audience,
      });
      await classifyLead(conv.id);
      const supportCalls = (enqueue as unknown as ReturnType<typeof vi.fn>).mock.calls
        .filter((c) => c[1] === "agent.handoff" && c[2]?.toRole === "support");
      expect(supportCalls.length).toBeGreaterThanOrEqual(1);
    }
  });

  it("audience=prospect NÃO enfileira support handoff", async () => {
    const { conv } = await createFixture();
    mockClassifierOutput({
      interestLevel: "medium",
      budgetSignal: "unknown",
      decisionTimeline: "unknown",
      courseInterestIds: [],
      rationale: "quer comprar",
      objections: [],
      audience: "prospect",
    });
    await classifyLead(conv.id);
    const supportCalls = (enqueue as unknown as ReturnType<typeof vi.fn>).mock.calls
      .filter((c) => c[1] === "agent.handoff" && c[2]?.toRole === "support");
    expect(supportCalls).toHaveLength(0);
  });
});
