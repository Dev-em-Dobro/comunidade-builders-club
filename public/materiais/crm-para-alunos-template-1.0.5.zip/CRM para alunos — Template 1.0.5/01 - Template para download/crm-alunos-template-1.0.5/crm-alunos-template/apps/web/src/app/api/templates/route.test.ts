import { describe, it, expect, vi, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));

import { GET } from "./route";
import { auth } from "@/auth";

const createdIds: string[] = [];

afterAll(async () => {
  if (createdIds.length > 0) {
    await prisma.messageTemplate.deleteMany({ where: { id: { in: createdIds } } });
  }
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "test-user" } } as never);
});

describe("GET /api/templates", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await GET();
    expect(res.status).toBe(401);
  });

  it("retorna só APPROVED, ordenados por metaName asc", async () => {
    const approved = await prisma.messageTemplate.create({
      data: {
        metaName: `apitest_z_${Date.now()}`,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [],
        variableCount: 0,
      },
    });
    const approved2 = await prisma.messageTemplate.create({
      data: {
        metaName: `apitest_a_${Date.now()}`,
        language: "pt_BR",
        category: "UTILITY",
        status: "APPROVED",
        components: [],
        variableCount: 0,
      },
    });
    const pending = await prisma.messageTemplate.create({
      data: {
        metaName: `apitest_p_${Date.now()}`,
        language: "pt_BR",
        category: "UTILITY",
        status: "PENDING",
        components: [],
        variableCount: 0,
      },
    });
    createdIds.push(approved.id, approved2.id, pending.id);

    const res = await GET();
    expect(res.status).toBe(200);
    const body = (await res.json()) as { templates: Array<{ metaName: string; status: string }> };
    const names = body.templates.map((t) => t.metaName);
    expect(names).toContain(approved.metaName);
    expect(names).toContain(approved2.metaName);
    expect(names).not.toContain(pending.metaName);
    // Ordenação asc por metaName
    const sliced = body.templates.filter((t) => t.metaName.startsWith("apitest_"));
    const sortedNames = [...sliced].sort((a, b) =>
      a.metaName.localeCompare(b.metaName),
    );
    expect(sliced).toEqual(sortedNames);
  });
});
