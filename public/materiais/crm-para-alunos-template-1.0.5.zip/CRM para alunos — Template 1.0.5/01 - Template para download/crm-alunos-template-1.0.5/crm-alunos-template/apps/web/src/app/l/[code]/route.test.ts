import { describe, it, expect, beforeAll, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { GET } from "./route";

const created = {
  contactIds: [] as string[],
  courseIds: [] as string[],
  launchIds: [] as string[],
};

let leadId: string;
let launchLeadId: string;
let courseId: string;
let courseNoUrlId: string;
let validCode: string;
let codeForCourseWithoutUrl: string;
let codePlanWithUrl: string;
let codePlanNoUrl: string;

beforeAll(async () => {
  const contact = await prisma.contact.create({
    data: { displayName: "Lead route test" },
  });
  created.contactIds.push(contact.id);
  const lead = await prisma.lead.create({
    data: { contactId: contact.id, stage: "qualified", interestCourseIds: [] },
  });
  leadId = lead.id;

  const c1 = await prisma.course.create({
    data: {
      name: "Route test C1",
      slug: `route-c1-${Date.now()}`,
      priceCents: 1000,
      checkoutUrl: "https://pay.example.com/c1?ref=x",
    },
  });
  courseId = c1.id;
  created.courseIds.push(c1.id);

  const c2 = await prisma.course.create({
    data: {
      name: "Route test C2",
      slug: `route-c2-${Date.now()}`,
      priceCents: 1000,
      checkoutUrl: "https://pay.example.com/c2",
    },
  });
  courseNoUrlId = c2.id;
  created.courseIds.push(c2.id);

  const sl1 = await prisma.shortLink.create({
    data: { code: `r${Date.now().toString(36).slice(-5)}`, leadId, courseId, sentCount: 1, lastSentAt: new Date() },
  });
  validCode = sl1.code;

  const sl2 = await prisma.shortLink.create({
    data: {
      code: `r${(Date.now() + 1).toString(36).slice(-5)}`,
      leadId,
      courseId: courseNoUrlId,
      sentCount: 1,
      lastSentAt: new Date(),
    },
  });
  codeForCourseWithoutUrl = sl2.code;
  // Now null the checkoutUrl to simulate "operator deleted after sending"
  await prisma.course.update({
    where: { id: courseNoUrlId },
    data: { checkoutUrl: null },
  });

  // Separate lead for launch plan tests (avoids unique constraint on leadId+courseId).
  // Two leads needed: slPlanWithUrl and slPlanNoUrl share the same courseId,
  // so they each need a distinct leadId.
  const launchContact = await prisma.contact.create({
    data: { displayName: "Lead route launch test" },
  });
  created.contactIds.push(launchContact.id);
  const launchLead = await prisma.lead.create({
    data: { contactId: launchContact.id, stage: "qualified", interestCourseIds: [] },
  });
  launchLeadId = launchLead.id;

  const launchContact2 = await prisma.contact.create({
    data: { displayName: "Lead route launch test 2" },
  });
  created.contactIds.push(launchContact2.id);
  const launchLead2 = await prisma.lead.create({
    data: { contactId: launchContact2.id, stage: "qualified", interestCourseIds: [] },
  });
  const launchLeadId2 = launchLead2.id;

  // Launch + LaunchPlan fixtures for launchPlanId tests
  const launch = await prisma.launch.create({
    data: {
      name: "Route test launch",
      slug: `route-launch-${Date.now()}`,
      startsAt: new Date(Date.now() - 86400000),
      endsAt: new Date(Date.now() + 86400000),
      status: "live",
      courseId,
    },
  });
  created.launchIds.push(launch.id);

  const planWithUrl = await prisma.launchPlan.create({
    data: {
      launchId: launch.id,
      name: "Plano com URL",
      priceCents: 1000,
      checkoutUrl: "https://pay.example.com/PLAN-URL",
      sortOrder: 0,
    },
  });
  const planNoUrl = await prisma.launchPlan.create({
    data: {
      launchId: launch.id,
      name: "Plano sem URL",
      priceCents: 2000,
      checkoutUrl: null,
      sortOrder: 1,
    },
  });

  const slPlanWithUrl = await prisma.shortLink.create({
    data: {
      code: `pl${Date.now().toString(36).slice(-4)}`,
      leadId: launchLeadId,
      courseId,
      launchPlanId: planWithUrl.id,
      sentCount: 1,
      lastSentAt: new Date(),
    },
  });
  codePlanWithUrl = slPlanWithUrl.code;

  const slPlanNoUrl = await prisma.shortLink.create({
    data: {
      code: `pn${(Date.now() + 1).toString(36).slice(-4)}`,
      leadId: launchLeadId2,
      courseId,
      launchPlanId: planNoUrl.id,
      sentCount: 1,
      lastSentAt: new Date(),
    },
  });
  codePlanNoUrl = slPlanNoUrl.code;
});

afterAll(async () => {
  // ShortLinks are deleted via lead cascade, but delete explicitly first for safety.
  await prisma.shortLink.deleteMany({ where: { courseId: { in: created.courseIds } } });
  await prisma.launchPlan.deleteMany({ where: { launch: { courseId: { in: created.courseIds } } } });
  await prisma.launch.deleteMany({ where: { courseId: { in: created.courseIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.$disconnect();
});

function fakeReq(): Request {
  return new Request("http://localhost/l/x", {
    headers: { "user-agent": "test-ua", referer: "https://wa.me/" },
  });
}

describe("GET /l/[code]", () => {
  it("redireciona 302 pra checkoutUrl com UTMs", async () => {
    const res = await GET(fakeReq(), { params: Promise.resolve({ code: validCode }) });
    expect(res.status).toBe(302);
    const loc = res.headers.get("location") ?? "";
    expect(loc).toContain("https://pay.example.com/c1?ref=x");
    expect(loc).toContain("utm_source=wa");
    expect(loc).toContain(`utm_content=${leadId}`);
    expect(loc).toContain("utm_campaign=route-c1-");
    expect(res.headers.get("cache-control")).toBe("no-store");

    // Background write — pode não ter rodado ainda; aguarda e checa.
    await new Promise((r) => setTimeout(r, 200));
    const link = await prisma.shortLink.findUniqueOrThrow({ where: { code: validCode } });
    expect(link.clickCount).toBe(1);
    expect(link.lastClickAt).not.toBeNull();

    const ev = await prisma.pipelineEvent.findFirst({
      where: { leadId, type: "cta_click" },
      orderBy: { createdAt: "desc" },
    });
    expect(ev).not.toBeNull();
  });

  it("retorna 404 quando code inválido", async () => {
    const res = await GET(fakeReq(), { params: Promise.resolve({ code: "INVAL1" }) });
    expect(res.status).toBe(404);
  });

  it("retorna 410 quando checkoutUrl virou null após envio", async () => {
    const res = await GET(fakeReq(), {
      params: Promise.resolve({ code: codeForCourseWithoutUrl }),
    });
    expect(res.status).toBe(410);

    // Não grava cta_click nesse caso.
    const link = await prisma.shortLink.findUniqueOrThrow({
      where: { code: codeForCourseWithoutUrl },
    });
    expect(link.clickCount).toBe(0);
  });

  it("redireciona pra LaunchPlan.checkoutUrl quando ShortLink tem launchPlanId", async () => {
    const res = await GET(fakeReq(), { params: Promise.resolve({ code: codePlanWithUrl }) });
    expect(res.status).toBe(302);
    const loc = res.headers.get("location") ?? "";
    expect(loc).toContain("https://pay.example.com/PLAN-URL");
    // UTM campaign continua sendo o slug do course
    expect(loc).toContain("utm_campaign=route-c1-");
  });

  it("retorna 410 quando launchPlan presente mas sem checkoutUrl (não faz fallback pro course)", async () => {
    const res = await GET(fakeReq(), { params: Promise.resolve({ code: codePlanNoUrl }) });
    expect(res.status).toBe(410);
    // course tem URL, mas launchPlan presente sem URL deve dar 410 mesmo assim
  });

  it("pipelineEvent cta_click inclui launchPlanId quando há plano", async () => {
    await GET(fakeReq(), { params: Promise.resolve({ code: codePlanWithUrl }) });
    await new Promise((r) => setTimeout(r, 200));
    const ev = await prisma.pipelineEvent.findFirst({
      where: { leadId: launchLeadId, type: "cta_click" },
      orderBy: { createdAt: "desc" },
    });
    expect(ev).not.toBeNull();
    expect((ev?.payload as { launchPlanId?: string }).launchPlanId).toBeTruthy();
  });
});
