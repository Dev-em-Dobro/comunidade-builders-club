import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/lib/email/resend", () => ({
  sendEmail: vi.fn().mockResolvedValue(undefined),
}));

import { bumpUnreadAndNotify, markConversationRead } from "./unread";
import { sendEmail } from "@/lib/email/resend";

const created = { contactIds: [] as string[] };
let convId: string;
const envBackup = {
  NOTIFY_EMAIL: process.env.NOTIFY_EMAIL,
  PUBLIC_BASE_URL: process.env.PUBLIC_BASE_URL,
};

beforeAll(async () => {
  const contact = await prisma.contact.create({ data: { displayName: "Lead Teste" } });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud" },
  });
  convId = conv.id;
});

afterAll(async () => {
  process.env.NOTIFY_EMAIL = envBackup.NOTIFY_EMAIL;
  process.env.PUBLIC_BASE_URL = envBackup.PUBLIC_BASE_URL;
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

beforeEach(async () => {
  vi.mocked(sendEmail).mockClear();
  vi.mocked(sendEmail).mockResolvedValue(undefined);
  process.env.NOTIFY_EMAIL = "avisos@t.local";
  await prisma.conversation.update({ where: { id: convId }, data: { unreadCount: 0 } });
});

describe("bumpUnreadAndNotify", () => {
  it("incrementa unreadCount pelo nº de msgs e retorna o valor anterior", async () => {
    const r = await bumpUnreadAndNotify({ conversationId: convId, count: 3, preview: "oi" });
    expect(r.previousUnread).toBe(0);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.unreadCount).toBe(3);
  });

  it("transição 0→N envia exatamente 1 email com contato, canal, preview e link", async () => {
    process.env.PUBLIC_BASE_URL = "https://crm.test";
    const r = await bumpUnreadAndNotify({
      conversationId: convId,
      count: 2,
      preview: "quero saber do curso",
    });
    expect(r.emailed).toBe(true);
    expect(sendEmail).toHaveBeenCalledTimes(1);
    const arg = vi.mocked(sendEmail).mock.calls[0]![0];
    expect(arg.to).toEqual(["avisos@t.local"]);
    expect(arg.subject).toContain("Lead Teste");
    expect(arg.text).toContain("whatsapp_cloud");
    expect(arg.text).toContain("quero saber do curso");
    expect(arg.text).toContain(`https://crm.test/conversations/${convId}`);
  });

  it("conversa JÁ não-lida (N>0) não re-envia email", async () => {
    await prisma.conversation.update({ where: { id: convId }, data: { unreadCount: 2 } });
    const r = await bumpUnreadAndNotify({ conversationId: convId, count: 1, preview: "e aí?" });
    expect(r.previousUnread).toBe(2);
    expect(r.emailed).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it("sem NOTIFY_EMAIL setado, incrementa mas não envia", async () => {
    delete process.env.NOTIFY_EMAIL;
    const r = await bumpUnreadAndNotify({ conversationId: convId, count: 1, preview: "oi" });
    expect(r.emailed).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.unreadCount).toBe(1);
  });

  it("falha no sendEmail não propaga (best-effort)", async () => {
    vi.mocked(sendEmail).mockRejectedValueOnce(new Error("Resend: boom"));
    const r = await bumpUnreadAndNotify({ conversationId: convId, count: 1, preview: "oi" });
    expect(r.emailed).toBe(false);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.unreadCount).toBe(1);
  });

  it("count <= 0 é no-op (não incrementa, não envia)", async () => {
    const r = await bumpUnreadAndNotify({ conversationId: convId, count: 0, preview: null });
    expect(r.previousUnread).toBe(0);
    expect(r.emailed).toBe(false);
    expect(sendEmail).not.toHaveBeenCalled();
  });

  it("preview longo é truncado no email", async () => {
    const long = "x".repeat(500);
    await bumpUnreadAndNotify({ conversationId: convId, count: 1, preview: long });
    const arg = vi.mocked(sendEmail).mock.calls[0]![0];
    expect(arg.text).toContain("x".repeat(200));
    expect(arg.text).not.toContain("x".repeat(201));
  });
});

describe("markConversationRead", () => {
  it("zera o contador", async () => {
    await prisma.conversation.update({ where: { id: convId }, data: { unreadCount: 5 } });
    await markConversationRead(convId);
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: convId } });
    expect(conv.unreadCount).toBe(0);
  });

  it("é idempotente e não falha em conversa inexistente", async () => {
    await expect(markConversationRead("missing")).resolves.toBeUndefined();
  });
});
