import { describe, it, expect } from "vitest";
import { looksLikeReturningStudent } from "./student-signals";

describe("looksLikeReturningStudent", () => {
  it("detecta o caso real do incidente (2026-08-20)", () => {
    expect(
      looksLikeReturningStudent(
        "Eu comprei o curso de vcs há um tempo e gostaria de voltar a acessá-lo. Tá me qual site pra fazer login?",
      ),
    ).toBe(true);
  });

  it.each([
    "já comprei o curso",
    "sou aluno e esqueci a senha",
    "não consigo acessar minha conta",
    "perdi o acesso, como recupero?",
    "qual o site pra fazer login?",
    "quero voltar a acessar as aulas",
    "tenho o curso antigo, ainda tenho acesso?",
  ])("casa sinal de aluno/acesso: %s", (msg) => {
    expect(looksLikeReturningStudent(msg)).toBe(true);
  });

  it.each([
    "Oi, tudo bem?",
    "quero saber mais sobre o curso",
    "quanto custa o Dev Quest?",
    "tem algum desconto pra quem quer começar?",
    "vim pelo site e queria informações",
    "",
    null,
    undefined,
  ])("NÃO casa mensagem de prospect/vazia: %s", (msg) => {
    expect(looksLikeReturningStudent(msg)).toBe(false);
  });

  it("ignora acento e caixa", () => {
    expect(looksLikeReturningStudent("VOLTAR A ACESSÁ-LO")).toBe(true);
    expect(looksLikeReturningStudent("esqueci a senha")).toBe(true);
  });
});
