import { auth } from "@/auth";
import Link from "next/link";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChannelCard } from "./_components/channel-card";
import { WhatsappQrCard } from "./_components/whatsapp-qr-card";
import { isChannelEnabled } from "@/lib/config";
import { CheckCircle2, AlertCircle, KeyRound, ArrowRight } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const channels = ["whatsapp_cloud", "instagram"] as const;
  let waqrEnabled = false;
  try { waqrEnabled = isChannelEnabled("whatsapp_qr"); } catch { /* sem setup.config.json: card mostra desligado */ }

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-8">
        <div className="flex items-center gap-2 mb-2">
          <Badge variant="outline" className="font-mono text-[10px]">
            client wizard
          </Badge>
          <Badge className="font-mono text-[10px]">{channels.length + 1} canais</Badge>
        </div>
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Onboarding
        </h1>
        <p className="text-muted-foreground mt-1">
          Conectar canais Meta · configurar o agente · testar fluxo end-to-end.
        </p>
      </header>

      <Tabs defaultValue="channels" className="space-y-6">
        <TabsList>
          <TabsTrigger value="channels">1. Canais</TabsTrigger>
          <TabsTrigger value="agent">2. Agente</TabsTrigger>
          <TabsTrigger value="test">3. Teste</TabsTrigger>
          <TabsTrigger value="done">4. Pronto</TabsTrigger>
        </TabsList>

        {/* ───────────── Canais ───────────── */}
        <TabsContent value="channels" className="space-y-4">
          <WhatsappQrCard initialEnabled={waqrEnabled} />

          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <KeyRound className="size-4 text-primary" />
                Credenciais Meta
              </CardTitle>
              <CardDescription>
                Cadastre as credenciais em <Link className="underline" href="/settings/meta">Configurações → Meta / Business</Link>. Use o guia docs/META.md. Para usar variáveis de ambiente, preencha o .env da raiz e reinicie.              </CardDescription>
            </CardHeader>
            <CardContent>
              <pre className="text-xs bg-muted p-4 rounded-md overflow-x-auto">
{`# WhatsApp Cloud API
META_APP_ID=
META_APP_SECRET=
META_PHONE_NUMBER_ID=
META_BUSINESS_ACCOUNT_ID=
META_SYSTEM_USER_TOKEN=
META_WEBHOOK_VERIFY_TOKEN=valor_gerado_pelo_setup

# Instagram Direct (mesmo App Meta, aba Instagram Graph)
META_IG_BUSINESS_ACCOUNT_ID=
META_IG_PAGE_ID=
META_IG_PAGE_ACCESS_TOKEN=`}
              </pre>
            </CardContent>
          </Card>

          <div className="grid gap-4 md:grid-cols-2">
            {channels.map((c) => (
              <ChannelCard key={c} channelId={c} />
            ))}
          </div>
        </TabsContent>

        {/* ───────────── Agente ───────────── */}
        <TabsContent value="agent">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Configurar agente padrão</CardTitle>
              <CardDescription>
                Crie pelo menos 1 <code>AgentSession</code> marcada como{" "}
                <code>isDefault</code>. O orquestrador usa essa quando a
                conversa não tem agente específico.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/settings/agents" className={buttonVariants()}>
                Ir pra Agentes <ArrowRight className="size-4" />
              </Link>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ───────────── Teste ───────────── */}
        <TabsContent value="test">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <AlertCircle className="size-4 text-warning" /> Smoke test
              </CardTitle>
              <CardDescription>
                Enviar 3 msgs em sequência (intervalo &lt; 5s) do seu número
                pro número da Cloud API. Esperado: 1 resposta coalesced em
                ~5000ms + LLM latency (gotcha 0.9.23 + §0.9.18 logs).
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p className="text-muted-foreground">
                Logs a observar (Railway → app → Logs):
              </p>
              <ul className="font-mono text-xs space-y-1 ml-4 list-disc">
                <li>webhook.whatsapp_cloud.recv</li>
                <li>debounce.flush (count: 3)</li>
                <li>flush.decided action=respond</li>
                <li>flush.llm_call</li>
                <li>flush.sent_ok</li>
              </ul>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ───────────── Pronto ───────────── */}
        <TabsContent value="done">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <CheckCircle2 className="size-4 text-success" /> Checklist final
              </CardTitle>
              <CardDescription>
                Antes de ativar um canal em Configurações → Geral, confirme suas credenciais, assinatura do webhook, chave de IA, agente e teste real de mensagem. Esta aba é um checklist; ela não certifica a conexão.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href="/dashboard" className={buttonVariants()}>
                Ir pro Dashboard <ArrowRight className="size-4" />
              </Link>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
