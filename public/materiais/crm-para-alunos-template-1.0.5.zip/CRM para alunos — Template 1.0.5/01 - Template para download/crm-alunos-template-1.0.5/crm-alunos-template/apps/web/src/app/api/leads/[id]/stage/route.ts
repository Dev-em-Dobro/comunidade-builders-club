import { NextResponse } from "next/server";
import { z } from "zod";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const VALID_STAGES = ["new", "contacted", "qualified", "proposal", "won", "lost"] as const;
const TERMINAL_STAGES = new Set(["won", "lost", "proposal"]);

const BodySchema = z
  .object({
    stage: z.enum(VALID_STAGES).optional(),
    lastFollowUpStep: z
      .union([z.literal(null), z.number().int().min(1).max(3)])
      .optional(),
  })
  .refine(
    (obj) => obj.stage !== undefined || obj.lastFollowUpStep !== undefined,
    { message: "Informe ao menos stage ou lastFollowUpStep" },
  );

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { id } = await params;
  const raw = await req.json().catch(() => null);
  const parsed = BodySchema.safeParse(raw);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Payload inválido" },
      { status: 400 },
    );
  }

  const lead = await prisma.lead.findUnique({
    where: { id },
    select: { id: true, stage: true, lastFollowUpStep: true },
  });
  if (!lead) {
    return NextResponse.json({ error: "Lead não encontrado" }, { status: 404 });
  }

  // Guard de stage terminal — não pode regredir de proposal/won/lost
  if (
    parsed.data.stage !== undefined &&
    TERMINAL_STAGES.has(lead.stage) &&
    parsed.data.stage !== lead.stage
  ) {
    return NextResponse.json(
      { error: "Stage terminal não pode regredir — edite manualmente no detalhe do lead se necessário" },
      { status: 400 },
    );
  }

  const updates: { stage?: string; lastFollowUpStep?: number | null; lastFollowUpAt?: Date | null } = {};
  if (parsed.data.stage !== undefined) updates.stage = parsed.data.stage;
  if (parsed.data.lastFollowUpStep !== undefined) {
    updates.lastFollowUpStep = parsed.data.lastFollowUpStep;
    updates.lastFollowUpAt =
      parsed.data.lastFollowUpStep === null ? null : new Date();
  }

  await prisma.$transaction(async (tx) => {
    await tx.lead.update({
      where: { id: lead.id },
      data: updates,
    });
    if (parsed.data.stage !== undefined && parsed.data.stage !== lead.stage) {
      await tx.pipelineEvent.create({
        data: {
          leadId: lead.id,
          type: "stage_change",
          payload: {
            from: lead.stage,
            to: parsed.data.stage,
            via: "manual_drag",
          },
        },
      });
    }
    if (
      parsed.data.lastFollowUpStep !== undefined &&
      parsed.data.lastFollowUpStep !== lead.lastFollowUpStep
    ) {
      await tx.pipelineEvent.create({
        data: {
          leadId: lead.id,
          type: "followup_step_change",
          payload: {
            from: lead.lastFollowUpStep,
            to: parsed.data.lastFollowUpStep,
            via: "manual_drag",
          },
        },
      });
    }
  });

  return NextResponse.json({ ok: true });
}
