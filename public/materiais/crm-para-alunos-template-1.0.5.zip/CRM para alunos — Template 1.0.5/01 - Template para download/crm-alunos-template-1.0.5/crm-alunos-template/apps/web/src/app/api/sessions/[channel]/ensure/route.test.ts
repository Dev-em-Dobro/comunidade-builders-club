import { describe, it, expect, vi, beforeEach } from "vitest";

vi.mock("@/auth", () => ({
  auth: vi.fn(),
}));

import { POST } from "./route";
import { auth } from "@/auth";

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: "u1", role: "admin" } } as never);
});

function req(): Request {
  return new Request("http://test", { method: "POST" });
}

describe("POST /api/sessions/[channel]/ensure", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await POST(req(), {
      params: Promise.resolve({ channel: "nope" }),
    });
    expect(res.status).toBe(401);
  });

  it("403 operador não pode inscrever aplicativos Meta", async () => {
    vi.mocked(auth).mockResolvedValueOnce({ user: { id: "operator", role: "operator" } } as never);
    const res = await POST(req(), { params: Promise.resolve({ channel: "instagram" }) });
    expect(res.status).toBe(403);
  });

  it("404 canal desconhecido com sessão", async () => {
    const res = await POST(req(), {
      params: Promise.resolve({ channel: "nope" }),
    });
    expect(res.status).toBe(404);
  });
});
