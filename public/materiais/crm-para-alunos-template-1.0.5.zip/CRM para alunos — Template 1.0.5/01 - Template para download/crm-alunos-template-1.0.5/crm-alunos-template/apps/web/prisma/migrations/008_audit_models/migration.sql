-- CreateTable
CREATE TABLE "AuditCriterion" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "exampleFail" TEXT,
    "weight" INTEGER NOT NULL DEFAULT 3,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AuditCriterion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditReport" (
    "id" TEXT NOT NULL,
    "runAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "status" TEXT NOT NULL DEFAULT 'queued',
    "conversationIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
    "trigger" TEXT NOT NULL DEFAULT 'manual',
    "summary" TEXT,
    "costUsd" DECIMAL(10,6),
    "modelUsed" TEXT,
    "finishedAt" TIMESTAMP(3),
    "errorMessage" TEXT,

    CONSTRAINT "AuditReport_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AuditFinding" (
    "id" TEXT NOT NULL,
    "reportId" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "contactDisplaySnapshot" TEXT,
    "criterionId" TEXT,
    "criterionNameSnapshot" TEXT NOT NULL,
    "verdict" TEXT NOT NULL,
    "severity" INTEGER,
    "evidence" TEXT,
    "recommendation" TEXT,
    "freeNotes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AuditFinding_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "AuditCriterion_active_idx" ON "AuditCriterion"("active");

-- CreateIndex
CREATE INDEX "AuditReport_runAt_idx" ON "AuditReport"("runAt");

-- CreateIndex
CREATE INDEX "AuditReport_status_idx" ON "AuditReport"("status");

-- CreateIndex
CREATE INDEX "AuditFinding_reportId_criterionId_idx" ON "AuditFinding"("reportId", "criterionId");

-- CreateIndex
CREATE INDEX "AuditFinding_conversationId_idx" ON "AuditFinding"("conversationId");

-- AddForeignKey
ALTER TABLE "AuditFinding" ADD CONSTRAINT "AuditFinding_reportId_fkey"
    FOREIGN KEY ("reportId") REFERENCES "AuditReport"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AuditFinding" ADD CONSTRAINT "AuditFinding_criterionId_fkey"
    FOREIGN KEY ("criterionId") REFERENCES "AuditCriterion"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- Seed dos 8 critérios default.
-- IDs são cuids fixos pra serem referenciáveis em tests/migrations futuras se preciso.
INSERT INTO "AuditCriterion" ("id", "name", "description", "exampleFail", "weight", "active", "createdAt", "updatedAt") VALUES
  ('audit_crit_repeat_question',    'Não repetiu pergunta',
   'O bot não deve perguntar duas vezes a mesma coisa quando o lead já respondeu. Quando o lead ignorou a 1ª pergunta, repetir é OK.',
   'Bot perguntou "Qual seu objetivo?" no turno 3 e novamente no turno 7 mesmo após o lead responder claramente no turno 4.',
   4, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_correct_price',      'Preço correto',
   'Qualquer valor monetário mencionado pelo bot deve bater com o catálogo de cursos. Inventar preço é fail crítico.',
   'Catálogo diz R$ 497,00 mas o bot disse R$ 397,00.',
   5, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_correct_info',       'Informação correta',
   'O bot não deve inventar regra, política, feature, garantia ou prazo do curso que não esteja no catálogo ou na base de conhecimento (RAG).',
   'Bot prometeu "garantia de 30 dias" mas o curso não tem essa política.',
   5, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_answered_objection', 'Respondeu a objeção',
   'Quando o lead levanta objeção (preço, tempo, cônjuge, etc.), o bot deve tratá-la antes de empurrar o pedido.',
   'Lead disse "está caro" e o bot mandou o link de checkout sem responder a objeção.',
   4, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_advanced_funnel',    'Avançou o funil',
   'Quando há sinal de qualificação clara, o bot deve mover o lead pra próxima etapa (link, handoff, marcar ready_to_buy) em vez de continuar perguntando.',
   'Lead pediu "como faço pra comprar?" mas o bot continuou com perguntas de qualificação.',
   3, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_tone',               'Tom adequado',
   'Tom formal/informal coerente com a marca, sem agressividade, sem subserviência exagerada, sem girias inadequadas.',
   'Bot respondeu com "FALOU MEU AMIGO!!! BORA FECHAR!!!" em conversa B2B.',
   3, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_latency',            'Latência aceitável',
   'Sem gaps absurdos entre turnos do bot (>1h sem causa identificável como handoff ou janela 24h fechada).',
   'Lead mandou pergunta às 14:00 e bot só respondeu às 19:00 sem motivo aparente.',
   2, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('audit_crit_recognized_limit',   'Reconheceu limite',
   'Quando não sabe responder, o bot deve pedir handoff humano em vez de inventar resposta.',
   'Lead perguntou sobre política de reembolso (não documentada) e bot inventou "30 dias para devolução".',
   4, true, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
