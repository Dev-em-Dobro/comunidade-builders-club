import { NextResponse } from "next/server";
import { requireSession } from "@/lib/api-auth";
import { prisma } from "@/lib/db";
import { getAdapter } from "@/lib/channels/registry";
import { channelHasMessagingWindow, isWithin24hWindow } from "@/lib/window24h";
import { ChannelSendError, META_OUT_OF_WINDOW } from "@/lib/channels/meta-graph";
import { notifyMessage, notifyConvEvent } from "@/lib/realtime/notify";
import { claimConversation } from "@/lib/conversations/claim";
import type { ChannelId } from "@/lib/channels/types";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_TEXT_LEN = 4096; // limite WA Cloud

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
): Promise<Response> {
  const gate = await requireSession();
  if (gate instanceof NextResponse) return gate;
  const { user } = gate;
  const { id: conversationId } = await params;
  const body = (await req.json().catch(() => null)) as { text?: string } | null;
  const text = (body?.text ?? "").trim();
  if (!text) return NextResponse.json({ error: "empty" }, { status: 400 });
  if (text.length > MAX_TEXT_LEN) {
    return NextResponse.json(
      { error: "text_too_long", max: MAX_TEXT_LEN },
      { status: 400 },
    );
  }

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    include: { contact: { include: { identities: true } } },
  });
  if (!conv) return NextResponse.json({ error: "not_found" }, { status: 404 });

  // Bloqueio preventivo da janela 24h (decisão #4 do spec).
  if (channelHasMessagingWindow(conv.channel) && !isWithin24hWindow(conv.windowClosesAt)) {
    return NextResponse.json(
      { error: "window_closed", windowClosesAt: conv.windowClosesAt },
      { status: 409 },
    );
  }

  const ident = conv.contact?.identities.find((i) => i.channel === conv.channel);
  if (!ident) {
    return NextResponse.json({ error: "no_identity" }, { status: 500 });
  }

  // Auto-claim: quem manda 1ª msg numa conversa sem dono vira dono.
  // Falha não bloqueia o envio (claimResult vira null e seguimos sem notify).
  let claimResult: Awaited<ReturnType<typeof claimConversation>> | null = null;
  try {
    claimResult = await claimConversation(conversationId, user.id);
  } catch (err) {
    console.error(
      JSON.stringify({
        event: "send.auto_claim_failed",
        conversationId,
        error: String((err as Error)?.message ?? err),
      }),
    );
  }

  // Send-then-persist: se a Meta rejeitar, zero msg fantasma no DB.
  try {
    const adapter = getAdapter(conv.channel as ChannelId);
    await adapter.sendText(ident.externalId, text);
  } catch (err) {
    if (err instanceof ChannelSendError && err.code === META_OUT_OF_WINDOW) {
      await prisma.conversation.update({
        where: { id: conversationId },
        data: { windowExpired: true },
      });
      return NextResponse.json({ error: "window_closed_meta" }, { status: 409 });
    }
    return NextResponse.json(
      { error: "send_failed", detail: String((err as Error)?.message ?? err) },
      { status: 502 },
    );
  }

  const saved = await prisma.message.create({
    data: {
      conversationId,
      direction: "outbound",
      role: "assistant", // decisão #3: indistinguível pro loadMemory
      text,
      sentByUserId: user.id,
      // modelUsed, tokensIn/Out, costUsd ficam null — discriminador implícito
    },
  });

  const now = new Date();
  await prisma.conversation.update({
    where: { id: conversationId },
    data: { lastMessageAt: now, lastOutboundAt: now },
  });

  await notifyMessage(conversationId, saved.id);

  // Se reclamamos a conversa agora, outras abas precisam saber pra atualizar o
  // badge "Atendente: <nome>" — o estado `assignedUserId` no client é
  // independente do estado de mensagens.
  if (claimResult?.claimed) {
    const actor = await prisma.user.findUnique({
      where: { id: user.id },
      select: { name: true },
    });
    await notifyConvEvent(conversationId, {
      type: "claim",
      userId: user.id,
      userName: actor?.name ?? null,
      previousOwnerId: claimResult.previousOwnerId,
    });
  }

  return NextResponse.json({
    ok: true,
    messageId: saved.id,
    createdAt: saved.createdAt,
  });
}
