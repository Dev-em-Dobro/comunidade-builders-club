import Link from "next/link";
import { prisma } from "@/lib/db";
import { auth } from "@/auth";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Plus, Rocket } from "lucide-react";
import { DeleteLaunchButton } from "./delete-launch-button";

export const dynamic = "force-dynamic";

const STATUS_VARIANT: Record<string, "default" | "secondary" | "outline"> = {
  live: "default",
  planned: "secondary",
  closed: "outline",
};

export default async function LaunchesPage() {
  const session = await auth();
  const isAdmin = (session?.user as { role?: string } | undefined)?.role === "admin";
  const launches = await safeQuery();

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Lançamentos
          </h1>
          <p className="text-muted-foreground mt-1">
            Janelas comerciais — cada Lead pode pertencer a um lançamento.
          </p>
        </div>
        {isAdmin && (
          <Link href="/launches/new" className={buttonVariants()}>
            <Plus className="size-4" /> Novo lançamento
          </Link>
        )}
      </header>

      {launches.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <Rocket className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhum lançamento</p>
          <p className="text-sm text-muted-foreground mt-1">
            Crie um pra associar leads e medir o funil de conversão.
          </p>
          {isAdmin && (
            <Link
              href="/launches/new"
              className={buttonVariants({ className: "mt-4" })}
            >
              <Plus className="size-4" /> Criar lançamento
            </Link>
          )}
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Nome</TableHead>
                <TableHead>Curso</TableHead>
                <TableHead>Período</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Planos</TableHead>
                <TableHead className="text-right">Leads</TableHead>
                <TableHead className="text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {launches.map((l) => (
                <TableRow key={l.id}>
                  <TableCell className="font-medium">
                    {l.name}
                    <div className="text-xs text-muted-foreground font-mono mt-0.5">{l.slug}</div>
                  </TableCell>
                  <TableCell className="text-sm">
                    {l.course?.name ?? <span className="text-muted-foreground italic">—</span>}
                  </TableCell>
                  <TableCell className="text-sm">
                    {fmtDate(l.startsAt)} → {fmtDate(l.endsAt)}
                  </TableCell>
                  <TableCell>
                    <Badge variant={STATUS_VARIANT[l.status] ?? "outline"}>
                      {l.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-mono text-right">{l._count.plans}</TableCell>
                  <TableCell className="font-mono text-right">{l._count.leads}</TableCell>
                  <TableCell className="text-right">
                    <div className="inline-flex items-center gap-1 justify-end">
                      <Link
                        href={`/launches/${l.id}`}
                        className={buttonVariants({ size: "sm", variant: "outline" })}
                      >
                        {isAdmin ? "Editar" : "Ver"}
                      </Link>
                      {isAdmin && (
                        <DeleteLaunchButton launchId={l.id} launchName={l.name} />
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}

function fmtDate(d: Date): string {
  return d.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

async function safeQuery() {
  try {
    return await prisma.launch.findMany({
      orderBy: { updatedAt: "desc" },
      include: {
        _count: { select: { leads: true, plans: true } },
        course: { select: { name: true } },
      },
    });
  } catch {
    return [];
  }
}
