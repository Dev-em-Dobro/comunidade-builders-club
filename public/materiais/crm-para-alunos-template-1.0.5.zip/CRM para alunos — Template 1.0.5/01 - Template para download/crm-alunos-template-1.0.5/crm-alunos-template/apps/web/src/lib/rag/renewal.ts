import type { RetrievedChunk } from "./retrieve";

export interface RenewalConversationTurn {
  role: string;
  content: string;
}

function normalize(text: string): string {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

/** Detecta perguntas que pedem renovar o curso ou o acesso. */
export function isRenewalRequest(text: string): boolean {
  return /\brenov\w*\b/.test(normalize(text));
}

/** Mantém no fluxo comercial escolhas curtas que seguem uma oferta de renovação. */
export function isRenewalFollowup(messages: RenewalConversationTurn[]): boolean {
  let latestUserIndex = -1;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === "user") {
      latestUserIndex = i;
      break;
    }
  }
  if (latestUserIndex < 0) return false;

  const latestUserText = messages[latestUserIndex]!.content;
  const normalizedLatest = normalize(latestUserText);
  if (/\b(?:quero falar com|preciso falar com|me transfere|me transfira|chama alguem|quero atendimento)\b/.test(normalizedLatest)) {
    return false;
  }
  if (isRenewalRequest(latestUserText)) return true;

  const recentStart = Math.max(0, latestUserIndex - 7);
  const recent = messages.slice(recentStart, latestUserIndex + 1);
  const renewalAskIndex = recent.findIndex(
    (turn) => turn.role === "user" && isRenewalRequest(turn.content),
  );
  if (renewalAskIndex < 0) return false;

  const receivedOffer = recent
    .slice(renewalAskIndex + 1, -1)
    .some(
      (turn) =>
        turn.role === "assistant" &&
        /R\$\s*\d[\d.,]*/i.test(turn.content) &&
        /https?:\/\/\S+/i.test(turn.content),
    );
  if (!receivedOffer) return false;

  const reply = normalizedLatest;
  return (
    /\b(?:nao tenho|nao possuo|estou sem|to sem|sem)\b.{0,30}\b(?:cartao|limite)\b/.test(reply) ||
    /\b(?:cartao|limite)\b.{0,30}\b(?:sem|insuficiente|acabou|estourou)\b/.test(reply) ||
    /\b(?:1|um|2|dois)\s+anos?\b/.test(reply) ||
    /\bmais barato\b|\bmais caro\b|\b(?:a )?(?:primeira|segunda) opcao\b/.test(reply)
  );
}

/** Só libera TMB quando o lead diz que não tem cartão ou limite suficiente. */
export function hasNoCardOrLimitSignal(messages: RenewalConversationTurn[]): boolean {
  let lastRenewalIndex = -1;
  for (let i = messages.length - 1; i >= 0; i -= 1) {
    if (messages[i]?.role === "user" && isRenewalRequest(messages[i]!.content)) {
      lastRenewalIndex = i;
      break;
    }
  }
  if (lastRenewalIndex < 0) return false;

  const userTexts = messages
    .slice(lastRenewalIndex)
    .filter((turn) => turn.role === "user")
    .map((turn) => normalize(turn.content));

  return userTexts.some(
    (text) =>
      /\b(?:nao tenho|nao possuo|estou sem|to sem|sem)\b.{0,30}\b(?:cartao|limite)\b/.test(text) ||
      /\b(?:limite|cartao)\b.{0,30}\b(?:insuficiente|acabou|estourou|sem limite|nao tem limite)\b/.test(text),
  );
}

/** Só trata a renovação como respondível quando o RAG achou preço e link. */
export function hasRenewalDetails(hits: RetrievedChunk[]): boolean {
  const context = hits.map((hit) => hit.text).join("\n");
  return (
    isRenewalRequest(context) &&
    /R\$\s*\d[\d.,]*/i.test(context) &&
    /https?:\/\/\S+/i.test(context)
  );
}

export function hasHublaRenewalDetails(hits: RetrievedChunk[]): boolean {
  const context = hits.map((hit) => hit.text).join("\n");
  return (
    isRenewalRequest(context) &&
    /R\$\s*\d[\d.,]*/i.test(context) &&
    /pay\.hub\.la\//i.test(context)
  );
}

export function hasTmbRenewalDetails(hits: RetrievedChunk[]): boolean {
  return /pay\.tmb\.com\.br\//i.test(hits.map((hit) => hit.text).join("\n"));
}

export function buildRenewalAnswerDirective(
  opts: { tmbEligible: boolean; hublaAlreadyOffered: boolean },
): string {
  const lines = [
    "# Renovação — prioridade Hubla",
    "A pessoa está renovando acesso já existente. Resolva a renovação diretamente com os dados do FAQ; não encaminhe para suporte apenas por ela já ser aluna.",
  ];

  if (opts.hublaAlreadyOffered) {
    lines.push(
      "Os links Hubla já foram enviados nesta conversa; não repita toda a lista. " +
        "Se a pessoa escolher um plano, confirme a escolha e reenvie o link Hubla daquele plano.",
    );
  } else {
    lines.push(
      "Ofereça PRIMEIRO somente os planos Hubla para cartão, com valores e links correspondentes exatamente como aparecem no FAQ. Se houver mais de um prazo, liste cada opção e seu link e pergunte qual prefere.",
    );
  }

  if (opts.tmbEligible) {
    lines.push(
      "A pessoa informou que não tem cartão ou limite suficiente. Agora pode oferecer o TMB como alternativa de boleto parcelado; use os preços e links pay.tmb.com.br do FAQ e não use renegocia.tmb.com.br como checkout.",
    );
  } else {
    lines.push(
      "Não mencione TMB, boleto parcelado, preços nem links TMB até a pessoa informar que não tem cartão ou limite suficiente no cartão.",
    );
  }

  return lines.join("\n");
}
