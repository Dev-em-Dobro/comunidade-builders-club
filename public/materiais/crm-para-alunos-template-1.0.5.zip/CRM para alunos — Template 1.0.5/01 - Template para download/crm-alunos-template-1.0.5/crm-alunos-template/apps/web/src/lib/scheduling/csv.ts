/**
 * CSV pra abrir direto no Excel em português e no Google Planilhas.
 *
 * - Separador ";" (Excel pt-BR usa vírgula como decimal e espera ponto e vírgula).
 * - BOM UTF-8 no início, senão o Excel quebra os acentos.
 * - Células que começam com = + - @ ganham um apóstrofo: a resposta do
 *   paciente não pode virar fórmula na planilha de quem baixa.
 */

const FORMULA_START = /^[=+\-@\t\r]/;

export function csvCell(value: unknown): string {
  let s = value === null || value === undefined ? "" : String(value);
  if (FORMULA_START.test(s)) s = `'${s}`;
  if (/[";\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

export function toCsv(rows: unknown[][]): string {
  return "﻿" + rows.map((r) => r.map(csvCell).join(";")).join("\r\n") + "\r\n";
}
