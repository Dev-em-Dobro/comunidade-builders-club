import { CourseForm } from "../course-form";

export default function NewCoursePage() {
  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Novo curso
        </h1>
        <p className="text-muted-foreground mt-1">
          Um produto do catálogo — nome, slug e preço.
        </p>
      </header>
      <CourseForm />
    </div>
  );
}
