/**
 * Campos da pré-consulta configurados no agente (AgentSession.intakeFields).
 * Cada campo vira uma propriedade do input do tool `book_appointment` — os
 * obrigatórios entram no `required` do JSON Schema e são revalidados no servidor.
 */

export interface IntakeField {
  /** Identificador estável (snake_case, sem acento). */
  key: string;
  /** Pergunta/rótulo mostrado ao agente e no evento. */
  label: string;
  required: boolean;
}

export const MAX_INTAKE_FIELDS = 15;
const MAX_ANSWER_LEN = 1000;

export const DEFAULT_INTAKE_FIELDS: IntakeField[] = [
  { key: "nome_completo", label: "Nome completo do paciente", required: true },
  { key: "data_nascimento", label: "Data de nascimento", required: true },
  { key: "motivo_consulta", label: "Motivo da consulta / principais sintomas", required: true },
  { key: "convenio", label: "Convênio (ou particular)", required: false },
  { key: "primeira_consulta", label: "É a primeira consulta com o profissional?", required: false },
];

/** "Data de nascimento" → "data_de_nascimento". */
export function slugifyKey(label: string): string {
  return label
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 40);
}

/** Lê/valida a lista vinda do banco ou do formulário. Chaves duplicadas recebem sufixo. */
export function normalizeIntakeFields(raw: unknown): IntakeField[] {
  if (!Array.isArray(raw)) return [];
  const seen = new Set<string>();
  const out: IntakeField[] = [];
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const label = String((item as { label?: unknown }).label ?? "").trim().slice(0, 200);
    if (!label) continue;
    let key = slugifyKey(String((item as { key?: unknown }).key ?? "") || label) || "campo";
    const base = key;
    for (let n = 2; seen.has(key); n++) key = `${base}_${n}`;
    seen.add(key);
    out.push({ key, label, required: (item as { required?: unknown }).required === true });
    if (out.length >= MAX_INTAKE_FIELDS) break;
  }
  return out;
}

/** Mantém só as chaves conhecidas, como string aparada e com tamanho limitado. */
export function cleanIntakeAnswers(
  fields: IntakeField[],
  raw: unknown,
): Record<string, string> {
  const out: Record<string, string> = {};
  if (!raw || typeof raw !== "object") return out;
  for (const f of fields) {
    const v = (raw as Record<string, unknown>)[f.key];
    if (v == null) continue;
    const s = String(v).trim().slice(0, MAX_ANSWER_LEN);
    if (s) out[f.key] = s;
  }
  return out;
}

export function missingRequired(
  fields: IntakeField[],
  answers: Record<string, string>,
): IntakeField[] {
  return fields.filter((f) => f.required && !answers[f.key]);
}

/** Tenta achar o nome do paciente nas respostas (campo cuja chave contém "nome"). */
export function patientNameFrom(
  fields: IntakeField[],
  answers: Record<string, string>,
): string | null {
  const f = fields.find((x) => x.key.includes("nome") && answers[x.key]);
  return f ? answers[f.key]! : null;
}
