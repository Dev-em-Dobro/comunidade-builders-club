"use server";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { encryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";
import { WAQR_FIELDS, validateWaqrValue } from "@/lib/settings/whatsapp-qr-fields";
import { WAQR_CREDENTIAL_PREFIX } from "@/lib/settings/whatsapp-qr";
import { revalidatePath } from "next/cache";

export async function saveWaqr(_previous: { error?: string; message?: string }, form: FormData): Promise<{ error?: string; message?: string }> {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Somente o administrador pode alterar as credenciais." };
  if (!secretsKeyConfigured()) return { error: "Configure SECRETS_KEY no servidor antes de salvar." };
  const entries = WAQR_FIELDS
    .map((field) => ({ ...field, value: String(form.get(field.key) || "").trim().replace(/\/+$/, "") }))
    .filter((field) => field.value);
  for (const field of entries) {
    if (!validateWaqrValue(field.value, field.kind)) {
      return { error: `Valor inválido: ${field.label}. URLs começam com http:// ou https://; chaves não podem conter espaços.` };
    }
  }
  if (!entries.length) return { message: "Nenhum valor alterado. Campos vazios preservam a configuração atual." };
  try {
    await prisma.$transaction(entries.map(({ key, value }) => prisma.providerCredential.upsert({
      where: { provider: `${WAQR_CREDENTIAL_PREFIX}${key}` },
      create: { provider: `${WAQR_CREDENTIAL_PREFIX}${key}`, apiKeyEnc: encryptSecret(value) },
      update: { apiKeyEnc: encryptSecret(value), hint: null },
    })));
  } catch { return { error: "Não foi possível salvar as credenciais. Verifique o banco de dados." }; }
  revalidatePath("/settings/whatsapp-qr");
  return { message: "Configuração salva e criptografada. Use \"Garantir sessão\" no onboarding e depois leia o QR." };
}

export async function clearWaqr() {
  const session = await auth();
  if (session?.user?.role !== "admin") throw new Error("Acesso negado");
  await prisma.providerCredential.deleteMany({
    where: { provider: { in: WAQR_FIELDS.map(({ key }) => `${WAQR_CREDENTIAL_PREFIX}${key}`) } },
  });
  revalidatePath("/settings/whatsapp-qr");
}
