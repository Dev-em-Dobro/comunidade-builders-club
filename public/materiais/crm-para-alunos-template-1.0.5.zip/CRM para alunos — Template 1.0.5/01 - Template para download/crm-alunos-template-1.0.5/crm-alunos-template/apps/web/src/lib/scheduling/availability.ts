/**
 * Cálculo de horários livres — função pura (sem banco, sem Google).
 *
 * livre = horário de atendimento (semana padrão, ou a exceção do dia)
 *         − intervalos ocupados (consultas do CRM + free/busy do Google, se vinculado)
 *         − horários antes de `now + minNoticeMin`
 */
import { addDays, minutesOf, timeOf, weekdayOf, zonedToUtc } from "./time";
import type { DayOverrides, WorkingHours } from "./working-hours";

export interface BusyRange {
  start: Date;
  end: Date;
}

export interface Slot {
  start: Date;
  end: Date;
  /** YYYY-MM-DD no fuso do negócio */
  date: string;
  /** HH:MM no fuso do negócio */
  time: string;
}

export interface ComputeSlotsInput {
  workingHours: WorkingHours;
  /** Exceções por data — substituem a semana padrão naquele dia. */
  overrides?: DayOverrides;
  durationMin: number;
  busy: BusyRange[];
  /** Primeiro dia (YYYY-MM-DD, fuso do negócio). */
  fromDate: string;
  /** Quantos dias a partir de fromDate (inclusive). */
  days: number;
  now: Date;
  tz: string;
  /** Antecedência mínima pra marcar. Default 60 min. */
  minNoticeMin?: number;
}

export function overlaps(a: BusyRange, b: BusyRange): boolean {
  return a.start < b.end && a.end > b.start;
}

export function computeSlots(input: ComputeSlotsInput): Slot[] {
  const duration = Math.max(5, Math.floor(input.durationMin));
  const earliest = new Date(input.now.getTime() + (input.minNoticeMin ?? 60) * 60_000);
  const slots: Slot[] = [];

  for (let i = 0; i < input.days; i++) {
    const date = addDays(input.fromDate, i);
    const intervals = input.overrides?.[date] ?? input.workingHours[String(weekdayOf(date))] ?? [];
    for (const interval of intervals) {
      const endMin = minutesOf(interval.end);
      for (let t = minutesOf(interval.start); t + duration <= endMin; t += duration) {
        const time = timeOf(t);
        const start = zonedToUtc(date, time, input.tz);
        const end = new Date(start.getTime() + duration * 60_000);
        if (start < earliest) continue;
        const candidate = { start, end };
        if (input.busy.some((b) => overlaps(candidate, b))) continue;
        slots.push({ start, end, date, time });
      }
    }
  }
  return slots;
}

/** Agrupa slots por dia, preservando a ordem. */
export function groupSlotsByDate(slots: Slot[]): { date: string; times: string[] }[] {
  const out: { date: string; times: string[] }[] = [];
  for (const s of slots) {
    const last = out[out.length - 1];
    if (last && last.date === s.date) last.times.push(s.time);
    else out.push({ date: s.date, times: [s.time] });
  }
  return out;
}
