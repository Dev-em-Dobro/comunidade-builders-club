import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { secretsKeyConfigured } from "@/lib/crypto/secrets";
import { CredentialForm } from "./_components/credential-form";

export const dynamic = "force-dynamic";

const PROVIDERS: { id: string; label: string }[] = [
  { id: "anthropic", label: "Anthropic (Claude)" },
  { id: "openai", label: "OpenAI (GPT)" },
];

export default async function CredentialsPage() {
  const session = await auth();
  if (session?.user?.role !== "admin") return <p className="p-8">Acesso exclusivo do administrador.</p>;
  const creds = await safeQuery();
  const byProvider = new Map(creds.map((c) => [c.provider, c]));
  const secretsOk = secretsKeyConfigured();

  return (
    <div className="p-6 md:p-8 max-w-2xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">Chaves de API</h1>
        <p className="text-muted-foreground mt-1">
          Configure as chaves dos providers de LLM. Guardadas criptografadas; nunca exibidas de volta.
        </p>
      </header>

      {!secretsOk && (
        <p className="mb-4 rounded-md border border-destructive/40 bg-destructive/5 p-3 text-sm text-destructive">
          <code>SECRETS_KEY</code> não está configurada no servidor. Defina essa variável de ambiente
          para habilitar o armazenamento seguro de chaves. Enquanto isso, o sistema usa apenas as
          env vars <code>ANTHROPIC_API_KEY</code> / <code>OPENAI_API_KEY</code>.
        </p>
      )}

      <div className="space-y-4">
        {PROVIDERS.map((p) => {
          const cred = byProvider.get(p.id);
          return (
            <CredentialForm
              key={p.id}
              provider={p.id}
              label={p.label}
              configured={Boolean(cred)}
              hint={cred?.hint ?? null}
            />
          );
        })}
      </div>
    </div>
  );
}

async function safeQuery() {
  try {
    return await prisma.providerCredential.findMany({
      select: { provider: true, hint: true },
    });
  } catch {
    return [];
  }
}
