"use client";

import { useTransition, useState } from "react";
import { Button } from "@/components/ui/button";
import { Play, Square, Loader2 } from "lucide-react";
import { activateLaunchAction, closeLaunchAction } from "@/app/(app)/launches/actions";

interface Props {
  launchId: string;
  status: string;
}

export function StatusToggle({ launchId, status }: Props) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const activate = () =>
    start(async () => {
      setError(null);
      const r = await activateLaunchAction(launchId);
      if (r.error) setError(r.error);
    });

  const close = () =>
    start(async () => {
      setError(null);
      const r = await closeLaunchAction(launchId);
      if (r.error) setError(r.error);
    });

  return (
    <div className="space-y-2">
      <div className="flex gap-2">
        {status !== "live" && status !== "closed" && (
          <Button onClick={activate} disabled={pending} size="sm">
            {pending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Play className="size-4" />
            )}
            Ativar agora
          </Button>
        )}
        {status === "live" && (
          <Button variant="destructive" onClick={close} disabled={pending} size="sm">
            {pending ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <Square className="size-4" />
            )}
            Encerrar agora
          </Button>
        )}
      </div>
      {error && <p className="text-sm text-destructive font-mono">{error}</p>}
    </div>
  );
}
