/**
 * Google Sheets API v4 — exporta uma linha por consulta agendada.
 *
 * Valores vão com valueInputOption=RAW: texto do paciente começando com "="
 * NÃO vira fórmula (evita injeção de fórmula na planilha).
 */
import { googleFetch } from "./oauth";

const BASE = "https://sheets.googleapis.com/v4/spreadsheets";

export const DEFAULT_TAB = "Agendamentos";

export const SHEET_HEADER = [
  "Agendado em",
  "Data",
  "Hora",
  "Profissional",
  "Especialidade",
  "Paciente",
  "Telefone",
  "Status",
  "Pré-consulta",
  "ID no CRM",
];
const STATUS_COL = "H";
const ID_COL = "J";

/** Aceita a URL da planilha ou o ID puro. */
export function parseSpreadsheetId(input: string): string | null {
  const s = input.trim();
  const m = /\/spreadsheets\/d\/([a-zA-Z0-9_-]{20,})/.exec(s);
  if (m) return m[1]!;
  return /^[a-zA-Z0-9_-]{20,}$/.test(s) ? s : null;
}

function range(tab: string, a1: string): string {
  return encodeURIComponent(`'${tab.replace(/'/g, "''")}'!${a1}`);
}

export async function createSpreadsheet(title: string, tab = DEFAULT_TAB): Promise<{ id: string; url: string }> {
  const created = await googleFetch<{ spreadsheetId: string; spreadsheetUrl: string }>(BASE, {
    method: "POST",
    body: JSON.stringify({
      properties: { title },
      sheets: [{ properties: { title: tab, gridProperties: { frozenRowCount: 1 } } }],
    }),
  });
  await writeHeader(created.spreadsheetId, tab);
  return { id: created.spreadsheetId, url: created.spreadsheetUrl };
}

async function writeHeader(id: string, tab: string) {
  await googleFetch(`${BASE}/${id}/values/${range(tab, "A1")}?valueInputOption=RAW`, {
    method: "PUT",
    body: JSON.stringify({ values: [SHEET_HEADER] }),
  });
}

/** Garante que a aba exista e tenha cabeçalho. Devolve a URL da planilha. */
export async function ensureTabAndHeader(id: string, tab: string): Promise<{ url: string; title: string }> {
  const meta = await googleFetch<{
    spreadsheetUrl: string;
    properties: { title: string };
    sheets?: { properties: { title: string } }[];
  }>(`${BASE}/${id}?fields=spreadsheetUrl,properties.title,sheets.properties.title`);
  const exists = meta.sheets?.some((s) => s.properties.title === tab);
  if (!exists) {
    await googleFetch(`${BASE}/${id}:batchUpdate`, {
      method: "POST",
      body: JSON.stringify({ requests: [{ addSheet: { properties: { title: tab } } }] }),
    });
  }
  const first = await googleFetch<{ values?: string[][] }>(`${BASE}/${id}/values/${range(tab, "A1:J1")}`);
  if (!first.values?.[0]?.length) await writeHeader(id, tab);
  return { url: meta.spreadsheetUrl, title: meta.properties.title };
}

export async function appendRow(id: string, tab: string, row: string[]): Promise<void> {
  await googleFetch(
    `${BASE}/${id}/values/${range(tab, "A1")}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    { method: "POST", body: JSON.stringify({ values: [row] }) },
  );
}

/** Atualiza a coluna Status da linha cujo "ID no CRM" bate. false = linha não encontrada. */
export async function updateStatusById(id: string, tab: string, appointmentId: string, status: string): Promise<boolean> {
  const col = await googleFetch<{ values?: string[][] }>(
    `${BASE}/${id}/values/${range(tab, `${ID_COL}:${ID_COL}`)}`,
  );
  const idx = (col.values ?? []).findIndex((r) => r[0] === appointmentId);
  if (idx < 0) return false;
  await googleFetch(`${BASE}/${id}/values/${range(tab, `${STATUS_COL}${idx + 1}`)}?valueInputOption=RAW`, {
    method: "PUT",
    body: JSON.stringify({ values: [[status]] }),
  });
  return true;
}
