"use client";

import { useState } from "react";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { saveLaunch, type LaunchFormState } from "./actions";
import { Loader2, Save } from "lucide-react";
import { BonusesEditor } from "@/components/launches/bonuses-editor";
import type { Bonus } from "@/lib/launches/types";

interface InitialLaunch {
  id?: string;
  name?: string;
  slug?: string;
  /** formato YYYY-MM-DD */
  startsAt?: string;
  endsAt?: string;
  status?: string;
  // NOVOS:
  courseId?: string | null;
  pitchAngle?: string | null;
  bonuses?: { title: string; description: string }[];
  paymentMethodsOverride?: string | null;
  guaranteePolicyOverride?: string | null;
  // pra placeholder/herança visual (mostra o que vai ser usado se override vazio):
  coursePaymentMethods?: string | null;
  courseGuaranteePolicy?: string | null;
}

interface CourseOption {
  id: string;
  name: string;
}

export function LaunchForm({
  initial,
  courses,
}: {
  initial?: InitialLaunch;
  courses: CourseOption[];
}) {
  const [state, action, pending] = useActionState<LaunchFormState, FormData>(
    async (_prev, formData) => saveLaunch(formData),
    {},
  );
  const [bonuses, setBonuses] = useState<Bonus[]>(initial?.bonuses ?? []);

  return (
    <form action={action} className="space-y-6 max-w-xl">
      {initial?.id && <input type="hidden" name="id" value={initial.id} />}

      <div className="space-y-2">
        <Label htmlFor="name">Nome</Label>
        <Input
          id="name"
          name="name"
          required
          defaultValue={initial?.name ?? ""}
          placeholder="Lançamento Turma 5"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="slug">Slug</Label>
        <Input
          id="slug"
          name="slug"
          required
          defaultValue={initial?.slug ?? ""}
          placeholder="turma-5"
        />
        <p className="text-xs text-muted-foreground">
          Identificador único — letras minúsculas, números e hífen.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="startsAt">Início</Label>
          <Input
            id="startsAt"
            name="startsAt"
            type="date"
            required
            defaultValue={initial?.startsAt ?? ""}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="endsAt">Fim</Label>
          <Input
            id="endsAt"
            name="endsAt"
            type="date"
            required
            defaultValue={initial?.endsAt ?? ""}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Status</Label>
        <Select name="status" defaultValue={initial?.status ?? "planned"}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="planned">planned — planejado</SelectItem>
            <SelectItem value="live">live — em andamento</SelectItem>
            <SelectItem value="closed">closed — encerrado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="courseId">Curso</Label>
        <Select name="courseId" defaultValue={initial?.courseId ?? "__none__"}>
          <SelectTrigger id="courseId">
            <SelectValue placeholder="Sem curso atribuído" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="__none__">— Sem curso —</SelectItem>
            {courses.map((c) => (
              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground">
          Obrigatório pra ativar o lançamento. Define qual curso a oferta cobre.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="pitchAngle">Ângulo do pitch</Label>
        <Textarea
          id="pitchAngle"
          name="pitchAngle"
          rows={3}
          defaultValue={initial?.pitchAngle ?? ""}
          placeholder="Ex: comemoração dos 5 anos do Produto Exemplo, foco em comunidade que cresceu junto"
        />
        <p className="text-xs text-muted-foreground">
          Tom/ângulo que o bot deve usar enquanto a oferta tá viva.
        </p>
      </div>

      <div className="space-y-2">
        <Label>Bônus</Label>
        <BonusesEditor value={bonuses} onChange={setBonuses} />
        <input type="hidden" name="bonuses" value={JSON.stringify(bonuses)} />
        <p className="text-xs text-muted-foreground">
          Bônus específicos da oferta — vão pra contexto do bot quando a oferta tá ativa.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="paymentMethodsOverride">Pagamento (override)</Label>
          <Textarea
            id="paymentMethodsOverride"
            name="paymentMethodsOverride"
            rows={3}
            defaultValue={initial?.paymentMethodsOverride ?? ""}
            placeholder={
              initial?.coursePaymentMethods
                ? `Herda do curso: ${initial.coursePaymentMethods}`
                : "(curso sem método cadastrado)"
            }
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="guaranteePolicyOverride">Garantia (override)</Label>
          <Textarea
            id="guaranteePolicyOverride"
            name="guaranteePolicyOverride"
            rows={3}
            defaultValue={initial?.guaranteePolicyOverride ?? ""}
            placeholder={
              initial?.courseGuaranteePolicy
                ? `Herda do curso: ${initial.courseGuaranteePolicy}`
                : "(curso sem garantia cadastrada)"
            }
          />
        </div>
      </div>

      {state?.error && (
        <p className="text-sm text-destructive font-mono">{state.error}</p>
      )}

      <div className="flex gap-2">
        <Button type="submit" disabled={pending}>
          {pending ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Save className="size-4" />
          )}
          Salvar
        </Button>
      </div>
    </form>
  );
}
