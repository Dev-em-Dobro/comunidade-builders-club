/** Cálculo puro do lead score e tipos da qualificação (Parte 10). Sem Prisma. */

import type { AskedFieldsMap } from "./asked-fields";

export type InterestLevel = "low" | "medium" | "high";
export type BudgetSignal = "unknown" | "weak" | "strong";
export type DecisionTimeline = "unknown" | "long" | "medium" | "short";

/** Resultado da classificação do lead — gravado em `Lead.qualification`. */
export interface Qualification {
  interestLevel: InterestLevel;
  budgetSignal: BudgetSignal;
  decisionTimeline: DecisionTimeline;
  /** ids de Course do catálogo — já filtrados contra ids válidos. */
  courseInterestIds: string[];
  /** 1 frase curta justificando a classificação. */
  rationale: string;
  /** Audiência do lead — gate do follow-up fora da janela.
   *  Só "prospect" recebe cadência; ausente (lead pré-feature) = não elegível. */
  audience?: "prospect" | "student" | "support" | "refund";
  /** Tracking das 6 perguntas de qualificação (opcional; lazy). */
  askedFields?: AskedFieldsMap;
}

export interface ScoreInput {
  qualification: Qualification | null;
  /** nº de mensagens inbound da conversa — sinal de engajamento. */
  inboundCount: number;
  /** stage atual do Lead — aplica pisos. */
  stage: string;
  /** Objeções ativas (últimas 24h) — penaliza o score (Parte 11). */
  activeObjections?: string[];
}

const INTEREST_PTS: Record<InterestLevel, number> = {
  low: 0,
  medium: 15,
  high: 30,
};
const BUDGET_PTS: Record<BudgetSignal, number> = {
  unknown: 0,
  weak: 5,
  strong: 20,
};
const TIMELINE_PTS: Record<DecisionTimeline, number> = {
  unknown: 0,
  long: 5,
  medium: 12,
  short: 25,
};

/** Engajamento satura em 8 inbounds. */
const MAX_ENGAGEMENT_INBOUNDS = 8;

/** Penalidade por objeção única. Cap em 3 tags → -15 pts. */
const OBJECTION_PENALTY = 5;
const OBJECTION_MAX_PENALTY = 15;

/**
 * Score 0–100 do lead. Soma ponderada dos sinais da qualificação +
 * engajamento, com pisos por stage (lead já quente não despenca).
 */
export function computeScore({
  qualification,
  inboundCount,
  stage,
  activeObjections,
}: ScoreInput): number {
  let score = 0;

  if (qualification) {
    score += INTEREST_PTS[qualification.interestLevel] ?? 0;
    score += BUDGET_PTS[qualification.budgetSignal] ?? 0;
    score += TIMELINE_PTS[qualification.decisionTimeline] ?? 0;
    if (qualification.courseInterestIds.length > 0) score += 9;
  }

  // Engajamento: 2 pts por inbound, até 16.
  const inbounds = Math.min(Math.max(inboundCount, 0), MAX_ENGAGEMENT_INBOUNDS);
  score += inbounds * 2;

  // Objeções ativas (Parte 11): -5/tag única, cap -15. Aplica ANTES dos pisos.
  if (activeObjections?.length) {
    const uniqueTags = new Set(activeObjections).size;
    const penalty = Math.min(uniqueTags * OBJECTION_PENALTY, OBJECTION_MAX_PENALTY);
    score -= penalty;
  }

  // Pisos por stage — proposal/won/lost sobrescrevem qualquer penalidade.
  if (stage === "proposal") score = Math.max(score, 75);
  else if (stage === "won") score = 100;
  else if (stage === "lost") score = 0;

  return Math.round(Math.min(100, Math.max(0, score)));
}
