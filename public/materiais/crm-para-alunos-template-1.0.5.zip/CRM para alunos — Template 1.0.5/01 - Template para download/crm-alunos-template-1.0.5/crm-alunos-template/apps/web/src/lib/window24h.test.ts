import { describe, it, expect } from "vitest";
import {
  channelHasMessagingWindow,
  computeWindowClose,
  isWithin24hWindow,
  hoursUntilClose,
} from "./window24h";

describe("window24h", () => {
  it("computeWindowClose soma 24h ao inbound", () => {
    const inbound = new Date("2026-05-21T10:00:00.000Z");
    expect(computeWindowClose(inbound).toISOString()).toBe(
      "2026-05-22T10:00:00.000Z",
    );
  });

  it("isWithin24hWindow: true antes de fechar, false depois", () => {
    const now = new Date("2026-05-21T12:00:00.000Z");
    expect(isWithin24hWindow(new Date("2026-05-21T13:00:00.000Z"), now)).toBe(
      true,
    );
    expect(isWithin24hWindow(new Date("2026-05-21T11:00:00.000Z"), now)).toBe(
      false,
    );
  });

  it("isWithin24hWindow: false quando windowClosesAt é null", () => {
    expect(isWithin24hWindow(null)).toBe(false);
  });

  it("hoursUntilClose: positivo, negativo e null", () => {
    const now = new Date("2026-05-21T12:00:00.000Z");
    expect(hoursUntilClose(new Date("2026-05-21T15:00:00.000Z"), now)).toBe(3);
    expect(hoursUntilClose(new Date("2026-05-21T10:00:00.000Z"), now)).toBe(-2);
    expect(hoursUntilClose(null)).toBeNull();
  });
});

describe("channelHasMessagingWindow", () => {
  it("só os canais oficiais da Meta têm janela de 24h", () => {
    expect(channelHasMessagingWindow("whatsapp_cloud")).toBe(true);
    expect(channelHasMessagingWindow("instagram")).toBe(true);
    expect(channelHasMessagingWindow("whatsapp_qr")).toBe(false);
  });
});
