import { Badge } from "@/components/ui/badge";
import { Button, buttonVariants } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { GoogleConnectionStatus } from "@/lib/google/oauth";
import { formatDateTime } from "@/lib/datetime";
import { disconnectGoogleAction } from "../actions";
import { CheckCircle2, LogIn, Unplug } from "lucide-react";

const ERRORS: Record<string, string> = {
  forbidden: "Somente o administrador pode conectar o Google.",
  missing_client: "Salve o Client ID e o Client Secret antes de conectar.",
  access_denied: "A autorização foi cancelada na tela do Google.",
  invalid_state: "A sessão de conexão expirou ou é inválida. Tente conectar de novo.",
  missing_code: "O Google não devolveu o código de autorização. Tente de novo.",
  exchange_failed:
    "Não foi possível concluir a conexão. Confira se o URI de redirecionamento cadastrado no Google Cloud é exatamente o mostrado abaixo e se o Client Secret está correto.",
  google_error: "O Google devolveu um erro na autorização. Tente de novo.",
};

export function ConnectionAlert({ connected, error }: { connected?: string; error?: string }) {
  if (connected) {
    return (
      <div role="status" className="rounded-md border border-primary/40 bg-primary/10 p-3 text-sm">
        Conta Google conectada com sucesso.
      </div>
    );
  }
  if (error) {
    return (
      <div role="alert" className="rounded-md border border-destructive/40 bg-destructive/10 p-3 text-sm">
        {ERRORS[error] ?? "Erro ao conectar com o Google."}
      </div>
    );
  }
  return null;
}

/** Card da conta Google (usada pelo Google Sheets). */
export function GoogleAccountCard({ status }: { status: GoogleConnectionStatus }) {
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="text-base">Conta Google</CardTitle>
          <Badge variant={status.connected ? "default" : "outline"}>
            {status.connected ? "conectada" : "não conectada"}
          </Badge>
        </div>
        <CardDescription>Conta onde fica a planilha de agendamentos.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {status.connected ? (
          <>
            <p className="text-sm flex items-center gap-2">
              <CheckCircle2 className="size-4 text-primary" />
              {status.accountEmail ?? "Conta conectada"}
              {status.connectedAt && (
                <span className="text-muted-foreground text-xs">desde {formatDateTime(status.connectedAt)}</span>
              )}
            </p>
            <div className="flex flex-wrap gap-2">
              <a href="/api/integrations/google/connect" className={buttonVariants({ variant: "outline", size: "sm" })}>
                <LogIn className="size-4" /> Reconectar
              </a>
              <form action={disconnectGoogleAction}>
                <Button type="submit" variant="ghost" size="sm" className="text-destructive">
                  <Unplug className="size-4" /> Desconectar
                </Button>
              </form>
            </div>
          </>
        ) : status.credentials === "ausente" ? (
          <p className="text-sm text-muted-foreground">
            Cadastre o Client ID e o Client Secret do Google Cloud acima para liberar a conexão.
          </p>
        ) : (
          <a href="/api/integrations/google/connect" className={buttonVariants()}>
            <LogIn className="size-4" /> Conectar com Google
          </a>
        )}
      </CardContent>
    </Card>
  );
}
