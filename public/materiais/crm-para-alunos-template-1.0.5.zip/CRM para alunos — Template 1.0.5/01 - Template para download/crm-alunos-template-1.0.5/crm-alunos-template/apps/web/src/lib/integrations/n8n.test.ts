import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { notifyNewConversation, type NewConversationEvent } from "./n8n";

const originalEnv = { ...process.env };
let fetchMock: ReturnType<typeof vi.fn>;

const EVENT: NewConversationEvent = {
  conversationId: "conv_1",
  contactName: "Fulano",
  channel: "whatsapp_cloud",
  externalId: "5511999",
  leadId: "lead_1",
  firstMessage: "oi, quero saber do curso",
  conversationUrl: "https://crm.example/conversations/conv_1",
  at: "2026-06-15T12:00:00.000Z",
};

beforeEach(() => {
  fetchMock = vi.fn();
  global.fetch = fetchMock as unknown as typeof fetch;
});

afterEach(() => {
  process.env = { ...originalEnv };
  vi.restoreAllMocks();
});

describe("notifyNewConversation", () => {
  it("vira no-op (não chama fetch) quando a URL não está setada", async () => {
    delete process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL;
    await expect(notifyNewConversation(EVENT)).resolves.toBeUndefined();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("faz POST com JSON do evento quando a URL está setada", async () => {
    process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL = "https://n8n.example/webhook/crm-new-conversation";
    delete process.env.N8N_WEBHOOK_TOKEN;
    fetchMock.mockResolvedValueOnce(new Response("", { status: 200 }));

    await notifyNewConversation(EVENT);

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, init] = fetchMock.mock.calls[0];
    expect(url).toBe("https://n8n.example/webhook/crm-new-conversation");
    expect((init as RequestInit).method).toBe("POST");
    expect(JSON.parse((init as RequestInit).body as string)).toEqual(EVENT);
    expect((init as RequestInit).headers).toMatchObject({
      "content-type": "application/json",
    });
  });

  it("inclui o header x-webhook-token quando N8N_WEBHOOK_TOKEN está setado", async () => {
    process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL = "https://n8n.example/webhook/x";
    process.env.N8N_WEBHOOK_TOKEN = "s3cr3t";
    fetchMock.mockResolvedValueOnce(new Response("", { status: 200 }));

    await notifyNewConversation(EVENT);

    const [, init] = fetchMock.mock.calls[0];
    expect((init as RequestInit).headers).toMatchObject({ "x-webhook-token": "s3cr3t" });
  });

  it("lança erro quando a resposta não é ok", async () => {
    process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL = "https://n8n.example/webhook/x";
    fetchMock.mockResolvedValueOnce(new Response("nope", { status: 500, statusText: "Server Error" }));

    await expect(notifyNewConversation(EVENT)).rejects.toThrow(/n8n webhook: 500/);
  });
});
