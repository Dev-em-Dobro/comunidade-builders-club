"use client";

import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  createSheetsSpreadsheet,
  saveGoogleClient,
  saveSheetsTarget,
  syncPendingSheets,
  type FormResult,
} from "../actions";
import { Copy, FilePlus2, Loader2, RefreshCw } from "lucide-react";

function Feedback({ state }: { state: FormResult }) {
  if (state.error) return <p role="alert" className="text-sm text-destructive">{state.error}</p>;
  if (state.message) return <p role="status" className="text-sm text-primary">{state.message}</p>;
  return null;
}

export function CopyField({ value }: { value: string }) {
  return (
    <div className="flex gap-2">
      <Input readOnly value={value} className="font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
      <Button
        type="button"
        variant="outline"
        size="icon"
        aria-label="Copiar"
        onClick={() => navigator.clipboard?.writeText(value)}
      >
        <Copy className="size-4" />
      </Button>
    </div>
  );
}

export function GoogleClientForm({ hasSecret, clientIdHint }: { hasSecret: boolean; clientIdHint: string | null }) {
  const [state, action, pending] = useActionState(saveGoogleClient, {});
  return (
    <form action={action} className="space-y-4" autoComplete="off">
      <div className="space-y-2">
        <Label htmlFor="clientId">Client ID</Label>
        <Input
          id="clientId"
          name="clientId"
          required
          placeholder={clientIdHint ? `Atual: ${clientIdHint}` : "123456789-abc.apps.googleusercontent.com"}
          className="font-mono text-xs"
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor="clientSecret">Client Secret</Label>
        <Input
          id="clientSecret"
          name="clientSecret"
          type="password"
          autoComplete="new-password"
          placeholder={hasSecret ? "Configurado — deixe vazio para manter" : "GOCSPX-…"}
          required={!hasSecret}
          className="font-mono text-xs"
        />
      </div>
      <Feedback state={state} />
      <Button type="submit" disabled={pending}>
        {pending && <Loader2 className="size-4 animate-spin" />} Salvar credenciais
      </Button>
    </form>
  );
}

export function SheetsTargetForm({ currentTab }: { currentTab: string | null }) {
  const [state, action, pending] = useActionState(saveSheetsTarget, {});
  return (
    <form action={action} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="spreadsheet">Link da planilha</Label>
        <Input id="spreadsheet" name="spreadsheet" required placeholder="https://docs.google.com/spreadsheets/d/…" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="tab">Aba</Label>
        <Input id="tab" name="tab" defaultValue={currentTab ?? "Agendamentos"} maxLength={100} />
        <p className="text-xs text-muted-foreground">Se a aba não existir, ela é criada com o cabeçalho.</p>
      </div>
      <Feedback state={state} />
      <Button type="submit" disabled={pending}>
        {pending && <Loader2 className="size-4 animate-spin" />} Vincular planilha
      </Button>
    </form>
  );
}

export function CreateSpreadsheetButton() {
  const [state, action, pending] = useActionState(createSheetsSpreadsheet, {});
  return (
    <form action={action} className="space-y-2">
      <Button type="submit" variant="outline" disabled={pending}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <FilePlus2 className="size-4" />}
        Criar planilha nova
      </Button>
      <Feedback state={state} />
    </form>
  );
}

export function SyncPendingButton({ pending: pendingCount }: { pending: number }) {
  const [state, action, pending] = useActionState(syncPendingSheets, {});
  return (
    <form action={action} className="space-y-2">
      <Button type="submit" variant="outline" size="sm" disabled={pending || pendingCount === 0}>
        {pending ? <Loader2 className="size-4 animate-spin" /> : <RefreshCw className="size-4" />}
        Enviar {pendingCount} consulta(s) pendente(s)
      </Button>
      <Feedback state={state} />
    </form>
  );
}
