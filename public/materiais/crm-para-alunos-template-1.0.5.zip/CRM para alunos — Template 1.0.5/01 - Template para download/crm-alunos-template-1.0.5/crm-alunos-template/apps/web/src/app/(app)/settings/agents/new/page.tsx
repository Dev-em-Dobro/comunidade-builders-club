import { prisma } from "@/lib/db";
import { AgentForm } from "../_components/agent-form";
import { allProviderModels } from "@/lib/llm/models";

export const dynamic = "force-dynamic";

export default async function NewAgentPage() {
  const [creds, modelOptions] = await Promise.all([
    prisma.providerCredential
      .findMany({ select: { provider: true } })
      .catch(() => [] as { provider: string }[]),
    allProviderModels(),
  ]);
  const configuredProviders = creds.map((c) => c.provider);

  return (
    <div className="p-6 md:p-8 max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
          Novo agente
        </h1>
        <p className="text-muted-foreground mt-1">
          Persona reutilizável — referenciada por <code>Conversation.agentSessionId</code>.
        </p>
      </header>
      <AgentForm configuredProviders={configuredProviders} modelOptions={modelOptions} />
    </div>
  );
}
