import { describe, it, expect } from "vitest";
import { unsupportedMediaReply } from "./media-fallback";
import type { ChannelMessage } from "@/lib/channels/types";

type Inbound = Pick<ChannelMessage, "text" | "media">;

const AUDIO = "Não consigo ouvir áudios por aqui 😅 Pode mandar por texto, por favor?";
const IMAGE = "Não consigo ver imagens por aqui 😅 Pode mandar por texto, por favor?";
const VIDEO = "Não consigo ver vídeos por aqui 😅 Pode mandar por texto, por favor?";
const DOC = "Não consigo abrir arquivos por aqui 😅 Pode mandar por texto, por favor?";

function msg(text: string, media?: Inbound["media"]): Inbound {
  return { text, media };
}

describe("unsupportedMediaReply", () => {
  it("texto puro → null (deixa o agente responder)", () => {
    expect(unsupportedMediaReply([msg("quanto custa?")])).toBeNull();
  });

  it("sem mídia e sem texto → null", () => {
    expect(unsupportedMediaReply([msg("")])).toBeNull();
    expect(unsupportedMediaReply([])).toBeNull();
  });

  it("áudio sozinho → aviso de áudio", () => {
    expect(
      unsupportedMediaReply([msg("[audio]", [{ type: "audio" }])]),
    ).toBe(AUDIO);
  });

  it("imagem sozinha → aviso de imagem", () => {
    expect(
      unsupportedMediaReply([msg("[image]", [{ type: "image" }])]),
    ).toBe(IMAGE);
  });

  it("figurinha → aviso de imagem (visual)", () => {
    expect(
      unsupportedMediaReply([msg("[sticker]", [{ type: "sticker" }])]),
    ).toBe(IMAGE);
  });

  it("vídeo → aviso de vídeo", () => {
    expect(
      unsupportedMediaReply([msg("[video]", [{ type: "video" }])]),
    ).toBe(VIDEO);
  });

  it("documento → aviso de arquivo", () => {
    expect(
      unsupportedMediaReply([msg("[document]", [{ type: "document" }])]),
    ).toBe(DOC);
  });

  it("imagem COM legenda → null (responde à legenda)", () => {
    expect(
      unsupportedMediaReply([
        msg("quanto custa esse?", [{ type: "image", caption: "quanto custa esse?" }]),
      ]),
    ).toBeNull();
  });

  it("mídia + mensagem de texto separada no mesmo lote → null", () => {
    expect(
      unsupportedMediaReply([
        msg("[audio]", [{ type: "audio" }]),
        msg("oi, tudo bem?"),
      ]),
    ).toBeNull();
  });

  it("tipos misturados → junta os avisos distintos na ordem estável", () => {
    expect(
      unsupportedMediaReply([
        msg("[image]", [{ type: "image" }]),
        msg("[audio]", [{ type: "audio" }]),
      ]),
    ).toBe(`${AUDIO} ${IMAGE}`);
  });

  it("imagem + figurinha → um único aviso de imagem (dedup por categoria)", () => {
    expect(
      unsupportedMediaReply([
        msg("[image]", [{ type: "image" }]),
        msg("[sticker]", [{ type: "sticker" }]),
      ]),
    ).toBe(IMAGE);
  });

  it("reconhece pelo placeholder mesmo sem array media populado", () => {
    expect(unsupportedMediaReply([msg("[audio]")])).toBe(AUDIO);
    expect(unsupportedMediaReply([msg("[sticker]")])).toBe(IMAGE);
  });

  it("placeholder não conta como texto real", () => {
    // garante que '[image]' não seja tratado como pergunta do usuário
    expect(unsupportedMediaReply([msg("[image]", [{ type: "image" }])])).toBe(
      IMAGE,
    );
  });
});
