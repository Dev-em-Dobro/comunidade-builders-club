import { auth } from "@/auth";
import { NextResponse } from "next/server";
import { getAdapterByUrlSlug } from "@/lib/channels/registry";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ channel: string }> },
) {
  const session = await auth();
  if (session?.user?.role !== "admin") return NextResponse.json({ error: "forbidden" }, { status: 403 });
  const { channel } = await params;
  const adapter = getAdapterByUrlSlug(channel);
  if (!adapter) {
    return NextResponse.json({ ok: false, error: `unknown channel: ${channel}` }, { status: 404 });
  }
  try {
    const state = await adapter.getSessionStatus();
    return NextResponse.json({ ok: true, state });
  } catch (err) {
    return NextResponse.json(
      { ok: false, error: String((err as Error)?.message ?? err) },
      { status: 500 },
    );
  }
}
