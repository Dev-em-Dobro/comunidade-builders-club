import { describe, it, expect, afterAll, beforeEach } from "vitest";
import { prisma } from "@/lib/db";
import { buildCatalogBlock, buildLeadContextBlock } from "./context-blocks";
import { _resetActiveLaunchCache } from "@/lib/launches/active";

const created = {
  contactIds: [] as string[],
  courseIds: [] as string[],
  leadIds: [] as string[],
};

afterAll(async () => {
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.course.deleteMany({ where: { id: { in: created.courseIds } } });
  await prisma.$disconnect();
});

describe("buildCatalogBlock", () => {
  it("retorna string ou null (smoke de tipo do retorno)", async () => {
    // Não cria curso. Pode haver cursos pre-existentes na DB compartilhada,
    // então só asseguramos a forma do retorno aqui. O caso null real está
    // coberto pelo próximo teste com try/finally.
    const block = await buildCatalogBlock();
    expect(block === null || typeof block === "string").toBe(true);
  });

  it("retorna null quando não há cursos ativos", async () => {
    // Snapshot active course IDs, deactivate all temporarily, restore in finally.
    const previouslyActive = await prisma.course.findMany({
      where: { active: true },
      select: { id: true },
    });
    try {
      await prisma.course.updateMany({
        where: { id: { in: previouslyActive.map((c) => c.id) } },
        data: { active: false },
      });
      const block = await buildCatalogBlock();
      expect(block).toBeNull();
    } finally {
      if (previouslyActive.length > 0) {
        await prisma.course.updateMany({
          where: { id: { in: previouslyActive.map((c) => c.id) } },
          data: { active: true },
        });
      }
    }
  });

  it("inclui curso ativo recém-criado", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Teste ${Date.now()}`,
        slug: `teste-${Date.now()}`,
        priceCents: 49700,
        active: true,
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    expect(block).toContain(c.name);
    expect(block).toContain(`id=${c.id}`);
    expect(block).toContain("R$ 497.00");
  });

  it("Course sem policy fields renderiza apenas linha-cabeçalho (compat)", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Sem Policy ${Date.now()}`,
        slug: `sem-policy-${Date.now()}`,
        priceCents: 10000,
        active: true,
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    const lineForC = block?.split("\n").find((l) => l.includes(`id=${c.id}`));
    expect(lineForC).toBeDefined();
    // linha-cabeçalho do curso não deve ter sub-bullets seus
    expect(block).not.toContain(`  - descrição: `);
    // (sub-bullets de outros cursos podem existir; testamos abaixo que ESTE
    // curso não gerou nenhum sub-bullet seu — varremos as 3 linhas seguintes)
    const lines = block!.split("\n");
    const idx = lines.findIndex((l) => l.includes(`id=${c.id}`));
    const next3 = lines.slice(idx + 1, idx + 4).join("\n");
    expect(next3).not.toMatch(/^\s+- (descrição|garantia|pagamento):/m);
  });

  it("Course com apenas guaranteePolicy renderiza só sub-bullet de garantia", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Só Garantia ${Date.now()}`,
        slug: `so-garantia-${Date.now()}`,
        priceCents: 20000,
        active: true,
        guaranteePolicy: "7 dias de garantia",
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    const lines = block!.split("\n");
    const idx = lines.findIndex((l) => l.includes(`id=${c.id}`));
    expect(lines[idx + 1]).toBe("  - garantia: 7 dias de garantia");
    // linha seguinte não pode ser sub-bullet (descrição/pagamento ausentes)
    const after = lines[idx + 2] ?? "";
    expect(after).not.toMatch(/^\s+- (descrição|pagamento):/);
  });

  it("Course com os 3 policy fields renderiza sub-bullets na ordem descrição, garantia, pagamento", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Completo ${Date.now()}`,
        slug: `completo-${Date.now()}`,
        priceCents: 199700,
        active: true,
        description: "Curso de 12 meses com mentoria",
        guaranteePolicy: "7 dias incondicional",
        paymentMethods: "Pix ou cartão 12x",
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    const lines = block!.split("\n");
    const idx = lines.findIndex((l) => l.includes(`id=${c.id}`));
    expect(lines[idx + 1]).toBe("  - descrição: Curso de 12 meses com mentoria");
    expect(lines[idx + 2]).toBe("  - garantia: 7 dias incondicional");
    expect(lines[idx + 3]).toBe("  - pagamento: Pix ou cartão 12x");
  });

  it("description multilinha preserva quebras com indentação de continuação", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Multilinha ${Date.now()}`,
        slug: `multilinha-${Date.now()}`,
        priceCents: 30000,
        active: true,
        description: "Linha 1\nLinha 2\nLinha 3",
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    const lines = block!.split("\n");
    const idx = lines.findIndex((l) => l.includes(`id=${c.id}`));
    expect(lines[idx + 1]).toBe("  - descrição: Linha 1");
    expect(lines[idx + 2]).toBe("    Linha 2");
    expect(lines[idx + 3]).toBe("    Linha 3");
  });

  it("policy field com apenas whitespace é tratado como vazio (sem sub-bullet)", async () => {
    const c = await prisma.course.create({
      data: {
        name: `Curso Whitespace ${Date.now()}`,
        slug: `whitespace-${Date.now()}`,
        priceCents: 40000,
        active: true,
        guaranteePolicy: "   ",
        paymentMethods: "\n\t  \n",
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    const lines = block!.split("\n");
    const idx = lines.findIndex((l) => l.includes(`id=${c.id}`));
    const next3 = lines.slice(idx + 1, idx + 4).join("\n");
    expect(next3).not.toMatch(/^\s+- (descrição|garantia|pagamento):/m);
  });

  it("header do bloco contém aviso anti-hallucination", async () => {
    // garantia de pelo menos um Course ativo pra o bloco existir
    const c = await prisma.course.create({
      data: {
        name: `Curso Header ${Date.now()}`,
        slug: `header-${Date.now()}`,
        priceCents: 9900,
        active: true,
      },
    });
    created.courseIds.push(c.id);
    const block = await buildCatalogBlock();
    expect(block).toContain(
      "Use APENAS os fatos listados abaixo — se algo não estiver aqui",
    );
  });
});

describe("buildCatalogBlock — com oferta ativa", () => {
  beforeEach(() => {
    _resetActiveLaunchCache();
  });

  it("oferta ativa pro course de interesse → bloco OFERTA ATIVA aparece ANTES do catálogo", async () => {
    const ts = Date.now();
    const course = await prisma.course.create({
      data: {
        name: `Curso Oferta ${ts}`,
        slug: `curso-oferta-${ts}`,
        priceCents: 99700,
        active: true,
      },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `Launch Ativa ${ts}`,
        slug: `launch-ativa-${ts}`,
        courseId: course.id,
        status: "live",
        startsAt: new Date(Date.now() - 60_000),
        endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
    await prisma.launchPlan.create({
      data: {
        launchId: launch.id,
        name: "Plano Anual",
        priceCents: 99700,
        checkoutUrl: "https://checkout.example.com/plano-anual",
      },
    });

    try {
      const block = await buildCatalogBlock({
        lead: { interestCourseIds: [course.id] },
        recentMessages: [],
        conversationId: "test_conv",
      });

      expect(block).not.toBeNull();
      const ofertaIdx = block!.indexOf("OFERTA ATIVA");
      const catalogoIdx = block!.indexOf("# Catálogo de cursos");
      expect(ofertaIdx).toBeGreaterThanOrEqual(0);
      expect(catalogoIdx).toBeGreaterThan(ofertaIdx);
    } finally {
      _resetActiveLaunchCache();
      await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
      await prisma.launch.delete({ where: { id: launch.id } });
      await prisma.course.delete({ where: { id: course.id } });
    }
  });

  it("catálogo continua presente quando há oferta (bot ainda precisa do courseId)", async () => {
    const ts = Date.now();
    const course = await prisma.course.create({
      data: {
        name: `Curso Oferta Catalogo ${ts}`,
        slug: `curso-oferta-catalogo-${ts}`,
        priceCents: 49700,
        active: true,
      },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `Launch Catalogo ${ts}`,
        slug: `launch-catalogo-${ts}`,
        courseId: course.id,
        status: "live",
        startsAt: new Date(Date.now() - 60_000),
        endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
    await prisma.launchPlan.create({
      data: {
        launchId: launch.id,
        name: "Plano Básico",
        priceCents: 49700,
        checkoutUrl: "https://checkout.example.com/basico",
      },
    });

    try {
      const block = await buildCatalogBlock({
        lead: { interestCourseIds: [course.id] },
        recentMessages: [],
        conversationId: "test_conv",
      });

      expect(block).not.toBeNull();
      expect(block).toContain("OFERTA ATIVA");
      expect(block).toContain("# Catálogo de cursos");
      expect(block).toContain(`id=${course.id}`);
    } finally {
      _resetActiveLaunchCache();
      await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
      await prisma.launch.delete({ where: { id: launch.id } });
      await prisma.course.delete({ where: { id: course.id } });
    }
  });

  it("sem oferta ativa pro course de interesse → bloco NÃO aparece, catálogo normal", async () => {
    const ts = Date.now();
    const course = await prisma.course.create({
      data: {
        name: `Curso Sem Oferta ${ts}`,
        slug: `curso-sem-oferta-${ts}`,
        priceCents: 29700,
        active: true,
      },
    });

    try {
      const block = await buildCatalogBlock({
        lead: { interestCourseIds: [course.id] },
        recentMessages: [],
        conversationId: "test_conv",
      });

      expect(block).not.toBeNull();
      expect(block).not.toContain("OFERTA ATIVA");
      expect(block).toContain("# Catálogo de cursos");
    } finally {
      _resetActiveLaunchCache();
      await prisma.course.delete({ where: { id: course.id } });
    }
  });

  it("oferta ativa reflete no catálogo mesmo SEM interesse detectado (regressão preço-base)", async () => {
    const ts = Date.now();
    const course = await prisma.course.create({
      data: {
        name: `Curso Reflete ${ts}`,
        slug: `curso-reflete-${ts}`,
        priceCents: 250000,
        active: true,
        paymentMethods: "Boleto até 24x, total R$ 2.500 (preço base)",
        guaranteePolicy: "7 dias base",
      },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `Oferta Reflete ${ts}`,
        slug: `oferta-reflete-${ts}`,
        courseId: course.id,
        status: "live",
        startsAt: new Date(Date.now() - 60_000),
        endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
        paymentMethodsOverride: "1597 à vista ou 12x de 131",
        guaranteePolicyOverride: "15 dias ou vai ou racha",
      },
    });
    await prisma.launchPlan.create({
      data: {
        launchId: launch.id,
        name: "1 ano",
        priceCents: 159700,
        checkoutUrl: "https://aniversario.example.com/",
        sortOrder: 0,
      },
    });

    try {
      // interestCourseIds VAZIO — simula a 1ª pergunta de preço, antes do
      // classificador gravar o interesse. É exatamente o cenário do bug.
      const block = await buildCatalogBlock({
        lead: { interestCourseIds: [] },
        recentMessages: [{ text: "quanto custa", createdAt: new Date() }],
        conversationId: "test_conv",
      });
      expect(block).not.toBeNull();

      const lines = block!.split("\n");
      const idx = lines.findIndex((l) => l.includes(`id=${course.id}`));
      expect(idx).toBeGreaterThanOrEqual(0);
      const courseSection = lines.slice(idx, idx + 6).join("\n");

      // Reflete a oferta: preço do plano + pagamento override.
      expect(courseSection).toContain("1.597");
      expect(courseSection).toContain("1597 à vista");
      expect(courseSection).toContain("15 dias ou vai ou racha");
      // NÃO vaza o preço-base do curso.
      expect(courseSection).not.toContain("Boleto até 24x");
      expect(courseSection).not.toContain("R$ 2.500");
    } finally {
      _resetActiveLaunchCache();
      await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
      await prisma.launch.delete({ where: { id: launch.id } });
      await prisma.course.delete({ where: { id: course.id } });
    }
  });

  it("opts ausente → comportamento idêntico ao atual, sem bloco OFERTA ATIVA", async () => {
    const ts = Date.now();
    const course = await prisma.course.create({
      data: {
        name: `Curso Opts Ausente ${ts}`,
        slug: `curso-opts-ausente-${ts}`,
        priceCents: 19700,
        active: true,
      },
    });
    // Cria launch live pra confirmar que sem opts ele NÃO é injetado
    const launch = await prisma.launch.create({
      data: {
        name: `Launch Opts Ausente ${ts}`,
        slug: `launch-opts-ausente-${ts}`,
        courseId: course.id,
        status: "live",
        startsAt: new Date(Date.now() - 60_000),
        endsAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });
    await prisma.launchPlan.create({
      data: {
        launchId: launch.id,
        name: "Plano Único",
        priceCents: 19700,
        checkoutUrl: "https://checkout.example.com/unico",
      },
    });

    try {
      // Chama SEM opts — caminho do auditor
      const block = await buildCatalogBlock();

      expect(block).not.toBeNull();
      expect(block).not.toContain("OFERTA ATIVA");
      expect(block).toContain("# Catálogo de cursos");
    } finally {
      _resetActiveLaunchCache();
      await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
      await prisma.launch.delete({ where: { id: launch.id } });
      await prisma.course.delete({ where: { id: course.id } });
    }
  });
});

describe("buildLeadContextBlock", () => {
  it("retorna null quando lead não existe", async () => {
    const block = await buildLeadContextBlock("ghost_lead_id", "ghost_contact_id");
    expect(block).toBeNull();
  });

  it("inclui stage e score do lead", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "T" } });
    created.contactIds.push(contact.id);
    const lead = await prisma.lead.create({
      data: { contactId: contact.id, stage: "qualified", score: 42 },
    });
    created.leadIds.push(lead.id);
    const block = await buildLeadContextBlock(lead.id, contact.id);
    expect(block).toContain("stage: qualified");
    expect(block).toContain("score: 42");
  });

  it("inclui checklist de askedFields quando o lead tem askedFields persistidos", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "AskedFields render" } });
    created.contactIds.push(contact.id);
    const lead = await prisma.lead.create({
      data: {
        contactId: contact.id,
        stage: "new",
        score: 10,
        qualification: {
          interestLevel: "medium",
          budgetSignal: "unknown",
          decisionTimeline: "unknown",
          courseInterestIds: [],
          rationale: "",
          askedFields: {
            objetivo: {
              askedAt: "2026-05-23T08:00:00Z",
              answeredAt: "2026-05-23T09:00:00Z",
              answer: "virar dev",
            },
            nivel: { askedAt: "2026-05-24T10:00:00Z" },
          },
        } as object,
      },
    });
    created.leadIds.push(lead.id);
    const block = await buildLeadContextBlock(lead.id, contact.id);
    expect(block).toContain("# Perguntas de qualificação (estado atual)");
    expect(block).toContain(`[x] objetivo — respondido: "virar dev"`);
    expect(block).toContain("[!] nivel — PERGUNTADA EM 2026-05-24T10:00:00Z");
    expect(block).toContain("[ ] urgencia — NÃO PERGUNTADA AINDA");
    expect(block).toContain("Próxima a perguntar: urgencia");
  });

  it("renderiza 6 itens não-perguntados quando lead não tem askedFields", async () => {
    const contact = await prisma.contact.create({ data: { displayName: "No askedFields" } });
    created.contactIds.push(contact.id);
    const lead = await prisma.lead.create({
      data: { contactId: contact.id, stage: "new", score: 0 },
    });
    created.leadIds.push(lead.id);
    const block = await buildLeadContextBlock(lead.id, contact.id);
    expect(block).toContain("# Perguntas de qualificação (estado atual)");
    expect(block).toContain("[ ] objetivo — NÃO PERGUNTADA AINDA");
    expect(block).toContain("Próxima a perguntar: objetivo");
  });
});
