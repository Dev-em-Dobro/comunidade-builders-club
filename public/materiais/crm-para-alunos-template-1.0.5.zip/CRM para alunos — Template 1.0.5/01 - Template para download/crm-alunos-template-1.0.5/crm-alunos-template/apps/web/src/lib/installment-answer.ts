import { prisma } from "@/lib/db";
import { getActiveLaunch } from "@/lib/launches/active";

type Turn = { role: string; content: string };
type CourseOption = { id: string; name: string; paymentMethods: string | null };

function normalize(text: string): string {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

export function isInstallmentQuestion(text: string): boolean {
  const normalized = normalize(text);
  return /\b(parcel\w*|presta\w*|quantas vezes|\d+x)\b/.test(normalized) &&
    !/\b(quero falar com|falar com (um|uma|o|a) (humano|pessoa|atendente)|me transfere|me transfira)\b/.test(normalized);
}

/** Escolhe o produto citado pelo lead ou indicado pelo agente no contexto recente. */
export function selectInstallmentCourse(
  turns: Turn[],
  interestCourseIds: string[],
  courses: CourseOption[],
): CourseOption | null {
  const latestUser = [...turns].reverse().find((turn) => turn.role === "user");
  if (!latestUser || !isInstallmentQuestion(latestUser.content)) return null;

  const namedByUser = courses.filter((course) =>
    normalize(latestUser.content).includes(normalize(course.name)),
  );
  if (namedByUser.length === 1) return namedByUser[0]!;

  const recentAssistant = [...turns].reverse().find((turn) => turn.role === "assistant");
  if (recentAssistant) {
    const text = normalize(recentAssistant.content);
    const recommended = courses.filter((course) =>
      text.includes(`recomendo o ${normalize(course.name)}`) ||
      text.includes(`recomendo a ${normalize(course.name)}`),
    );
    if (recommended.length === 1) return recommended[0]!;
  }

  const interested = courses.filter((course) => interestCourseIds.includes(course.id));
  if (interested.length === 1) return interested[0]!;

  if (recentAssistant) {
    const mentioned = courses.filter((course) =>
      normalize(recentAssistant.content).includes(normalize(course.name)),
    );
    if (mentioned.length === 1) return mentioned[0]!;
  }
  return null;
}

/** Só intercepta o handoff quando há valor por parcela no cadastro vigente. */
export async function getInstallmentAnswerFacts(
  turns: Turn[],
  interestCourseIds: string[],
): Promise<{ courseName: string; answer: string } | null> {
  const latestUser = [...turns].reverse().find((turn) => turn.role === "user");
  if (!latestUser || !isInstallmentQuestion(latestUser.content)) return null;

  const courses = await prisma.course.findMany({
    where: { active: true },
    select: { id: true, name: true, paymentMethods: true },
  });
  const course = selectInstallmentCourse(turns, interestCourseIds, courses);
  if (!course) return null;

  const activeOffer = await getActiveLaunch(course.id);
  if (activeOffer && activeOffer.plans.length > 1) return null;
  // A oferta pode ter preço diferente do catálogo base. Sem override, o valor
  // por parcela do curso base não é evidência para essa oferta.
  const paymentMethods = activeOffer
    ? activeOffer.paymentMethodsOverride?.trim()
    : course.paymentMethods?.trim();
  if (!paymentMethods) return null;
  const installment = paymentMethods.match(/\b(\d{1,2})\s*x?\s+de\s+(R\$\s*[\d.,]+)/i);
  if (!installment) return null;

  // A resposta genérica anuncia apenas o cartão. Boleto parcelado tem fluxo
  // próprio e não deve ser oferecido antes de a pessoa dizer que não tem cartão.
  const afterInstallment = paymentMethods
    .slice(installment.index! + installment[0].length)
    .split(/(?:\.\s*|\n)(?:Boleto|Pix|Cart[aã]o\s+[aà]\s+vista)\b/i)[0]!;
  const total = afterInstallment.match(/\btotal(?: aproximado)?\s+(R\$\s*[\d.,]+)/i);
  const cash = paymentMethods.match(/(?:Pix|Cart[aã]o)\s+[aà]\s+vista:\s*(R\$\s*[\d.,]+)/i);
  const cleanMoney = (value: string) => value.replace(/\.+$/, "");
  const answer = [
    `Sim! O ${course.name} pode ser parcelado no cartão em ${installment[1]}x de ${cleanMoney(installment[2]!)}.`,
    total ? `O total parcelado é aproximadamente ${cleanMoney(total[1]!)}.` : null,
    cash ? `À vista, o valor cadastrado é ${cleanMoney(cash[1]!)}.` : null,
  ].filter(Boolean).join(" ");
  return { courseName: course.name, answer };
}
