import { describe, it, expect, beforeEach, vi } from "vitest";
import { findOverlappingLive } from "./validation";
import { prisma } from "@/lib/db";

vi.mock("@/lib/db", () => ({
  prisma: { launch: { findFirst: vi.fn() } },
}));
const findFirst = prisma.launch.findFirst as unknown as ReturnType<typeof vi.fn>;

beforeEach(() => findFirst.mockReset());

describe("findOverlappingLive", () => {
  it("monta a query com NOT current.id e overlap [start,end) ∩ [otherStart,otherEnd)", async () => {
    findFirst.mockResolvedValueOnce(null);
    const start = new Date("2026-06-01");
    const end = new Date("2026-06-30");
    await findOverlappingLive({
      courseId: "c1",
      startsAt: start,
      endsAt: end,
      excludeLaunchId: "launch_self",
    });
    expect(findFirst).toHaveBeenCalledWith({
      where: {
        courseId: "c1",
        status: "live",
        id: { not: "launch_self" },
        // Overlap: existing.startsAt < end AND existing.endsAt > start
        startsAt: { lt: end },
        endsAt: { gt: start },
      },
      select: { id: true, name: true },
    });
  });

  it("retorna o conflito quando há", async () => {
    findFirst.mockResolvedValueOnce({ id: "x", name: "Aniversário" });
    const r = await findOverlappingLive({
      courseId: "c1",
      startsAt: new Date(),
      endsAt: new Date(Date.now() + 86400000),
    });
    expect(r).toEqual({ id: "x", name: "Aniversário" });
  });

  it("omite o filtro id:not quando excludeLaunchId é null/undefined", async () => {
    findFirst.mockResolvedValueOnce(null);
    await findOverlappingLive({
      courseId: "c1",
      startsAt: new Date(),
      endsAt: new Date(Date.now() + 86400000),
    });
    const call = findFirst.mock.calls[0]![0];
    expect(call.where.id).toBeUndefined();
  });
});
