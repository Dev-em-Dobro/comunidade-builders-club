-- Cada agente de consulta passa a ter os próprios profissionais.

-- Professional.agentSessionId (obrigatório). Profissionais já cadastrados vão
-- para o agente de consulta mais antigo; sem agente de consulta, são removidos
-- (as consultas ficam, com professionalId nulo e o nome no snapshot).
ALTER TABLE "Professional" ADD COLUMN "agentSessionId" TEXT;

UPDATE "Professional"
SET "agentSessionId" = (
  SELECT "id" FROM "AgentSession" WHERE "role" = 'scheduling' ORDER BY "createdAt" ASC LIMIT 1
);

DELETE FROM "Professional" WHERE "agentSessionId" IS NULL;

ALTER TABLE "Professional" ALTER COLUMN "agentSessionId" SET NOT NULL;

DROP INDEX "Professional_active_idx";

CREATE INDEX "Professional_agentSessionId_active_idx" ON "Professional"("agentSessionId", "active");

ALTER TABLE "Professional" ADD CONSTRAINT "Professional_agentSessionId_fkey" FOREIGN KEY ("agentSessionId") REFERENCES "AgentSession"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Appointment.agentSessionId: agente que marcou a consulta.
ALTER TABLE "Appointment" ADD COLUMN "agentSessionId" TEXT;

UPDATE "Appointment" AS a
SET "agentSessionId" = p."agentSessionId"
FROM "Professional" AS p
WHERE a."professionalId" = p."id";

CREATE INDEX "Appointment_agentSessionId_startsAt_idx" ON "Appointment"("agentSessionId", "startsAt");

ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_agentSessionId_fkey" FOREIGN KEY ("agentSessionId") REFERENCES "AgentSession"("id") ON DELETE SET NULL ON UPDATE CASCADE;
