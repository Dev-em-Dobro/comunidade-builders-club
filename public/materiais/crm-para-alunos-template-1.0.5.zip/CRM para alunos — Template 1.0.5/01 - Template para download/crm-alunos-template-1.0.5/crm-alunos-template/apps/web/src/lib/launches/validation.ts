import { prisma } from "@/lib/db";

export interface OverlapCheckInput {
  courseId: string;
  startsAt: Date;
  endsAt: Date;
  /** Se passado, exclui esse Launch da busca (útil em edits). */
  excludeLaunchId?: string;
}

/**
 * Acha o primeiro Launch `live` no mesmo `courseId` cuja janela
 * [startsAt, endsAt) intersecta com a janela fornecida.
 *
 * Critério de overlap: existing.startsAt < newEnd AND existing.endsAt > newStart.
 */
export async function findOverlappingLive(
  input: OverlapCheckInput,
): Promise<{ id: string; name: string } | null> {
  const where: Record<string, unknown> = {
    courseId: input.courseId,
    status: "live",
    startsAt: { lt: input.endsAt },
    endsAt: { gt: input.startsAt },
  };
  if (input.excludeLaunchId) {
    where.id = { not: input.excludeLaunchId };
  }
  return prisma.launch.findFirst({ where, select: { id: true, name: true } });
}
