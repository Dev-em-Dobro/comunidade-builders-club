/**
 * Mapping de Lead pra coluna do kanban /pipeline.
 *
 * Lógica: se lead tem follow-up step (1/2/3) E não é terminal (won/lost),
 * vai pra coluna F<N>. Senão, vai pra coluna do seu stage. won/lost são
 * agregados na coluna "closed".
 */

export const COLUMN_IDS = [
  "new",
  "contacted",
  "qualified",
  "proposal",
  "f1",
  "f2",
  "f3",
  "closed",
] as const;

export type ColumnId = (typeof COLUMN_IDS)[number];

export const COLUMN_LABEL: Record<ColumnId, string> = {
  new: "Novo",
  contacted: "Contatado",
  qualified: "Qualificado",
  proposal: "Proposta",
  f1: "Follow-up 1",
  f2: "Follow-up 2",
  f3: "Follow-up 3",
  closed: "Fechado",
};

const TERMINAL_STAGES = new Set(["won", "lost"]);

export interface DeriveColumnInput {
  stage: string;
  lastFollowUpStep: number | null;
}

/**
 * Retorna a coluna lógica do lead. Terminal stages (won/lost) sempre vão
 * pra "closed" mesmo se tiverem step não-null (edge case raro).
 */
export function deriveColumn(input: DeriveColumnInput): ColumnId {
  if (TERMINAL_STAGES.has(input.stage)) return "closed";

  const step = input.lastFollowUpStep;
  if (step === 1) return "f1";
  if (step === 2) return "f2";
  if (step === 3) return "f3";

  if (input.stage === "new") return "new";
  if (input.stage === "contacted") return "contacted";
  if (input.stage === "qualified") return "qualified";
  if (input.stage === "proposal") return "proposal";

  return "new";
}
