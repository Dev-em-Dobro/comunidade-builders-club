import { describe, it, expect } from "vitest";
import { resolveCheckoutCourseId } from "./closer-handoff";

const d = (s: string) => new Date(s);
const courses = [
  { id: "c1", name: "Produto Exemplo", slug: "produto-exemplo" },
  { id: "c2", name: "Outro", slug: "outro" },
];

describe("resolveCheckoutCourseId", () => {
  it("interesse vazio + 1 curso ativo → esse curso", () => {
    expect(resolveCheckoutCourseId([], [], [courses[0]!])).toBe("c1");
  });

  it("interesse vazio + 2 cursos → null (indeterminável)", () => {
    expect(resolveCheckoutCourseId([], [], courses)).toBeNull();
  });

  it("interesse válido único → esse curso", () => {
    expect(resolveCheckoutCourseId(["c2"], [], courses)).toBe("c2");
  });

  it("2 interesses → o mencionado mais recente vence", () => {
    const msgs = [
      { text: "me fala do Outro", createdAt: d("2026-01-01T00:00:00Z") },
      { text: "na vdd quero o Produto Exemplo", createdAt: d("2026-01-01T00:01:00Z") },
    ];
    expect(resolveCheckoutCourseId(["c1", "c2"], msgs, courses)).toBe("c1");
  });

  it("interesse stale (não ativo) + 1 curso ativo → cai pro curso único", () => {
    expect(resolveCheckoutCourseId(["morto"], [], [courses[0]!])).toBe("c1");
  });

  it("interesse stale + 2 cursos ativos → null", () => {
    expect(resolveCheckoutCourseId(["morto"], [], courses)).toBeNull();
  });
});
