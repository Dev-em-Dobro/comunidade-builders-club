import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { enqueue } from "@/lib/queue";
import { outOfWindowFollowupConfig } from "@/lib/config";
import { isQuietHours } from "@/lib/quiet-hours";
import {
  isOutOfWindowFollowupDue,
  isOutOfWindowCadenceExhaustedLost,
  resolveTemplateVars,
} from "@/lib/out-window-followup";
import { sendApprovedTemplate } from "@/lib/conversations/send-template-core";
import { ChannelSendError } from "@/lib/channels/meta-graph";
import type { OutWindowSendJobData } from "@/lib/queue/types";

const SCAN_CAP = 500;

function audienceOf(qualification: unknown): string | null {
  return (qualification as { audience?: string } | null)?.audience ?? null;
}

/** Processador da fila `out-window-followup`. Ramifica por job.name. */
export async function outWindowFollowupProcessor(job: Job): Promise<void> {
  if (job.name === "scan") return scan();
  if (job.name === "send") return send(job.data as OutWindowSendJobData);
  log("out_window.unknown_job", { jobName: job.name });
}

/** Scan repetível (30 min): enfileira envios devidos + marca lost esgotado. */
async function scan(): Promise<void> {
  const cfg = outOfWindowFollowupConfig();
  if (!cfg.enabled) {
    log("out_window.scan_skipped", { reason: "disabled" });
    return;
  }
  const now = new Date();
  if (isQuietHours(now, cfg.quietHours)) {
    log("out_window.scan_skipped", { reason: "quiet_hours" });
    return;
  }

  // ── 1. Envios devidos (janela fechada, lead quente prospect, step devido)
  const convs = await prisma.conversation.findMany({
    where: {
      windowClosesAt: { lt: now },
      aiEnabled: true,
      handoffRequested: false,
      lead: { stage: { in: cfg.eligibleStages } },
    },
    select: {
      id: true,
      windowClosesAt: true,
      aiEnabled: true,
      handoffRequested: true,
      lead: {
        select: { stage: true, lastFollowUpStep: true, lastFollowUpAt: true, qualification: true },
      },
    },
    take: SCAN_CAP,
  });

  let enqueued = 0;
  for (const conv of convs) {
    // NOTA: o scan itera CONVERSAS (windowClosesAt é por-conversa), mas o step
    // é por-LEAD. Um lead com 2+ conversas (canais) pode receber 1 envio por
    // conversa no mesmo step. Na prática os leads são WhatsApp-only (o template
    // só envia via WhatsApp Cloud). Se virar multi-canal, dedupe por lead aqui.
    if (!conv.lead) continue;
    const step = isOutOfWindowFollowupDue(
      {
        windowClosesAt: conv.windowClosesAt,
        lastFollowUpStep: conv.lead.lastFollowUpStep,
        lastFollowUpAt: conv.lead.lastFollowUpAt,
        leadStage: conv.lead.stage,
        audience: audienceOf(conv.lead.qualification),
        aiEnabled: conv.aiEnabled,
        handoffRequested: conv.handoffRequested,
      },
      now,
      cfg,
    );
    if (step == null) continue;

    const data: OutWindowSendJobData = { conversationId: conv.id, step };
    await enqueue("out-window-followup", "send", data, {
      jobId: `outwin:${conv.id}:${step}`, // dedupe entre scans
      removeOnComplete: true,
      removeOnFail: 50,
    });
    enqueued++;
  }

  // ── 2. Lost por cadência esgotada (F3 + grace, sem resposta)
  const exhausted = await prisma.lead.findMany({
    where: {
      stage: { in: cfg.eligibleStages },
      lastFollowUpStep: { gte: cfg.intervalsDays.length },
    },
    select: { id: true, stage: true, lastFollowUpStep: true, lastFollowUpAt: true, qualification: true },
    take: SCAN_CAP,
  });

  let lostMarked = 0;
  for (const lead of exhausted) {
    const isLost = isOutOfWindowCadenceExhaustedLost(
      {
        leadStage: lead.stage,
        audience: audienceOf(lead.qualification),
        lastFollowUpStep: lead.lastFollowUpStep,
        lastFollowUpAt: lead.lastFollowUpAt,
      },
      now,
      cfg,
    );
    if (!isLost) continue;

    try {
      await prisma.$transaction(async (tx) => {
        const claimed = await tx.lead.updateMany({
          where: { id: lead.id, stage: { in: cfg.eligibleStages } },
          data: { stage: "lost", lostReason: "no_response", lostAt: now },
        });
        if (claimed.count === 0) throw new Error("LOST_CLAIM_LOST_RACE");
        await tx.pipelineEvent.create({
          data: {
            leadId: lead.id,
            type: "stage_change",
            payload: { from: lead.stage, to: "lost", via: "no_response_out_window" },
          },
        });
      });
      lostMarked++;
    } catch (err) {
      if ((err as Error)?.message === "LOST_CLAIM_LOST_RACE") continue;
      log("out_window.lost_failed", {
        leadId: lead.id,
        error: String((err as Error)?.message ?? err),
      });
    }
  }

  log("out_window.scan_done", { scanned: convs.length, enqueued, scannedExhausted: exhausted.length, lostMarked });
}

/** Envia 1 template do step. Revalida estado fresco antes de enviar. */
async function send(data: OutWindowSendJobData): Promise<void> {
  const { conversationId, step } = data;
  const cfg = outOfWindowFollowupConfig();
  if (!cfg.enabled) {
    log("out_window.send_abort", { conversationId, reason: "disabled" });
    return;
  }
  const now = new Date();

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: {
      id: true,
      channel: true,
      contactId: true,
      leadId: true,
      windowClosesAt: true,
      aiEnabled: true,
      handoffRequested: true,
      contact: { select: { displayName: true } },
      lead: {
        select: { stage: true, lastFollowUpStep: true, lastFollowUpAt: true, qualification: true, interestCourseIds: true },
      },
    },
  });
  if (!conv || !conv.lead) {
    log("out_window.send_abort", { conversationId, reason: "no_lead" });
    return;
  }
  if (isQuietHours(now, cfg.quietHours)) {
    log("out_window.send_abort", { conversationId, reason: "quiet_hours" });
    return;
  }

  // Revalida: o step devido AGORA tem que ser exatamente o do job.
  const due = isOutOfWindowFollowupDue(
    {
      windowClosesAt: conv.windowClosesAt,
      lastFollowUpStep: conv.lead.lastFollowUpStep,
      lastFollowUpAt: conv.lead.lastFollowUpAt,
      leadStage: conv.lead.stage,
      audience: audienceOf(conv.lead.qualification),
      aiEnabled: conv.aiEnabled,
      handoffRequested: conv.handoffRequested,
    },
    now,
    cfg,
  );
  if (due !== step) {
    log("out_window.send_abort", { conversationId, reason: "step_changed", due, step });
    return;
  }

  // Template configurado pro step (dashboard).
  const cadence = await prisma.followupCadenceStep.findUnique({ where: { step } });
  if (!cadence?.metaName || !cadence.language) {
    log("out_window.send_abort", { conversationId, reason: "no_template_for_step", step });
    return;
  }
  const tpl = await prisma.messageTemplate.findUnique({
    where: { metaName_language: { metaName: cadence.metaName, language: cadence.language } },
  });
  if (!tpl || tpl.status !== "APPROVED") {
    log("out_window.send_abort", { conversationId, reason: "template_unavailable", step });
    return;
  }

  const ident = await prisma.contactIdentity.findFirst({
    where: { contactId: conv.contactId, channel: conv.channel },
    select: { externalId: true },
  });
  if (!ident) {
    log("out_window.send_abort", { conversationId, reason: "no_identity" });
    return;
  }

  // Nome do curso de interesse (1º id) pra variável {{2}}.
  let courseName: string | null = null;
  const firstCourseId = conv.lead.interestCourseIds?.[0];
  if (firstCourseId) {
    const course = await prisma.course.findUnique({
      where: { id: firstCourseId },
      select: { name: true },
    });
    courseName = course?.name ?? null;
  }

  const variables = resolveTemplateVars(
    conv.contact?.displayName ?? null,
    courseName,
    tpl.variableCount,
  );

  try {
    await sendApprovedTemplate({
      conversationId: conv.id,
      leadId: conv.leadId,
      externalId: ident.externalId,
      template: { metaName: tpl.metaName, language: tpl.language, bodyText: tpl.bodyText },
      variables,
      step,
      sentByUserId: null, // bot
    });
    log("out_window.sent", { conversationId, leadId: conv.leadId, step });
  } catch (err) {
    if (err instanceof ChannelSendError) {
      log("out_window.meta_rejected", { conversationId, step, code: err.code });
      return;
    }
    log("out_window.send_failed", {
      conversationId,
      step,
      error: String((err as Error)?.message ?? err),
    });
  }
}

function log(event: string, fields: Record<string, unknown>) {
  console.log(JSON.stringify({ event, ...fields, at: new Date().toISOString() }));
}
