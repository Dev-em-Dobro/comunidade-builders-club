import { describe, it, expect, vi, beforeEach, afterEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";
import { _resetActiveLaunchCache } from "@/lib/launches/active";

vi.mock("@/lib/llm", async () => {
  const actual = await vi.importActual<typeof import("@/lib/llm")>("@/lib/llm");
  return { ...actual, generateReply: vi.fn() };
});
vi.mock("@/lib/channels/registry", () => ({
  getAdapter: vi.fn(() => ({ sendText: vi.fn().mockResolvedValue(undefined) })),
}));
vi.mock("@/lib/realtime/notify", () => ({
  notifyMessage: vi.fn().mockResolvedValue(undefined),
}));
vi.mock("@/lib/handoff", () => ({
  runHandoff: vi.fn().mockResolvedValue(undefined),
}));

import { generateReply } from "@/lib/llm";
import { runHandoff } from "@/lib/handoff";
import { runAgentHandoffWithCheckout } from "./closer-handoff";

const ids = {
  agentSessionIds: [] as string[],
  conversationIds: [] as string[],
  leadIds: [] as string[],
  contactIds: [] as string[],
  courseIds: [] as string[],
  launchIds: [] as string[],
};

function mockReply(text: string) {
  (generateReply as unknown as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
    text, modelUsed: "test", tokensIn: 10, tokensOut: 5, toolUses: [],
  });
}

async function fixture(opts?: {
  withCloser?: boolean;
  courseCheckoutUrl?: string | null;
  initialRole?: "sdr" | "closer";
  leadStage?: string;
}) {
  const withCloser = opts?.withCloser ?? true;
  const initialRole = opts?.initialRole ?? "sdr";

  const sdr = await prisma.agentSession.create({
    data: { name: `SDR ${Date.now()}-${Math.random()}`, systemPrompt: "SDR", role: "sdr" },
  });
  ids.agentSessionIds.push(sdr.id);

  let closerId: string | null = null;
  if (withCloser) {
    const closer = await prisma.agentSession.create({
      data: {
        name: `Closer ${Date.now()}-${Math.random()}`,
        persona: "Lucas", systemPrompt: "Closer", role: "closer",
      },
    });
    ids.agentSessionIds.push(closer.id);
    closerId = closer.id;
  }

  const course = await prisma.course.create({
    data: {
      name: `Curso ${Date.now()}-${Math.random()}`,
      slug: `curso-${Date.now()}-${Math.random()}`,
      priceCents: 10000,
      checkoutUrl: opts?.courseCheckoutUrl === undefined ? "https://pay.x/c" : opts.courseCheckoutUrl,
    },
  });
  ids.courseIds.push(course.id);

  const contact = await prisma.contact.create({ data: { displayName: "CTA Handoff" } });
  ids.contactIds.push(contact.id);
  await prisma.contactIdentity.create({
    data: { contactId: contact.id, channel: "test", externalId: `ext-${Date.now()}-${Math.random()}` },
  });

  const lead = await prisma.lead.create({
    data: {
      contactId: contact.id,
      stage: opts?.leadStage ?? "contacted",
      interestCourseIds: [course.id],
    },
  });
  ids.leadIds.push(lead.id);

  const conv = await prisma.conversation.create({
    data: {
      channel: "test", contactId: contact.id, leadId: lead.id,
      agentSessionId: initialRole === "closer" && closerId ? closerId : sdr.id,
      aiEnabled: true,
    },
  });
  ids.conversationIds.push(conv.id);
  await prisma.message.create({
    data: { conversationId: conv.id, direction: "inbound", role: "user", text: "manda o link" },
  });

  return { sdr, closerId, course, lead, conv, contact };
}

beforeEach(() => {
  (generateReply as unknown as ReturnType<typeof vi.fn>).mockReset();
  (runHandoff as unknown as ReturnType<typeof vi.fn>).mockReset();
  _resetActiveLaunchCache();
});

afterEach(async () => {
  await prisma.shortLink.deleteMany({ where: { leadId: { in: ids.leadIds } } });
  await prisma.pipelineEvent.deleteMany({ where: { leadId: { in: ids.leadIds } } });
  await prisma.launchPlan.deleteMany({ where: { launchId: { in: ids.launchIds } } });
  await prisma.launch.deleteMany({ where: { id: { in: ids.launchIds } } });
  await prisma.message.deleteMany({ where: { conversationId: { in: ids.conversationIds } } });
  await prisma.conversation.deleteMany({ where: { id: { in: ids.conversationIds } } });
  await prisma.lead.deleteMany({ where: { id: { in: ids.leadIds } } });
  await prisma.course.deleteMany({ where: { id: { in: ids.courseIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: ids.contactIds } } });
  await prisma.agentSession.deleteMany({ where: { id: { in: ids.agentSessionIds } } });
  ids.agentSessionIds.length = 0; ids.conversationIds.length = 0; ids.leadIds.length = 0;
  ids.contactIds.length = 0; ids.courseIds.length = 0; ids.launchIds.length = 0;
});

afterAll(async () => { await prisma.$disconnect(); });

describe("runAgentHandoffWithCheckout", () => {
  it("link direto: envia saudação + URL, flipa pro closer, stage→proposal, eventos", async () => {
    const fx = await fixture();
    mockReply("Opa! Aqui é o Lucas, segue o link:");

    const handled = await runAgentHandoffWithCheckout(fx.conv.id);
    expect(handled).toBe(true);

    const msgs = await prisma.message.findMany({
      where: { conversationId: fx.conv.id, direction: "outbound" },
    });
    expect(msgs).toHaveLength(1);
    expect(msgs[0]!.text).toContain("/l/");
    expect(msgs[0]!.text).toContain("Lucas");

    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: fx.conv.id } });
    expect(conv.agentSessionId).toBe(fx.closerId);
    expect(conv.aiEnabled).toBe(true);

    const lead = await prisma.lead.findUniqueOrThrow({ where: { id: fx.lead.id } });
    expect(lead.stage).toBe("proposal");

    const evTypes = (await prisma.pipelineEvent.findMany({ where: { leadId: fx.lead.id } }))
      .map((e) => e.type).sort();
    expect(evTypes).toContain("agent_handoff");
    expect(evTypes).toContain("stage_change");
    expect(evTypes).toContain("cta_sent");
    expect(runHandoff).not.toHaveBeenCalled();
  });

  it("sem checkoutUrl → handoff humano, NÃO flipa pro closer, não gera saudação", async () => {
    const fx = await fixture({ courseCheckoutUrl: null });

    const handled = await runAgentHandoffWithCheckout(fx.conv.id);
    expect(handled).toBe(true);
    expect(runHandoff).toHaveBeenCalledTimes(1);
    expect(generateReply).not.toHaveBeenCalled();

    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: fx.conv.id } });
    expect(conv.agentSessionId).toBe(fx.sdr.id);
  });

  it("oferta com 2 planos de URLs diferentes → Closer pergunta o plano, sem URL", async () => {
    const fx = await fixture();
    const launch = await prisma.launch.create({
      data: {
        name: `L ${Date.now()}`, slug: `l-${Date.now()}-${Math.random()}`,
        startsAt: new Date(Date.now() - 86400000), endsAt: new Date(Date.now() + 86400000),
        status: "live", courseId: fx.course.id,
      },
    });
    ids.launchIds.push(launch.id);
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "1 ano", priceCents: 100, checkoutUrl: "https://pay.x/1", sortOrder: 0 },
    });
    await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "2 anos", priceCents: 200, checkoutUrl: "https://pay.x/2", sortOrder: 1 },
    });
    _resetActiveLaunchCache();
    mockReply("Oi, aqui é o Lucas! Você prefere 1 ano ou 2 anos?");

    const handled = await runAgentHandoffWithCheckout(fx.conv.id);
    expect(handled).toBe(true);

    const msg = (await prisma.message.findFirst({
      where: { conversationId: fx.conv.id, direction: "outbound" },
    }))!;
    expect(msg.text).not.toContain("/l/");
    const conv = await prisma.conversation.findUniqueOrThrow({ where: { id: fx.conv.id } });
    expect(conv.agentSessionId).toBe(fx.closerId);
  });

  it("sem Closer cadastrado → handoff humano", async () => {
    const fx = await fixture({ withCloser: false });

    const handled = await runAgentHandoffWithCheckout(fx.conv.id);
    expect(handled).toBe(true);
    expect(runHandoff).toHaveBeenCalledTimes(1);
    expect(generateReply).not.toHaveBeenCalled();
  });

  it("conversa já no Closer → no-op, retorna false (deixa o caminho legado)", async () => {
    const fx = await fixture({ initialRole: "closer" });

    const handled = await runAgentHandoffWithCheckout(fx.conv.id);
    expect(handled).toBe(false);
    expect(generateReply).not.toHaveBeenCalled();
    expect(runHandoff).not.toHaveBeenCalled();
  });
});
