/**
 * "Jeito de gente" nas respostas do agente (AgentSession.humanize):
 *
 *  - waitSeconds: espera o contato terminar de escrever antes de responder
 *    (janela do debounce — cada mensagem nova recomeça a contagem).
 *  - typing: mostra "digitando…" antes de cada mensagem, pelo tempo que uma
 *    pessoa levaria pra escrever aquele texto.
 *  - splitMessages: quebra a resposta por parágrafo em até MAX_BUBBLES balões.
 *
 * Funções puras — sem banco nem canal.
 */

export interface HumanizeSettings {
  waitSeconds: number;
  typing: boolean;
  splitMessages: boolean;
}

export const DEFAULT_HUMANIZE: HumanizeSettings = { waitSeconds: 8, typing: true, splitMessages: true };
export const WAIT_SECONDS_MIN = 2;
export const WAIT_SECONDS_MAX = 30;
export const MAX_BUBBLES = 3;

/** Lê o JSON do banco com defaults — agente antigo (`{}`) já ganha o comportamento novo. */
export function normalizeHumanize(raw: unknown): HumanizeSettings {
  const o = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const wait = Number(o.waitSeconds);
  return {
    waitSeconds: Number.isFinite(wait)
      ? Math.min(WAIT_SECONDS_MAX, Math.max(WAIT_SECONDS_MIN, Math.round(wait)))
      : DEFAULT_HUMANIZE.waitSeconds,
    typing: typeof o.typing === "boolean" ? o.typing : DEFAULT_HUMANIZE.typing,
    splitMessages: typeof o.splitMessages === "boolean" ? o.splitMessages : DEFAULT_HUMANIZE.splitMessages,
  };
}

/**
 * Quebra por parágrafo (linha em branco). Até `max` balões — o excedente vai
 * junto no último, pra não virar uma rajada de mensagens.
 */
export function splitReply(text: string, max = MAX_BUBBLES): string[] {
  const parts = text
    .split(/\n[ \t]*\n+/)
    .map((p) => p.trim())
    .filter(Boolean);
  if (parts.length <= 1) return [text.trim()].filter(Boolean);
  if (parts.length <= max) return parts;
  return [...parts.slice(0, max - 1), parts.slice(max - 1).join("\n\n")];
}

/**
 * Instrução pro modelo quando a quebra em balões está ligada — sem ela o
 * modelo tende a responder num parágrafo só e não há o que quebrar.
 */
export function humanizeDirective(h: HumanizeSettings): string | null {
  if (!h.splitMessages) return null;
  return [
    "# Formato das mensagens (WhatsApp)",
    "Escreva como uma pessoa no WhatsApp: quando a resposta tiver mais de uma ideia, separe em parágrafos curtos " +
      `com uma linha em branco entre eles — cada parágrafo é enviado como uma mensagem (no máximo ${MAX_BUBBLES}). ` +
      "Resposta simples fica num parágrafo só. Não numere nem anuncie as partes.",
  ].join("\n");
}

/** Tempo de "digitando…": ~35 ms por caractere, entre 1,2 s e 6 s. */
export function typingDelayMs(text: string): number {
  return Math.min(6_000, Math.max(1_200, text.length * 35));
}
