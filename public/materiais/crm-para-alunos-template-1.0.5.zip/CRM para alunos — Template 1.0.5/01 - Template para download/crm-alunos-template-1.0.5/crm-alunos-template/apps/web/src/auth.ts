/**
 * Auth.js v5 — Credentials Provider (login email + senha).
 *
 * Decisão: JWT sessions (Credentials NÃO suporta database sessions).
 * Hash: bcrypt 12 rounds (lento o suficiente pra defender brute force, rápido pra UX).
 *
 * Convenção v5: este arquivo exporta { auth, signIn, signOut, handlers } —
 * importar de @/auth onde precisar.
 *
 * Rotas protegidas: ver proxy.ts (Next 16 usa proxy.ts em vez de middleware.ts).
 */

import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/db";
// Força a resolução de next-auth/jwt pro `declare module` abaixo conseguir
// augmentar a interface JWT — sem isto o TS solta TS2664.
import type {} from "next-auth/jwt";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      email: string;
      name?: string | null;
      role: "operator" | "admin";
    };
  }

  interface User {
    role?: "operator" | "admin";
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    sub: string;
    role?: "operator" | "admin";
  }
}

export const { auth, signIn, signOut, handlers } = NextAuth({
  // Trust host header — necessário atrás de proxy (Railway, ngrok).
  trustHost: true,

  // JWT obrigatório com Credentials.
  session: { strategy: "jwt", maxAge: 60 * 60 * 24 * 30 /* 30d */ },

  pages: {
    signIn: "/login",
    error: "/login",
  },

  providers: [
    Credentials({
      name: "Email e senha",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Senha", type: "password" },
      },
      async authorize(credentials) {
        const email = typeof credentials?.email === "string"
          ? credentials.email.trim().toLowerCase()
          : "";
        const password = typeof credentials?.password === "string"
          ? credentials.password
          : "";

        if (!email || !password) return null;

        const user = await prisma.user.findUnique({
          where: { email },
          select: {
            id: true,
            email: true,
            name: true,
            role: true,
            passwordHash: true,
          },
        });

        // Usuário inexistente ou sem senha → fail silencioso (não vaza qual dos dois).
        if (!user?.passwordHash) return null;

        const ok = await bcrypt.compare(password, user.passwordHash);
        if (!ok) return null;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role as "operator" | "admin",
        };
      },
    }),
  ],

  callbacks: {
    // Persistir id + role no JWT (Credentials não preenche por padrão).
    async jwt({ token, user }) {
      if (user) {
        token.sub = user.id!;
        token.role = (user.role ?? "operator") as "operator" | "admin";
      }
      return token;
    },

    // Refletir no Session.user pra ficar disponível via auth() / useSession().
    async session({ session, token }) {
      if (token.sub) session.user.id = token.sub;
      if (token.role) session.user.role = token.role;
      return session;
    },
  },
});
