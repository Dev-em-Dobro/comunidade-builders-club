"use server";

import { revalidatePath } from "next/cache";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";

export interface RuleFormState {
  ok?: boolean;
  error?: string;
}

const MODES = [
  "always_on",
  "contact_whitelist",
  "contact_blacklist",
  "keyword_trigger",
  "keyword_pause",
  "schedule",
  "manual_approval",
  "human_takeover",
] as const;

const ACTIONS = ["respond", "drop", "handoff", "static_reply"] as const;

/** Quebra texto em itens — aceita uma por linha ou separadas por vírgula. */
function splitItems(raw: string): string[] {
  return raw
    .split(/[\n,]/)
    .map((s) => s.trim())
    .filter(Boolean);
}

/** Monta o JSON `params` conforme o mode — shape esperado por `evaluateRule`. */
function buildParams(mode: string, fd: FormData): Prisma.InputJsonObject {
  switch (mode) {
    case "keyword_trigger":
    case "keyword_pause":
      return {
        keywords: splitItems(String(fd.get("keywords") ?? "")),
        matchMode: String(fd.get("matchMode") ?? "any") === "all" ? "all" : "any",
        caseSensitive: fd.get("caseSensitive") === "on",
      };
    case "contact_whitelist":
    case "contact_blacklist":
      return { contactIds: splitItems(String(fd.get("contactIds") ?? "")) };
    case "schedule":
      return {
        timezone:
          String(fd.get("timezone") ?? "").trim() || "America/Sao_Paulo",
        days: String(fd.get("days") ?? "")
          .split(",")
          .map((s) => Number(s.trim()))
          .filter((n) => Number.isInteger(n) && n >= 0 && n <= 6),
        start: String(fd.get("start") ?? "00:00"),
        end: String(fd.get("end") ?? "23:59"),
      };
    default:
      return {};
  }
}

/** Cria (sem `id`) ou edita (com `id`) uma regra de IA. */
export async function saveRule(formData: FormData): Promise<RuleFormState> {
  const id = (formData.get("id") as string | null) || null;
  const agentSessionId = String(formData.get("agentSessionId") ?? "");
  const mode = String(formData.get("mode") ?? "");
  const action = String(formData.get("action") ?? "respond");
  const priority = Number(formData.get("priority") ?? 100);
  const enabled = formData.get("enabled") === "on";
  const staticReply = String(formData.get("staticReply") ?? "").trim();

  if (!agentSessionId) return { error: "Agente inválido." };
  if (!MODES.includes(mode as (typeof MODES)[number])) {
    return { error: "Selecione um tipo de regra válido." };
  }
  if (!ACTIONS.includes(action as (typeof ACTIONS)[number])) {
    return { error: "Selecione uma ação válida." };
  }
  if (!Number.isFinite(priority) || priority < 0) {
    return { error: "Prioridade precisa ser um número maior ou igual a 0." };
  }

  const params = buildParams(mode, formData);

  if (
    (mode === "keyword_trigger" || mode === "keyword_pause") &&
    (params.keywords as string[]).length === 0
  ) {
    return { error: "Informe ao menos uma palavra-chave." };
  }
  if (
    (mode === "contact_whitelist" || mode === "contact_blacklist") &&
    (params.contactIds as string[]).length === 0
  ) {
    return { error: "Informe ao menos um ID de contato." };
  }
  if (mode === "schedule" && (params.days as number[]).length === 0) {
    return { error: "Selecione ao menos um dia da semana." };
  }
  if (action === "static_reply" && !staticReply) {
    return { error: "A ação 'Resposta fixa' precisa de um texto." };
  }

  // static_reply exige texto; handoff aceita um aviso opcional; resto não usa.
  const staticReplyToStore =
    action === "static_reply" || action === "handoff"
      ? staticReply || null
      : null;

  try {
    if (id) {
      // agentSessionId não muda numa edição — regra não troca de agente.
      await prisma.aIRule.update({
        where: { id },
        data: {
          priority,
          enabled,
          mode,
          action,
          params,
          staticReply: staticReplyToStore,
        },
      });
    } else {
      await prisma.aIRule.create({
        data: {
          agentSessionId,
          priority,
          enabled,
          mode,
          action,
          params,
          staticReply: staticReplyToStore,
        },
      });
    }
  } catch (err) {
    return { error: String((err as Error)?.message ?? err) };
  }

  revalidatePath(`/settings/agents/${agentSessionId}/rules`);
  return { ok: true };
}

/** Liga/desliga uma regra sem abrir o formulário. */
export async function toggleRule(
  id: string,
  agentSessionId: string,
  enabled: boolean,
): Promise<void> {
  await prisma.aIRule
    .update({ where: { id }, data: { enabled } })
    .catch(() => {});
  revalidatePath(`/settings/agents/${agentSessionId}/rules`);
}

/** Remove uma regra. */
export async function deleteRule(
  id: string,
  agentSessionId: string,
): Promise<void> {
  await prisma.aIRule.delete({ where: { id } }).catch(() => {});
  revalidatePath(`/settings/agents/${agentSessionId}/rules`);
}
