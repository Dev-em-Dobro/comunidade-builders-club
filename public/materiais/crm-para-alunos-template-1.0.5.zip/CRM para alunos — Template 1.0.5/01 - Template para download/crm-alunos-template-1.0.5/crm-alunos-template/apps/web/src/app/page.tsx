import { redirect } from "next/navigation";
import { auth } from "@/auth";

export default async function Home() {
  // Página inicial: se já está logado, vai direto pro painel; senão, login.
  const session = await auth();
  redirect(session?.user ? "/dashboard" : "/login");
}
