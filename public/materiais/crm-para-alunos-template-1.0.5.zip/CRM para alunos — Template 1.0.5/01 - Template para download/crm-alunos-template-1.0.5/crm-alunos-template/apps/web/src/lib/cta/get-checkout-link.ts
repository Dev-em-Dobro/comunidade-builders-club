import type { PrismaClient } from "@prisma/client";
import { Prisma } from "@prisma/client";
import { generateBase62Code } from "./short-code";
import { getActiveLaunch } from "@/lib/launches/active";
import { tryAttributeLaunchId } from "@/lib/leads";

export type CheckoutLinkResult =
  | { ok: true; url: string; code: string; planName?: string }
  | { ok: true; needsPlanChoice: true; plans: { id: string; name: string; priceCents: number }[] }
  | { ok: false; error: "no_checkout_url"; handoff: true }
  | { ok: false; error: "course_not_found" }
  | { ok: false; error: "invalid_plan_id" };

export interface GetCheckoutLinkInput {
  /**
   * Aceita PrismaClient (a função abre sua própria transação) ou
   * Prisma.TransactionClient (já vem de um $transaction externo — roda direto).
   */
  prisma: PrismaClient | Prisma.TransactionClient;
  leadId: string;
  courseId: string;
  conversationId: string;
  agentSessionId: string;
  baseUrl: string;
  planId?: string | null; // NEW
}

const SHORT_CODE_LEN = 6;
const MAX_CODE_RETRIES = 3;

export async function getCheckoutLink(
  input: GetCheckoutLinkInput,
): Promise<CheckoutLinkResult> {
  // Se vier PrismaClient, abre tx interactive; se já vier TxClient, roda direto.
  if ("$transaction" in input.prisma) {
    let interestPushed = false;
    const result = await (input.prisma as PrismaClient).$transaction(async (tx) => {
      const { result: r, interestPushed: pushed } = await runGetCheckoutLink({ ...input, prisma: tx });
      interestPushed = pushed;
      return r;
    });
    // Atribuição de rastreabilidade: roda APÓS commit da tx (analytics, não atômica).
    // fire-and-forget — não bloqueia nem throwa.
    if (interestPushed) void tryAttributeLaunchId(input.leadId);
    return result;
  }
  const { result, interestPushed } = await runGetCheckoutLink(input as GetCheckoutLinkInput & { prisma: Prisma.TransactionClient });
  // Sem tx wrapper: o write já foi commitado (autocommit), pode atribuir direto.
  if (interestPushed) void tryAttributeLaunchId(input.leadId);
  return result;
}

async function runGetCheckoutLink(
  input: GetCheckoutLinkInput & { prisma: Prisma.TransactionClient },
): Promise<{ result: CheckoutLinkResult; interestPushed: boolean }> {
  const { prisma, leadId, courseId, conversationId, agentSessionId, baseUrl, planId } = input;

  // Verifica oferta ativa antes da lógica de Course.checkoutUrl
  const active = await getActiveLaunch(courseId);
  if (active) {
    // Detecta caso "planos diferentes com mesma URL de checkout" — comum quando
    // a landing page resolve a escolha do plano internamente. Nesse caso, não
    // faz sentido perguntar qual plano antes; manda o link direto.
    const firstUrl = active.plans[0]?.checkoutUrl ?? null;
    const allPlansSameUrl =
      active.plans.length >= 2 &&
      firstUrl != null &&
      active.plans.every((p) => p.checkoutUrl === firstUrl);

    // 2+ planos sem escolha → devolve lista pra LLM perguntar (a MENOS que
    // todos compartilhem a mesma URL — aí cai no fluxo normal usando plans[0]).
    if (active.plans.length >= 2 && !planId && !allPlansSameUrl) {
      return {
        result: {
          ok: true,
          needsPlanChoice: true,
          plans: active.plans.map((p) => ({
            id: p.id,
            name: p.name,
            priceCents: p.priceCents,
          })),
        },
        interestPushed: false,
      };
    }

    // Determina plano alvo: se planId passado, busca o match; senão usa o único.
    const targetPlan = planId
      ? active.plans.find((p) => p.id === planId)
      : active.plans[0];

    if (planId && !targetPlan) {
      return { result: { ok: false, error: "invalid_plan_id" }, interestPushed: false };
    }

    // Safe — se chegou aqui sem planId, há exatamente 1 plano.
    if (!targetPlan!.checkoutUrl) {
      await prisma.pipelineEvent.create({
        data: {
          leadId,
          type: "cta_link_missing",
          payload: {
            courseId,
            launchId: active.id,
            planId: targetPlan!.id,
            agentId: agentSessionId,
          },
        },
      });
      await prisma.conversation.update({
        where: { id: conversationId },
        data: { handoffRequested: true },
      });
      await prisma.pipelineEvent.create({
        data: { leadId, type: "handoff", payload: { reason: "cta_missing" } },
      });
      return { result: { ok: false, error: "no_checkout_url", handoff: true }, interestPushed: false };
    }

    // ShortLink existente: chave (leadId, courseId) continua, mas armazena launchPlanId.
    const existing = await prisma.shortLink.findUnique({
      where: { leadId_courseId: { leadId, courseId } },
    });

    let code: string;
    let sentCount: number;
    if (existing) {
      code = existing.code;
      const updated = await prisma.shortLink.update({
        where: { id: existing.id },
        data: {
          launchPlanId: targetPlan!.id,
          sentCount: { increment: 1 },
          lastSentAt: new Date(),
        },
      });
      sentCount = updated.sentCount;
    } else {
      let created: { code: string; sentCount: number } | null = null;
      for (let attempt = 0; attempt < MAX_CODE_RETRIES; attempt++) {
        const candidate = generateBase62Code(SHORT_CODE_LEN);
        try {
          created = await prisma.shortLink.create({
            data: {
              code: candidate,
              leadId,
              courseId,
              launchPlanId: targetPlan!.id,
              sentCount: 1,
              lastSentAt: new Date(),
            },
          });
          break;
        } catch (err) {
          if (
            err instanceof Prisma.PrismaClientKnownRequestError &&
            err.code === "P2002"
          ) {
            continue;
          }
          throw err;
        }
      }
      if (!created) {
        throw new Error("getCheckoutLink: falha ao gerar code único após retries");
      }
      code = created.code;
      sentCount = created.sentCount;
    }

    // Inclui courseId em interestCourseIds se ainda não está (mesma lógica atual).
    const lead = await prisma.lead.findUniqueOrThrow({
      where: { id: leadId },
      select: { interestCourseIds: true },
    });
    let interestPushed = false;
    if (!lead.interestCourseIds.includes(courseId)) {
      await prisma.lead.update({
        where: { id: leadId },
        data: { interestCourseIds: { push: courseId } },
      });
      await prisma.pipelineEvent.create({
        data: {
          leadId,
          type: "interest_added",
          payload: { courseId, source: "cta_tool" },
        },
      });
      interestPushed = true;
    }

    await prisma.pipelineEvent.create({
      data: {
        leadId,
        type: "cta_sent",
        payload: { courseId, launchId: active.id, planId: targetPlan!.id, code, sentCount },
      },
    });

    return { result: { ok: true, url: `${baseUrl}/l/${code}`, code, planName: targetPlan!.name }, interestPushed };
  }

  // Fallback: sem oferta ativa — usa Course.checkoutUrl
  const course = await prisma.course.findUnique({ where: { id: courseId } });
  if (!course) return { result: { ok: false, error: "course_not_found" }, interestPushed: false };

  if (course.checkoutUrl == null) {
    await prisma.pipelineEvent.create({
      data: {
        leadId,
        type: "cta_link_missing",
        payload: { courseId, agentId: agentSessionId },
      },
    });
    await prisma.conversation.update({
      where: { id: conversationId },
      data: { handoffRequested: true },
    });
    await prisma.pipelineEvent.create({
      data: {
        leadId,
        type: "handoff",
        payload: { reason: "cta_missing" },
      },
    });
    return { result: { ok: false, error: "no_checkout_url", handoff: true }, interestPushed: false };
  }

  const existing = await prisma.shortLink.findUnique({
    where: { leadId_courseId: { leadId, courseId } },
  });

  let code: string;
  let sentCount: number;

  if (existing) {
    code = existing.code;
    const updated = await prisma.shortLink.update({
      where: { id: existing.id },
      data: { sentCount: { increment: 1 }, lastSentAt: new Date() },
    });
    sentCount = updated.sentCount;
  } else {
    let created: { code: string; sentCount: number } | null = null;
    for (let attempt = 0; attempt < MAX_CODE_RETRIES; attempt++) {
      const candidate = generateBase62Code(SHORT_CODE_LEN);
      try {
        created = await prisma.shortLink.create({
          data: {
            code: candidate,
            leadId,
            courseId,
            sentCount: 1,
            lastSentAt: new Date(),
          },
        });
        break;
      } catch (err) {
        if (
          err instanceof Prisma.PrismaClientKnownRequestError &&
          err.code === "P2002"
        ) {
          continue;
        }
        throw err;
      }
    }
    if (!created) {
      throw new Error("getCheckoutLink: falha ao gerar code único após retries");
    }
    code = created.code;
    sentCount = created.sentCount;
  }

  const lead = await prisma.lead.findUniqueOrThrow({
    where: { id: leadId },
    select: { interestCourseIds: true },
  });
  let interestPushed = false;
  if (!lead.interestCourseIds.includes(courseId)) {
    await prisma.lead.update({
      where: { id: leadId },
      data: { interestCourseIds: { push: courseId } },
    });
    await prisma.pipelineEvent.create({
      data: {
        leadId,
        type: "interest_added",
        payload: { courseId, source: "cta_tool" },
      },
    });
    interestPushed = true;
  }

  await prisma.pipelineEvent.create({
    data: {
      leadId,
      type: "cta_sent",
      payload: { courseId, code, sentCount },
    },
  });

  return { result: { ok: true, url: `${baseUrl}/l/${code}`, code }, interestPushed };
}
