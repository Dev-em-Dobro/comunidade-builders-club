import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { activateLaunch, closeLaunch } from "@/lib/launches/transitions";

function log(o: Record<string, unknown>) {
  console.log(JSON.stringify({ ts: new Date().toISOString(), ...o }));
}

/**
 * Job idempotente: ativa planned com startsAt<=now, encerra live com endsAt<=now.
 * Erros individuais são logados e seguem; não derruba o worker.
 *
 * Exportado separado pra fácil teste sem BullMQ.
 */
export async function runLaunchTransitionScan(): Promise<void> {
  const now = new Date();

  // 1. planned + janela já aberta → ativar
  const toActivate = await prisma.launch.findMany({
    where: {
      status: "planned",
      startsAt: { lte: now },
      endsAt: { gt: now },
      courseId: { not: null },
    },
    select: { id: true },
  });
  for (const l of toActivate) {
    const r = await activateLaunch({
      launchId: l.id,
      byUserId: null,
      reason: "cron_start",
    });
    if ("error" in r && r.error) {
      log({ event: "launch.cron_activate_failed", launchId: l.id, error: r.error });
    } else {
      log({ event: "launch.cron_activated", launchId: l.id });
    }
  }

  // 2. live + janela já fechada → encerrar
  const toClose = await prisma.launch.findMany({
    where: { status: "live", endsAt: { lte: now } },
    select: { id: true },
  });
  for (const l of toClose) {
    const r = await closeLaunch({
      launchId: l.id,
      byUserId: null,
      reason: "cron_end",
    });
    if ("error" in r && r.error) {
      log({ event: "launch.cron_close_failed", launchId: l.id, error: r.error });
    } else {
      log({ event: "launch.cron_closed", launchId: l.id });
    }
  }
}

/** Processador BullMQ — chamado pelo scheduler a cada 5 min. */
export async function launchTransitionsProcessor(_job: Job): Promise<void> {
  await runLaunchTransitionScan();
}
