/**
 * Predicados puros da cadência de reengajamento (Parte 11).
 *
 * Sem Prisma — o worker carrega o estado e chama os predicados. Mantém a
 * lógica testável e separada do I/O.
 */
import { ownsLeadForOutWindowCadence } from "./out-window-followup";

/** Após N horas sem atividade do lead, dispara reengajamento. */
export const REENGAGE_AFTER_MS = 12 * 60 * 60 * 1000;
/** Após N horas sem atividade, marca `lost(no_response)`. */
export const LOST_AFTER_MS = 24 * 60 * 60 * 1000;
/** Stages elegíveis pra cadência. `new` é excluído — lead nunca interagiu. */
export const ELIGIBLE_STAGES = ["contacted", "qualified"] as const;

/** Campos que os predicados precisam do Lead + Conversation. */
export interface ReengagementCandidate {
  leadId: string;
  conversationId: string;
  leadStage: string;
  lastActivityAt: Date | null;
  reengagementSentAt: Date | null;
  windowClosesAt: Date | null;
  aiEnabled: boolean;
  handoffRequested: boolean;
}

/**
 * Predicado: este lead deve receber reengajamento agora?
 *
 * `true` quando o lead está num stage elegível, parado há ≥12h, com janela
 * ainda aberta, IA ativa, sem handoff e nunca foi reengajado.
 */
export function isReengagementDue(c: ReengagementCandidate, now: Date): boolean {
  if (!ELIGIBLE_STAGES.includes(c.leadStage as (typeof ELIGIBLE_STAGES)[number])) {
    return false;
  }
  if (c.lastActivityAt == null) return false;
  if (now.getTime() - c.lastActivityAt.getTime() < REENGAGE_AFTER_MS) return false;
  if (c.reengagementSentAt != null) return false;
  if (c.windowClosesAt == null || c.windowClosesAt.getTime() <= now.getTime()) return false;
  if (!c.aiEnabled) return false;
  if (c.handoffRequested) return false;
  return true;
}

/** Subset que basta pra isLostByNoResponse + reconciliação com a cadência fora-da-janela. */
export type LostCandidate = Pick<
  ReengagementCandidate,
  "leadStage" | "lastActivityAt" | "reengagementSentAt"
> & {
  /** Lead.qualification.audience — pra reconciliação. */
  audience?: string | null;
  /** Lead.lastFollowUpStep — pra reconciliação. */
  lastFollowUpStep?: number | null;
};

/** Config mínima da cadência fora-da-janela pra reconciliação do lost. */
export interface OutWindowLostGuard {
  enabled: boolean;
  eligibleStages: string[];
  intervalsDays: number[];
}

/**
 * Predicado: este lead já é caso de `lost(no_response)`?
 *
 * `true` quando o lead está em stage elegível, já foi reengajado, e passaram
 * ≥24h sem atividade — EXCETO quando ele está sob uma cadência de follow-up
 * fora-da-janela ainda ativa (essa cadência adia o lost até esgotar o F3).
 */
export function isLostByNoResponse(
  c: LostCandidate,
  now: Date,
  outWindow?: OutWindowLostGuard,
): boolean {
  if (!ELIGIBLE_STAGES.includes(c.leadStage as (typeof ELIGIBLE_STAGES)[number])) {
    return false;
  }
  if (c.reengagementSentAt == null) return false;
  if (c.lastActivityAt == null) return false;
  if (now.getTime() - c.lastActivityAt.getTime() < LOST_AFTER_MS) return false;

  // Reconciliação: a cadência fora-da-janela é dona do lost desses leads.
  if (
    outWindow?.enabled &&
    ownsLeadForOutWindowCadence(
      {
        leadStage: c.leadStage,
        audience: c.audience ?? null,
        lastFollowUpStep: c.lastFollowUpStep ?? null,
      },
      { eligibleStages: outWindow.eligibleStages, intervalsDays: outWindow.intervalsDays },
    )
  ) {
    return false;
  }

  return true;
}
