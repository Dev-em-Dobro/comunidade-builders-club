import { randomUUID } from "node:crypto";
import { getRedis, hasRedis } from "@/lib/redis";
import { flushConversation } from "@/lib/flush";
import { debounceConfig } from "@/lib/config";
import { replyWaitMs } from "@/lib/reply-wait";
import type { ChannelMessage } from "@/lib/channels/types";

/**
 * Enfileira uma msg pro debounce.
 *
 *   - Cada msg RESETA o timer da janela (sliding window).
 *   - Compare-and-delete token evita race entre 2 workers.
 *   - LTRIM cap defende contra spam.
 *   - Gotcha 0.9.23: lockTtl = windowMs * 4 (lock precisa sobreviver pra além do fire do timer).
 *   - Gotcha 0.9.25: fallback síncrono se Redis cair.
 */
export async function enqueueForDebounce(msg: ChannelMessage): Promise<void> {
  const cfg = debounceConfig();
  if (!cfg.enabled || !hasRedis()) {
    log({ event: "debounce.passthrough", reason: !cfg.enabled ? "disabled" : "no_redis" });
    await flushConversation([msg]);
    return;
  }

  let redis;
  try {
    redis = getRedis();
  } catch (err) {
    log({
      event: "debounce.redis_init_failed",
      error: String((err as Error)?.message ?? err),
    });
    await flushConversation([msg]);
    return;
  }

  // Janela = tempo de espera do agente da conversa (padrão 8 s); config é o fallback.
  const windowMs = await replyWaitMs(msg.channel, msg.contactId, cfg.windowMs);
  const maxBuf = cfg.maxBufferedMessages;
  const lockTtlMs = windowMs * 4; // gotcha 0.9.23

  const key = `${cfg.keyPrefix}:${msg.channel}:${msg.contactId}`;
  const lock = `${key}:lock`;

  try {
    await redis
      .multi()
      .rpush(key, JSON.stringify(msg))
      .ltrim(key, -maxBuf, -1)
      .pexpire(key, lockTtlMs)
      .exec();

    const token = randomUUID();
    await redis.set(lock, token, "PX", lockTtlMs);

    setTimeout(async () => {
      try {
        const current = await redis.get(lock);
        if (current === null) {
          // Lock expirou antes do timer — só acontece se lockTtlMs estiver mal configurado.
          log({ event: "debounce.lock_expired", key });
          return;
        }
        if (current !== token) {
          // Outra msg chegou e renovou o lock — este flush é cancelado.
          log({ event: "debounce.superseded", key });
          return;
        }
        const buffered = await redis.lrange(key, 0, -1);
        await redis.multi().del(key).del(lock).exec();

        if (!buffered.length) return;
        const msgs = buffered
          .map((s) => {
            try { return JSON.parse(s) as ChannelMessage; }
            catch { return null; }
          })
          .filter((m): m is ChannelMessage => !!m);

        log({ event: "debounce.flush", key, count: msgs.length });
        await flushConversation(msgs);
      } catch (err) {
        log({
          event: "debounce.flush_error",
          key,
          error: String((err as Error)?.message ?? err),
        });
      }
    }, windowMs + 50);
  } catch (err) {
    log({
      event: "debounce.enqueue_failed",
      key,
      error: String((err as Error)?.message ?? err),
    });
    // Fallback síncrono (gotcha 0.9.25)
    await flushConversation([msg]);
  }
}

function log(payload: Record<string, unknown>) {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
