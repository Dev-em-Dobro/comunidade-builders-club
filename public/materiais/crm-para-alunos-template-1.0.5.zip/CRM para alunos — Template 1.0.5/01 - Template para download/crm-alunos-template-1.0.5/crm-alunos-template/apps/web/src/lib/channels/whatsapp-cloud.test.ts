import { describe, it, expect } from "vitest";
import { createHmac } from "node:crypto";
import { describeNonText, whatsappCloudAdapter } from "./whatsapp-cloud";

/**
 * Buraco residual no parser: tipos NÃO-mídia e NÃO-texto (localização, contato,
 * reação, unsupported, desconhecido) caíam no fallback `""` → conversa vazia na
 * inbox + bot mudo. `describeNonText` garante texto legível pra todos eles.
 */
describe("describeNonText", () => {
  it("localização → label + nome + coords + link de mapa", () => {
    const out = describeNonText(
      { location: { latitude: -23.56, longitude: -46.64, name: "Av Paulista" } },
      "location",
    );
    expect(out).toContain("[localização]");
    expect(out).toContain("Av Paulista");
    expect(out).toContain("https://www.google.com/maps?q=-23.56,-46.64");
  });

  it("localização só com coords → ainda gera o link", () => {
    const out = describeNonText({ location: { latitude: -1, longitude: -2 } }, "location");
    expect(out).toContain("(-1, -2)");
    expect(out).toContain("https://www.google.com/maps?q=-1,-2");
  });

  it("contato (vCard) → nome e telefone", () => {
    const out = describeNonText(
      { contacts: [{ name: { formatted_name: "João Silva" }, phones: [{ phone: "+55 11 90000-0000" }] }] },
      "contacts",
    );
    expect(out).toContain("[contato]");
    expect(out).toContain("João Silva");
    expect(out).toContain("+55 11 90000-0000");
  });

  it("contato sem dados úteis → [contato] (nunca vazio)", () => {
    expect(describeNonText({ contacts: [] }, "contacts")).toBe("[contato]");
  });

  it("reação → label + emoji", () => {
    expect(describeNonText({ reaction: { message_id: "wamid.x", emoji: "👍" } }, "reaction")).toBe(
      "[reação] 👍",
    );
  });

  it("reação sem emoji → [reação]", () => {
    expect(describeNonText({ reaction: {} }, "reaction")).toBe("[reação]");
  });

  it("tipo 'unsupported' da Meta → placeholder legível", () => {
    expect(describeNonText({}, "unsupported")).toBe("[mensagem não suportada]");
  });

  it("tipo futuro/desconhecido → inclui o tipo, nunca vazio", () => {
    const out = describeNonText({}, "order");
    expect(out.length).toBeGreaterThan(0);
    expect(out).toContain("order");
  });
});

describe("mídia no webhook WhatsApp", () => {
  it("preserva o ID e o tipo do áudio para exibição no CRM", async () => {
    const previousSecret = process.env.META_APP_SECRET;
    process.env.META_APP_SECRET = "test-secret";
    try {
      const payload = JSON.stringify({
        entry: [{ changes: [{ value: {
          contacts: [{ wa_id: "5511999999999" }],
          messages: [{
            from: "5511999999999",
            id: "wamid.audio-1",
            type: "audio",
            timestamp: "1700000000",
            audio: { id: "998877", mime_type: "audio/ogg", voice: true },
          }],
        } }] }],
      });
      const signature = createHmac("sha256", "test-secret").update(payload).digest("hex");
      const request = new Request("http://localhost/api/webhooks/whatsapp-cloud", {
        method: "POST",
        headers: { "x-hub-signature-256": `sha256=${signature}` },
        body: payload,
      });

      const message = await whatsappCloudAdapter.parseWebhook(request);
      expect(message?.text).toBe("[audio]");
      expect(message?.media).toEqual([{ type: "audio", id: "998877", mimeType: "audio/ogg", caption: undefined }]);
    } finally {
      if (previousSecret === undefined) delete process.env.META_APP_SECRET;
      else process.env.META_APP_SECRET = previousSecret;
    }
  });
});
