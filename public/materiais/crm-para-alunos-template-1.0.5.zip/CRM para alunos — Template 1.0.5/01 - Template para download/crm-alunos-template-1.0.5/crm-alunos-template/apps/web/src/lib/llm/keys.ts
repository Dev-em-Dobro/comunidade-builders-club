import { prisma } from "@/lib/db";
import { decryptSecret, secretsKeyConfigured } from "@/lib/crypto/secrets";

const ENV_BY_PROVIDER: Record<string, string> = {
  anthropic: "ANTHROPIC_API_KEY",
  openai: "OPENAI_API_KEY",
};

/**
 * Resolve a chave de API de um provider: primeiro do banco (ProviderCredential,
 * descriptografada), depois da env var correspondente. Retorna undefined se
 * nenhuma fonte tiver a chave.
 */
export async function resolveProviderKey(provider: string): Promise<string | undefined> {
  if (secretsKeyConfigured()) {
    try {
      const cred = await prisma.providerCredential.findUnique({ where: { provider } });
      if (cred?.apiKeyEnc) {
        return decryptSecret(cred.apiKeyEnc);
      }
    } catch {
      // DB indisponível ou decrypt falhou — cai pro fallback de env var.
    }
  }
  const envName = ENV_BY_PROVIDER[provider];
  const fromEnv = envName ? process.env[envName] : undefined;
  return fromEnv || undefined;
}
