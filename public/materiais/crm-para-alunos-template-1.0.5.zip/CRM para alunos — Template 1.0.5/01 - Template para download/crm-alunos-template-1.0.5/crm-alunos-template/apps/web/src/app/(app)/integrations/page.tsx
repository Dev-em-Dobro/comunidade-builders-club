import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { googleConnectionStatus } from "@/lib/google/oauth";
import { Sheet, Workflow, ChevronRight } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function IntegrationsPage() {
  const google = await googleConnectionStatus();
  const n8n = Boolean(process.env.N8N_NEW_CONVERSATION_WEBHOOK_URL);

  const items = [
    {
      href: "/integrations/google-sheets",
      icon: Sheet,
      title: "Google Sheets",
      description: "Opcional: cada consulta agendada vira uma linha numa planilha — com a pré-consulta do paciente.",
      status: google.sheetsSpreadsheetId
        ? "planilha vinculada"
        : google.connected
          ? "sem planilha"
          : google.credentials === "ausente"
            ? "não configurado"
            : "pronto para conectar",
      on: Boolean(google.connected && google.sheetsSpreadsheetId),
    },
    {
      href: null,
      icon: Workflow,
      title: "n8n",
      description: "Webhook de nova conversa (N8N_NEW_CONVERSATION_WEBHOOK_URL). Configurado por variável de ambiente.",
      status: n8n ? "ativo" : "desligado",
      on: n8n,
    },
  ];

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <header className="mb-6">
        <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">Integrações</h1>
        <p className="text-muted-foreground mt-1">Conecte o CRM aos serviços que sua equipe já usa.</p>
      </header>
      <div className="grid gap-3 md:grid-cols-2">
        {items.map((it) => {
          const Icon = it.icon;
          const card = (
            <Card className={it.href ? "h-full transition-colors hover:border-primary/60" : "h-full"}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between gap-2">
                  <CardTitle className="text-base flex items-center gap-2">
                    <Icon className="size-4 text-primary" /> {it.title}
                  </CardTitle>
                  <Badge variant={it.on ? "default" : "outline"} className="text-[10px]">
                    {it.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="flex items-end justify-between gap-3">
                <CardDescription>{it.description}</CardDescription>
                {it.href && <ChevronRight className="size-4 text-muted-foreground shrink-0" />}
              </CardContent>
            </Card>
          );
          return it.href ? (
            <Link key={it.title} href={it.href}>
              {card}
            </Link>
          ) : (
            <div key={it.title}>{card}</div>
          );
        })}
      </div>
    </div>
  );
}
