import { businessConfig } from "@/lib/config";
import Link from "next/link";
import { ArrowLeft, Bot } from "lucide-react";

/**
 * Layout compartilhado das páginas legais públicas (privacidade, exclusão de
 * dados). Sem autenticação — vive no route group (public). Server Component.
 */
export function LegalPage({
  title,
  updatedAt,
  children,
}: {
  title: string;
  updatedAt: string;
  children: React.ReactNode;
}) {
  return (
    <main className="flex min-h-screen flex-col">
      <header className="border-b border-border">
        <div className="container mx-auto flex items-center justify-between px-6 py-4">
          <Link href="/" className="flex items-center gap-3">
            <div className="flex size-8 items-center justify-center rounded-md bg-primary glow-primary">
              <Bot className="size-5 text-primary-foreground" />
            </div>
            <span className="font-mono font-semibold tracking-tight">
              {businessConfig().brandName}
            </span>
          </Link>
          <Link
            href="/"
            className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="size-4" />
            Voltar ao início
          </Link>
        </div>
      </header>

      <article className="container mx-auto w-full max-w-3xl flex-1 px-6 py-12">
        <h1 className="text-balance text-3xl font-semibold tracking-tight md:text-4xl">
          {title}
        </h1>
        <p className="mt-2 font-mono text-sm text-muted-foreground">
          Última atualização: {updatedAt}
        </p>
        <div className="mt-10 space-y-8 text-sm leading-relaxed text-muted-foreground">
          {children}
        </div>
      </article>

      <footer className="border-t border-border py-6">
        <div className="container mx-auto px-6 text-sm text-muted-foreground">
          <span className="font-mono">{businessConfig().legalName}</span>
          {" · "}
          <Link
            href="/privacy"
            className="underline underline-offset-2 hover:text-foreground"
          >
            Política de Privacidade
          </Link>
          {" · "}
          <Link
            href="/data-deletion"
            className="underline underline-offset-2 hover:text-foreground"
          >
            Exclusão de dados
          </Link>
        </div>
      </footer>
    </main>
  );
}

/** Bloco numerado de uma página legal: título + conteúdo. */
export function LegalSection({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="space-y-3">
      <h2 className="text-lg font-semibold tracking-tight text-foreground">
        {title}
      </h2>
      {children}
    </section>
  );
}

/** Link inline com o destaque verde do tema. Aceita rota interna ou mailto. */
export function LegalLink({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  const className =
    "text-primary underline underline-offset-2 hover:text-primary/80";
  if (href.startsWith("/")) {
    return (
      <Link href={href} className={className}>
        {children}
      </Link>
    );
  }
  return (
    <a href={href} className={className}>
      {children}
    </a>
  );
}

/** Ênfase em termos dentro do corpo de texto (claro sobre o muted). */
export function LegalStrong({ children }: { children: React.ReactNode }) {
  return <strong className="font-medium text-foreground">{children}</strong>;
}

/** Lista com marcadores padrão das páginas legais. */
export function LegalList({ items }: { items: React.ReactNode[] }) {
  return (
    <ul className="list-disc space-y-1.5 pl-5 marker:text-muted-foreground">
      {items.map((item, i) => (
        <li key={i}>{item}</li>
      ))}
    </ul>
  );
}
