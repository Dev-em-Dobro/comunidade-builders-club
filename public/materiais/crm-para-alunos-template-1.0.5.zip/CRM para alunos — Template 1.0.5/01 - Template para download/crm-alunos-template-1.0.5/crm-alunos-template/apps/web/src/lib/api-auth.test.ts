import { describe, it, expect, vi } from "vitest";
import { NextResponse } from "next/server";

vi.mock("@/auth", () => ({
  auth: vi.fn(),
}));

import { requireSession } from "./api-auth";
import { auth } from "@/auth";

describe("requireSession", () => {
  it("devolve 401 NextResponse quando não há sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const result = await requireSession();
    expect(result).toBeInstanceOf(NextResponse);
    expect((result as NextResponse).status).toBe(401);
    const body = await (result as NextResponse).json();
    expect(body.error).toBe("unauthorized");
  });

  it("devolve 401 quando sessão existe mas sem user.id", async () => {
    vi.mocked(auth).mockResolvedValueOnce({ user: {} } as never);
    const result = await requireSession();
    expect(result).toBeInstanceOf(NextResponse);
    expect((result as NextResponse).status).toBe(401);
  });

  it("devolve { user } com a sessão quando válida", async () => {
    vi.mocked(auth).mockResolvedValueOnce({
      user: { id: "u1", role: "operator", email: "a@t.local" },
    } as never);
    const result = await requireSession();
    expect(result).not.toBeInstanceOf(NextResponse);
    const { user } = result as { user: { id: string; role: string } };
    expect(user.id).toBe("u1");
    expect(user.role).toBe("operator");
  });
});
