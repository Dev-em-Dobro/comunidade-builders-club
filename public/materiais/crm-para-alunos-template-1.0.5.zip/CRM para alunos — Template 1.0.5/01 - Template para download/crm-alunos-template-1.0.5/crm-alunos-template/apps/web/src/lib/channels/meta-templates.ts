import { resolveMetaSettings } from "@/lib/settings/meta";
/**
 * Wrappers da Graph API pra Message Templates do WhatsApp Cloud.
 *
 * Listagem: GET /{business_account_id}/message_templates (paginado).
 * Envio:    POST /{phone_number_id}/messages com type=template.
 *
 * Mesma estratégia de erro do whatsapp-cloud.ts: 2xx → resultado parseado;
 * !2xx → ChannelSendError com code Meta preservado.
 */

import {
  META_GRAPH_BASE,
  ChannelSendError,
  describeMetaError,
} from "./meta-graph";
import type { MetaComponent } from "@/lib/templates/parse";

export interface MetaTemplate {
  name: string;
  language: string;
  category: string;
  status: string;
  components: MetaComponent[];
}

interface ListResponse {
  data?: Array<{
    name: string;
    language: string;
    category: string;
    status: string;
    components?: MetaComponent[];
  }>;
  paging?: { next?: string };
}

async function env() {
  const meta = await resolveMetaSettings();
  return {
    wabaId: meta.META_BUSINESS_ACCOUNT_ID,
    phoneNumberId: meta.META_PHONE_NUMBER_ID,
    token: meta.META_SYSTEM_USER_TOKEN,
  };
}

async function requireCreds(needed: Array<"wabaId" | "phoneNumberId" | "token">) {
  const e = await env();
  const missing = needed.filter((k) => !e[k]);
  if (missing.length > 0) {
    throw new Error(
      `Credenciais Meta ausentes (${missing.join(", ")}). Configure META_BUSINESS_ACCOUNT_ID, META_PHONE_NUMBER_ID, META_SYSTEM_USER_TOKEN.`,
    );
  }
  return e as Required<Awaited<ReturnType<typeof env>>>;
}

/**
 * GET /{waba_id}/message_templates?fields=name,language,category,status,components
 * Segue paginação via paging.next até cursor terminar.
 */
export async function listMetaTemplates(): Promise<MetaTemplate[]> {
  const e = await requireCreds(["wabaId", "token"]);
  const fields = "name,language,category,status,components";
  let url: string | undefined = `${META_GRAPH_BASE}/${e.wabaId}/message_templates?fields=${fields}&limit=200`;
  const all: MetaTemplate[] = [];

  while (url) {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${e.token}` },
      cache: "no-store",
    });
    if (!res.ok) {
      const body = await res.text();
      const info = describeMetaError(res.status, body);
      console.error(
        JSON.stringify({
          event: "meta_templates.list_error",
          status: res.status,
          code: info.code,
          name: info.name,
          action: info.action,
          at: new Date().toISOString(),
        }),
      );
      throw new ChannelSendError(info, res.status);
    }
    const json = (await res.json()) as ListResponse;
    for (const t of json.data ?? []) {
      all.push({
        name: t.name,
        language: t.language,
        category: t.category,
        status: t.status,
        components: t.components ?? [],
      });
    }
    url = json.paging?.next;
  }

  return all;
}

export interface SendTemplateOpts {
  externalId: string;
  templateName: string;
  language: string;
  variables: string[];
}

/**
 * POST /{phone_number_id}/messages com payload:
 * { messaging_product, to, type: "template", template: { name, language, components } }
 *
 * Quando variables tem itens, monta UM component type=body com parameters
 * na ordem. Sem variables, omite components (template sem vars).
 */
export async function sendTemplateMessage(
  opts: SendTemplateOpts,
): Promise<{ providerMsgId: string }> {
  // Gotcha 0.9.27: externalId DEVE ser wa_id (E.164), nunca Contact.id cuid.
  if (/^c[a-z0-9]{24}$/.test(opts.externalId)) {
    throw new Error(
      `sendTemplateMessage recebeu cuid (${opts.externalId}); use ContactIdentity.externalId.`,
    );
  }

  const e = await requireCreds(["phoneNumberId", "token"]);

  const components =
    opts.variables.length > 0
      ? [
          {
            type: "body",
            parameters: opts.variables.map((v) => ({ type: "text", text: v })),
          },
        ]
      : undefined;

  const res = await fetch(`${META_GRAPH_BASE}/${e.phoneNumberId}/messages`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${e.token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: opts.externalId,
      type: "template",
      template: {
        name: opts.templateName,
        language: { code: opts.language },
        ...(components ? { components } : {}),
      },
    }),
  });

  if (!res.ok) {
    const body = await res.text();
    const info = describeMetaError(res.status, body);
    console.error(
      JSON.stringify({
        event: "whatsapp_cloud.send_template_error",
        status: res.status,
        code: info.code,
        name: info.name,
        action: info.action,
        templateName: opts.templateName,
        at: new Date().toISOString(),
      }),
    );
    throw new ChannelSendError(info, res.status);
  }

  const json = (await res.json()) as { messages?: Array<{ id?: string }> };
  const id = json.messages?.[0]?.id;
  if (!id) {
    throw new Error(
      `sendTemplateMessage: resposta Meta sem messages[0].id — ${JSON.stringify(json).slice(0, 200)}`,
    );
  }
  return { providerMsgId: id };
}
