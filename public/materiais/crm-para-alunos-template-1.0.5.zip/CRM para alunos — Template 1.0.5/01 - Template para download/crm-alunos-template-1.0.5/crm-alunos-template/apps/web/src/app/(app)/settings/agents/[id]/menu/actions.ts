"use server";

import { revalidatePath } from "next/cache";
import type { Prisma } from "@prisma/client";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";
import { DELIVERY_ROLE } from "@/lib/delivery/agent";
import { parseAreasText, parseMenuLines } from "@/lib/delivery/menu";

export interface MenuFormState {
  error?: string;
  ok?: string;
}

const path = (agentId: string) => `/settings/agents/${agentId}/menu`;

/** Admin + agente de delivery. */
async function guard(agentId: string) {
  const session = await auth();
  if (session?.user?.role !== "admin") return { error: "Acesso exclusivo do administrador." } as const;
  const agent = await prisma.agentSession.findFirst({
    where: { id: agentId, role: DELIVERY_ROLE },
    select: { id: true, provider: true, model: true },
  });
  if (!agent) return { error: "Agente de delivery não encontrado." } as const;
  return { agent } as const;
}

export async function saveStoreSettings(agentId: string, _prev: MenuFormState, form: FormData): Promise<MenuFormState> {
  const g = await guard(agentId);
  if ("error" in g) return { error: g.error };
  let areas;
  try {
    areas = parseAreasText(String(form.get("areas") ?? ""));
  } catch (err) {
    return { error: (err as Error).message };
  }
  const text = (key: string, max: number) => String(form.get(key) ?? "").trim().slice(0, max) || null;
  const data = {
    description: text("description", 2000),
    hours: text("hours", 200),
    pickupEnabled: form.get("pickupEnabled") === "on",
    pickupAddress: text("pickupAddress", 300),
    areas: areas as unknown as Prisma.InputJsonValue,
  };
  await prisma.deliveryStore.upsert({ where: { agentSessionId: agentId }, create: { agentSessionId: agentId, ...data }, update: data });
  revalidatePath(path(agentId));
  return { ok: "Dados do estabelecimento salvos." };
}

export async function saveMenuItems(agentId: string, _prev: MenuFormState, form: FormData): Promise<MenuFormState> {
  const g = await guard(agentId);
  if ("error" in g) return { error: g.error };
  let items;
  try {
    items = parseMenuLines(String(form.get("items") ?? ""));
  } catch (err) {
    return { error: (err as Error).message };
  }
  const data = { menuItems: items as unknown as Prisma.InputJsonValue, menuUpdatedAt: new Date() };
  await prisma.deliveryStore.upsert({ where: { agentSessionId: agentId }, create: { agentSessionId: agentId, ...data }, update: data });
  revalidatePath(path(agentId));
  return { ok: `Itens salvos: ${items.length}.` };
}
