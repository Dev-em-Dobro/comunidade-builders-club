/**
 * Quanto esperar o contato terminar de escrever antes de responder — vem do
 * agente que atende a conversa (AgentSession.humanize.waitSeconds), ou do
 * agente padrão quando a conversa ainda não tem um.
 *
 * Roda a cada mensagem recebida (antes do debounce), então tem cache curto em
 * memória e nunca lança: qualquer falha cai no valor do setup.config.json.
 */
import { prisma } from "@/lib/db";
import { normalizeHumanize } from "@/lib/humanize";

const TTL_MS = 60_000;
const cache = new Map<string, { at: number; ms: number }>();

export async function replyWaitMs(channel: string, externalId: string, fallbackMs: number): Promise<number> {
  const key = `${channel}:${externalId}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.ms;

  try {
    const identity = await prisma.contactIdentity.findUnique({
      where: { channel_externalId: { channel, externalId } },
      select: { contactId: true },
    });
    const conv = identity
      ? await prisma.conversation.findFirst({
          where: { contactId: identity.contactId, channel },
          orderBy: { createdAt: "desc" },
          select: { agentSession: { select: { humanize: true } } },
        })
      : null;
    const humanize =
      conv?.agentSession?.humanize ??
      (await prisma.agentSession.findFirst({ where: { isDefault: true }, select: { humanize: true } }))?.humanize;
    if (humanize === undefined) return fallbackMs;
    const ms = normalizeHumanize(humanize).waitSeconds * 1000;
    cache.set(key, { at: Date.now(), ms });
    return ms;
  } catch {
    return fallbackMs;
  }
}
