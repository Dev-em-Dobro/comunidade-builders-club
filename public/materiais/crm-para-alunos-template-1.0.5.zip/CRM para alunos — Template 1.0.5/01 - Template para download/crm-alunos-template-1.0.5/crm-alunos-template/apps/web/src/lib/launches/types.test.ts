import { describe, it, expect } from "vitest";
import { BonusesSchema, parseBonuses, type Bonus } from "./types";

describe("BonusesSchema", () => {
  it("aceita lista válida", () => {
    const bonuses: Bonus[] = [
      { title: "Mentoria mensal", description: "1h por mês" },
      { title: "Grupo de alumni", description: "Networking" },
    ];
    expect(BonusesSchema.parse(bonuses)).toEqual(bonuses);
  });

  it("aceita lista vazia", () => {
    expect(BonusesSchema.parse([])).toEqual([]);
  });

  it("rejeita item sem title", () => {
    expect(() => BonusesSchema.parse([{ description: "x" }])).toThrow();
  });

  it("rejeita item sem description", () => {
    expect(() => BonusesSchema.parse([{ title: "x" }])).toThrow();
  });

  it("rejeita não-array", () => {
    expect(() => BonusesSchema.parse({ title: "x" })).toThrow();
  });
});

describe("parseBonuses (Json -> Bonus[])", () => {
  it("retorna [] pra null/undefined/lixo", () => {
    expect(parseBonuses(null)).toEqual([]);
    expect(parseBonuses(undefined)).toEqual([]);
    expect(parseBonuses("{}")).toEqual([]);
    expect(parseBonuses({ a: 1 })).toEqual([]);
  });

  it("parseia array válido", () => {
    expect(
      parseBonuses([{ title: "x", description: "y" }]),
    ).toEqual([{ title: "x", description: "y" }]);
  });

  it("filtra itens malformados sem explodir", () => {
    expect(
      parseBonuses([
        { title: "ok", description: "ok" },
        { title: "fail" }, // sem description
        "lixo",
      ]),
    ).toEqual([{ title: "ok", description: "ok" }]);
  });
});
