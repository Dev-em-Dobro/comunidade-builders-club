import { describe, it, expect, vi, beforeAll, beforeEach, afterAll } from "vitest";
import { prisma } from "@/lib/db";

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "" } })),
}));

import { POST } from "./route";
import { auth } from "@/auth";

const created = {
  convIds: [] as string[],
  leadIds: [] as string[],
  contactIds: [] as string[],
  userIds: [] as string[],
};
let userId: string;

beforeAll(async () => {
  const user = await prisma.user.create({
    data: { email: `outcome-${Date.now()}@t.local`, name: "Atendente" },
  });
  userId = user.id;
  created.userIds.push(user.id);
});

afterAll(async () => {
  await prisma.conversation.deleteMany({ where: { id: { in: created.convIds } } });
  await prisma.pipelineEvent.deleteMany({ where: { leadId: { in: created.leadIds } } });
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.user.deleteMany({ where: { id: { in: created.userIds } } });
  await prisma.$disconnect();
});

beforeEach(() => {
  vi.mocked(auth).mockResolvedValue({ user: { id: userId } } as never);
});

async function makeLead(
  stage: string,
  extra: { lostAt?: Date; lostReason?: string; wonAt?: Date } = {},
) {
  const c = await prisma.contact.create({
    data: { displayName: `L-${Date.now()}-${Math.random()}` },
  });
  created.contactIds.push(c.id);
  const l = await prisma.lead.create({
    data: {
      contactId: c.id,
      stage,
      lostAt: extra.lostAt ?? null,
      lostReason: extra.lostReason ?? null,
      wonAt: extra.wonAt ?? null,
    },
  });
  created.leadIds.push(l.id);
  return l;
}

async function makeConversation(leadId: string, contactId: string) {
  const conv = await prisma.conversation.create({
    data: { contactId, channel: "whatsapp", leadId, aiEnabled: true },
  });
  created.convIds.push(conv.id);
  return conv;
}

function req(body: unknown): Request {
  return new Request("http://test", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body),
  });
}

describe("POST /api/leads/[id]/outcome", () => {
  it("401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const lead = await makeLead("contacted");
    const res = await POST(req({ outcome: "won" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(401);
  });

  it("404 lead inexistente", async () => {
    const res = await POST(req({ outcome: "won" }), {
      params: Promise.resolve({ id: "cmnonexistent000000000000" }),
    });
    expect(res.status).toBe(404);
  });

  it("400 outcome inválido", async () => {
    const lead = await makeLead("contacted");
    const res = await POST(req({ outcome: "talvez" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(400);
  });

  it("400 perdido sem motivo", async () => {
    const lead = await makeLead("contacted");
    const res = await POST(req({ outcome: "lost" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(400);
  });

  it("400 motivo fora do vocabulário", async () => {
    const lead = await makeLead("contacted");
    const res = await POST(req({ outcome: "lost", reason: "qualquer_coisa" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(400);
  });

  it("200 ganho: stage=won, wonAt setado + PipelineEvent(via=manual_conversation)", async () => {
    const lead = await makeLead("contacted");
    const res = await POST(req({ outcome: "won" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    expect(after.wonAt).not.toBeNull();
    const ev = await prisma.pipelineEvent.findFirstOrThrow({
      where: { leadId: lead.id, type: "stage_change" },
      orderBy: { createdAt: "desc" },
    });
    expect(ev.payload).toMatchObject({
      from: "contacted",
      to: "won",
      via: "manual_conversation",
    });
  });

  it("200 perdido com motivo + observação: lostAt/lostReason setados, note no evento", async () => {
    const lead = await makeLead("qualified");
    const res = await POST(
      req({ outcome: "lost", reason: "preco", note: "achou caro" }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("lost");
    expect(after.lostAt).not.toBeNull();
    expect(after.lostReason).toBe("preco");
    const ev = await prisma.pipelineEvent.findFirstOrThrow({
      where: { leadId: lead.id, type: "stage_change" },
      orderBy: { createdAt: "desc" },
    });
    expect(ev.payload).toMatchObject({ to: "lost", reason: "preco", note: "achou caro" });
  });

  it("proposal → won é permitido (sem guard de stage terminal)", async () => {
    const lead = await makeLead("proposal");
    const res = await POST(req({ outcome: "won" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
  });

  it("correção perdido → ganho limpa lostAt/lostReason", async () => {
    const lead = await makeLead("lost", {
      lostAt: new Date("2026-05-01"),
      lostReason: "preco",
    });
    const res = await POST(req({ outcome: "won" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    expect(after.lostAt).toBeNull();
    expect(after.lostReason).toBeNull();
    expect(after.wonAt).not.toBeNull();
  });

  it("correção ganho → perdido limpa wonAt", async () => {
    const lead = await makeLead("won", { wonAt: new Date("2026-05-01") });
    const res = await POST(req({ outcome: "lost", reason: "outro" }), {
      params: Promise.resolve({ id: lead.id }),
    });
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("lost");
    expect(after.wonAt).toBeNull();
    expect(after.lostReason).toBe("outro");
  });

  it("pausa a IA da conversa quando conversationId é passado", async () => {
    const lead = await makeLead("contacted");
    const conv = await makeConversation(lead.id, lead.contactId);
    const res = await POST(
      req({ outcome: "won", conversationId: conv.id }),
      { params: Promise.resolve({ id: lead.id }) },
    );
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.aiPaused).toBe(true);
    const after = await prisma.conversation.findUniqueOrThrow({ where: { id: conv.id } });
    expect(after.aiEnabled).toBe(false);
  });
});
