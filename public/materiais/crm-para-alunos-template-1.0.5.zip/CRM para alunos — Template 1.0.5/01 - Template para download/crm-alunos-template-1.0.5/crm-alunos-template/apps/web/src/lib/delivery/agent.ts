/**
 * Agente de delivery (AgentSession.role = "delivery").
 *
 * Recebe o cliente, apresenta o estabelecimento, envia o cardápio, anota o
 * pedido, confirma o total e registra o pedido pra cozinha (aba Pedidos +
 * histórico do contato).
 *
 * Tools (loop em llm/tool-loop.ts): send_menu, quote_order, place_order.
 * Preço vem SEMPRE do cardápio guardado (lib/delivery/menu.ts).
 */
import type { LLMToolDef, LLMToolUse } from "@/lib/llm/types";
import { prisma } from "@/lib/db";
import { getAdapter } from "@/lib/channels/registry";
import type { ChannelId } from "@/lib/channels/types";
import { sendOutboundMessage } from "@/lib/outbound";
import { notifyMessage } from "@/lib/realtime/notify";
import { dayLabel, zonedParts } from "@/lib/scheduling/time";
import { schedulingTimezone } from "@/lib/scheduling/timezone";
import { formatBRL, menuAsText, PAYMENT_LABEL, type PaymentMethod } from "./menu";
import { getStore, placeOrder, quoteOrder } from "./service";

export const DELIVERY_ROLE = "delivery";
export const DELIVERY_TOOL_NAMES = new Set(["send_menu", "quote_order", "place_order"]);
export const isDeliveryTool = (name: string) => DELIVERY_TOOL_NAMES.has(name);

/** Marca da mensagem gravada quando o cardápio é enviado (evita reenviar em seguida). */
const MENU_SENT_MARK = "📋 Cardápio enviado";
const RESEND_AFTER_MS = 30 * 60_000;

const orderSchema = (requireCheckout: boolean) => ({
  type: "object",
  properties: {
    items: {
      type: "array",
      description: "Itens do pedido, com o nome EXATAMENTE como está no cardápio.",
      items: {
        type: "object",
        properties: {
          name: { type: "string" },
          quantity: { type: "integer", minimum: 1 },
          notes: { type: "string", description: "Observação do item (ex.: sem cebola)." },
        },
        required: ["name", "quantity"],
      },
    },
    fulfillment: { type: "string", enum: ["delivery", "pickup"], description: "Entrega ou retirada no local." },
    neighborhood: { type: "string", description: "Bairro de entrega, como está na lista de bairros atendidos." },
    ...(requireCheckout
      ? {
          address: { type: "string", description: "Endereço completo: rua, número, complemento e referência." },
          paymentMethod: { type: "string", enum: ["pix", "card", "cash"] },
          changeFor: { type: "number", description: "Dinheiro: troco para quanto (em reais). Omita se não precisa." },
          customerName: { type: "string" },
          notes: { type: "string", description: "Observação geral do pedido." },
        }
      : {}),
  },
  required: requireCheckout ? ["items", "fulfillment", "paymentMethod"] : ["items", "fulfillment"],
});

export const DELIVERY_TOOLS: LLMToolDef[] = [
  {
    name: "send_menu",
    description:
      "Envia o cardápio (arquivo ou link) para o cliente no WhatsApp. Use quando o cliente pedir o cardápio " +
      "ou no início do atendimento. Não reenvie se já foi enviado nesta conversa, a menos que o cliente peça.",
    inputSchema: { type: "object", properties: {} },
  },
  {
    name: "quote_order",
    description:
      "Calcula o pedido com os preços oficiais do cardápio e a taxa do bairro. Use para montar o resumo e o " +
      "total ANTES de confirmar com o cliente. Não registra nada.",
    inputSchema: orderSchema(false),
  },
  {
    name: "place_order",
    description:
      "Registra o pedido e manda para a cozinha. Só chame depois que o cliente CONFIRMAR o resumo com o total. " +
      "O pedido só está feito se o retorno for ok:true.",
    inputSchema: orderSchema(true),
  },
];

export interface DeliverySetup {
  tools: LLMToolDef[];
  contextBlock: string;
}

export async function prepareDelivery(args: { agentSessionId: string; contactId: string; now?: Date }): Promise<DeliverySetup> {
  const tz = schedulingTimezone();
  const now = zonedParts(args.now ?? new Date(), tz);
  const [store, recent] = await Promise.all([
    getStore(args.agentSessionId),
    prisma.order.findMany({
      where: { contactId: args.contactId, agentSessionId: args.agentSessionId },
      orderBy: { createdAt: "desc" },
      take: 3,
      select: { number: true, createdAt: true, totalCents: true, items: true, status: true },
    }),
  ]);
  const canOrder = store.menu.length > 0;

  const lines: string[] = [
    "# Delivery (REGRAS PRIORITÁRIAS)",
    `Agora: ${dayLabel(now.date)} às ${now.time} (fuso ${tz}).`,
    "",
    "## Estabelecimento",
    store.description ?? "(sem descrição cadastrada)",
    `Horário: ${store.hours ?? "não informado"}`,
    store.pickupEnabled
      ? `Retirada no local: sim${store.pickupAddress ? ` — ${store.pickupAddress}` : ""}`
      : "Retirada no local: não (só entrega).",
    "",
    "## Entrega — bairros atendidos e taxa",
    ...(store.areas.length
      ? store.areas.map((a) => `- ${a.name}: ${formatBRL(a.feeCents)}`)
      : ["- nenhum bairro cadastrado (só retirada, se houver)"]),
    "Fora desses bairros não entregamos.",
    "",
    "## Cardápio (preços oficiais — o sistema calcula o total por eles)",
    canOrder ? menuAsText(store.menu) : "(cardápio ainda não cadastrado)",
    "",
    "## Pedidos anteriores deste cliente",
    ...(recent.length
      ? recent.map((o) => {
          const items = (Array.isArray(o.items) ? o.items : []) as { name?: string; quantity?: number }[];
          return `- #${o.number} (${zonedParts(o.createdAt, tz).date.split("-").reverse().join("/")}): ${items
            .map((i) => `${i.quantity}x ${i.name}`)
            .join(", ")} — ${formatBRL(o.totalCents)}`;
        })
      : ["- nenhum"]),
    "",
    "## Como conduzir",
  ];
  if (canOrder) {
    lines.push(
      "1. Receba o cliente com simpatia e apresente o estabelecimento em poucas palavras.",
      "2. Envie o cardápio com send_menu no início ou quando o cliente pedir. Se o envio falhar, mande os itens em texto.",
      "3. Anote o pedido usando os nomes EXATOS do cardápio. Nunca invente itens, sabores, tamanhos ou preços.",
      "4. Pergunte se é entrega ou retirada. Entrega: bairro (da lista) e endereço completo (rua, número, complemento, referência).",
      `5. Forma de pagamento (paga na entrega/retirada): ${Object.values(PAYMENT_LABEL).join(", ")}. Dinheiro: pergunte se precisa de troco e pra quanto.`,
      "6. Chame quote_order e mostre ao cliente o resumo: itens, taxa e TOTAL. Peça a confirmação.",
      "7. Só depois do 'sim/confirmo', chame place_order. Diga que o pedido foi feito só se vier ok:true — informe o número do pedido e o total.",
      "8. Mudar ou cancelar um pedido já feito: use request_handoff para a equipe.",
    );
  } else {
    lines.push(
      "O cardápio ainda não foi cadastrado: você NÃO consegue registrar pedidos. Explique que a equipe vai atender e use request_handoff.",
    );
  }
  return { tools: canOrder ? DELIVERY_TOOLS : [], contextBlock: lines.join("\n") };
}

export interface DeliveryToolContext {
  agentSessionId: string;
  contactId: string;
  conversationId: string;
  channel: ChannelId;
  externalId: string;
}

async function sendMenu(ctx: DeliveryToolContext): Promise<Record<string, unknown>> {
  const recent = await prisma.message.findFirst({
    where: {
      conversationId: ctx.conversationId,
      direction: "outbound",
      text: { startsWith: MENU_SENT_MARK },
      createdAt: { gte: new Date(Date.now() - RESEND_AFTER_MS) },
    },
    select: { id: true },
  });
  if (recent) return { ok: true, alreadySent: true, message: "O cardápio já foi enviado agora há pouco — não reenvie." };

  const store = await prisma.deliveryStore.findUnique({
    where: { agentSessionId: ctx.agentSessionId },
    select: { menuFile: true, menuMimeType: true, menuFileName: true, menuToken: true },
  });
  if (!store?.menuFile || !store.menuMimeType) {
    return { ok: false, error: "no_menu_file", message: "Não há arquivo de cardápio: mande os itens em texto." };
  }
  const fileName = store.menuFileName ?? "cardapio";

  // 1) Arquivo direto no WhatsApp.
  try {
    const adapter = getAdapter(ctx.channel);
    if (!adapter.sendMedia) throw new Error("canal sem envio de arquivo");
    await adapter.sendMedia(ctx.externalId, {
      type: store.menuMimeType.startsWith("image/") ? "image" : "document",
      base64: Buffer.from(store.menuFile).toString("base64"),
      mimeType: store.menuMimeType,
      fileName,
      caption: "Nosso cardápio 📋",
    });
    const saved = await prisma.message.create({
      data: { conversationId: ctx.conversationId, direction: "outbound", role: "assistant", text: `${MENU_SENT_MARK} (${fileName})` },
    });
    notifyMessage(ctx.conversationId, saved.id).catch(() => {});
    return { ok: true, sentAs: "file" };
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "delivery.send_menu_file_failed",
        conversationId: ctx.conversationId,
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
  }

  // 2) Plano B: link público do cardápio hospedado no CRM.
  const base = process.env.PUBLIC_BASE_URL?.replace(/\/+$/, "");
  if (base && store.menuToken) {
    const sent = await sendOutboundMessage({
      conversationId: ctx.conversationId,
      channel: ctx.channel,
      externalId: ctx.externalId,
      text: `${MENU_SENT_MARK}: ${base}/cardapio/${store.menuToken}`,
    });
    if (sent.ok) return { ok: true, sentAs: "link" };
  }
  return { ok: false, error: "send_failed", message: "Não consegui enviar o arquivo: mande os itens do cardápio em texto." };
}

/** Executa um tool do delivery e devolve o JSON que volta pro modelo. */
export async function executeDeliveryTool(call: LLMToolUse, ctx: DeliveryToolContext): Promise<string> {
  const input = (call.input ?? {}) as Record<string, unknown>;
  try {
    if (call.name === "send_menu") return JSON.stringify(await sendMenu(ctx));
    if (call.name === "quote_order") {
      const q = await quoteOrder(ctx.agentSessionId, input);
      if (!q.ok) return JSON.stringify(q);
      return JSON.stringify({
        ok: true,
        items: q.lines.map((l) => ({ ...l, unitPrice: formatBRL(l.unitPriceCents), lineTotal: formatBRL(l.unitPriceCents * l.quantity) })),
        subtotal: formatBRL(q.subtotalCents),
        deliveryFee: formatBRL(q.deliveryFeeCents),
        total: formatBRL(q.totalCents),
        neighborhood: q.neighborhood,
      });
    }
    if (call.name === "place_order") {
      const r = await placeOrder({
        agentSessionId: ctx.agentSessionId,
        contactId: ctx.contactId,
        conversationId: ctx.conversationId,
        input,
      });
      if (r.ok) return JSON.stringify({ ...r, payment: PAYMENT_LABEL[r.payment as PaymentMethod] ?? r.payment });
      return JSON.stringify(r);
    }
    return JSON.stringify({ ok: false, error: "unknown_tool" });
  } catch (err) {
    console.log(
      JSON.stringify({
        event: "delivery.tool_error",
        tool: call.name,
        conversationId: ctx.conversationId,
        error: String((err as Error)?.message ?? err),
        at: new Date().toISOString(),
      }),
    );
    return JSON.stringify({
      ok: false,
      error: "internal_error",
      message: "Tive um problema pra registrar agora. Peça desculpas e use request_handoff para a equipe concluir o pedido.",
    });
  }
}
