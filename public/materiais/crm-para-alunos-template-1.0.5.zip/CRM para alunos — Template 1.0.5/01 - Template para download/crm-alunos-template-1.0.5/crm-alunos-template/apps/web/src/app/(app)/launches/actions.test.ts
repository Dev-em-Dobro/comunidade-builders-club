import { describe, it, expect, vi } from "vitest";

vi.mock("next/cache", () => ({ revalidatePath: vi.fn() }));
vi.mock("next/navigation", () => ({ redirect: vi.fn() }));
vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user", role: "admin" } })),
}));

import { auth } from "@/auth";
import { saveLaunch, savePlan, deletePlan, activateLaunchAction, closeLaunchAction } from "./actions";
import { prisma } from "@/lib/db";

function fd(fields: Record<string, string>): FormData {
  const f = new FormData();
  for (const [k, v] of Object.entries(fields)) f.set(k, v);
  return f;
}

const base = {
  name: "Turma 5",
  slug: "turma-5",
  startsAt: "2026-06-01",
  endsAt: "2026-06-10",
  status: "planned",
};

describe("saveLaunch — validação", () => {
  it("rejeita nome vazio", async () => {
    const r = await saveLaunch(fd({ ...base, name: "" }));
    expect(r.error).toMatch(/nome/i);
  });

  it("rejeita slug com caracteres inválidos", async () => {
    const r = await saveLaunch(fd({ ...base, slug: "Turma 5!" }));
    expect(r.error).toMatch(/slug/i);
  });

  it("rejeita data de fim antes do início", async () => {
    const r = await saveLaunch(
      fd({ ...base, startsAt: "2026-06-10", endsAt: "2026-06-01" }),
    );
    expect(r.error).toMatch(/fim/i);
  });

  it("rejeita status inválido", async () => {
    const r = await saveLaunch(fd({ ...base, status: "arquivado" }));
    expect(r.error).toMatch(/status/i);
  });
});

describe("saveLaunch — campos da oferta", () => {
  it("rejeita bonuses com JSON inválido", async () => {
    const r = await saveLaunch(fd({ ...base, bonuses: "isso não é JSON" }));
    expect(r.error).toMatch(/JSON/);
  });

  it("rejeita bonuses com item sem title", async () => {
    const r = await saveLaunch(fd({
      ...base,
      bonuses: JSON.stringify([{ description: "x" }]),
    }));
    expect(r.error).toMatch(/Bônus inválidos/);
  });

  it("aceita bonuses vazios (default '[]')", async () => {
    // não deve dar erro de validação de bonuses
    // saveLaunch chama redirect() no sucesso — com mock, retorna undefined
    const r = await saveLaunch(fd({ ...base, slug: "trial-bonus-vazio" }));
    expect((r?.error) ?? "").not.toMatch(/Bônus/);
  });
});

describe("savePlan", () => {
  it("rejeita nome vazio", async () => {
    const r = await savePlan("any", { name: "", priceCents: 100, checkoutUrl: "", sortOrder: 0 });
    expect(r.error).toMatch(/nome/i);
  });

  it("rejeita preço negativo", async () => {
    const r = await savePlan("any", { name: "X", priceCents: -1, checkoutUrl: "", sortOrder: 0 });
    expect(r.error).toMatch(/preço/i);
  });

  it("rejeita URL inválida", async () => {
    const r = await savePlan("any", {
      name: "X", priceCents: 100, checkoutUrl: "não-é-url", sortOrder: 0,
    });
    expect(r.error).toMatch(/url/i);
  });

  it("aceita checkoutUrl vazio (null)", async () => {
    // create real fixture pra não bater no error fake
    const course = await prisma.course.create({
      data: { name: "savePlan course", slug: `save-plan-${Date.now()}`, priceCents: 100 },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `savePlan launch ${Date.now()}`,
        slug: `save-plan-launch-${Date.now()}`,
        startsAt: new Date(),
        endsAt: new Date(Date.now() + 86400000),
        status: "planned",
        courseId: course.id,
      },
    });
    const r = await savePlan(launch.id, {
      name: "Plano sem URL", priceCents: 100, checkoutUrl: "", sortOrder: 0,
    });
    expect(r.ok).toBe(true);
    // cleanup
    await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
    await prisma.launch.delete({ where: { id: launch.id } });
    await prisma.course.delete({ where: { id: course.id } });
  });
});

describe("deletePlan", () => {
  it("retorna erro se launch não existe", async () => {
    const r = await deletePlan("does-not-exist", "any-plan");
    expect(r.error).toMatch(/encontrado/i);
  });

  it("bloqueia remoção do último plano em launch live", async () => {
    const course = await prisma.course.create({
      data: { name: "dp course", slug: `dp-${Date.now()}`, priceCents: 100 },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `dp launch ${Date.now()}`,
        slug: `dp-launch-${Date.now()}`,
        startsAt: new Date(Date.now() - 86400000),
        endsAt: new Date(Date.now() + 86400000),
        status: "live",
        courseId: course.id,
      },
    });
    const plan = await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "Único", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });
    const r = await deletePlan(launch.id, plan.id);
    expect(r.error).toMatch(/último plano/i);
    // cleanup
    await prisma.launchPlan.deleteMany({ where: { launchId: launch.id } });
    await prisma.launch.delete({ where: { id: launch.id } });
    await prisma.course.delete({ where: { id: course.id } });
  });

  it("permite remover último plano em launch planned (não live)", async () => {
    const course = await prisma.course.create({
      data: { name: "dp2 course", slug: `dp2-${Date.now()}`, priceCents: 100 },
    });
    const launch = await prisma.launch.create({
      data: {
        name: `dp2 launch ${Date.now()}`,
        slug: `dp2-launch-${Date.now()}`,
        startsAt: new Date(),
        endsAt: new Date(Date.now() + 86400000),
        status: "planned",
        courseId: course.id,
      },
    });
    const plan = await prisma.launchPlan.create({
      data: { launchId: launch.id, name: "Único", priceCents: 100, checkoutUrl: "x", sortOrder: 0 },
    });
    const r = await deletePlan(launch.id, plan.id);
    expect(r.ok).toBe(true);
    // cleanup
    await prisma.launch.delete({ where: { id: launch.id } });
    await prisma.course.delete({ where: { id: course.id } });
  });
});

describe("gating admin-only", () => {
  it("saveLaunch rejeita operator", async () => {
    (auth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      user: { id: "operator-user", role: "operator" },
    });
    const r = await saveLaunch(fd({ ...base, slug: "gate-test" }));
    expect(r.error).toMatch(/permissão|admin/i);
  });

  it("savePlan rejeita operator", async () => {
    (auth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      user: { id: "operator-user", role: "operator" },
    });
    const r = await savePlan("any-launch", {
      name: "X", priceCents: 100, checkoutUrl: "", sortOrder: 0,
    });
    expect(r.error).toMatch(/permissão|admin/i);
  });

  it("deletePlan rejeita operator", async () => {
    (auth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      user: { id: "operator-user", role: "operator" },
    });
    const r = await deletePlan("any-launch", "any-plan");
    expect(r.error).toMatch(/permissão|admin/i);
  });

  it("activateLaunchAction rejeita operator", async () => {
    (auth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      user: { id: "operator-user", role: "operator" },
    });
    const r = await activateLaunchAction("any");
    expect(r.error).toMatch(/permissão|admin/i);
  });

  it("closeLaunchAction rejeita operator", async () => {
    (auth as ReturnType<typeof vi.fn>).mockResolvedValueOnce({
      user: { id: "operator-user", role: "operator" },
    });
    const r = await closeLaunchAction("any");
    expect(r.error).toMatch(/permissão|admin/i);
  });
});
