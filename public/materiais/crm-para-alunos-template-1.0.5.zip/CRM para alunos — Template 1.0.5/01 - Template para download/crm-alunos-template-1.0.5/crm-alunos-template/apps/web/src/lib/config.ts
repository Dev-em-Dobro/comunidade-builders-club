import fs from "node:fs";
import path from "node:path";

export type ChannelId = "whatsapp_cloud" | "instagram" | "whatsapp_qr";

export interface SetupConfig {
  $schema?: string;
  version: number;
  project: { name: string; slug: string; repoPath: string; createdAt: string };
  channels: {
    enabled: ChannelId[];
    whatsapp_cloud: { enabled: boolean; phoneNumberId?: string | null; businessAccountId?: string | null; appId?: string | null; webhookVerifyToken?: string | null };
    instagram_direct: { enabled: boolean; igBusinessAccountId?: string | null; pageId?: string | null; webhookVerifyToken?: string | null };
    /** WhatsApp via QR (provedor não oficial). Opcional: instalações antigas não têm o bloco.
     *  Credenciais ficam em Configurações → WhatsApp via QR ou nas variáveis WAQR_*. */
    whatsapp_qr?: { enabled: boolean };
  };
  useCase: "sdr" | "support" | "scheduling" | "assistant";
  language: "pt-BR" | "en" | "bilingual";
  volume: "low" | "medium" | "high";
  handoff: {
    trigger: "explicit" | "low_confidence" | "never";
    destination: "same_channel" | "email" | "slack";
    /** Minutos até escalar um handoff não assumido — Parte 8. Ausente = default via handoffConfig(). */
    slaHandoffMin?: number;
    /** Estratégia de atribuição — Parte 8. */
    assignment?: "round_robin";
  };
  llm: { providers: string[]; primary: string; defaultModel: string; fallbackPolicy: string; memory: string };
  tools: { calendar: boolean; webSearch: boolean; rag: boolean; webhook: boolean };
  schedule: { mode: "24_7" | "business_hours"; timezone: string };
  cache: { enabled: boolean; provider: string; debounce: { enabled: boolean; windowMs: number; maxBufferedMessages: number; keyPrefix: string } };
  infra: { db: string; auth: string; domain: string; customDomain: string | null };
  /** SLA de primeira resposta — Parte 4. Ausente = defaults via slaConfig(). */
  sla?: {
    thresholdMin: number;
    notify: string[];
    quietHours: { start: string; end: string } | null;
  };
  /** Follow-up automático de reengajamento — Parte 7. Ausente = defaults via followupConfig(). */
  followup?: {
    enabled: boolean;
    maxPerWindow: number;
    quietHours: { start: string; end: string } | null;
  };
  /** Qualificação estruturada + lead scoring — Parte 10. Ausente = defaults via qualificationConfig(). */
  qualification?: {
    enabled: boolean;
    handoffOnReady: boolean;
    model: string;
  };
  /** Follow-up automático FORA da janela 24h via template — Parte fora-janela.
   *  Ausente = defaults via outOfWindowFollowupConfig(). */
  outOfWindowFollowup?: {
    enabled: boolean;
    intervalsDays: number[];
    eligibleStages: string[];
    lostGraceDays: number;
  };
  /** Auditor de conversas — Parte auditor. Ausente = defaults via auditorConfig(). */
  auditor?: {
    enabled?: boolean;
    maxCostPerRunUsd?: number;
    maxCostPerDayUsd?: number;
    orphanThresholdMinutes?: number;
    reapIntervalMinutes?: number;
  };
  /** Identidade do negócio (template self-hosted). Fonte única dos valores
   *  específicos do tenant — marca, e-mails, URL de acesso do aluno, fraseado
   *  de handoff. Ausente = defaults genéricos via businessConfig(). */
  business?: {
    brandName?: string;
    legalName?: string;
    /** E-mail que o BOT pode passar ao cliente (contato/suporte). */
    supportEmail?: string;
    /** E-mail de contato das páginas públicas (privacidade/exclusão). */
    contactEmail?: string;
    /** URL de acesso/login do aluno (equivalente ao checkout, pós-compra). */
    accessUrl?: string | null;
    /** Como o bot se refere ao humano ("um dos nossos especialistas"). */
    handoffPhrasing?: string;
    /** Aviso enviado ao cliente ao escalar pra humano. */
    handoffNotice?: string;
    language?: string;
  };
  checkpoint: string;
  warnings: string[];
}

// Gotcha 0.9.11: setup.config.json precisa existir em runtime no filesystem.
// Resolução: env override → cwd → ../../.
function resolveConfigPath(): string {
  if (process.env.SETUP_CONFIG_PATH) return process.env.SETUP_CONFIG_PATH;
  return path.resolve(process.cwd(), "setup.config.json");
}



export function loadConfig(): SetupConfig {
  const p = resolveConfigPath();
  if (!fs.existsSync(/*turbopackIgnore: true*/ p)) {
    throw new Error(
      `setup.config.json não encontrado em ${p}. Set SETUP_CONFIG_PATH ou execute npm run setup na raiz do projeto`,
    );
  }
  const raw = fs.readFileSync(/*turbopackIgnore: true*/ p, "utf8");
  return JSON.parse(raw) as SetupConfig;
}

export function getEnabledChannels(): ChannelId[] {
  const cfg = loadConfig();
  return cfg.channels.enabled.map((id) => (id as string) === "instagram_direct" ? "instagram" : id);
}

export function isChannelEnabled(id: ChannelId): boolean {
  return getEnabledChannels().includes(id);
}

/** Liga/desliga um canal mantendo a lista `enabled` e o bloco do canal coerentes. Não grava. */
export function withChannelEnabled(config: SetupConfig, id: ChannelId, enabled: boolean): SetupConfig {
  const others = config.channels.enabled.filter((c) => c !== id && (c as string) !== (id === "instagram" ? "instagram_direct" : id));
  const channels = { ...config.channels, enabled: enabled ? [...others, id] : others };
  if (id === "whatsapp_cloud") channels.whatsapp_cloud = { ...channels.whatsapp_cloud, enabled };
  else if (id === "instagram") channels.instagram_direct = { ...channels.instagram_direct, enabled };
  else channels.whatsapp_qr = { ...channels.whatsapp_qr, enabled };
  return { ...config, channels };
}

export function debounceConfig() {
  return loadConfig().cache.debounce;
}

/** Config de SLA com defaults — o bloco `sla` é opcional no setup.config.json. */
export function slaConfig() {
  const sla = loadConfig().sla;
  return {
    thresholdMin: sla?.thresholdMin ?? 5,
    notify: sla?.notify ?? [],
    quietHours: sla?.quietHours ?? null,
  };
}

/** Config de follow-up com defaults — o bloco `followup` é opcional. */
export function followupConfig() {
  const f = loadConfig().followup;
  return {
    // Default OFF: follow-up automático é opt-in (outbound proativo).
    enabled: f?.enabled ?? false,
    maxPerWindow: f?.maxPerWindow ?? 1,
    quietHours: f?.quietHours ?? null,
  };
}

/** Config de qualificação com defaults — o bloco `qualification` é opcional. */
export function qualificationConfig() {
  const q = loadConfig().qualification;
  return {
    // Default ON: classificador é barato (Haiku) e não-intrusivo.
    enabled: q?.enabled ?? true,
    // Default OFF: flagReadyToBuy só marca o stage; o humano decide o handoff.
    handoffOnReady: q?.handoffOnReady ?? false,
    model: q?.model ?? "claude-haiku-4-5",
  };
}

/** Jev é habilitado com uma chave; false permite voltar ao Haiku imediatamente. */
export function jevQualificationConfig() {
  const bounded = (name: string, fallback: number, min: number, max: number) => {
    const raw = process.env[name];
    const value = raw?.trim() ? Number(raw) : NaN;
    return Number.isFinite(value) && value >= min && value <= max ? value : fallback;
  };
  return {
    enabled: process.env.JEV_QUALIFICATION_ENABLED !== "false" && !!process.env.TYPESAFE_API_KEY?.trim(),
    model: process.env.JEV_MODEL?.trim() || "jev-1.13.0",
    minConfidence: bounded("JEV_MIN_CONFIDENCE", 0.8, 0.5, 1),
    audienceMinConfidence: bounded("JEV_AUDIENCE_MIN_CONFIDENCE", 0.9, 0.5, 1),
    timeoutMs: bounded("JEV_TIMEOUT_MS", 2000, 100, 10000),
  };
}

/**
 * Identidade do negócio com defaults genéricos — o bloco `business` é opcional.
 * Fonte ÚNICA dos valores específicos do tenant (template self-hosted): marca,
 * e-mails, URL de acesso, fraseado de handoff. Tirar isto de `const`s espalhadas
 * pelo código foi o P0 pra o CRM virar template sem vazar dados de um cliente.
 */
export function businessConfig() {
  const b = loadConfig().business;
  const handoffPhrasing = b?.handoffPhrasing ?? "um dos nossos especialistas";
  const supportEmail = b?.supportEmail ?? process.env.SUPPORT_EMAIL ?? "";
  return {
    brandName: b?.brandName ?? "Minha Empresa",
    legalName: b?.legalName || b?.brandName || "[Configure a razão social em Configurações]",
    supportEmail,
    // Páginas públicas caem no supportEmail se não houver e-mail próprio.
    contactEmail: b?.contactEmail ?? supportEmail,
    accessUrl: b?.accessUrl ?? null,
    handoffPhrasing,
    handoffNotice:
      b?.handoffNotice ??
      `Estou transferindo você para ${handoffPhrasing}, só um momento.`,
    language: b?.language ?? "pt-BR",
  };
}

/** Config de handoff com defaults — os campos slaHandoffMin/assignment são opcionais. */
export function handoffConfig() {
  const h = loadConfig().handoff;
  return {
    trigger: h.trigger,
    destination: h.destination,
    slaHandoffMin: h.slaHandoffMin ?? 10,
    assignment: h.assignment ?? "round_robin",
  };
}

/** Config do auditor com defaults — o bloco `auditor` é opcional. */
export function auditorConfig() {
  const a = loadConfig().auditor;
  return {
    // Default ON: auditor é opt-out.
    enabled: a?.enabled ?? true,
    maxCostPerRunUsd: a?.maxCostPerRunUsd ?? 0.20,
    maxCostPerDayUsd: a?.maxCostPerDayUsd ?? 2,
    orphanThresholdMinutes: a?.orphanThresholdMinutes ?? 15,
    reapIntervalMinutes: a?.reapIntervalMinutes ?? 5,
  };
}

/** Config do follow-up fora da janela com defaults — o bloco é opcional.
 *  Quiet hours reusa a fonte do follow-up de reengajamento (followupConfig). */
export function outOfWindowFollowupConfig() {
  const o = loadConfig().outOfWindowFollowup;
  return {
    // Default OFF: outbound proativo é opt-in (igual ao followupConfig).
    enabled: o?.enabled ?? false,
    intervalsDays: o?.intervalsDays ?? [1, 2, 4],
    eligibleStages: o?.eligibleStages ?? ["qualified", "proposal"],
    lostGraceDays: o?.lostGraceDays ?? 2,
    quietHours: followupConfig().quietHours,
  };
}

export function saveConfig(config: SetupConfig): void {
  const target = resolveConfigPath();
  const temporary = `${target}.${process.pid}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(config, null, 2) + "\n", { mode: 0o600, flag: "wx" });
    fs.renameSync(temporary, target);
  } finally {
    if (fs.existsSync(temporary)) fs.unlinkSync(temporary);
  }
}
