import type { Job } from "bullmq";
import { reapOrphans } from "@/lib/audit/reaper";

/**
 * Processador do job `audit.reap`.
 *
 * Chamado pelo reaper cron (upsertJobScheduler a cada REAP_INTERVAL_MS).
 * Marca como 'error' qualquer AuditReport em 'running' por mais de
 * ORPHAN_THRESHOLD_MS.
 */
export async function auditReapProcessor(_job: Job): Promise<void> {
  const result = await reapOrphans();
  console.log(
    JSON.stringify({
      event: "audit.reap.done",
      reapedCount: result.reaped,
      at: new Date().toISOString(),
    }),
  );
}
