"use server";

import { revalidatePath } from "next/cache";
import { auth } from "@/auth";
import { prisma } from "@/lib/db";

/**
 * O operador logado assume a conversa em handoff. Registra o
 * `PipelineEvent('handoff_accepted')` — é este evento que cancela o
 * escalonamento agendado (ver `handoffEscalationProcessor`).
 */
export async function claimConversation(conversationId: string): Promise<void> {
  const session = await auth();
  if (!session?.user?.id) return;

  // findUnique antes de escrever: se a conversa não existe mais, sai sem erro
  // (evita o throw P2025 do Prisma virar um toast com erro cru de DB).
  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { leadId: true },
  });
  if (!conv) return;

  await prisma.conversation.updateMany({
    where: { id: conversationId },
    data: { assignedUserId: session.user.id },
  });

  if (conv.leadId) {
    await prisma.pipelineEvent.create({
      data: {
        leadId: conv.leadId,
        type: "handoff_accepted",
        payload: { conversationId, userId: session.user.id },
      },
    });
  }

  revalidatePath(`/conversations/${conversationId}`);
}

/**
 * Troca manualmente o agente que atende a conversa. `null` = volta pro agente
 * padrão (isDefault). Vale a partir da próxima mensagem do contato e fica
 * registrado como `agent_handoff` (via "manual") no histórico do lead.
 */
export async function setConversationAgent(
  conversationId: string,
  agentSessionId: string | null,
): Promise<{ error?: string }> {
  const session = await auth();
  if (!session?.user?.id) return { error: "Acesso negado" };

  const conv = await prisma.conversation.findUnique({
    where: { id: conversationId },
    select: { leadId: true, agentSessionId: true },
  });
  if (!conv) return { error: "Conversa não encontrada" };
  if (conv.agentSessionId === agentSessionId) return {};

  const [from, to] = await Promise.all([
    conv.agentSessionId
      ? prisma.agentSession.findUnique({ where: { id: conv.agentSessionId }, select: { id: true, name: true, persona: true } })
      : prisma.agentSession.findFirst({ where: { isDefault: true }, select: { id: true, name: true, persona: true } }),
    agentSessionId
      ? prisma.agentSession.findUnique({ where: { id: agentSessionId }, select: { id: true, name: true, persona: true } })
      : prisma.agentSession.findFirst({ where: { isDefault: true }, select: { id: true, name: true, persona: true } }),
  ]);
  if (agentSessionId && !to) return { error: "Agente não encontrado" };

  await prisma.$transaction([
    prisma.conversation.update({ where: { id: conversationId }, data: { agentSessionId } }),
    ...(conv.leadId
      ? [
          prisma.pipelineEvent.create({
            data: {
              leadId: conv.leadId,
              type: "agent_handoff",
              payload: {
                from: from?.id ?? null,
                to: to?.id ?? null,
                fromName: from?.name ?? null,
                toName: to?.name ?? null,
                fromPersona: from?.persona ?? null,
                toPersona: to?.persona ?? null,
                via: "manual",
                userId: session.user.id,
              },
            },
          }),
        ]
      : []),
  ]);

  revalidatePath(`/conversations/${conversationId}`);
  return {};
}
