-- AlterTable
ALTER TABLE "Course" ADD COLUMN     "description" TEXT,
ADD COLUMN     "guaranteePolicy" TEXT,
ADD COLUMN     "paymentMethods" TEXT;
