import { describe, expect, it } from "vitest";
import { isOpenAIChatModel, orderModels } from "./models";

describe("isOpenAIChatModel", () => {
  it("mantém modelos de chat e tira áudio, imagem, embeddings…", () => {
    expect(isOpenAIChatModel("gpt-5")).toBe(true);
    expect(isOpenAIChatModel("gpt-4.1-mini")).toBe(true);
    expect(isOpenAIChatModel("o4-mini")).toBe(true);
    expect(isOpenAIChatModel("gpt-4o-mini-transcribe")).toBe(false);
    expect(isOpenAIChatModel("gpt-realtime")).toBe(false);
    expect(isOpenAIChatModel("gpt-image-1")).toBe(false);
    expect(isOpenAIChatModel("text-embedding-3-small")).toBe(false);
    expect(isOpenAIChatModel("whisper-1")).toBe(false);
  });
});

describe("orderModels", () => {
  it("põe os recomendados que existem na conta no topo, custo-benefício primeiro", () => {
    const available = [
      { id: "claude-haiku-4-5", label: "Haiku 4.5" },
      { id: "claude-opus-5-5", label: "Opus 5.5" },
      { id: "claude-sonnet-5-5", label: "Sonnet 5.5" },
      { id: "claude-haiku-5-5", label: "Haiku 5.5" },
    ];
    expect(orderModels("anthropic", available).map((m) => m.id)).toEqual([
      "claude-haiku-5-5",
      "claude-sonnet-5-5",
      "claude-opus-5-5",
      "claude-haiku-4-5",
    ]);
  });

  it("o padrão (1º) de cada provedor é o de melhor custo-benefício", () => {
    expect(orderModels("anthropic", [{ id: "claude-haiku-5-5", label: "" }, { id: "claude-opus-5-5", label: "" }])[0]?.label).toMatch(
      /custo-benefício/,
    );
    expect(orderModels("openai", [{ id: "gpt-5", label: "" }, { id: "gpt-4.1-mini", label: "" }])[0]?.id).toBe("gpt-4.1-mini");
  });
});
