/**
 * Gate de autorização pra route handlers da API.
 *
 * Modelo (Parte 14 / backlog segurança #4): "sessão + gate por operação".
 * Toda rota que muta recurso exige sessão válida; operações sensíveis de dono
 * (release/reassign) checam ownership inline no próprio handler — o inbox é
 * compartilhado, então leitura/ação corriqueira não exige ser o dono.
 *
 * Padrão de uso:
 *
 *   const gate = await requireSession();
 *   if (gate instanceof NextResponse) return gate;
 *   const { user } = gate;
 *
 * O 401 devolve o mesmo shape `{ error: "unauthorized" }` que as rotas já
 * usavam inline — clientes existentes não quebram.
 */

import { NextResponse } from "next/server";
import { auth } from "@/auth";

export interface AuthedUser {
  id: string;
  role: "operator" | "admin";
  email: string;
  name?: string | null;
}

/** Exige sessão autenticada. Devolve `{ user }` ou um 401 `NextResponse`. */
export async function requireSession(): Promise<{ user: AuthedUser } | NextResponse> {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  return { user: session.user as AuthedUser };
}
