"use client";

import { useActionState, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { FileText, Link2, Loader2, Plus, Type } from "lucide-react";
import { addRagDocument, type RagFormState } from "./actions";

type SourceType = "text" | "pdf" | "url";

const SOURCES: { id: SourceType; label: string; icon: typeof Type }[] = [
  { id: "text", label: "Texto", icon: Type },
  { id: "pdf", label: "PDF", icon: FileText },
  { id: "url", label: "URL", icon: Link2 },
];

export function RagForm({ agentId }: { agentId: string }) {
  const [state, action, pending] = useActionState<RagFormState, FormData>(
    async (_prev, fd) => addRagDocument(fd),
    {},
  );
  const [sourceType, setSourceType] = useState<SourceType>("text");

  return (
    <form action={action} className="space-y-4">
      <input type="hidden" name="agentId" value={agentId} />
      <input type="hidden" name="sourceType" value={sourceType} />

      <div className="space-y-2">
        <Label>Tipo de fonte</Label>
        <div className="flex gap-2">
          {SOURCES.map((s) => {
            const Icon = s.icon;
            const active = sourceType === s.id;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setSourceType(s.id)}
                className={cn(
                  "flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-colors",
                  active
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/40",
                )}
              >
                <Icon className="size-4" />
                {s.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="title">Título</Label>
        <Input
          id="title"
          name="title"
          required
          placeholder="FAQ do Produto Exemplo"
        />
      </div>

      {sourceType === "text" && (
        <div className="space-y-2">
          <Label htmlFor="text">Conteúdo</Label>
          <Textarea
            id="text"
            name="text"
            required
            rows={9}
            placeholder="Cole aqui o texto que o agente deve conhecer (FAQ, descrição de produto, políticas...)."
          />
        </div>
      )}

      {sourceType === "pdf" && (
        <div className="space-y-2">
          <Label htmlFor="file">Arquivo PDF</Label>
          <Input
            id="file"
            name="file"
            type="file"
            accept="application/pdf,.pdf"
            required
          />
          <p className="text-xs text-muted-foreground">
            Máx. 10MB. PDF escaneado (imagem) não funciona — precisa ter texto.
          </p>
        </div>
      )}

      {sourceType === "url" && (
        <div className="space-y-2">
          <Label htmlFor="url">URL</Label>
          <Input
            id="url"
            name="url"
            type="url"
            required
            placeholder="https://example.com/produto"
          />
        </div>
      )}

      {state?.error && (
        <p className="text-sm text-destructive">{state.error}</p>
      )}
      {state?.ok && state.message && (
        <p className="text-sm text-primary">{state.message}</p>
      )}

      <Button type="submit" disabled={pending}>
        {pending ? (
          <Loader2 className="size-4 animate-spin" />
        ) : (
          <Plus className="size-4" />
        )}
        Indexar documento
      </Button>
    </form>
  );
}
