import type { Job } from "bullmq";
import { prisma } from "@/lib/db";
import { notifyConvEvent } from "@/lib/realtime/notify";
import type { WindowWarningJobData } from "@/lib/queue/types";

/**
 * Worker do job `window-warning.fire` — alerta proativo 1h antes do
 * fechamento da janela 24h do WhatsApp.
 *
 * Sanity-checks (single source of truth = DB):
 *  - conversa ainda existe
 *  - windowClosesAt está no futuro
 *  - faltam ≤65min (folga pra job atrasado; se for muito mais, foi inbound novo
 *    e o scheduler já criou outro job — esse aqui é "fantasma").
 *
 * Cria 1 Notification por User isOnDuty=true e dispara notifyConvEvent
 * mesmo se não houver on-duty (toast pra quem estiver com a aba aberta).
 */
export async function windowWarningProcessor(job: Job): Promise<void> {
  const data = job.data as WindowWarningJobData;
  const conv = await prisma.conversation.findUnique({
    where: { id: data.conversationId },
    select: {
      id: true,
      windowClosesAt: true,
      contact: { select: { displayName: true } },
    },
  });
  if (!conv) {
    log({ event: "window_warning.skipped", reason: "conv_not_found", ...data });
    return;
  }
  if (!conv.windowClosesAt || conv.windowClosesAt.getTime() <= Date.now()) {
    log({ event: "window_warning.skipped", reason: "window_closed", ...data });
    return;
  }
  const minutesLeft = Math.round(
    (conv.windowClosesAt.getTime() - Date.now()) / 60_000,
  );
  if (minutesLeft > 65) {
    log({
      event: "window_warning.skipped",
      reason: "too_far",
      minutesLeft,
      ...data,
    });
    return;
  }

  const users = await prisma.user.findMany({
    where: { isOnDuty: true },
    select: { id: true },
  });

  if (users.length > 0) {
    const who = conv.contact?.displayName ?? "Conversa";
    await prisma.notification.createMany({
      data: users.map((u) => ({
        userId: u.id,
        type: "window_warning",
        payload: {
          title: "Janela do WhatsApp fechando",
          body: `${who} — janela fecha em ${minutesLeft}min.`,
          conversationId: conv.id,
          contactName: conv.contact?.displayName ?? null,
          minutesLeft,
          windowClosesAt: conv.windowClosesAt!.toISOString(),
        },
      })),
    });
  } else {
    log({ event: "window_warning.no_recipients", conversationId: conv.id });
  }

  await notifyConvEvent(conv.id, {
    type: "window_warning",
    minutesLeft,
    windowClosesAt: conv.windowClosesAt!.toISOString(),
  });

  log({
    event: "window_warning.fired",
    conversationId: conv.id,
    recipients: users.length,
    minutesLeft,
  });
}

function log(payload: Record<string, unknown>): void {
  console.log(JSON.stringify({ ...payload, at: new Date().toISOString() }));
}
