import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  jev: vi.fn(), haiku: vi.fn(), enqueue: vi.fn(),
  conversation: vi.fn(), messages: vi.fn(), courses: vi.fn(), update: vi.fn(),
  objections: vi.fn(), insertObjections: vi.fn(), event: vi.fn(),
  settings: { enabled: true, model: "jev-1.13.0", minConfidence: 0.8, audienceMinConfidence: 0.9, timeoutMs: 2000 },
}));
vi.mock("./qualification-jev", () => ({ classifyWithJev: mocks.jev }));
vi.mock("./llm/reply", () => ({ generateReplyWithKey: mocks.haiku }));
vi.mock("./config", () => ({
  qualificationConfig: () => ({ enabled: true, model: "claude-haiku-4-5" }),
  jevQualificationConfig: () => mocks.settings,
}));
vi.mock("./queue", () => ({ enqueue: mocks.enqueue }));
vi.mock("./db", () => ({ prisma: {
  conversation: { findUnique: mocks.conversation }, message: { findMany: mocks.messages },
  course: { findMany: mocks.courses }, lead: { update: mocks.update },
  objectionTag: { findMany: mocks.objections, createMany: mocks.insertObjections },
  pipelineEvent: { create: mocks.event },
} }));
import { classifyLead } from "./qualification";

const qualification = { audience: "prospect", interestLevel: "low", budgetSignal: "unknown", decisionTimeline: "unknown",
  courseInterestIds: [], objections: [], rationale: "Sem sinal", askedFields: {},
};
beforeEach(() => {
  vi.resetAllMocks();
  vi.spyOn(console, "log").mockImplementation(() => {});
  mocks.settings.enabled = true;
  mocks.conversation.mockResolvedValue({ id: "conv", lead: { id: "lead", stage: "new", score: 0,
    qualification: { askedFields: { nivel: { askedAt: "2026-09-20T12:00:00Z", answeredAt: "2026-09-20T12:01:00Z", answer: "zero" } } },
  }, agentSession: { role: "sdr" } });
  mocks.messages.mockResolvedValue([{ direction: "inbound", text: "Quanto custa?", createdAt: new Date("2026-09-28T12:00:00Z") }]);
  mocks.courses.mockResolvedValue([]);
  mocks.objections.mockResolvedValue([]);
  mocks.update.mockResolvedValue({});
  mocks.event.mockResolvedValue({});
  mocks.enqueue.mockResolvedValue(undefined);
  mocks.jev.mockResolvedValue({ qualification, model: "jev-1.13.0", inputTokens: 3000, costUsd: 0.000126, minConfidence: 0.99, durationMs: 100 });
  mocks.haiku.mockResolvedValue({ modelUsed: "claude-haiku-4-5", toolUses: [{ name: "record_qualification", input: qualification }] });
});
afterEach(() => vi.restoreAllMocks());

describe("classificador Jev primeiro, Haiku fallback", () => {
  it("persiste resultado Jev e tracking anterior sem chamar Haiku", async () => {
    await classifyLead("conv");
    expect(mocks.jev).toHaveBeenCalledTimes(1);
    expect(mocks.haiku).not.toHaveBeenCalled();
    expect(mocks.update).toHaveBeenCalledWith(expect.objectContaining({ data: expect.objectContaining({
      qualification: expect.objectContaining({ audience: "prospect", askedFields: expect.objectContaining({ nivel: expect.objectContaining({ answer: "zero" }) }) }),
    }) }));
  });

  it.each(["jev_low_confidence:audience", "jev_timeout", "jev_http_429", "jev_invalid_response"])("chama Haiku uma vez em %s", async (reason) => {
    mocks.jev.mockRejectedValue(new Error(reason));
    await classifyLead("conv");
    expect(mocks.haiku).toHaveBeenCalledTimes(1);
    expect(mocks.update).toHaveBeenCalled();
  });

  it("Jev desligado preserva o fluxo Haiku", async () => {
    mocks.settings.enabled = false;
    await classifyLead("conv");
    expect(mocks.jev).not.toHaveBeenCalled();
    expect(mocks.haiku).toHaveBeenCalledTimes(1);
  });

  it("fallback inválido não altera o lead nem agenda handoff", async () => {
    mocks.jev.mockRejectedValue(new Error("jev_timeout"));
    mocks.haiku.mockResolvedValue({ toolUses: [{ name: "record_qualification", input: { audience: "inventado" } }] });
    await classifyLead("conv");
    expect(mocks.update).not.toHaveBeenCalled();
    expect(mocks.enqueue).not.toHaveBeenCalled();
  });

  it("resultado Jev inválido passa pelo schema e recorre ao Haiku", async () => {
    mocks.jev.mockResolvedValue({ qualification: { ...qualification, interestLevel: "inventado" } });
    await classifyLead("conv");
    expect(mocks.haiku).toHaveBeenCalledTimes(1);
  });

  it("aluno classificado pelo Jev mantém o roteamento para suporte", async () => {
    mocks.jev.mockResolvedValue({ qualification: { ...qualification, audience: "student" }, model: "jev-1.13.0" });
    await classifyLead("conv");
    expect(mocks.haiku).not.toHaveBeenCalled();
    expect(mocks.enqueue).toHaveBeenCalledWith("sla", "agent.handoff", { conversationId: "conv", toRole: "support" }, expect.any(Object));
  });
});
