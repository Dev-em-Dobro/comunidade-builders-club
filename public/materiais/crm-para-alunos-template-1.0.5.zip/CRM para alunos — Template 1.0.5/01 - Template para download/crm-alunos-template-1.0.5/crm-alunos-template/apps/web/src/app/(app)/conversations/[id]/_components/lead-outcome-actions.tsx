"use client";

import { useState, useTransition } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { LeadOutcomeBadge } from "@/components/lead-outcome-badge";
import { LOSS_REASONS, lossReasonShort } from "@/lib/loss-reasons";
import { toast } from "sonner";
import { CircleX, Loader2, Trophy } from "lucide-react";

interface Props {
  leadId: string;
  /** Conversa de onde a ação parte — pausa a IA dela ao fechar. */
  conversationId: string;
  initialStage: string;
  initialLostReason: string | null;
  /** Avisa o parent (ConversationView) pra refletir a pausa da IA sem refresh. */
  onAiPaused: () => void;
}

/**
 * Botões de fechamento manual do lead na tela de conversa: "Marcar ganho" e
 * "Marcar perdido" (este com motivo obrigatório via dialog). Ao fechar, a IA
 * desta conversa é pausada no server e o parent é avisado.
 *
 * Num lead já fechado o botão OPOSTO continua visível pra corrigir engano
 * (lost↔won), e o selo de resultado fica ao lado.
 */
export function LeadOutcomeActions({
  leadId,
  conversationId,
  initialStage,
  initialLostReason,
  onAiPaused,
}: Props) {
  const [stage, setStage] = useState(initialStage);
  const [lostReason, setLostReason] = useState<string | null>(initialLostReason);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [note, setNote] = useState("");
  const [pending, startTransition] = useTransition();

  const isWon = stage === "won";
  const isLost = stage === "lost";

  function postOutcome(
    body: { outcome: "won" | "lost"; reason?: string; note?: string },
    onOk: () => void,
  ) {
    startTransition(async () => {
      try {
        const r = await fetch(`/api/leads/${leadId}/outcome`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...body, conversationId }),
        });
        const data = (await r.json().catch(() => ({}))) as {
          error?: string;
          aiPaused?: boolean;
        };
        if (!r.ok) {
          toast.error(data.error ?? `HTTP ${r.status}`);
          return;
        }
        if (data.aiPaused) onAiPaused();
        onOk();
      } catch (e) {
        toast.error(String((e as Error)?.message ?? e));
      }
    });
  }

  function markWon() {
    if (
      typeof window !== "undefined" &&
      !window.confirm("Marcar este lead como GANHO?\n\nA IA será pausada nesta conversa.")
    ) {
      return;
    }
    postOutcome({ outcome: "won" }, () => {
      setStage("won");
      setLostReason(null);
      toast.success("Lead marcado como ganho 🎉");
    });
  }

  function submitLost() {
    if (!reason) {
      toast.error("Selecione um motivo da perda");
      return;
    }
    const trimmed = note.trim();
    postOutcome(
      { outcome: "lost", reason, note: trimmed || undefined },
      () => {
        setStage("lost");
        setLostReason(reason);
        setDialogOpen(false);
        setNote("");
        toast.success(`Lead perdido · ${lossReasonShort(reason)}`);
      },
    );
  }

  return (
    <>
      {(isWon || isLost) && (
        <LeadOutcomeBadge stage={stage} lostReason={lostReason} />
      )}

      {!isWon && (
        <Button
          size="sm"
          variant="outline"
          onClick={markWon}
          disabled={pending}
          className="border-success/40 text-success hover:bg-success/10"
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <Trophy className="size-4" />}
          Marcar ganho
        </Button>
      )}

      {!isLost && (
        <Button
          size="sm"
          variant="outline"
          onClick={() => setDialogOpen(true)}
          disabled={pending}
          className="border-destructive/40 text-destructive hover:bg-destructive/10"
        >
          {pending ? <Loader2 className="size-4 animate-spin" /> : <CircleX className="size-4" />}
          Marcar perdido
        </Button>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CircleX className="size-4 text-destructive" />
              Marcar lead como perdido
            </DialogTitle>
            <DialogDescription>
              Registra o motivo da perda no histórico do funil. A IA será pausada
              nesta conversa.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="loss-reason">
                Motivo da perda <span className="text-destructive">*</span>
              </Label>
              <Select value={reason} onValueChange={(v) => setReason(String(v))}>
                <SelectTrigger id="loss-reason" className="w-full">
                  <SelectValue placeholder="Selecione um motivo..." />
                </SelectTrigger>
                <SelectContent>
                  {LOSS_REASONS.map((r) => (
                    <SelectItem key={r.code} value={r.code}>
                      {r.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="loss-note">
                Observação{" "}
                <span className="text-muted-foreground font-normal">(opcional)</span>
              </Label>
              <Textarea
                id="loss-note"
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Detalhe o contexto, se quiser..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="ghost"
              onClick={() => setDialogOpen(false)}
              disabled={pending}
            >
              Cancelar
            </Button>
            <Button
              variant="destructive"
              onClick={submitLost}
              disabled={pending || !reason}
            >
              {pending ? <Loader2 className="size-4 animate-spin" /> : <CircleX className="size-4" />}
              Confirmar perda
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
