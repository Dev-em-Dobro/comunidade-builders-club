import Link from "next/link";
import { prisma } from "@/lib/db";
import { buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import { Plus, Bot, ArrowRight } from "lucide-react";
import { AGENT_ROLES, roleTabs } from "./_roles";

export const dynamic = "force-dynamic";

export default async function AgentsListPage() {
  const agents = await safeQuery();

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">
            Agentes
          </h1>
          <p className="text-muted-foreground mt-1">
            Personas reutilizáveis · system prompt · modelo · tools
          </p>
        </div>
        <Link href="/settings/agents/new" className={buttonVariants()}>
          <Plus className="size-4" /> Novo agente
        </Link>
      </header>

      {agents.length === 0 ? (
        <Card className="p-12 flex flex-col items-center text-center">
          <Bot className="size-10 text-muted-foreground mb-3" />
          <p className="font-medium">Nenhum agente configurado</p>
          <p className="text-sm text-muted-foreground mt-1">
            Crie pelo menos 1 marcado como <code>isDefault</code> — o orquestrador
            usa esse pra qualquer conversa nova.
          </p>
          <Link href="/settings/agents/new" className={buttonVariants({ className: "mt-4" })}>
            <Plus className="size-4" /> Criar agente padrão
          </Link>
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {agents.map((a) => (
            <Card key={a.id} className="hover:border-primary/40 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <CardTitle className="text-base">{a.name}</CardTitle>
                  <div className="flex gap-1">
                    {a.role && (
                      <Badge variant="outline" className="text-[10px]">
                        {AGENT_ROLES.find((r) => r.value === a.role)?.label.split(" — ")[0] ?? a.role}
                      </Badge>
                    )}
                    {a.isDefault && <Badge className="font-mono text-[10px]">default</Badge>}
                  </div>
                </div>
                <CardDescription className="font-mono text-xs">
                  {a.provider} · {a.model} · temp {a.temperature.toFixed(1)} · mem {a.memoryMode}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm line-clamp-3 text-muted-foreground">
                  {a.systemPrompt}
                </p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Link
                    href={`/settings/agents/${a.id}`}
                    className={buttonVariants({ size: "sm", variant: "outline" })}
                  >
                    Editar <ArrowRight className="size-4" />
                  </Link>
                  {roleTabs(a.role).map((t) => (
                    <Link
                      key={t.slug}
                      href={`/settings/agents/${a.id}/${t.slug}`}
                      className={buttonVariants({ size: "sm", variant: "ghost" })}
                    >
                      {t.label}
                    </Link>
                  ))}
                  <Link
                    href={`/settings/agents/${a.id}/rules`}
                    className={buttonVariants({ size: "sm", variant: "ghost" })}
                  >
                    Regras
                  </Link>
                  <Link
                    href={`/settings/agents/${a.id}/rag`}
                    className={buttonVariants({ size: "sm", variant: "ghost" })}
                  >
                    Conhecimento
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

async function safeQuery() {
  try {
    return await prisma.agentSession.findMany({
      orderBy: [{ isDefault: "desc" }, { createdAt: "desc" }],
    });
  } catch {
    return [];
  }
}
