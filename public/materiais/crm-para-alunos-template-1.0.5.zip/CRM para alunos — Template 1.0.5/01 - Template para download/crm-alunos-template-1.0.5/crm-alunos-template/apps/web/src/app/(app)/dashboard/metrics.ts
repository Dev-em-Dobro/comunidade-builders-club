/** Funções puras de cálculo do dashboard de conversão (Parte 9). Sem Prisma. */

/** Ordem do funil. `lost` fica fora — é terminal-negativo. */
export const STAGE_ORDER = [
  "new",
  "contacted",
  "qualified",
  "proposal",
  "won",
] as const;

export type Stage = (typeof STAGE_ORDER)[number];

const STAGE_LABEL: Record<Stage, string> = {
  new: "Novo",
  contacted: "Contatado",
  qualified: "Qualificado",
  proposal: "Proposta",
  won: "Ganho",
};

export interface FunnelLevel {
  stage: Stage;
  label: string;
  count: number;
  /** queda % vs. o nível anterior; null no primeiro nível ou se o anterior é 0. */
  dropoffPct: number | null;
}

/**
 * Funil cumulativo: nível(i).count = soma dos counts de STAGE_ORDER[i..fim].
 * Monotônico decrescente. A chave `lost` em `stageCounts`, se houver, é ignorada.
 */
export function buildFunnel(stageCounts: Record<string, number>): FunnelLevel[] {
  const levels: FunnelLevel[] = [];
  let prev: number | null = null;
  for (let i = 0; i < STAGE_ORDER.length; i++) {
    let count = 0;
    for (let j = i; j < STAGE_ORDER.length; j++) {
      count += stageCounts[STAGE_ORDER[j]] ?? 0;
    }
    const dropoffPct =
      prev === null || prev === 0 ? null : ((prev - count) / prev) * 100;
    levels.push({
      stage: STAGE_ORDER[i],
      label: STAGE_LABEL[STAGE_ORDER[i]],
      count,
      dropoffPct,
    });
    prev = count;
  }
  return levels;
}

/** % de SLA cumprido (não-breached / total). null se não há leads. */
export function slaCompliancePct(
  total: number,
  breached: number,
): number | null {
  if (total === 0) return null;
  return (1 - breached / total) * 100;
}

/** Delta entre duas medidas, em pontos. Positivo = melhora. */
export function trendDelta(current: number, previous: number): number {
  return current - previous;
}

/** Porcentagem com guarda de divisão por zero. Float cru — arredondar na exibição. */
export function pct(part: number, total: number): number | null {
  if (total === 0) return null;
  return (part / total) * 100;
}

export interface DayBucket {
  /** YYYY-MM-DD (UTC) */
  date: string;
  won: number;
  lost: number;
}

/** Chave YYYY-MM-DD de uma data, em UTC. */
function dayKey(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/**
 * Agrupa won/lost por dia nos últimos `rangeDays` dias, preenchendo dias
 * vazios com 0. Buckets em ordem cronológica crescente; o último é o dia
 * de `now`.
 */
export function bucketConversionsByDay(
  won: Date[],
  lost: Date[],
  rangeDays: number,
  now: Date,
): DayBucket[] {
  const buckets = new Map<string, DayBucket>();
  for (let i = rangeDays - 1; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
    const key = dayKey(d);
    buckets.set(key, { date: key, won: 0, lost: 0 });
  }
  for (const d of won) {
    const b = buckets.get(dayKey(d));
    if (b) b.won++;
  }
  for (const d of lost) {
    const b = buckets.get(dayKey(d));
    if (b) b.lost++;
  }
  return [...buckets.values()];
}

/** Taxa de conversão = won / (won + lost). null se não há resultados. */
export function conversionRate(won: number, lost: number): number | null {
  return pct(won, won + lost);
}

/** Custo médio de LLM por lead. null se não há leads. */
export function costPerLead(
  totalCostUsd: number,
  leadCount: number,
): number | null {
  if (leadCount === 0) return null;
  return totalCostUsd / leadCount;
}

/**
 * Formata uma duração de espera (ms) em texto curto pt-BR.
 * "<1min" | "47min" | "2h 12min" | "3d 4h". Negativo é tratado como 0.
 */
export function formatWaitDuration(ms: number): string {
  if (ms < 60_000) return "<1min";
  const totalMin = Math.floor(ms / 60_000);
  const totalH = Math.floor(totalMin / 60);
  const d = Math.floor(totalH / 24);
  const h = totalH % 24;
  const m = totalMin % 60;
  if (d > 0) return `${d}d ${h}h`;
  if (totalH > 0) return `${totalH}h ${m}min`;
  return `${m}min`;
}

export type WaitTier = "ok" | "warn" | "urgent";

/**
 * Severidade da espera por atendimento humano, por tempo decorrido:
 * urgente ≥ 60min, atenção ≥ 15min, ok abaixo disso.
 */
export function waitTier(ms: number): WaitTier {
  if (ms >= 60 * 60_000) return "urgent";
  if (ms >= 15 * 60_000) return "warn";
  return "ok";
}
