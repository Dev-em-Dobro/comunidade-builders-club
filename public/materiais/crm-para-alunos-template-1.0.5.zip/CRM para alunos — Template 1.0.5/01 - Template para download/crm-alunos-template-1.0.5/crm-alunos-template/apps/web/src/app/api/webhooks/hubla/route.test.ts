import { describe, it, expect, beforeAll, afterAll, beforeEach, vi } from "vitest";
import { prisma } from "@/lib/db";
import { POST } from "./route";

const TOKEN = "test-token-aaaaaaaaaaaaaaaaaaaa";

const created = { contactIds: [] as string[], leadIds: [] as string[] };

beforeAll(() => {
  vi.stubEnv("HUBLA_WEBHOOK_TOKEN", TOKEN);
});

afterAll(async () => {
  vi.unstubAllEnvs();
  await prisma.pipelineEvent.deleteMany({ where: { leadId: { in: created.leadIds } } });
  await prisma.lead.deleteMany({ where: { id: { in: created.leadIds } } });
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.webhookEvent.deleteMany({ where: { provider: "hubla" } });
  await prisma.$disconnect();
});

beforeEach(async () => {
  await prisma.webhookEvent.deleteMany({ where: { provider: "hubla" } });
});

function req(opts: {
  token?: string;
  idem?: string;
  body?: string | object;
}): Request {
  const headers: Record<string, string> = {
    "content-type": "application/json",
  };
  if (opts.token !== undefined) headers["x-hubla-token"] = opts.token;
  if (opts.idem !== undefined) headers["x-hubla-idempotency"] = opts.idem;
  const body =
    typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body ?? {});
  return new Request("http://localhost/api/webhooks/hubla", {
    method: "POST",
    headers,
    body,
  });
}

describe("POST /api/webhooks/hubla — estrutura", () => {
  it("401 quando token ausente", async () => {
    const res = await POST(req({ idem: "i1", body: { type: "x" } }));
    expect(res.status).toBe(401);
    expect(await prisma.webhookEvent.count()).toBe(0);
  });

  it("401 quando token inválido", async () => {
    const res = await POST(req({ token: "errado", idem: "i1", body: { type: "x" } }));
    expect(res.status).toBe(401);
    expect(await prisma.webhookEvent.count()).toBe(0);
  });

  it("400 quando JSON malformado", async () => {
    const res = await POST(req({ token: TOKEN, idem: "i1", body: "{nao eh json" }));
    expect(res.status).toBe(400);
  });

  it("400 quando idempotency header ausente", async () => {
    const res = await POST(req({ token: TOKEN, body: { type: "x" } }));
    expect(res.status).toBe(400);
  });

  it("tipo não tratado → 200, WebhookEvent com result='ignored_type'", async () => {
    const res = await POST(
      req({ token: TOKEN, idem: "i_ignore", body: { type: "subscription.activated" } }),
    );
    expect(res.status).toBe(200);
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_ignore" } },
    });
    expect(row.result).toBe("ignored_type");
    expect(row.processedAt).not.toBeNull();
    expect(row.eventType).toBe("subscription.activated");
  });

  it("reentrega (mesmo idempotencyKey) → 200, registra dedup_race no segundo", async () => {
    await POST(req({ token: TOKEN, idem: "i_dup", body: { type: "subscription.activated" } }));
    const res = await POST(
      req({ token: TOKEN, idem: "i_dup", body: { type: "subscription.activated" } }),
    );
    expect(res.status).toBe(200);
    // Só um WebhookEvent existe (a constraint unique impediu o segundo)
    const rows = await prisma.webhookEvent.findMany({
      where: { provider: "hubla", idempotencyKey: "i_dup" },
    });
    expect(rows.length).toBe(1);
  });
});

async function makeLeadWithContact(stage: string, email: string | null) {
  const contact = await prisma.contact.create({
    data: { displayName: `Route test ${Date.now()}-${Math.random()}`, email },
  });
  created.contactIds.push(contact.id);
  const lead = await prisma.lead.create({
    data: { contactId: contact.id, stage, interestCourseIds: [] },
  });
  created.leadIds.push(lead.id);
  return { contact, lead };
}

function paidPayload(opts: {
  leadIdUtm?: string | null;
  payerEmail?: string | null;
  invoiceId?: string;
}) {
  const utm = opts.leadIdUtm === null
    ? undefined
    : { content: opts.leadIdUtm ?? "lead_x" };
  return {
    type: "invoice.payment_succeeded",
    event: {
      invoice: {
        id: opts.invoiceId ?? "inv_route_1",
        status: "paid",
        currency: "BRL",
        paymentMethod: "credit_card",
        installments: 12,
        saleDate: "2026-05-28T14:30:00.000Z",
        amount: { totalCents: 50000 },
        firstPaymentSession: utm ? { utm } : undefined,
        products: [{ id: "prod_route", offers: [{ id: "offer_route" }] }],
      },
      payer: opts.payerEmail
        ? { email: opts.payerEmail }
        : undefined,
    },
  };
}

describe("POST /api/webhooks/hubla — invoice.payment_succeeded", () => {
  it("happy path com UTM: marca won + result='applied'", async () => {
    const { lead } = await makeLeadWithContact("qualified", null);
    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_paid_utm",
        body: paidPayload({ leadIdUtm: lead.id }),
      }),
    );
    expect(res.status).toBe(200);

    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");

    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_paid_utm" } },
    });
    expect(row.result).toBe("applied");
    expect(row.leadId).toBe(lead.id);
    expect(row.processedAt).not.toBeNull();
  });

  it("UTM inválido (lead inexistente) cai no fallback por email", async () => {
    const email = `bad-utm-${Date.now()}@test.local`;
    const { lead } = await makeLeadWithContact("qualified", email);
    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_paid_bad_utm",
        body: paidPayload({
          leadIdUtm: "lead_inexistente_xyz",
          payerEmail: email,
        }),
      }),
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_paid_bad_utm" } },
    });
    expect(row.result).toBe("applied");
    expect(row.leadId).toBe(lead.id);
  });

  it("UTM ausente, fallback por email funciona", async () => {
    const email = `fb-${Date.now()}@test.local`;
    const { lead } = await makeLeadWithContact("contacted", email);
    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_paid_email",
        body: paidPayload({ leadIdUtm: null, payerEmail: email }),
      }),
    );
    expect(res.status).toBe(200);
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_paid_email" } },
    });
    expect(row.result).toBe("applied");
    expect(row.leadId).toBe(lead.id);
  });

  it("lead não encontrado por UTM nem por email → result='lead_not_found', 200", async () => {
    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_paid_404",
        body: paidPayload({
          leadIdUtm: "lead_inexistente",
          payerEmail: "ninguem@test.local",
        }),
      }),
    );
    expect(res.status).toBe(200);
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_paid_404" } },
    });
    expect(row.result).toBe("lead_not_found");
    expect(row.leadId).toBeNull();
  });

  it("lead já 'won' → result='already_won'", async () => {
    const { lead } = await makeLeadWithContact("won", null);
    await prisma.lead.update({ where: { id: lead.id }, data: { wonAt: new Date("2026-05-01") } });
    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_paid_upsell",
        body: paidPayload({ leadIdUtm: lead.id, invoiceId: "inv_upsell" }),
      }),
    );
    expect(res.status).toBe(200);
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_paid_upsell" } },
    });
    expect(row.result).toBe("already_won");
    // wonAt original preservado
    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.wonAt?.toISOString()).toBe("2026-05-01T00:00:00.000Z");
  });

  it("payload sem invoice.id → result='invalid_payload'", async () => {
    const broken = {
      type: "invoice.payment_succeeded",
      event: { invoice: { status: "paid" }, payer: { email: "x@test.local" } },
    };
    const res = await POST(req({ token: TOKEN, idem: "i_invalid", body: broken }));
    expect(res.status).toBe(200);
    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_invalid" } },
    });
    expect(row.result).toBe("invalid_payload");
    expect(row.leadId).toBeNull();
  });

  it("órfão (result=null) é reprocessado em vez de bloqueado por dedup", async () => {
    const { lead } = await makeLeadWithContact("qualified", null);
    // Pré-semeia um WebhookEvent órfão (simula falha entre create e update).
    await prisma.webhookEvent.create({
      data: {
        provider: "hubla",
        idempotencyKey: "i_orphan",
        eventType: "invoice.payment_succeeded",
        payload: paidPayload({ leadIdUtm: lead.id, invoiceId: "inv_orphan" }) as object,
      },
    });

    const res = await POST(
      req({
        token: TOKEN,
        idem: "i_orphan",
        body: paidPayload({ leadIdUtm: lead.id, invoiceId: "inv_orphan" }),
      }),
    );
    expect(res.status).toBe(200);

    const after = await prisma.lead.findUniqueOrThrow({ where: { id: lead.id } });
    expect(after.stage).toBe("won");

    const row = await prisma.webhookEvent.findUniqueOrThrow({
      where: { provider_idempotencyKey: { provider: "hubla", idempotencyKey: "i_orphan" } },
    });
    expect(row.result).toBe("applied");
    expect(row.leadId).toBe(lead.id);
  });
});
