import { describe, it, expect, beforeAll, afterAll, vi } from "vitest";
import { prisma } from "@/lib/db";

// Mock auth — testes não passam por NextAuth real.
vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "u-test" } })),
}));

import { GET } from "./route";
import { auth } from "@/auth";

const created = { contactIds: [] as string[] };
let convId: string;
let firstMsgId: string;
let secondMsgId: string;

beforeAll(async () => {
  const contact = await prisma.contact.create({
    data: { displayName: "Msgs route test" },
  });
  created.contactIds.push(contact.id);
  const conv = await prisma.conversation.create({
    data: { contactId: contact.id, channel: "whatsapp_cloud" },
  });
  convId = conv.id;
  const m1 = await prisma.message.create({
    data: { conversationId: convId, direction: "inbound", role: "user", text: "oi" },
  });
  firstMsgId = m1.id;
  // Pequeno delay pra garantir createdAt distinto.
  await new Promise((r) => setTimeout(r, 5));
  const m2 = await prisma.message.create({
    data: { conversationId: convId, direction: "outbound", role: "assistant", text: "olá" },
  });
  secondMsgId = m2.id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: { in: created.contactIds } } });
  await prisma.$disconnect();
});

function req(url: string): Request {
  return new Request(url);
}

describe("GET /api/conversations/[id]/messages", () => {
  it("retorna 401 sem sessão", async () => {
    vi.mocked(auth).mockResolvedValueOnce(null as never);
    const res = await GET(req(`http://localhost/api/conversations/${convId}/messages`), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(401);
  });

  it("retorna todas as msgs ordenadas asc por createdAt", async () => {
    const res = await GET(req(`http://localhost/api/conversations/${convId}/messages`), {
      params: Promise.resolve({ id: convId }),
    });
    expect(res.status).toBe(200);
    const body = (await res.json()) as { messages: { id: string }[] };
    expect(body.messages.map((m) => m.id)).toEqual([firstMsgId, secondMsgId]);
  });

  it("respeita since — só msgs criadas depois", async () => {
    const res = await GET(
      req(`http://localhost/api/conversations/${convId}/messages?since=${firstMsgId}`),
      { params: Promise.resolve({ id: convId }) },
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { messages: { id: string }[] };
    expect(body.messages.map((m) => m.id)).toEqual([secondMsgId]);
  });
});
