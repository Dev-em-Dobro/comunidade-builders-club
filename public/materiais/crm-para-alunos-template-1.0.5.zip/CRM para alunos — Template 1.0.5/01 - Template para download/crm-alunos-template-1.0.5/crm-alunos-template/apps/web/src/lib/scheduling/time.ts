/**
 * Datas "de parede" (YYYY-MM-DD + HH:MM) num fuso IANA ↔ instantes UTC.
 *
 * Sem lib de timezone: usa Intl.DateTimeFormat pra descobrir o offset do fuso
 * no instante em questão. Funciona com horário de verão (2 passadas), ao
 * contrário do offset fixo de quiet-hours.ts.
 *
 * Módulo PURO — também roda no navegador (formulário de profissionais e calendário).
 * Não importe nada de servidor aqui (config/fs/prisma): o fuso do negócio
 * fica em ./timezone.ts.
 */

export const DEFAULT_TZ = "America/Sao_Paulo";

export function isValidTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

const WEEKDAY_SHORT = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export interface ZonedParts {
  /** YYYY-MM-DD */
  date: string;
  /** HH:MM (24h) */
  time: string;
  /** 0 = domingo */
  weekday: number;
}

function partsOf(d: Date, tz: string): Record<string, string> {
  const fmt = new Intl.DateTimeFormat("en-US", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
    weekday: "short",
  });
  return Object.fromEntries(fmt.formatToParts(d).map((p) => [p.type, p.value]));
}

/** Data/hora de parede de um instante no fuso `tz`. */
export function zonedParts(d: Date, tz: string): ZonedParts {
  const p = partsOf(d, tz);
  return {
    date: `${p.year}-${p.month}-${p.day}`,
    time: `${p.hour}:${p.minute}`,
    weekday: WEEKDAY_SHORT.indexOf(p.weekday),
  };
}

/** Offset (ms) do fuso no instante: horaDeParede − UTC. */
function offsetMs(instant: Date, tz: string): number {
  const p = partsOf(instant, tz);
  const asUtc = Date.UTC(
    Number(p.year),
    Number(p.month) - 1,
    Number(p.day),
    Number(p.hour),
    Number(p.minute),
    Number(p.second),
  );
  return asUtc - Math.floor(instant.getTime() / 1000) * 1000;
}

/** Converte data + hora de parede no fuso `tz` pro instante UTC. */
export function zonedToUtc(date: string, time: string, tz: string): Date {
  const [y, m, d] = date.split("-").map(Number);
  const [hh, mm] = time.split(":").map(Number);
  const wall = Date.UTC(y!, m! - 1, d!, hh!, mm!);
  let guess = wall - offsetMs(new Date(wall), tz);
  // 2ª passada corrige quando o offset muda entre `wall` e o palpite (DST).
  guess = wall - offsetMs(new Date(guess), tz);
  return new Date(guess);
}

export const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
export const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

export function isValidDate(date: string): boolean {
  if (!DATE_RE.test(date)) return false;
  const [y, m, d] = date.split("-").map(Number);
  const dt = new Date(Date.UTC(y!, m! - 1, d!));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m! - 1 && dt.getUTCDate() === d;
}

/** Soma dias numa data YYYY-MM-DD (calendário puro, sem fuso). */
export function addDays(date: string, n: number): string {
  const [y, m, d] = date.split("-").map(Number);
  const dt = new Date(Date.UTC(y!, m! - 1, d! + n));
  return dt.toISOString().slice(0, 10);
}

/** Dia da semana (0 = domingo) de uma data YYYY-MM-DD. */
export function weekdayOf(date: string): number {
  const [y, m, d] = date.split("-").map(Number);
  return new Date(Date.UTC(y!, m! - 1, d!)).getUTCDay();
}

export function minutesOf(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return h! * 60 + m!;
}

export function timeOf(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

const WEEKDAY_PT = [
  "domingo",
  "segunda-feira",
  "terça-feira",
  "quarta-feira",
  "quinta-feira",
  "sexta-feira",
  "sábado",
];

/** "segunda-feira, 17/11" — rótulo humano de uma data YYYY-MM-DD. */
export function dayLabel(date: string): string {
  const [, m, d] = date.split("-");
  return `${WEEKDAY_PT[weekdayOf(date)]}, ${d}/${m}`;
}

/** "segunda-feira, 17/11 às 09:00" — rótulo humano de um instante no fuso `tz`. */
export function slotLabel(instant: Date, tz: string): string {
  const p = zonedParts(instant, tz);
  return `${dayLabel(p.date)} às ${p.time}`;
}
