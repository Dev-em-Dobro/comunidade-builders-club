import { describe, it, expect } from "vitest";
import {
  isOutOfWindowFollowupDue,
  isOutOfWindowCadenceExhaustedLost,
  ownsLeadForOutWindowCadence,
  resolveTemplateVars,
  type OutWindowCandidate,
  type ExhaustedLostCandidate,
} from "./out-window-followup";

const CFG = {
  intervalsDays: [1, 2, 4],
  eligibleStages: ["qualified", "proposal"],
  lostGraceDays: 2,
};
const DAY = 24 * 60 * 60 * 1000;
const NOW = new Date("2026-06-16T12:00:00.000Z");

function due(over: Partial<OutWindowCandidate> = {}): OutWindowCandidate {
  return {
    // janela fechou há 1.5 dias → F1 (intervalo 1d) já venceu
    windowClosesAt: new Date(NOW.getTime() - 1.5 * DAY),
    lastFollowUpStep: null,
    lastFollowUpAt: null,
    leadStage: "qualified",
    audience: "prospect",
    aiEnabled: true,
    handoffRequested: false,
    ...over,
  };
}

describe("isOutOfWindowFollowupDue", () => {
  it("retorna step 1 quando janela fechada há > intervalo[0] e nunca houve follow-up", () => {
    expect(isOutOfWindowFollowupDue(due(), NOW, CFG)).toBe(1);
  });

  it("janela ABERTA → null", () => {
    const c = due({ windowClosesAt: new Date(NOW.getTime() + DAY) });
    expect(isOutOfWindowFollowupDue(c, NOW, CFG)).toBeNull();
  });

  it("windowClosesAt null → null", () => {
    expect(isOutOfWindowFollowupDue(due({ windowClosesAt: null }), NOW, CFG)).toBeNull();
  });

  it("stage não-elegível (contacted) → null", () => {
    expect(isOutOfWindowFollowupDue(due({ leadStage: "contacted" }), NOW, CFG)).toBeNull();
  });

  it("audience != prospect → null (student/support/refund/null)", () => {
    for (const a of ["student", "support", "refund", null]) {
      expect(isOutOfWindowFollowupDue(due({ audience: a }), NOW, CFG)).toBeNull();
    }
  });

  it("IA desligada ou handoff → null", () => {
    expect(isOutOfWindowFollowupDue(due({ aiEnabled: false }), NOW, CFG)).toBeNull();
    expect(isOutOfWindowFollowupDue(due({ handoffRequested: true }), NOW, CFG)).toBeNull();
  });

  it("step 2 vence só após intervalo[1] (2 dias) do fechamento", () => {
    // janela fechou há 1.5d, F1 já enviado (step=1). F2 vence em +2d do fechamento.
    const closed = new Date(NOW.getTime() - 1.5 * DAY);
    const c = due({ windowClosesAt: closed, lastFollowUpStep: 1 });
    expect(isOutOfWindowFollowupDue(c, NOW, CFG)).toBeNull(); // 1.5d < 2d
    const later = new Date(closed.getTime() + 2 * DAY + 1000);
    expect(isOutOfWindowFollowupDue(c, later, CFG)).toBe(2);
    const atExact = new Date(closed.getTime() + 2 * DAY);
    expect(isOutOfWindowFollowupDue(c, atExact, CFG)).toBe(2); // boundary exato: >= inclui
  });

  it("step 3 vence após intervalo[2] (4 dias) do fechamento", () => {
    const closed = new Date("2026-06-10T12:00:00.000Z");
    const c = due({ windowClosesAt: closed, lastFollowUpStep: 2 });
    const at4d = new Date(closed.getTime() + 4 * DAY + 1000);
    expect(isOutOfWindowFollowupDue(c, at4d, CFG)).toBe(3);
  });

  it("cap: lastFollowUpStep === maxSteps (3) → null", () => {
    const closed = new Date("2026-06-01T12:00:00.000Z");
    const c = due({ windowClosesAt: closed, lastFollowUpStep: 3 });
    expect(isOutOfWindowFollowupDue(c, NOW, CFG)).toBeNull();
  });
});

describe("isOutOfWindowCadenceExhaustedLost", () => {
  function ex(over: Partial<ExhaustedLostCandidate> = {}): ExhaustedLostCandidate {
    return {
      leadStage: "qualified",
      audience: "prospect",
      lastFollowUpStep: 3,
      lastFollowUpAt: new Date(NOW.getTime() - 3 * DAY), // F3 há 3d > grace 2d
      ...over,
    };
  }
  it("step 3 + grace vencido → true", () => {
    expect(isOutOfWindowCadenceExhaustedLost(ex(), NOW, CFG)).toBe(true);
  });
  it("step 3 mas dentro do grace → false", () => {
    const c = ex({ lastFollowUpAt: new Date(NOW.getTime() - 1 * DAY) });
    expect(isOutOfWindowCadenceExhaustedLost(c, NOW, CFG)).toBe(false);
  });
  it("step < 3 → false", () => {
    expect(isOutOfWindowCadenceExhaustedLost(ex({ lastFollowUpStep: 2 }), NOW, CFG)).toBe(false);
  });
  it("audience != prospect → false", () => {
    expect(isOutOfWindowCadenceExhaustedLost(ex({ audience: "student" }), NOW, CFG)).toBe(false);
  });
  it("lastFollowUpAt null → false", () => {
    expect(isOutOfWindowCadenceExhaustedLost(ex({ lastFollowUpAt: null }), NOW, CFG)).toBe(false);
  });
});

describe("ownsLeadForOutWindowCadence", () => {
  it("qualified + prospect + step < max → true", () => {
    expect(ownsLeadForOutWindowCadence(
      { leadStage: "qualified", audience: "prospect", lastFollowUpStep: 1 }, CFG,
    )).toBe(true);
  });
  it("step === max (cadência terminou) → false", () => {
    expect(ownsLeadForOutWindowCadence(
      { leadStage: "qualified", audience: "prospect", lastFollowUpStep: 3 }, CFG,
    )).toBe(false);
  });
  it("não-prospect ou stage fora → false", () => {
    expect(ownsLeadForOutWindowCadence(
      { leadStage: "qualified", audience: "student", lastFollowUpStep: 0 }, CFG,
    )).toBe(false);
    expect(ownsLeadForOutWindowCadence(
      { leadStage: "contacted", audience: "prospect", lastFollowUpStep: 0 }, CFG,
    )).toBe(false);
  });
});

describe("resolveTemplateVars", () => {
  it("2 vars → [primeiro nome, curso]", () => {
    expect(resolveTemplateVars("João Silva", "React do Zero", 2)).toEqual(["João", "React do Zero"]);
  });
  it("1 var → só primeiro nome", () => {
    expect(resolveTemplateVars("João Silva", "React", 1)).toEqual(["João"]);
  });
  it("0 vars → []", () => {
    expect(resolveTemplateVars("João", "React", 0)).toEqual([]);
  });
  it("fallbacks quando nome/curso vazios", () => {
    expect(resolveTemplateVars(null, null, 2)).toEqual(["tudo bem", "o curso"]);
  });
});
