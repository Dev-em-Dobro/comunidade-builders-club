/**
 * Tipos e metadados compartilhados da UI de Regras de IA.
 * Sem diretiva "use server"/"use client" — importável por server e client.
 * O engine que consome essas regras vive em `@/lib/ai-rules`.
 */

/** Regra serializada (params como objeto puro) passada do servidor pro cliente. */
export interface SerializedRule {
  id: string;
  priority: number;
  enabled: boolean;
  mode: string;
  action: string;
  params: Record<string, unknown>;
  staticReply: string | null;
}

/** Modes disponíveis — id bate com `RuleMode` em `@/lib/ai-rules`. */
export const RULE_MODES = [
  {
    id: "always_on",
    label: "Sempre ativa",
    desc: "Casa com qualquer mensagem recebida.",
  },
  {
    id: "keyword_trigger",
    label: "Gatilho por palavra-chave",
    desc: "Casa quando a mensagem contém alguma das palavras.",
  },
  {
    id: "keyword_pause",
    label: "Pausa por palavra-chave",
    desc: "Mesma checagem do gatilho — normalmente pareada com a ação 'Calar IA'.",
  },
  {
    id: "contact_whitelist",
    label: "Lista de permissão",
    desc: "Casa quando o contato está na lista.",
  },
  {
    id: "contact_blacklist",
    label: "Lista de bloqueio",
    desc: "Casa quando o contato está na lista.",
  },
  {
    id: "schedule",
    label: "Horário",
    desc: "Casa quando o horário atual está dentro da janela configurada.",
  },
  {
    id: "manual_approval",
    label: "Aprovação manual",
    desc: "Abre um ticket em vez de chamar o LLM.",
  },
  {
    id: "human_takeover",
    label: "Atendimento humano",
    desc: "Reservado — sem efeito por enquanto (tratado antes pelo flush).",
  },
] as const;

/** Actions disponíveis — id bate com `RuleAction` em `@/lib/ai-rules`. */
export const RULE_ACTIONS = [
  {
    id: "respond",
    label: "Responder",
    desc: "A IA gera a resposta normalmente.",
  },
  {
    id: "drop",
    label: "Calar IA",
    desc: "A IA não responde nada a essa mensagem.",
  },
  {
    id: "handoff",
    label: "Handoff",
    desc: "Transfere a conversa para um atendente humano.",
  },
  {
    id: "static_reply",
    label: "Resposta fixa",
    desc: "Envia um texto pronto, sem passar pelo LLM.",
  },
] as const;
