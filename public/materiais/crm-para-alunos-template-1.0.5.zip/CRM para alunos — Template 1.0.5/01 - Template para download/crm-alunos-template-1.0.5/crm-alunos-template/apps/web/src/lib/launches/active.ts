import { prisma } from "@/lib/db";
import type { Course, Launch, LaunchPlan } from "@prisma/client";

export type ActiveLaunch = Launch & {
  plans: LaunchPlan[];
  course: Course;
};

const CACHE_TTL_MS = 60_000;

/**
 * Cache em-memória POR PROCESSO. Cada instância (web, worker) tem seu próprio
 * cache; troca de status pode levar até CACHE_TTL_MS pra propagar. Operador
 * que precisar de efeito imediato troca status e aguarda 1 min.
 *
 * Chave = courseId. Valor: { result, expiresAt }.
 */
const cache = new Map<string, { result: ActiveLaunch | null; expiresAt: number }>();

/** Útil pra testes. Não chamar em produção. */
export function _resetActiveLaunchCache(): void {
  cache.clear();
}

/**
 * Retorna a oferta ativa pra um curso num dado momento, ou null se não há.
 *
 * Regras (do spec):
 *  - status='live' AND startsAt <= at AND endsAt > at AND courseId = ?
 *  - se 2+ retornarem (estado inválido criado externamente), pega o de
 *    updatedAt DESC e loga warning. Validação na escrita previne isso normalmente.
 *  - cache em-memória 60s por courseId.
 */
export async function getActiveLaunch(
  courseId: string,
  at: Date = new Date(),
): Promise<ActiveLaunch | null> {
  const now = Date.now();
  const cached = cache.get(courseId);
  if (cached && cached.expiresAt > now) return cached.result;

  const rows = await prisma.launch.findMany({
    where: {
      courseId,
      status: "live",
      startsAt: { lte: at },
      endsAt: { gt: at },
    },
    include: {
      plans: { orderBy: { sortOrder: "asc" } },
      course: true,
    },
    orderBy: { updatedAt: "desc" },
  });

  if (rows.length > 1) {
    console.warn(
      `[getActiveLaunch] estado inválido: ${rows.length} Launches live pro courseId=${courseId} — usando ${rows[0]!.id}`,
    );
  }

  const result = (rows[0] ?? null) as ActiveLaunch | null;
  cache.set(courseId, { result, expiresAt: now + CACHE_TTL_MS });
  return result;
}

/** Invalidação manual — chame depois de mudar status manualmente no mesmo processo. */
export function invalidateActiveLaunch(courseId: string): void {
  cache.delete(courseId);
}
