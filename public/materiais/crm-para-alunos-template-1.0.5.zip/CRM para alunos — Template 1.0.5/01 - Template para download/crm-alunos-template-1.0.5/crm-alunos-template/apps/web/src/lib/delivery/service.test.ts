/**
 * Integração com o Postgres de teste: pedido do agente de delivery — preço do
 * cardápio, validações, histórico do contato, status e módulo do agente.
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { prisma } from "@/lib/db";
import { prepareRoleModule } from "@/lib/agent-modules";
import { placeOrder, updateOrderStatus } from "./service";

let agentId: string;
let otherAgentId: string;
let contactId: string;
let leadId: string;

const BASE = { items: [{ name: "x-burguer", quantity: 2 }], fulfillment: "delivery", neighborhood: "Centro" };

beforeAll(async () => {
  const stamp = Date.now();
  agentId = (await prisma.agentSession.create({ data: { name: `Delivery teste ${stamp}`, systemPrompt: "x", role: "delivery" } })).id;
  otherAgentId = (await prisma.agentSession.create({ data: { name: `Delivery outro ${stamp}`, systemPrompt: "x", role: "delivery" } })).id;
  await prisma.deliveryStore.create({
    data: {
      agentSessionId: agentId,
      areas: [{ name: "Centro", feeCents: 500 }],
      menuItems: [
        { category: "Lanches", name: "X-Burguer", priceCents: 2500 },
        { category: "Bebidas", name: "Coca-Cola 2L", priceCents: 1200 },
      ],
    },
  });
  const contact = await prisma.contact.create({ data: { displayName: "Cliente Teste" } });
  contactId = contact.id;
  leadId = (await prisma.lead.create({ data: { contactId } })).id;
});

afterAll(async () => {
  await prisma.contact.deleteMany({ where: { id: contactId } });
  await prisma.agentSession.deleteMany({ where: { id: { in: [agentId, otherAgentId] } } });
  await prisma.$disconnect();
});

const order = (input: Record<string, unknown>, agent = agentId) =>
  placeOrder({ agentSessionId: agent, contactId, conversationId: null, input });

describe("pedido do delivery", () => {
  it("registra com o preço do cardápio + taxa e vai pro histórico do contato", async () => {
    const r = await order({
      ...BASE,
      address: "Rua das Flores, 120, ap 3",
      paymentMethod: "cash",
      changeFor: 100,
      // preço "inventado" pelo modelo é ignorado — não existe no schema
      price: 1,
    });
    expect(r).toMatchObject({ ok: true, payment: "cash" });
    if (!r.ok) return;
    expect(r.total.replace(/\s/g, " ")).toBe("R$ 55,00");

    const saved = await prisma.order.findFirstOrThrow({ where: { contactId, number: r.orderNumber } });
    expect(saved).toMatchObject({
      subtotalCents: 5000,
      deliveryFeeCents: 500,
      totalCents: 5500,
      changeForCents: 10000,
      neighborhood: "Centro",
      status: "new",
      customerName: "Cliente Teste",
    });
    const event = await prisma.pipelineEvent.findFirst({ where: { leadId, type: "order_placed" } });
    expect(event?.payload).toMatchObject({ number: r.orderNumber });
  });

  it("exige endereço na entrega, forma de pagamento e troco >= total", async () => {
    expect(await order({ ...BASE, paymentMethod: "pix" })).toMatchObject({ ok: false, error: "missing_address" });
    expect(await order({ ...BASE, address: "Rua A, 1" })).toMatchObject({ ok: false, error: "missing_payment" });
    expect(await order({ ...BASE, address: "Rua A, 1", paymentMethod: "cash", changeFor: 20 })).toMatchObject({
      ok: false,
      error: "invalid_change",
    });
  });

  it("recusa item fora do cardápio e loja de outro agente", async () => {
    expect(await order({ ...BASE, items: [{ name: "Sushi", quantity: 1 }], address: "Rua A, 1", paymentMethod: "pix" })).toMatchObject({
      ok: false,
      error: "unknown_items",
    });
    // outro agente não tem cardápio cadastrado
    expect(await order({ ...BASE, address: "Rua A, 1", paymentMethod: "pix" }, otherAgentId)).toMatchObject({
      ok: false,
      error: "no_menu",
    });
  });

  it("status só muda pelo agente dono do pedido", async () => {
    const o = await prisma.order.findFirstOrThrow({ where: { contactId, agentSessionId: agentId } });
    expect(await updateOrderStatus(otherAgentId, o.id, "preparing")).toBe(false);
    expect(await updateOrderStatus(agentId, o.id, "voando")).toBe(false);
    expect(await updateOrderStatus(agentId, o.id, "preparing")).toBe(true);
    expect((await prisma.order.findUniqueOrThrow({ where: { id: o.id } })).status).toBe("preparing");
  });
});

describe("módulo do agente de delivery", () => {
  const ctx = (agent: { id: string; role: string }) => ({
    agentSession: { ...agent, intakeFields: [] },
    contactId,
    conversationId: "conv-teste",
    channel: "whatsapp_qr" as const,
    externalId: "5511999999999",
  });

  it("com cardápio: ganha send_menu, quote_order e place_order + contexto com preços", async () => {
    const m = await prepareRoleModule(ctx({ id: agentId, role: "delivery" }));
    expect(m?.tools.map((t) => t.name)).toEqual(["send_menu", "quote_order", "place_order"]);
    expect(m?.contextBlock).toMatch(/X-Burguer — R\$\s25,00/);
    expect(m?.contextBlock).toMatch(/Centro: R\$\s5,00/);
    expect(m?.handles("place_order")).toBe(true);
    expect(m?.handles("check_availability")).toBe(false);
  });

  it("sem cardápio: sem tools e instrução de transferir pra equipe", async () => {
    const m = await prepareRoleModule(ctx({ id: otherAgentId, role: "delivery" }));
    expect(m?.tools).toEqual([]);
    expect(m?.contextBlock).toMatch(/request_handoff/);
  });

  it("quote_order pelo executor devolve o resumo com total", async () => {
    const m = await prepareRoleModule(ctx({ id: agentId, role: "delivery" }));
    const out = JSON.parse(
      await m!.execute({ id: "t1", name: "quote_order", input: { items: [{ name: "Coca", quantity: 3 }], fulfillment: "pickup" } }),
    );
    expect(out.ok).toBe(true);
    expect(String(out.total).replace(/\s/g, " ")).toBe("R$ 36,00");
  });
});
