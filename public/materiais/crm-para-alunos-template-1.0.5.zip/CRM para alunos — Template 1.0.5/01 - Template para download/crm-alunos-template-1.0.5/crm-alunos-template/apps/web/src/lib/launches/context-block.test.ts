import { describe, it, expect } from "vitest";
import { renderOfferBlock } from "./context-block";
import type { ActiveLaunch } from "./active";

function fx(overrides: Partial<ActiveLaunch> = {}): ActiveLaunch {
  return {
    id: "l1",
    name: "Especial Aniversário 5 anos",
    slug: "aniversario-5",
    startsAt: new Date("2026-05-25T00:00:00Z"),
    endsAt: new Date("2026-05-31T23:59:59Z"),
    status: "live",
    courseId: "c1",
    pitchAngle: "comemoração dos 5 anos",
    bonuses: [
      { title: "Mentoria mensal", description: "1h por mês" },
    ],
    paymentMethodsOverride: "Pix 10% off ou 12x sem juros",
    guaranteePolicyOverride: "14 dias incondicional",
    createdAt: new Date(),
    updatedAt: new Date(),
    plans: [
      {
        id: "p1",
        launchId: "l1",
        name: "1 ano",
        priceCents: 49700,
        checkoutUrl: "https://hot.com/1ano",
        description: null,
        sortOrder: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        id: "p2",
        launchId: "l1",
        name: "2 anos",
        priceCents: 79700,
        checkoutUrl: "https://hot.com/2anos",
        description: null,
        sortOrder: 1,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ],
    course: {
      id: "c1",
      name: "Produto Exemplo",
      slug: "produto-exemplo",
      priceCents: 99700,
      active: true,
      checkoutUrl: "https://hot.com/produto-exemplo",
      guaranteePolicy: "7 dias",
      paymentMethods: "12x",
      description: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    ...overrides,
  } as ActiveLaunch;
}

const AT = new Date("2026-05-28T12:00:00Z");

describe("renderOfferBlock", () => {
  it("inclui nome do launch e janela com dias restantes", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("Especial Aniversário 5 anos");
    expect(md).toContain("Janela:");
    expect(md).toMatch(/3 dias restantes|4 dias restantes/);
  });

  it("inclui ÂNGULO quando pitchAngle preenchido", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("ÂNGULO:");
    expect(md).toContain("comemoração dos 5 anos");
  });

  it("omite ÂNGULO quando pitchAngle null", () => {
    const md = renderOfferBlock(fx({ pitchAngle: null }), AT);
    expect(md).not.toContain("ÂNGULO:");
  });

  it("lista PLANOS com preço formatado em R$ e marca [tem checkout] vs [sem checkout]", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("PLANOS:");
    expect(md).toContain("1 ano — R$ 497,00 — [tem checkout]");
    expect(md).toContain("2 anos — R$ 797,00 — [tem checkout]");
  });

  it("marca [sem checkout] para plano com checkoutUrl null", () => {
    const launch = fx();
    launch.plans[0]!.checkoutUrl = null;
    const md = renderOfferBlock(launch, AT);
    expect(md).toContain("[sem checkout]");
  });

  it("lista BÔNUS com title e description", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("BÔNUS INCLUÍDOS:");
    expect(md).toContain("Mentoria mensal");
    expect(md).toContain("1h por mês");
  });

  it("omite BÔNUS quando lista vazia", () => {
    const md = renderOfferBlock(fx({ bonuses: [] }), AT);
    expect(md).not.toContain("BÔNUS INCLUÍDOS:");
  });

  it("usa overrides quando preenchidos", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("Pix 10% off ou 12x sem juros");
    expect(md).toContain("14 dias incondicional");
  });

  it("herda do course quando override null", () => {
    const md = renderOfferBlock(
      fx({ paymentMethodsOverride: null, guaranteePolicyOverride: null }),
      AT,
    );
    expect(md).toContain("12x");
    expect(md).toContain("7 dias");
  });

  it("inclui regras de comportamento incluindo aviso pra perguntar plano (2+ planos, URLs diferentes)", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("REGRAS DE COMPORTAMENTO");
    expect(md).toMatch(/[Pp]ergunte qual plano/);
  });

  it("NÃO inclui aviso 'pergunte qual plano' quando há só 1 plano", () => {
    const launch = fx();
    launch.plans = [launch.plans[0]!];
    const md = renderOfferBlock(launch, AT);
    expect(md).not.toMatch(/[Pp]ergunte qual plano/);
  });

  it("inclui regra de handoff pra oferta encerrada e bônus fora da lista", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("oferta anterior/encerrada");
    expect(md).toContain("bônus não listado");
  });

  it("regra DEPOIS-da-escolha aparece quando há 2+ planos com URLs diferentes", () => {
    const md = renderOfferBlock(fx(), AT);
    expect(md).toContain("DEPOIS que o lead responder");
    expect(md).toContain("case o nome");
  });

  it("quando 2+ planos compartilham a MESMA URL → regra muda, sem ask-plan", () => {
    const launch = fx();
    launch.plans[0]!.checkoutUrl = "https://aniversario.example.com/";
    launch.plans[1]!.checkoutUrl = "https://aniversario.example.com/";
    const md = renderOfferBlock(launch, AT);
    expect(md).toContain("mesma URL de checkout");
    expect(md).toContain("a landing page decide");
    expect(md).not.toContain("Pergunte qual plano");
    expect(md).not.toContain("DEPOIS que o lead responder");
  });
});
