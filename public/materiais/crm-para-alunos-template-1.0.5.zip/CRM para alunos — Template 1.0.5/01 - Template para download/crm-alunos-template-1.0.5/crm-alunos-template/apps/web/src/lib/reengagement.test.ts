import { describe, it, expect } from "vitest";
import {
  isReengagementDue,
  isLostByNoResponse,
  REENGAGE_AFTER_MS,
  LOST_AFTER_MS,
  type ReengagementCandidate,
  type LostCandidate,
} from "./reengagement";

const now = new Date("2026-05-22T12:00:00Z");
const hoursAgo = (h: number) => new Date(now.getTime() - h * 3_600_000);

function base(): ReengagementCandidate {
  return {
    leadId: "l1",
    conversationId: "c1",
    leadStage: "contacted",
    lastActivityAt: hoursAgo(13),
    reengagementSentAt: null,
    windowClosesAt: new Date(now.getTime() + 6 * 3_600_000), // janela aberta
    aiEnabled: true,
    handoffRequested: false,
  };
}

describe("isReengagementDue", () => {
  it("true quando todos os predicados batem", () => {
    expect(isReengagementDue(base(), now)).toBe(true);
  });

  it("false quando lastActivityAt < 12h atrás", () => {
    expect(isReengagementDue({ ...base(), lastActivityAt: hoursAgo(11) }, now)).toBe(false);
  });

  it("false quando lastActivityAt é null", () => {
    expect(isReengagementDue({ ...base(), lastActivityAt: null }, now)).toBe(false);
  });

  it("false quando já foi reengajado", () => {
    expect(
      isReengagementDue({ ...base(), reengagementSentAt: hoursAgo(1) }, now),
    ).toBe(false);
  });

  it("false em stage 'new'", () => {
    expect(isReengagementDue({ ...base(), leadStage: "new" }, now)).toBe(false);
  });

  it("false em stage 'proposal'", () => {
    expect(isReengagementDue({ ...base(), leadStage: "proposal" }, now)).toBe(false);
  });

  it("false quando a janela está fechada", () => {
    expect(
      isReengagementDue({ ...base(), windowClosesAt: hoursAgo(1) }, now),
    ).toBe(false);
  });

  it("false quando aiEnabled é false", () => {
    expect(isReengagementDue({ ...base(), aiEnabled: false }, now)).toBe(false);
  });

  it("false quando handoffRequested é true", () => {
    expect(isReengagementDue({ ...base(), handoffRequested: true }, now)).toBe(false);
  });
});

describe("isLostByNoResponse", () => {
  it("true após 24h sem atividade e reengajamento já enviado", () => {
    expect(
      isLostByNoResponse(
        { ...base(), lastActivityAt: hoursAgo(25), reengagementSentAt: hoursAgo(12) },
        now,
      ),
    ).toBe(true);
  });

  it("false antes de 24h", () => {
    expect(
      isLostByNoResponse(
        { ...base(), lastActivityAt: hoursAgo(23), reengagementSentAt: hoursAgo(11) },
        now,
      ),
    ).toBe(false);
  });

  it("false quando o reengajamento nunca foi enviado", () => {
    expect(
      isLostByNoResponse(
        { ...base(), lastActivityAt: hoursAgo(25), reengagementSentAt: null },
        now,
      ),
    ).toBe(false);
  });

  it("false em stage não-elegível", () => {
    expect(
      isLostByNoResponse(
        {
          ...base(),
          leadStage: "won",
          lastActivityAt: hoursAgo(25),
          reengagementSentAt: hoursAgo(12),
        },
        now,
      ),
    ).toBe(false);
  });
});

describe("constants", () => {
  it("REENGAGE_AFTER_MS é 12h", () => {
    expect(REENGAGE_AFTER_MS).toBe(12 * 3_600_000);
  });
  it("LOST_AFTER_MS é 24h", () => {
    expect(LOST_AFTER_MS).toBe(24 * 3_600_000);
  });
});

// ── Task 6: reconciliação com cadência fora-da-janela ────────────────────────

const DAY = 24 * 60 * 60 * 1000;
const NOW = new Date("2026-06-16T12:00:00.000Z");
const OUT_WINDOW = {
  enabled: true,
  eligibleStages: ["qualified", "proposal"],
  intervalsDays: [1, 2, 4],
};

function baseOutWindow(over: Partial<LostCandidate> = {}): LostCandidate {
  return {
    leadStage: "qualified",
    lastActivityAt: new Date(NOW.getTime() - 2 * DAY), // > 24h parado
    reengagementSentAt: new Date(NOW.getTime() - 2 * DAY),
    audience: "prospect",
    lastFollowUpStep: null,
    ...over,
  };
}

describe("isLostByNoResponse — reconciliação com cadência fora-da-janela", () => {
  it("lead sob cadência ativa (qualified+prospect+step<max) → NÃO marca lost", () => {
    expect(isLostByNoResponse(baseOutWindow({ lastFollowUpStep: 1 }), NOW, OUT_WINDOW)).toBe(false);
  });

  it("cadência esgotada (step === max) → volta a permitir lost", () => {
    expect(isLostByNoResponse(baseOutWindow({ lastFollowUpStep: 3 }), NOW, OUT_WINDOW)).toBe(true);
  });

  it("não-prospect qualified → comportamento antigo (marca lost)", () => {
    expect(isLostByNoResponse(baseOutWindow({ audience: "student" }), NOW, OUT_WINDOW)).toBe(true);
  });

  it("feature desligada → comportamento antigo (marca lost)", () => {
    const off = { ...OUT_WINDOW, enabled: false };
    expect(isLostByNoResponse(baseOutWindow({ lastFollowUpStep: 1 }), NOW, off)).toBe(true);
  });

  it("sem config de out-window → comportamento antigo", () => {
    expect(isLostByNoResponse(baseOutWindow(), NOW)).toBe(true);
  });

  it("stage não-elegível ao lost (new) → false como antes", () => {
    expect(isLostByNoResponse(baseOutWindow({ leadStage: "new" }), NOW)).toBe(false);
  });

  it("parado < 24h → false", () => {
    const c = baseOutWindow({ lastActivityAt: new Date(NOW.getTime() - 0.5 * DAY) });
    expect(isLostByNoResponse(c, NOW)).toBe(false);
  });
});
