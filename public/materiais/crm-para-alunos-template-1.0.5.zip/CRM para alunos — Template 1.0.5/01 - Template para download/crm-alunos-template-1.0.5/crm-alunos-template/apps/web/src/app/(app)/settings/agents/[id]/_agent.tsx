/**
 * Cabeçalho com abas da página do agente + helpers dos módulos por tipo.
 *
 * Abas: Configuração · [abas do tipo, ex.: Profissionais, Consultas] ·
 * Regras de IA · Conhecimento. As abas do tipo vêm de `roleTabs` (_roles.ts).
 */
import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { cn } from "@/lib/utils";
import { ArrowLeft } from "lucide-react";
import { roleTabs } from "../_roles";

export interface AgentSummary {
  id: string;
  name: string;
  role: string | null;
}

/** Carrega o agente e exige o tipo certo — 404 quando a aba não é desse tipo. */
export async function requireAgentOfRole(id: string, role: string): Promise<AgentSummary> {
  const agent = await prisma.agentSession
    .findUnique({ where: { id }, select: { id: true, name: true, role: true } })
    .catch(() => null);
  if (!agent || agent.role !== role) notFound();
  return agent;
}

export function AgentHeader({
  agent,
  active,
  description,
  children,
}: {
  agent: AgentSummary;
  /** slug da aba atual ("" = Configuração). */
  active: string;
  description?: React.ReactNode;
  children?: React.ReactNode;
}) {
  const tabs = [
    { slug: "", label: "Configuração" },
    ...roleTabs(agent.role),
    { slug: "rules", label: "Regras de IA" },
    { slug: "rag", label: "Conhecimento" },
  ];
  return (
    <header className="mb-6 space-y-4">
      <div>
        <Link
          href="/settings/agents"
          className="text-xs text-muted-foreground hover:text-foreground inline-flex items-center gap-1 mb-2"
        >
          <ArrowLeft className="size-3" /> Agentes
        </Link>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h1 className="text-2xl md:text-3xl font-semibold tracking-tight">{agent.name}</h1>
          {children}
        </div>
        {description && <p className="text-muted-foreground mt-1">{description}</p>}
      </div>
      <nav aria-label="Seções do agente" className="flex gap-1 overflow-x-auto border-b border-border">
        {tabs.map((t) => (
          <Link
            key={t.slug}
            href={t.slug ? `/settings/agents/${agent.id}/${t.slug}` : `/settings/agents/${agent.id}`}
            aria-current={t.slug === active ? "page" : undefined}
            className={cn(
              "whitespace-nowrap border-b-2 px-3 py-2 text-sm transition-colors",
              t.slug === active
                ? "border-primary font-medium text-foreground"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {t.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
