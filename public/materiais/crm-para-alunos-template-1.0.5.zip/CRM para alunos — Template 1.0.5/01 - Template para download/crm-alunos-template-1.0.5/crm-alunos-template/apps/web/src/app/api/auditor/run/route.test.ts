import { describe, it, expect, vi, beforeEach } from "vitest";

const enqueueMock = vi.fn().mockResolvedValue(undefined);

vi.mock("@/auth", () => ({
  auth: vi.fn(async () => ({ user: { id: "test-user" } })),
}));
vi.mock("@/lib/queue", () => ({
  enqueue: (...args: unknown[]) => enqueueMock(...args),
}));
vi.mock("@/lib/audit/budget", () => ({
  exceedsDailyBudget: vi.fn(async () => ({ exceeded: false, current: 0 })),
}));
vi.mock("@/lib/db", () => ({
  prisma: {
    auditReport: {
      findFirst: vi.fn(async () => null),
      create: vi.fn(async () => ({ id: "fake-report-id" })),
    },
  },
}));

import { POST } from "./route";

beforeEach(() => {
  enqueueMock.mockClear();
});

describe("POST /api/auditor/run", () => {
  it("enfileira audit.run com attempts: 1 (sem retry — runAudit não é idempotente)", async () => {
    const req = new Request("http://test/api/auditor/run", {
      method: "POST",
      body: JSON.stringify({}),
      headers: { "Content-Type": "application/json" },
    });
    const res = await POST(req);
    expect(res.status).toBe(202);

    expect(enqueueMock).toHaveBeenCalledTimes(1);
    const [queueName, jobName, data, opts] = enqueueMock.mock.calls[0];
    expect(queueName).toBe("audit");
    expect(jobName).toBe("audit.run");
    expect(data).toEqual({ reportId: "fake-report-id" });
    expect(opts).toMatchObject({
      jobId: "audit-manual-fake-report-id",
      removeOnComplete: true,
      removeOnFail: 50,
      attempts: 1,
    });
  });
});
