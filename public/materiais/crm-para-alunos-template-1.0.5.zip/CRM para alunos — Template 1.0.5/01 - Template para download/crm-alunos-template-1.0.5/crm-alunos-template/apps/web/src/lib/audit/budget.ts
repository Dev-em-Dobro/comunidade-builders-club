/**
 * Helpers de cap de custo do auditor.
 *
 * Funções puras primeiro — sem I/O. Funções Prisma por baixo.
 */
import { prisma } from "@/lib/db";

/**
 * Retorna true se `costUsd` iguala ou excede o cap por execução.
 *
 * Comparação `>=` (não `>`) é intencional: assim que a próxima conversa
 * estimada empata com o cap, já paramos (evita 1 LLM call extra que
 * empurraria por cima do orçamento). Contrasta com `exceedsDailyBudget`
 * abaixo, que usa `>` porque o estouro só vale quando passa estritamente.
 */
export function exceedsRunBudget(costUsd: number, maxPerRun: number): boolean {
  return costUsd >= maxPerRun;
}

/** Soma `costUsd` de todos os AuditReports com `runAt >= início do dia UTC`. */
export async function getDailyCostUsd(): Promise<number> {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);

  const agg = await prisma.auditReport.aggregate({
    _sum: { costUsd: true },
    where: { runAt: { gte: startOfDay } },
  });

  return Number(agg._sum.costUsd ?? 0);
}

/**
 * Verifica se adicionar `prospectiveAddUsd` ao custo diário já acumulado
 * excederia `maxDaily` estritamente (`>`, não `>=`).
 *
 * Justificativa do `>`: o cap diário é tolerância suave — empate com o
 * cap ainda passa, porque o usuário pode ter rodado o último audit do
 * dia e a estimativa ficar exata. Estritamente acima é estouro real.
 *
 * Retorna `exceeded: true` e o custo atual antes da adição.
 */
export async function exceedsDailyBudget(
  prospectiveAddUsd: number,
  maxDaily: number,
): Promise<{ exceeded: boolean; current: number }> {
  const current = await getDailyCostUsd();
  return {
    exceeded: current + prospectiveAddUsd > maxDaily,
    current,
  };
}
