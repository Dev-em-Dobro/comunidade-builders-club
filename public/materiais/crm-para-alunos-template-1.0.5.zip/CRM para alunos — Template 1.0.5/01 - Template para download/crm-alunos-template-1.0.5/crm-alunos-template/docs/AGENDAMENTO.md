# Agente de agendamento e agenda do CRM

O agente de agendamento recepciona o paciente pelo WhatsApp, faz a pré-consulta, pergunta com qual profissional ele quer ser atendido, mostra os horários livres e marca a consulta. A agenda é do próprio CRM: não precisa de Google nem de nenhuma conta externa.

Tudo fica dentro do agente. Em **Agentes → Novo agente**, escolha o tipo **Agendamento** e salve. A página do agente ganha as abas:

- **Configuração**: prompt, modelo e pré-consulta;
- **Profissionais**: quem esse agente agenda, com a semana padrão e as exceções de cada um;
- **Consultas**: calendário, listas e **Baixar CSV**;
- **Regras de IA** e **Conhecimento**, como em qualquer agente.

Cada agente tem os próprios profissionais e consultas. Duas unidades ou duas clínicas podem ter um agente cada, sem um enxergar a agenda do outro.

Ordem de configuração:

1. Criar o agente do tipo **Agendamento** (seção 3). Ao salvar, você cai na aba **Profissionais**.
2. Cadastrar os profissionais, com a semana padrão de cada um.
3. Marcar as **exceções** (folgas, feriados, dias extras) quando precisar.
4. Acompanhar tudo na aba **Consultas**. Para levar os dados para fora, use **Baixar CSV** ou, se quiser uma planilha atualizada sozinha, o Google Sheets ([INTEGRACOES_GOOGLE.md](INTEGRACOES_GOOGLE.md)).

## 1. Profissionais

Na aba **Profissionais** do agente, clique em **Novo profissional** e preencha:

- **Nome, especialidade e um texto curto sobre o profissional.** O agente usa esse texto para apresentá-lo ao paciente.
- **Duração da consulta.** Os horários são oferecidos nesse intervalo (ex.: 30 min → 08:00, 08:30, 09:00…).
- **Semana padrão.** Os intervalos de cada dia da semana, como `08:00-12:00, 14:00-18:00`. Deixe vazio nos dias em que o profissional não atende.

Desative o profissional para tirá-lo do agente sem perder o histórico.

## 2. Exceções: folgas, feriados e dias extras

Na edição do profissional, a seção **Exceções** tem um calendário:

1. Clique nos dias (pode escolher vários: uma semana de férias, vários feriados).
2. Escolha **não atende** ou **atende em horário diferente**. A segunda opção também serve para abrir um dia que normalmente é fechado, como um sábado extra.
3. Se quiser, escreva o motivo e clique em **Salvar exceção**.

No calendário, dias riscados em vermelho são folgas e dias sublinhados têm horário diferente. Num dia com exceção, vale a exceção e não a semana padrão. Para desfazer, remova a exceção na lista **Próximas exceções**.

Marcar uma folga **não cancela** consultas que já estavam marcadas nesse dia. Confira na aba **Consultas** e cancele o que precisar.

### Como os horários livres são calculados

Horário livre = semana padrão (ou a exceção do dia) − consultas já marcadas.

- O fuso é o `schedule.timezone` do `setup.config.json` (padrão `America/Sao_Paulo`).
- Só são oferecidos horários com pelo menos 60 minutos de antecedência e até 90 dias à frente.
- Duas reservas simultâneas para o mesmo profissional são processadas em fila, e o horário é conferido de novo na hora de marcar, então dois pacientes nunca ficam com o mesmo horário.

## 3. Criar o agente

Em **Agentes → Novo agente**:

1. **Tipo de agente: Agendamento — recepção e consultas.** O prompt troca para um modelo de recepcionista; substitua os campos entre colchetes pelos dados da clínica.
2. **Pré-consulta.** Liste os dados que o agente deve coletar antes de marcar. Os campos obrigatórios são exigidos pelo sistema: sem eles a consulta não é criada e o agente volta a perguntar.
3. Marque **Default** se esse agente vai atender todas as conversas novas.

A cada mensagem o sistema entrega ao agente:

- a data e a hora atuais, para ele entender "amanhã" e "sexta";
- a lista de profissionais com especialidade, duração e semana padrão;
- as consultas futuras do paciente;
- as regras do fluxo: oferecer só horários vindos da agenda, confirmar antes de marcar e só dizer que marcou depois da confirmação do sistema.

Remarcação e cancelamento pelo WhatsApp são passados para a equipe (`request_handoff`). Se o agente não tiver nenhum profissional ativo, ele faz a pré-consulta e transfere para a equipe.

## 4. Consultas

A aba **Consultas** do agente tem três visões:

- **Calendário**: o mês com um ponto nos dias que têm consulta. Clique num dia para ver as consultas dele.
- **Próximas** e **Anteriores**: as consultas em lista.

Nas três visões dá para filtrar por profissional e abrir as respostas da pré-consulta. O botão **Cancelar** libera o horário na hora.

### Baixar CSV

Escolha o período (**De** / **Até**) e clique em **Baixar CSV**. Se houver um profissional no filtro, o arquivo traz só as consultas dele. O arquivo abre direto no Excel e no Google Planilhas, com estas colunas: agendado em, data, hora, profissional, especialidade, paciente, telefone, status, pré-consulta e ID no CRM.

Respostas que começam com `=`, `+`, `-` ou `@` ganham um apóstrofo na frente, para não virarem fórmula na planilha de quem abre.

## Privacidade

Motivo da consulta e sintomas são dados pessoais sensíveis (LGPD). Antes de ativar:

- colete só o necessário para marcar a consulta;
- lembre que as mensagens passam pelo provedor de IA escolhido no agente;
- o CSV tem dados de pacientes: guarde e compartilhe com cuidado;
- informe isso na sua política de privacidade.

## Problemas comuns

| Sintoma | Causa provável |
| --- | --- |
| Agente diz que não há horário | Confira a semana padrão, a duração da consulta e as exceções do período. A agenda pode estar cheia. |
| Agente não oferece um profissional | O profissional está inativo ou foi cadastrado em outro agente. |
| Horário aparece num feriado | Falta a exceção desse dia no profissional (aba **Profissionais** → editar → **Exceções**). |

## Roteiro de teste

Faça o teste com um número de WhatsApp seu e um profissional de teste:

1. Mande "oi, quero marcar uma consulta". O agente deve recepcionar e começar a pré-consulta.
2. Responda a pré-consulta e escolha o profissional. Os horários oferecidos devem respeitar a semana padrão.
3. Marque uma folga num dos dias oferecidos e peça de novo: esse dia deve sumir.
4. Escolha um horário e confirme. O agente só pode dizer que marcou depois disso.
5. Confira a consulta na aba **Consultas → Calendário** e baixe o CSV.
6. Cancele pelo CRM e peça o mesmo horário de novo: ele deve voltar a aparecer.
7. Peça para remarcar. O agente deve transferir para a equipe.
