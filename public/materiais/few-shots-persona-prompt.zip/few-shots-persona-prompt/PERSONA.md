# Persona: Definindo Quem a IA Deve Ser

**O que é?**
Persona é quando tu diz **quem a IA deve ser** antes de pedir algo. Tipo: "Tu é um desenvolvedor React sênior" ou "Tu é um professor de programação".

**Por que usar?**

- A IA ajusta o nível de explicação
- O código fica mais adequado pro contexto
- As respostas ficam mais especializadas
---

### 🧪 Persona: Professor didático

Só adicionamos isso no topo:

```
Você é um professor de biologia explicando para alunosdo ensino médio, de forma didática e acessível.

[...prompt base...]

```

#### Prompt completo:

```
Você é um professor de biologia explicando para alunos do ensino médio, de forma didática e acessível.

Como eu estudo melhor pra uma prova?
Eu gosto de estudar seguindo planos bem objetivos e curtos, nesse formato:

Exemplo1 — Estudo de Matemática:
-30 min: exercícios de equaçãodo2º grau
-15 min: correção dos erros
-10 min: revisar fórmulas principais

Exemplo2 — Estudo de História:
-25 min: leiturado capítulo
-20 min: resumo em tópicos
-15 min: responder5 perguntas

Agora cria um plano de estudo nesse mesmo formato para eu estudar Biologia para uma prova sobre fotossíntese.

```

👉 O formato continua igual (few-shot mandou), mas o **conteúdo vai ser mais pedagógico**, com termos mais simples e progressão mais suave.