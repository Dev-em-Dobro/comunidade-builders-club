# Few-Shots

**O que é?**  
Few-shot é quando você dá **exemplos práticos** pra IA entender exatamente o padrão que tu quer. 

Em vez de descrever com palavras, tu mostra como deve ser.

**Por que usar?**

- A IA aprende 10x mais rápido com exemplos  
- Tu garante consistência no código  
- Funciona pra qualquer linguagem ou estilo  


Resumindo — serve pra ensinar a IA a resolver problemas do teu jeito.

---

### 🧪 TESTE 1 — Sem Few-Shot (genérico)

https://chatgpt.com/g/g-5VFOJosej-playground

👉 Cola isso no playground:

```txt
Como eu estudo melhor pra uma prova?
``` 

💥 Resultado esperado:

- resposta genérica

- “faça um cronograma”, “revise”, “durma bem”, etc.

- nada adaptado ao teu estilo

---

### 🧪 TESTE 2 — Com Few-Shot (tu impõe o formato)

Agora tu não descreve o que tu quer — tu mostra exemplos de planos do jeito que tu gosta.

👉 Cola isso:

```txt
Como eu estudo melhor pra uma prova?
Eu gosto de estudar seguindo planos bem objetivos e curtos, nesse formato:

Exemplo1 — Estudo de Matemática:
- 30 min: exercícios de equação do 2º grau
- 15 min: correção dos erros
- 10 min: revisar fórmulas principais

Exemplo2 — Estudo de História:
- 25 min: leitura do capítulo
- 20 min: resumo em tópicos
- 15 min: responder 5 perguntas

Agora cria um plano de estudo nesse mesmo formato para eu estudar Biologia para uma prova sobre fotossíntese.

```

### 🧠 O que acontece aqui

A IA agora:

- entende que tu quer blocos de tempo
- entende que tu quer formato em lista
- entende que tu quer ações concretas, não conselhos vagos
- entende que tu quer algo executável
---

Sem few-shot → conselhos

Com few-shot → plano operacional