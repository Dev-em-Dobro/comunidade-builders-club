# 3. Prompt Iterativo: Refinando Até Ficar Perfeito

## 🎯 Problema

Criar um plano de estudo para **Biologia (fotossíntese)** no formato dos exemplos.

Já temos:

- **Few-shot** → define o formato  
- **Persona** → define quem responde  

Agora vamos **iterar até ficar do jeito que a gente quer**.

---

### 🧪 ITERAÇÃO 1 — Primeira tentativa

#### 📥 Prompt

```txt
Tu é um professor de biologia explicando para alunos do ensino médio, de forma didática e acessível.

Como eu estudo melhor pra uma prova?
Eu gosto de estudar seguindo planos bem objetivos e curtos, nesse formato:

Exemplo1 — Estudo de Matemática:
- 30 min: exercícios de equação do 2º grau
- 15 min: correção dos erros
- 10 min: revisar fórmulas principais

Exemplo2 — Estudo de História:
- 25 min: leitura do capítulo
- 20 min: resumo em tópicos
- 15 min: responder 5 perguntas

Agora cria um plano de estudo nesse mesmo formato para eu estudar Biologia para uma prova sobre fotossíntese.
```

### 🧪 Iteração 2 

#### 📥 Prompt
```txt
Muito bom. Agora ajusta o plano para que:
- Tenha mais atividades ativas (explicar com as próprias palavras, desenhar, testar)
- Menos leitura passiva
- Inclua pelo menos um momento de revisão

Mantém exatamente o mesmo formato.
```

### 🧪 Iteração 3

#### 📥 Prompt

```txt
Perfeito. Agora ajusta o plano para:
- Cobrir especificamente: fases clara e escura, cloroplasto, clorofila, reagentes e produtos
- Incluir um mini-simulado no final
- Continuar no mesmo formato e com blocos curtos

```


