'use client';

interface ChatMessageProps {
  role: 'ai' | 'user';
  content: string;
  isLoading?: boolean;
  source?: { page: number };
}

export default function ChatMessage({
  role,
  content,
  isLoading = false,
  source,
}: ChatMessageProps) {
  const isAI = role === 'ai';

  return (
    <div className="flex items-start gap-4" data-role={role}>
      {/* Avatar */}
      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-800">
        {isAI ? (
          <span className="material-symbols-outlined text-xl text-slate-600 dark:text-slate-300">
            smart_toy
          </span>
        ) : (
          <span className="material-symbols-outlined text-xl text-slate-600 dark:text-slate-300">
            account_circle
          </span>
        )}
      </div>

      {/* Mensagem */}
      <div
        className={`flex flex-col gap-2 max-w-[80%] ${!isAI ? 'items-end' : ''}`}
      >
        {/* Label */}
        <span className="text-[13px] font-semibold text-slate-500 dark:text-slate-400">
          {isAI ? 'DocPilot AI' : 'Você'}
        </span>

        {/* Bolha de mensagem */}
        {isLoading ? (
          <div
            className={`rounded-2xl px-5 py-3.5 ${
              isAI
                ? 'rounded-tl-none border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
                : 'rounded-tr-none bg-primary'
            }`}
          >
            <div className="flex gap-1">
              <span className="inline-block h-2 w-2 rounded-full bg-slate-400 dark:bg-slate-600 animate-pulse"></span>
              <span className="inline-block h-2 w-2 rounded-full bg-slate-400 dark:bg-slate-600 animate-pulse"></span>
              <span className="inline-block h-2 w-2 rounded-full bg-slate-400 dark:bg-slate-600 animate-pulse"></span>
            </div>
          </div>
        ) : (
          <div
            className={`rounded-2xl px-5 py-3.5 text-base leading-relaxed shadow-sm ${
              isAI
                ? 'rounded-tl-none border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100'
                : 'rounded-tr-none bg-primary text-white'
            }`}
          >
            {content}
          </div>
        )}

        {/* Source */}
        {source && isAI && (
          <div className="flex items-center gap-2 text-[12px] text-slate-500 dark:text-slate-400 mt-1">
            <span className="material-symbols-outlined text-sm">description</span>
            <span>Fonte: Página {source.page}</span>
          </div>
        )}
      </div>
    </div>
  );
}
