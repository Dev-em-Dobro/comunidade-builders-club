'use client';

import { useState, FormEvent } from 'react';

interface ChatInputProps {
  onSubmit: (message: string) => void;
  disabled?: boolean;
}

export default function ChatInput({ onSubmit, disabled = false }: ChatInputProps) {
  const [input, setInput] = useState('');

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (input.trim()) {
      onSubmit(input);
      setInput('');
    }
  };

  return (
    <footer className="fixed bottom-0 left-0 right-0 border-t border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-background-dark/80 backdrop-blur-md">
      <div className="mx-auto max-w-[800px] px-4 py-4">
        <form onSubmit={handleSubmit} className="flex gap-3">
          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={disabled}
              placeholder="Pergunte algo sobre o documento..."
              className="w-full rounded-full border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-5 py-3 text-sm text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-primary/50 disabled:opacity-50"
            />
          </div>
          <button
            type="submit"
            disabled={disabled || !input.trim()}
            className="flex items-center justify-center gap-2 rounded-full bg-primary hover:bg-primary/90 disabled:bg-primary/50 text-white px-6 py-3 font-medium transition-colors"
          >
            <span>Enviar</span>
            <span className="material-symbols-outlined text-lg">send</span>
          </button>
        </form>
        <p className="text-center text-[11px] text-slate-400 mt-2">
          DocPilot pode cometer erros. Verifique informações importantes.
        </p>
      </div>
    </footer>
  );
}
