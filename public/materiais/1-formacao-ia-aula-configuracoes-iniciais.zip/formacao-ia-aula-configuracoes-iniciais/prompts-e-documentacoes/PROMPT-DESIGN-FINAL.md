Act like um designer de produto sênior (Product Designer / UI Designer) especializado em SaaS minimalistas, ferramentas de IA e interfaces focadas em usabilidade.
Você cria interfaces modernas, claras e funcionais, com forte hierarquia visual e foco total na experiência do usuário.

🎯 Objetivo do Design

Criar o layout visual de uma aplicação web chamada “DocPilot”, cuja função é permitir que o usuário converse com um único arquivo PDF por meio de um chat inteligente.

O foco deste design é apenas a estrutura visual, componentes e organização da tela, sem detalhes técnicos de implementação.

A interface deve ser:

Simples

Moderna

Limpa

Centrada no conteúdo

Inspirada em experiências como ChatGPT e WhatsApp Web, sem sidebar

Todos os textos da interface devem estar em português do Brasil.

🧱 Estrutura Geral da Interface

Aplicação de tela única

Conteúdo centralizado

Sem menu lateral

Sem login

Interface clara, com bastante espaço em branco

Tipografia moderna e legível

Estilo visual profissional e confiável (produto de IA)

🔁 Estados da Interface
🟢 Estado 1 — Tela Inicial

Criar uma tela de aterrissagem simples e direta, com os seguintes elementos:


Elementos centrais:

Título principal (H1):
DocPilot

Subtítulo / descrição curta:
Converse com seus documentos instantaneamente.

A interface principal é em um chat.

Com uma área pras mensagens trocadas entre o usuário e a IA.

Bem abaixo fica o input pro usuário digitar as perguntas


💬 Área Central — Mensagens do Chat

Área de rolagem vertical

Estilo de conversa (bolhas de chat)

Diferenciação visual clara entre:

Mensagens do usuário

Respostas da IA

Respostas da IA podem incluir:

Texto principal

Pequena indicação de fonte/citação (visual sutil, ex: rodapé da mensagem)

⌨️ Rodapé — Campo de Pergunta (fixo)

Input de texto fixo na parte inferior da tela

Placeholder:
Faça uma pergunta sobre este documento...

Botão de envio (ícone de seta ou “Enviar”)

Estilo limpo, confortável para digitação contínua

🎨 Diretrizes Visuais

Design clean e moderno

Uso equilibrado de cores neutras

Destaque apenas para ações principais

Bordas suaves, sombras leves

Interface responsiva (desktop-first)

✅ Resultado Esperado

Um layout de chat inteligente, extremamente simples de usar, onde:

O usuário entende o que fazer em segundos

O chat é o protagonista da experiência